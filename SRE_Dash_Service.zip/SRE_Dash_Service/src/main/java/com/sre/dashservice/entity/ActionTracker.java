package com.sre.dashservice.entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class ActionTracker implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long trackerId;
	private String actionPlan;
	private List<Remark> remark;
	private Date targetDate;
	private String currentStatus;
	private Tenet tenent;

}
