package com.sre.dashservice.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;


@Entity
public class Tenet implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long tenetId;
	private String description;
	
	@ManyToOne(targetEntity = Capability.class, fetch = FetchType.EAGER)
	@JoinColumn(name="capabilityId",referencedColumnName="capabilityId", insertable = true, updatable = true)
	private Capability capability;
	
	@OneToMany(mappedBy = "tenet")
	private List<Level> levels;
	
	private double maxMaturityIndexScore;

	public Long getTenetId() {
		return tenetId;
	}

	public void setTenetId(Long tenetId) {
		this.tenetId = tenetId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Capability getCapability() {
		return capability;
	}

	public void setCapability(Capability capability) {
		this.capability = capability;
	}

	public List<Level> getLevels() {
		return levels;
	}

	public void setLevels(List<Level> levels) {
		this.levels = levels;
	}

	public double getMaxMaturityIndexScore() {
		return maxMaturityIndexScore;
	}

	public void setMaxMaturityIndexScore(double maxMaturityIndexScore) {
		this.maxMaturityIndexScore = maxMaturityIndexScore;
	}
	
	
}
