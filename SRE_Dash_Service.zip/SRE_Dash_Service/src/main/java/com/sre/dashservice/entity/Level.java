package com.sre.dashservice.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Level implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long levelId;
	private String description;
	
	@ManyToOne(targetEntity = Tenet.class, fetch = FetchType.EAGER)
	@JoinColumn(name="tenetId",referencedColumnName="tenetId", insertable = true, updatable = true)
	private Tenet tenet;

	public Long getLevelId() {
		return levelId;
	}

	public void setLevelId(Long levelId) {
		this.levelId = levelId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Tenet getTenet() {
		return tenet;
	}

	public void setTenet(Tenet tenet) {
		this.tenet = tenet;
	}
	
	
}
