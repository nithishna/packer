package com.sre.dashservice.entity;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Capability implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long capabilityId;
	private String description;
	
	@OneToMany(mappedBy = "capability")
	private List<Tenet> tenets;

	public Long getCapabilityId() {
		return capabilityId;
	}

	public void setCapabilityId(Long capabilityId) {
		this.capabilityId = capabilityId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Tenet> getTenets() {
		return tenets;
	}

	public void setTenets(List<Tenet> tenets) {
		this.tenets = tenets;
	}

	
	
}
	