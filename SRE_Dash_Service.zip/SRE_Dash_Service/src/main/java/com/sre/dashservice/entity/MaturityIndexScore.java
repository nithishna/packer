package com.sre.dashservice.entity;

import java.util.List;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class MaturityIndexScore implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long scoreId;
	private double score;
	private String appraiserDescription;
	
	private String appraiserUserId;
	private boolean isApproved;
	private String reviewerUserId;
	private List<Comment> comments;
	
	@Embedded
	private Audit audit;

}
