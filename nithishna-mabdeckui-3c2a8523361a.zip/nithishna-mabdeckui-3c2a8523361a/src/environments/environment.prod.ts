﻿export const environment = {
    production: true,
    host: "http://fileserver:9011/"
};