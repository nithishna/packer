﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, ResponseContentType, Headers } from '@angular/http';
import { ISupplyPoint, IMeterTemplate } from "../../../../shared/interface";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class BulkMeterService {

    constructor(private http: Http) { }
    meterTemplateUrl = environment.host + 'bulk-meter-template';

    downloadFile(data: any) {
        var blob = new Blob([data], { type: 'text/csv' });
        var exportFilename = 'BulkMeter-MeterAllocationTemplate.csv';
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.setAttribute('download', exportFilename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    getBulkMeterTemplateForClientAndNetworkAndSupply(meterTemplate: IMeterTemplate) {
        this.getFile(this.meterTemplateUrl, meterTemplate).subscribe(data => {
            let parsedResponse = data.text();
            this.downloadFile(parsedResponse)
        }, error => console.log("Error downloading the file."),
            () => console.info("OK"));
    }

    getFile(url: string, meterTemplate: IMeterTemplate) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(url, meterTemplate, { headers: headers });
    }
}