﻿import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { Router, ActivatedRoute } from '@angular/router';
import { ClientSetupService } from "../../../onboarding/components/clientsetup/clientSetup.service";
import { MeterService } from "../meters/meters.service";
import { INetwork, IClient, ISupplyPoint, IMeterTemplate } from "../../../../shared/interface";
import { MeterTemplate } from "../../../../shared/class";
import { BulkMeterService } from "./bulkmeter.service";
@Component({
    selector: 'app-bulkmeter-import',
    templateUrl: './bulkmeter.component.html',
    styleUrls: ['./bulkmeter.component.scss'],
    providers: [BulkMeterService, ClientSetupService, MeterService]
})
export class BulkmeterComponent implements OnInit {
    load: Boolean = false;
    networks: INetwork[];
    clientData: IClient[];
    supplyType: ISupplyPoint[];
    selectedClientId: number;
    selectedNetworkId: number;
    selectedSupplyTypeId: number;
    expanded = false;
    submitted = false;
    meterTemplate: IMeterTemplate = new MeterTemplate();

    constructor(public _bulkMeterService: BulkMeterService, public _globalService: GlobalService, public router: Router, private _clientSetupService: ClientSetupService, private _meterService: MeterService) {
        this._globalService.dataBusChanged('isActived', { title: 'Bulkmeter - Meter Allocation' });
    }

    ngOnInit() {
        this.authenticationCheck();
        this.loadClientData();
    }

    loadClientData() {
        this._clientSetupService.getClients().then((value) => {
            this.clientData = value;
            if (this.clientData != undefined && this.clientData.length > 0) {
                this.selectedClientId = this.clientData[0].clientId;
                this.fetchNetworkData();
            }
        });
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.submitted = false;
            this.selectedClientId = undefined;
            this.selectedNetworkId = undefined;
            this.selectedSupplyTypeId = undefined;
        }
    }

    fetchNetworkData() {
        for (var i = 0; i < this.clientData.length; i++) {
            let client = this.clientData[i];
            if (this.selectedClientId == client.clientId) {
                this.networks = client.network;
                if (this.networks != undefined && this.networks.length > 0) {
                    this.selectedNetworkId = this.networks[0].networkId;
                    this.fetchSupplyData();
                }
            }
        }
    }

    fetchSupplyData() {
        this._meterService.getSupplyTypeByClientAndNetwork(this.selectedClientId, this.selectedNetworkId).then((value) => {
            this.supplyType = value;
            if (this.supplyType != undefined && this.supplyType.length > 0) {
                this.selectedSupplyTypeId = this.supplyType[0].supplyId;
            }
        });
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    downloadBulkMeterTemplate() {
        this.load = true;
        this.submitted = true;
        if (this.selectedClientId == undefined || this.selectedNetworkId == undefined || this.selectedSupplyTypeId == undefined)
            return;
        this.meterTemplate.clientId = this.selectedClientId;
        this.meterTemplate.networkId = this.selectedNetworkId;
        this.meterTemplate.supplyTypeId = this.selectedSupplyTypeId;
        this._bulkMeterService.getBulkMeterTemplateForClientAndNetworkAndSupply(this.meterTemplate);
        this.load = false;
    }
}
