﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, ResponseContentType, Headers } from '@angular/http';
import { environment } from "../../../../../environments/environment";

@Injectable()
export class PaymentService {

    constructor(private http: Http) { }
    paymentTemplateUrl = environment.host +'payment-template?network_id=';

    downloadFile(data: any) {
        var blob = new Blob([data], { type: 'text/csv' });
        var exportFilename = 'paymentTemplate.csv';
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.setAttribute('download', exportFilename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    getPaymentTemplateForNetwork(networkId: number, transactionTypeId: number, paymentMethodId: number) {
        let url = this.paymentTemplateUrl + networkId.toString() + '&transaction_type_id=' + transactionTypeId.toString() + '&payment_method_id=' + paymentMethodId.toString();
        this.getFile(url).subscribe(data => {
            let parsedResponse = data.text();
            this.downloadFile(parsedResponse)
        },error => console.log("Error downloading the file."),
        () => console.info("OK"));
    }

    getFile(url: string) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(url, { headers: headers });
    }
}
