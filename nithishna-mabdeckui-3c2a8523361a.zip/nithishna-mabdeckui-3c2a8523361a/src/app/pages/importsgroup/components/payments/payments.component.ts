﻿import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { ClientSetupService } from "../../../onboarding/components/clientsetup/clientSetup.service";
import { PaymentService } from "./payments.service";
import { INetwork, IClient } from "../../../../shared/interface";
import { Router, ActivatedRoute } from '@angular/router';
@Component({
    selector: 'app-payments-import',
    templateUrl: './payments.component.html',
    styleUrls: ['./payments.component.scss'],
    providers: [ClientSetupService, PaymentService]
})
export class PaymentsComponent implements OnInit {
    load: Boolean = false;
    constructor(public router: Router, public _globalService: GlobalService, private _clientSetupService: ClientSetupService, private _paymentService: PaymentService) {
        this._globalService.dataBusChanged('isActived', { title: 'Payments Import' });
    }

    networks: INetwork[];
    clientData: IClient[];
    selectedClientId: number;
    selectedNetworkId: number;
    selectedTransactionId: number;
    selectedPaymentId: number;
    expanded = false;
    submitted = false;

    ngOnInit() {
        this.authenticationCheck();
        this.loadClientData();
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    loadClientData() {
        this._clientSetupService.getClients().then((value) => {
            console.log("Value = " + value);
            this.clientData = value;
        });
    }

    fetchNetworkData() {
        for (var i = 0; i < this.clientData.length; i++) {
            let client = this.clientData[i];
            if (this.selectedClientId == client.clientId) {
                this.networks = client.network;
            }
        }
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.submitted = false;
            this.selectedClientId = undefined;
            this.selectedNetworkId = undefined;
            this.selectedPaymentId = undefined;
            this.selectedTransactionId = undefined;
        }
    }

    getPaymentTemplateForNetwork() {
        this.load = true;
        this.submitted = false;
        if (this.selectedClientId == undefined || this.selectedNetworkId == undefined || this.selectedPaymentId == undefined || this.selectedTransactionId == undefined)
            return;
        this._paymentService.getPaymentTemplateForNetwork(this.selectedNetworkId, this.selectedTransactionId, this.selectedPaymentId);
        this.load = false;
    }
}
