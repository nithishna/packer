﻿import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { TariffService } from "../../../onboarding/components/tariffandband/tariff.service";
import { IClient, INetwork, IBand } from "../../../../shared/interface";
import { ClientSetupService } from "../../../onboarding/components/clientsetup/clientSetup.service";
import { SupplyPointService } from "./supplypoints.service";
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import swal from 'sweetalert2';
@Component({
    selector: 'app-supplypoints-import',
    templateUrl: './supplypoints.component.html',
    styleUrls: ['./supplypoints.component.scss'],
    providers: [TariffService, ClientSetupService, SupplyPointService]
})
export class SupplyPointsComponent implements OnInit {
    load: Boolean = false;
    networks: INetwork[];
    clientData: IClient[];
    bandData: IBand[];
    selectedClientId: number;
    selectedNetworkId: number;
    selectedBandId: number;
    selectedSupplyTypeId: number;
    expanded = false;
    submitted = false;
    uploadedFile: File; 
    constructor(public router: Router, public _globalService: GlobalService, private _supplyPointService: SupplyPointService, private _clientSetupService: ClientSetupService, private _tariffService: TariffService) {
        this._globalService.dataBusChanged('isActived', { title: 'Properties Import' });
    }

    ngOnInit() {
        this.authenticationCheck();
        this.loadClientData();
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }
    loadClientData() {
        this._clientSetupService.getClients().then((value) => {
            console.log("Value = " + value);
            this.clientData = value;
        });
    }

    fetchNetworkData() {
        for (var i = 0; i < this.clientData.length; i++) {
            let client = this.clientData[i];
            if (this.selectedClientId == client.clientId) {
                this.networks = client.network;
                if (this.networks != undefined && this.networks.length > 0) {
                    this.selectedNetworkId = this.networks[0].networkId;
                } else {
                    this.selectedNetworkId = undefined;
                    this.bandData = undefined;
                }
            }
        }
        this.fetchBandData();
    }

    fetchBandData() {

        if (this.selectedNetworkId != undefined) {
            this._tariffService.getBandsByClientAndNetwork(this.selectedClientId, this.selectedNetworkId).then((value) => {
                this.bandData = value;
            });
        }
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.submitted = false;
            this.selectedBandId = undefined;
            this.selectedClientId = undefined;
            this.selectedNetworkId = undefined;
            this.selectedSupplyTypeId = undefined;
        }
    }

    downloadSupplyPointTemplate() {
        this.load = true;
        this.submitted = true;
        if (this.selectedBandId == undefined || this.selectedClientId == undefined || this.selectedNetworkId == undefined || this.selectedSupplyTypeId == undefined)
            return;
        this._supplyPointService.getSupplyPointTemplateForNetwork(this.selectedClientId, this.selectedNetworkId, this.selectedBandId, this.selectedSupplyTypeId);
        this.load = false;
    }

    onFileChanged(event) {
        if (!this.validateFile(event.target.files[0].name)) {
            swal({
                type: 'error',
                title: 'Oops...',
                text: 'Selected file format is not supported. Kindly upload a csv file'
            }); 
            return;
        }
        this.uploadedFile = event.target.files[0];
    }
    validateFile(name: String) {
        var ext = name.substring(name.lastIndexOf('.') + 1);
        if (ext.toLowerCase() == 'csv') {
            return true;
        }
        else {
            return false;
        }
    }

    uploadCSVFile() {
        this.load = true;
        if (this.uploadedFile != undefined) {
            this._supplyPointService.uploadCSVFile(this.uploadedFile);
            this.uploadedFile = undefined;
            swal({ type: 'success', title: 'Supply points uploaded. Check the result.csv file for more details!', showConfirmButton: true });
            this.load = false
            /*.subscribe(
                (s) => { this.uploadedFile = undefined; alert("File Uploaded successfully!"); this.load = false; },
                (err) => {
                    this.uploadedFile = undefined;
                    this.load = false;
                    let details = err.json().message;
                    alert(details);
                }
            );*/
        } else {
            this.load = false;
            swal({
                type: 'error',
                title: 'Oops...',
                text: 'Please select a file and then upload!'
            }); 
        }
    }
}
