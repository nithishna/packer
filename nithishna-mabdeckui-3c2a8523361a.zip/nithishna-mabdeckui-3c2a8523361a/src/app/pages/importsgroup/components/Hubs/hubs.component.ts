﻿import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { INetwork, IClient, IHubTemplate } from "../../../../shared/interface";
import { HubService } from "./hubs.service";
import { Network, HubTemplate } from "../../../../shared/class";
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
@Component({
    selector: 'app-hubs-import',
    templateUrl: './hubs.component.html',
    styleUrls: ['./hubs.component.scss'],
    providers: [HubService]
})
export class HubsComponent implements OnInit {
    load: Boolean = false;
    networks: INetwork[];
    clientData: IClient[];
    selectedClientId: number;
    selectedNetwork: INetwork = new Network();
    hubTemplate: IHubTemplate = new HubTemplate();
    hubModel: string[] = [];
    expanded = false;
    submitted: boolean = false;
    uploadedFile: File;
    constructor(public _globalService: GlobalService, private _hubService: HubService, public router: Router) {
        this._globalService.dataBusChanged('isActived', { title: 'Hubs Import' });
    }

    ngOnInit() {
        this.authenticationCheck();
        this.loadClientData();
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }
    loadClientData() {
        this._hubService.getClientsWithHubManufacturer().then((value) => {
            this.clientData = value;
        });
    }

    fetchNetworkData() {
        for (var i = 0; i < this.clientData.length; i++) {
            let client = this.clientData[i];
            if (this.selectedClientId == client.clientId) {
                this.networks = client.network;
            }
        }
        this.hubModel = new Array(0);
    }

    fetchHubModelDetails() {
        if (this.selectedClientId != undefined && this.selectedNetwork.networkId != undefined) {
            this._hubService.getAllHubModelsForClientAndNetwork(this.selectedClientId, this.selectedNetwork.networkId).then((value) => {
                this.hubModel = value;
            });
            for (let i = 0; i < this.networks.length; i++){
                if (this.networks[i].networkId == this.selectedNetwork.networkId) {
                    this.selectedNetwork.hubManufacturer = this.networks[i].hubManufacturer;
                }
            }
        }
    }

    downloadTemplate() {
        this.load = true;
        this.submitted = true;
        if (this.selectedNetwork == undefined)
            return;
        if ((this.selectedNetwork.networkId == undefined) || this.selectedClientId == undefined || this.hubTemplate.hubModel == undefined)
            return;
        this.hubTemplate.networkId = this.selectedNetwork.networkId;
        this.hubTemplate.clientId = this.selectedClientId;
        this.hubTemplate.hubManufacturer = this.selectedNetwork.hubManufacturer;
        this._hubService.gethubTemplateForNetwork(this.hubTemplate);
        this.load = false;
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.hubTemplate = new HubTemplate();
            this.selectedClientId = undefined;
            this.selectedNetwork.networkId = undefined;
            this.submitted = false;
        }
    }
    onFileChanged(event) {
        if (!this.validateFile(event.target.files[0].name)) {
            alert("Selected file format is not supported. Kindly upload a csv file");
            return;
        }
        this.uploadedFile = event.target.files[0];
    }
    validateFile(name: String) {
        var ext = name.substring(name.lastIndexOf('.') + 1);
        if (ext.toLowerCase() == 'csv') {
            return true;
        }
        else {
            return false;
        }
    }

    uploadCSVFile() {
        this.load = true;
        if (this.uploadedFile != undefined) {
            this._hubService.uploadCSVFile(this.uploadedFile).subscribe(
                (s) => { this.uploadedFile = undefined; alert("File Uploaded successfully!"); this.load = false;},
                (err) => {
                    this.uploadedFile = undefined;
                    let details = err.json().message;
                    this.load = false;
                    alert(details);
                }
            );
        } else {
            this.load = false;
            alert("Please select a file and then upload!");
        }

    }
}
