﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, ResponseContentType, Headers } from '@angular/http';
import { IMeterTemplate, IClient, IHubTemplate } from "../../../../shared/interface";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class HubService {

    constructor(private http: Http) { }
    hubTemplateUrl = environment.host+'hub-template';
    hubClientUrl = environment.host +'clients-hub';
    hubModelUrl = environment.host + 'hub-models?client_id=';
    bulkUploadHubTemplateUrl = environment.host + 'upload-bulk-hub-template';
    getClientsWithHubManufacturer() {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.hubClientUrl, { headers: headers })
            .toPromise()
            .then((res) => res.json() as IClient[]);
    }

    downloadFile(data: any) {
        var blob = new Blob([data], { type: 'text/csv' });
        var exportFilename = 'hubTemplate.csv';
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.setAttribute('download', exportFilename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    gethubTemplateForNetwork(hubTemplate: IHubTemplate) {
        this.getFile(this.hubTemplateUrl, hubTemplate).subscribe(data => {
            let parsedResponse = data.text();
            this.downloadFile(parsedResponse)
        }, error => console.log("Error downloading the file."),
            () => console.info("OK"));
    }

    getFile(url: string, hubTemplate: IHubTemplate) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(url, hubTemplate, { headers: headers });
    }

    getAllHubModelsForClientAndNetwork(clientId: number, networkId: number) {
        let url = this.hubModelUrl + clientId + '&network_id=' + networkId;
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, { headers: headers })
            .toPromise()
            .then((res) => res.json() as string[]);
    }

    uploadCSVFile(file: File) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let input = new FormData();
        input.append('file', file);
        return this.http.post(this.bulkUploadHubTemplateUrl, input, { headers: headers });
    }
}

