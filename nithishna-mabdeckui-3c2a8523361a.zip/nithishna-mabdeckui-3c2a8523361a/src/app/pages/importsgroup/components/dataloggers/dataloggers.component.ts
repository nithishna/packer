﻿import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { Router, ActivatedRoute } from '@angular/router';
import { INetwork, IClient } from "../../../../shared/interface";
import { ClientSetupService } from "../../../onboarding/components/clientsetup/clientSetup.service";
import { MeterService } from "../meters/meters.service";
import { DataLoggerService } from "./dataloggers.service";
@Component({
    selector: 'app-datalogger-import',
    templateUrl: './dataloggers.component.html',
    styleUrls: ['./dataloggers.component.scss'],
    providers: [ClientSetupService, DataLoggerService]
})
export class DataloggersComponent implements OnInit {
    load: Boolean = false;
    networks: INetwork[];
    clientData: IClient[];
    selectedClientId: number;
    selectedNetworkId: number;
    expanded = false;
    submitted = false;
    uploadedFile: File; 
    constructor(public _dataLoggerService: DataLoggerService, public _globalService: GlobalService, public router: Router, private _clientSetupService: ClientSetupService) {
        this._globalService.dataBusChanged('isActived', { title: 'Dataloggers - Meter Allocation' });
    }

    ngOnInit() {
        this.authenticationCheck();
        this.loadClientData();
    }

    loadClientData() {
        this._clientSetupService.getClients().then((value) => {
            this.clientData = value;
            if (this.clientData != undefined && this.clientData.length > 0) {
                this.selectedClientId = this.clientData[0].clientId;
                this.fetchNetworkData();
            }
        });
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.submitted = false;
            this.selectedClientId = undefined;
            this.selectedNetworkId = undefined;
        }
    }

    fetchNetworkData() {
        for (var i = 0; i < this.clientData.length; i++) {
            let client = this.clientData[i];
            if (this.selectedClientId == client.clientId) {
                this.networks = client.network;
                if (this.networks != undefined && this.networks.length > 0) {
                    this.selectedNetworkId = this.networks[0].networkId;
                }
            }
        }
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    downloadDataLoggerTemplate() {
        this.load = true;
        this.submitted = true;
        if (this.selectedClientId == undefined || this.selectedNetworkId == undefined)
            return;
        this._dataLoggerService.getDataLoggerTemplate(this.selectedClientId, this.selectedNetworkId);
        this.load = false;
    }

    onFileChanged(event) {
        if (!this.validateFile(event.target.files[0].name)) {
            alert("Selected file format is not supported. Kindly upload a csv file");
            return;
        }
        this.uploadedFile = event.target.files[0];
    }
    validateFile(name: String) {
        var ext = name.substring(name.lastIndexOf('.') + 1);
        if (ext.toLowerCase() == 'csv') {
            return true;
        }
        else {
            return false;
        }
    }

    uploadCSVFile() {
        this.load = true;
        if (this.uploadedFile != undefined) {
            this._dataLoggerService.uploadCSVFile(this.uploadedFile).subscribe(
                (s) => { this.uploadedFile = undefined; alert("File Uploaded successfully!"); this.load = false;},
                (err) => {
                    this.load = false;
                    this.uploadedFile = undefined;
                    let details = err.json().message;
                    alert(details);
                }
            );
        } else {
            this.load = false;
            alert("Please select a file and then upload!");
        }
    }

}
