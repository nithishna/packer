﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalService } from "../../../../shared/services/global.service";
@Component({
    selector: 'app-imports',
    templateUrl: './imports.component.html',
    styleUrls: ['./imports.component.scss']
})
export class ImportsComponent implements OnInit {

    constructor(public router: Router, public _globalService: GlobalService) { }
    block = 0;
    ngOnInit() {
        this.authenticationCheck();
    }

    mouseEnter(num: number) {
        this.block = num;
    }

    mouseLeave() {
        this.block = 0;
    }
    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }
}
