﻿import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { Router, ActivatedRoute } from '@angular/router';
@Component({
    selector: 'app-propertyowners-import',
    templateUrl: './propertyowners.component.html',
    styleUrls: ['./propertyowners.component.scss']
})
export class PropertyOwnersComponent implements OnInit {

    constructor(public router: Router, public _globalService: GlobalService) {
        this._globalService.dataBusChanged('isActived', { title: 'Initial Property Owners Import' });
    }

    ngOnInit() {
        this.authenticationCheck();
        this.loadData();
    }

    loadData() {
    }
    
    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

}
