﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, ResponseContentType, Headers } from '@angular/http';
import { ISupplyPoint, IMeterTemplate } from "../../../../shared/interface";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class AccountService {

    constructor(private http: Http) { }
    dataLoggerTemplateUrl = environment.host + 'account-template?client_id=';
    uploadBulkAccountUrl = environment.host + 'account-template';
    downloadFile(data: any, fileName: string) {
        var blob = new Blob([data], { type: 'text/csv' });
        var exportFilename = fileName;
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.setAttribute('download', exportFilename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    getAccountTemplate(clientId: number, networkId: number) {
        let url = this.dataLoggerTemplateUrl + clientId + "&network_id=" + networkId;
        this.getFile(url).subscribe(data => {
            let parsedResponse = data.text();
            this.downloadFile(parsedResponse, 'AccountTemplate.csv');
        }, error => console.log("Error downloading the file."),
            () => console.info("OK"));
    }

    getFile(url: string) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(url, { headers: headers });
    }

    uploadCSVFile(file: File) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let input = new FormData();
        input.append('file', file);
        return this.http.post(this.uploadBulkAccountUrl, input, { headers: headers }).subscribe(
            data => {
                let parsedRes = data.text();
                this.downloadFile(parsedRes, 'result.csv');
            },
            error => console.log("Error downloading the file."),
            () => console.info("OK")
        );  
    }
}