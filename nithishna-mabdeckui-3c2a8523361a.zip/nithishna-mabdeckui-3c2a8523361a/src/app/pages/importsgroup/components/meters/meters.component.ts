﻿import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { IClient, INetwork, ISupplyPoint, IMeterTemplate } from "../../../../shared/interface";
import { ClientSetupService } from "../../../onboarding/components/clientsetup/clientSetup.service";
import { MeterService } from "./meters.service";
import { MeterTemplate } from "../../../../shared/class";
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import swal from 'sweetalert2';
@Component({
    selector: 'app-meters-import',
    templateUrl: './meters.component.html',
    styleUrls: ['./meters.component.scss'],
    providers: [ClientSetupService, MeterService]
})
export class MetersComponent implements OnInit {
    load: Boolean = false;
    networks: INetwork[];
    clientData: IClient[];
    supplyType: ISupplyPoint[];
    selectedClientId: number;
    selectedNetworkId: number;
    selectedSupplyTypeId: number;
    expanded = false;
    submitted = false;
    meterTemplate: IMeterTemplate = new MeterTemplate();
    uploadedFile: File; 
    constructor(public router: Router, public _globalService: GlobalService, private _clientSetupService: ClientSetupService, private _meterService: MeterService) {
        this._globalService.dataBusChanged('isActived', { title: 'Properties Import' });
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    ngOnInit() {
        this.authenticationCheck();
        this.loadClientData();
    }

    loadClientData() {
        this._clientSetupService.getClients().then((value) => {
            console.log("Value = " + value);
            this.clientData = value;
        });
    }

    fetchNetworkData() {
        for (var i = 0; i < this.clientData.length; i++) {
            let client = this.clientData[i];
            if (this.selectedClientId == client.clientId) {
                this.networks = client.network;
            }
        }
    }

    fetchSupplyData() {
        this._meterService.getSupplyTypeByClientAndNetwork(this.selectedClientId, this.selectedNetworkId).then((value) => {
            this.supplyType = value;
        });
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.submitted = false;
            this.selectedClientId = undefined;
            this.selectedNetworkId = undefined;
            this.selectedSupplyTypeId = undefined;
            this.meterTemplate = new MeterTemplate();
        }
    }
    downloadSupplyPointTemplate() {
        this.load = true;
        this.submitted = true;
        if (this.selectedClientId == undefined || this.selectedNetworkId == undefined || this.selectedSupplyTypeId == undefined)
            return;
        if (this.meterTemplate.meterUseId == undefined || this.meterTemplate.readingFrequencyId == undefined || this.meterTemplate.unitId == undefined) {
            return;
        }
        this.meterTemplate.clientId = this.selectedClientId;
        this.meterTemplate.networkId = this.selectedNetworkId;
        this.meterTemplate.supplyTypeId = this.selectedSupplyTypeId;
        this._meterService.getMeterTemplateForNetwork(this.meterTemplate);
        this.load = false;
    }

    onFileChanged(event) {
        if (!this.validateFile(event.target.files[0].name)) {           
            swal({
                type: 'error',
                title: 'Oops...',
                text: 'Selected file format is not supported. Kindly upload a csv file'
            }); 
            return;
        }
        this.uploadedFile = event.target.files[0];
    }
    validateFile(name: String) {
        var ext = name.substring(name.lastIndexOf('.') + 1);
        if (ext.toLowerCase() == 'csv') {
            return true;
        }
        else {
            return false;
        }
    }

    uploadCSVFile() {
        this.load = true;
        if (this.uploadedFile != undefined) {
            this._meterService.uploadCSVFile(this.uploadedFile);
            this.uploadedFile = undefined;
            swal({ type: 'success', title: 'Meters uploaded. Check the result.csv file for more details!', showConfirmButton: true });
            this.load = false;
            /*.subscribe(
                (s) => { this.uploadedFile = undefined; alert("File Uploaded successfully!"); this.load = false;},
                (err) => {
                    this.uploadedFile = undefined;
                    let details = err.json().message;
                    this.load = false;
                    alert(details);
                }
            );*/
        } else {
            this.load = false;
            swal({
                type: 'error',
                title: 'Oops...',
                text: 'Please select a file and then upload!'
            }); 
        }
    }
}
