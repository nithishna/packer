﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, ResponseContentType, Headers } from '@angular/http';
import { ISupplyPoint, IMeterTemplate } from "../../../../shared/interface";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class MeterService {

    constructor(private http: Http) { }
    supplyTypeByClientAndNetworkUrl = environment.host + 'client/';
    meterTemplateUrl = environment.host + 'meter-template';
    bulkMeterTemplateUrl = environment.host + 'upload-bulk-meter-template';

    getSupplyTypeByClientAndNetwork(clientId: number, networkId: number) {
        let url = this.supplyTypeByClientAndNetworkUrl + clientId + '/network/' + networkId + '/supplypoint';
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, { headers: headers })
            .toPromise()
            .then((res) => res.json() as ISupplyPoint[]);
    }

    downloadFile(data: any, fileName: string) {
        var blob = new Blob([data], { type: 'text/csv' });
        var exportFilename = fileName;
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.setAttribute('download', exportFilename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    getMeterTemplateForNetwork(meterTemplate: IMeterTemplate) {
        this.getFile(this.meterTemplateUrl, meterTemplate).subscribe(data => {
            let parsedResponse = data.text();
            this.downloadFile(parsedResponse, 'meterTemplate.csv')
        }, error => console.log("Error downloading the file."),
            () => console.info("OK"));
    }

    getFile(url: string, meterTemplate: IMeterTemplate) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(url, meterTemplate, { headers: headers });
    }

    uploadCSVFile(file: File) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let input = new FormData();
        input.append('file', file);
        return this.http.post(this.bulkMeterTemplateUrl, input, { headers: headers }).subscribe(
            data => {
                let parsedRes = data.text();
                this.downloadFile(parsedRes, 'result.csv');
            },
            error => console.log("Error downloading the file."),
            () => console.info("OK")
        );      
    }
}