﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { routing } from './importsgroup.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';
/* components */
import { ImportsGroupComponent } from './importsgroup.component';
import { ImportsComponent } from './components/imports/imports.component';
import { MeterImportsComponent } from './components/meterimports/meterimports.component';
import { AccountsComponent } from './components/accounts/accounts.component';
import { BulkmeterComponent } from './components/bulkmeter/bulkmeter.component';
import { DataloggersComponent } from './components/dataloggers/dataloggers.component';
import { MetersComponent } from './components/meters/meters.component';
import { PaymentsComponent } from './components/payments/payments.component';
import { PropertiesComponent } from './components/properties/properties.component';
import { PropertyOwnersComponent } from './components/propertyowners/propertyowners.component';
import { SupplyPointsComponent } from './components/supplypoints/supplypoints.component';
import { HubsComponent } from './components/hubs/hubs.component';
import { LayoutModule } from "../../shared/layout.module";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        routing,
        NgxPaginationModule,
        LayoutModule
    ],
    declarations: [
        ImportsGroupComponent,
        ImportsComponent,
        MeterImportsComponent,
        AccountsComponent,
        BulkmeterComponent,
        DataloggersComponent,
        MetersComponent,
        PaymentsComponent,
        PropertiesComponent,
        PropertyOwnersComponent,
        SupplyPointsComponent,
        HubsComponent        
    ]
})
export class ImportsGroupModule { }
