﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-importsgroup',
    template: `<router-outlet></router-outlet>`
})
export class ImportsGroupComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
