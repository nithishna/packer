﻿import { Routes, RouterModule } from '@angular/router';
import { ImportsGroupComponent } from './importsgroup.component';
import { ImportsComponent } from './components/imports/imports.component';
import { MeterImportsComponent } from './components/meterimports/meterimports.component';
import { AccountsComponent } from './components/accounts/accounts.component';
import { BulkmeterComponent } from './components/bulkmeter/bulkmeter.component';
import { DataloggersComponent } from './components/dataloggers/dataloggers.component';
import { MetersComponent } from './components/meters/meters.component';
import { PaymentsComponent } from './components/payments/payments.component';
import { PropertiesComponent } from './components/properties/properties.component';
import { PropertyOwnersComponent } from './components/propertyowners/propertyowners.component';
import { SupplyPointsComponent } from './components/supplypoints/supplypoints.component';
import { HubsComponent } from './components/hubs/hubs.component';

const childRoutes: Routes = [
    {
        path: '',
        component: ImportsGroupComponent,
        children: [
            { path: '', redirectTo: 'imports', pathMatch: 'full' },
            { path: 'imports', component: ImportsComponent },
            { path: 'meterimports', component: MeterImportsComponent },
            { path: 'accounts', component: AccountsComponent },
            { path: 'bulkmeter', component: BulkmeterComponent },
            { path: 'dataloggers', component: DataloggersComponent },
            { path: 'meters', component: MetersComponent },
            { path: 'payments', component: PaymentsComponent },
            { path: 'properties', component: PropertiesComponent },
            { path: 'propertyowners', component: PropertyOwnersComponent },
            { path: 'supplypoints', component: SupplyPointsComponent },
            { path: 'hubs', component: HubsComponent }
        ]
    }
];

export const routing = RouterModule.forChild(childRoutes);