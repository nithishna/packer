﻿import { Injectable } from '@angular/core';

@Injectable()
export class CorrespondenceService {
    constructor() { }

    DATA = [
        {
            client: 'Lewisham Gateway',
            network: 'River Mill',
            account: 'SAVRMO10081',
            name: 'Yue Zhao',
            address: '152 River Mill One Station Road London SE13 5FS',
            type: 'Credit Control',
            date: '27 Novemeber 2018'
        },
        {
            client: 'Lewisham Gateway',
            network: 'River Mill',
            account: 'SAVRMO10081',
            name: 'Yue Zhao',
            address: '152 River Mill One Station Road London SE13 5FS',
            type: 'Credit Control',
            date: '27 Novemeber 2018'
        },
        {
            client: 'Lewisham Gateway',
            network: 'River Mill',
            account: 'SAVRMO10081',
            name: 'Yue Zhao',
            address: '152 River Mill One Station Road London SE13 5FS',
            type: 'Credit Control',
            date: '27 Novemeber 2018'
        },
        {
            client: 'Lewisham Gateway',
            network: 'River Mill',
            account: 'SAVRMO10081',
            name: 'Yue Zhao',
            address: '152 River Mill One Station Road London SE13 5FS',
            type: 'Credit Control',
            date: '27 Novemeber 2018'
        },
        {
            client: 'Lewisham Gateway',
            network: 'River Mill',
            account: 'SAVRMO10081',
            name: 'Yue Zhao',
            address: '152 River Mill One Station Road London SE13 5FS',
            type: 'Credit Control',
            date: '27 Novemeber 2018'
        },
        {
            client: 'Lewisham Gateway',
            network: 'River Mill',
            account: 'SAVRMO10081',
            name: 'Yue Zhao',
            address: '152 River Mill One Station Road London SE13 5FS',
            type: 'Credit Control',
            date: '27 Novemeber 2018'
        },
        {
            client: 'Lewisham Gateway',
            network: 'River Mill',
            account: 'SAVRMO10081',
            name: 'Yue Zhao',
            address: '152 River Mill One Station Road London SE13 5FS',
            type: 'Credit Control',
            date: '27 Novemeber 2018'
        },
        {
            client: 'Lewisham Gateway',
            network: 'River Mill',
            account: 'SAVRMO10081',
            name: 'Yue Zhao',
            address: '152 River Mill One Station Road London SE13 5FS',
            type: 'Credit Control',
            date: '27 Novemeber 2018'
        }
    ];

}
