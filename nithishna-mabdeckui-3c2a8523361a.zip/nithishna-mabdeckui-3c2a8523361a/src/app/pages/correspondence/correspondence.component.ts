﻿import { Component, OnInit } from '@angular/core';
import { CorrespondenceService } from './correspondence.service';
import { GlobalService } from "../../shared/services/global.service";
import { Router, ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-correspondence',
    templateUrl: './correspondence.component.html',
    styleUrls: ['./correspondence.component.scss'],
    providers: [CorrespondenceService]
})
export class CorrespondenceComponent implements OnInit {
    tableData: Array<any>;

    /* pagination Info */
    pageSize = 10;
    pageNumber = 1;
    load = false;

    value: number = 1;
    onChangeOfData() {
        this.load = true;
        setTimeout(() => {
            this.load = false;
        },1000);
    }

    constructor(private router: Router, private _tablesDataService: CorrespondenceService, public _globalService: GlobalService) { }

    ngOnInit() {
        this.authenticationCheck();
        this.loadData();
    }

    loadData() {
        this.tableData = this._tablesDataService.DATA;
    }

    pageChanged(pN: number): void {
        this.pageNumber = pN;
    }

    authenticationCheck() {
        this._globalService.authenticateUser().map(
            res => res.json(),
            error => {
                this.router.navigate(['/login']);
            }
        ).subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

}