﻿import { Routes, RouterModule } from '@angular/router';
import { CorrespondenceComponent } from './correspondence.component';

const childRoutes: Routes = [
    {
        path: '',
        component: CorrespondenceComponent
    }
];

export const routing = RouterModule.forChild(childRoutes);