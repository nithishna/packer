﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { routing } from './correspondence.routing';
import { SharedModule } from '../../shared/shared.module';
import { CorrespondenceComponent } from './correspondence.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { LayoutModule } from '../../shared/layout.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        routing,
        NgxPaginationModule,
        LayoutModule
    ],
    declarations: [
        CorrespondenceComponent
    ]
})
export class CorrespondenceModule { }
