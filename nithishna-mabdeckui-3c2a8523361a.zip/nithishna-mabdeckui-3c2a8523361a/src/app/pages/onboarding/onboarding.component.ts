﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-onboarding',
    template: `<router-outlet></router-outlet>`
})
export class OnboardingComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
