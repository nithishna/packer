﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Band } from "../../../../shared/class";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class AllTariffService {

    constructor(private http: Http) { }
    bandBaseUrl = environment.host +'band/';

    getBandById(bandId: string) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.bandBaseUrl + bandId, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as Band[]);
    } 
}