﻿import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IBand } from "../../../../shared/interface";
import { Band } from "../../../../shared/class";
import { AllTariffService } from "./alltariffs.service";
import { GlobalService } from "../../../../shared/services/global.service";
import { Router } from '@angular/router';
@Component({
    selector: 'app-alltariffs-setup',
    templateUrl: './alltariffs.component.html',
    styleUrls: ['./alltariffs.component.scss'],
    providers: [AllTariffService]
})
export class AllTariffsComponent implements OnInit {
    load: Boolean = false;
    ngOnInit() {
        this.authenticationCheck();
        this.loadBand();
    }
    tableData: IBand[];
    param: string;
    pageSize = 10;
    pageNumber = 1;

    constructor(public router: Router,private _globalService: GlobalService, private route: ActivatedRoute, private _tablesDataService: AllTariffService) {
        this.route.params.subscribe(
            params => {
                this.param = params['id'];
            }
        );
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    loadBand() {
        this.load = true;
        this._tablesDataService.getBandById(this.param).then((value) => {
            this.tableData = value;
            this.load = false;
        });        
    }


}