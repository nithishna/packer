﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, URLSearchParams, Headers } from '@angular/http';
import { ISupplyPoint, IMeter, IHub, IProperty } from "../../../../shared/interface";
import { SupplyPoint, Meter, Hub } from "../../../../shared/class";
import { Observable } from "rxjs";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class HardwareService {
    constructor(private http: Http) { }

    supplyPointUrl = environment.host +'supplypoint';
    meterUrl = environment.host +'meter';
    hubUrl = environment.host +'hub';
    baseUrl = environment.host;
    supplyPropertiesUrl = environment.host +'supply-properties';
    supplyBaseUrl = environment.host +'supply/';
    supplyPropertiesUrlV2 = environment.host + 'supply-properties-v2?index=';
    supplyCount = environment.host + 'supply-point/count';

    getSupplyCount() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.supplyCount, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as number);

    }

    getHubById(hubId: number) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let url = this.hubUrl + "/" + hubId;
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as Hub);
    }

    getMeterById(meterId: number) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let url = this.meterUrl + "/" + meterId;
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as Meter);
    }

    getSupplyPointById(supplyPointId: number) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let url = this.supplyPointUrl + "/" + supplyPointId;
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as SupplyPoint);
    }

    getSupplyProperties(index: number, size: number) {
        let url = this.supplyPropertiesUrlV2 + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IProperty[]);
    }

    getSupplyPoints() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.supplyPointUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as ISupplyPoint[]);
    }

    insertSupplyPoint(supplyPoint: ISupplyPoint): Observable<any>  {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.supplyPointUrl, supplyPoint, {
            headers: headers
        });
    }

    getParentMeterForSupplyPoint(supplyId: number) {
        let url = this.supplyBaseUrl + supplyId + '/meter';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IMeter[]);
    }

    updateSupplyPoint(supplyPoint: ISupplyPoint): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.supplyPointUrl, supplyPoint, {
            headers: headers
        });
    }

    getSupplyPointByClientAndNetworkAndProperty(clientId: number, networkId: number, propertyId: number) {
        let url = this.baseUrl + 'client/' + clientId + '/network/' + networkId + '/property/' + propertyId + '/supplypoint';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as ISupplyPoint[]);
    }

    insertMeter(meter: IMeter): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.meterUrl, meter, {
            headers: headers
        });
    }

    updateMeter(meter: IMeter): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.meterUrl, meter, {
            headers: headers
        });
    }

    getMeters() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.meterUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IMeter[]);

    }


    insertHub(hub: IHub): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.hubUrl, hub, {
            headers: headers
        });
    }

    updateHub(hub: IHub): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.hubUrl, hub, {
            headers: headers
        });
    }

    getHubs() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.hubUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IHub[]);
    }

}
