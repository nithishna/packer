﻿import { Component, OnInit } from '@angular/core';
import { HardwareService } from './hardware.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { GlobalService } from "../../../../shared/services/global.service";
import { ClientSetupService } from "../clientsetup/clientSetup.service";
import { IMyDpOptions } from "mydatepicker";
import { IClient, INetwork, IBand, IProperty, ISupplyPoint, IHub, IMeter, IAddress } from "../../../../shared/interface";
import { PropertiesService } from "../properties/properties.service";
import { SupplyPoint, Hub, Meter, Address } from "../../../../shared/class";
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';

@Component({
    selector: 'app-hardware-setup',
    templateUrl: './hardware.component.html',
    styleUrls: ['./hardware.component.scss'],
    providers: [HardwareService, ClientSetupService, PropertiesService]
})
export class HardwareComponent implements OnInit {
    load: Boolean = false;
    tableData: IProperty[];
    supplies: ISupplyPoint[];
    dispSupply = false;
    supplyData: ISupplyPoint = new SupplyPoint();
    meterData: IMeter = new Meter();
    selectedPropertyId: number;
    selectedClientId: number;
    selectedNetworkId: number;
    SelectedSupplyPoint: number;
    showProperty: boolean;
    ischildOrParent: string = "child";
    totalNumberOfItems = 0;

    parentMeters: IMeter[] = new Array(0);
    supplyPoint: ISupplyPoint[];
    showSupplyAndMeterDetails = false;
    networks: INetwork[];
    bands: IBand[];
    property: IProperty[];
    selectedIndex: number = undefined;
    public startDate: any = null;
    public endDate: any = null;

    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
    };
    clientData: IClient[];
    hubClientData: IClient[];
    hubNetworks: INetwork[];
    hubProperty: IProperty[];
    hubManufacturer: string;
    /* pagination Info */
    pageSize = 10;
    pageNumber = 1;
    hub: IHub = new Hub();
    expanded = false;
    meterExpanded = false;
    hubExpanded = false;
    supplyPointSelected: SupplyPoint;
    meterSelected: Meter[];
    editOverideDefault: boolean = false;

    supplyPointForm: FormGroup;
    meterForm: FormGroup;
    hubForm: FormGroup;
    submitted: boolean = false;

    editSupply: boolean = false;
    editMeter: boolean = false;
    editHub: boolean = false;

    constructor(public router: Router, private _tablesDataService: HardwareService, public _globalService: GlobalService, private _clientSetupService: ClientSetupService, private _propertiesService: PropertiesService, private formBuilder: FormBuilder) {
        this._globalService.dataBusChanged('isActived', { title: 'Hardware and Supplies' });
    }

    getSupplyCount() {
        this._tablesDataService.getSupplyCount().then(
            (data) => {
                this.totalNumberOfItems = data;
                console.log("count=" + data);
            },
            (error) => {
                console.error("Error" + error);
            }
        );
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    showMeter() {
        this.editMeter = false;
        this.editOverideDefault = false;
        this.submitted = false;
        this.expanded = false;
        this.meterExpanded = true;
        this.hubExpanded = false;
        this.startDate = null;
        this.endDate = null;
        this.selectedClientId = undefined;
        this.selectedNetworkId = undefined;
        this.selectedPropertyId = undefined;
        this.SelectedSupplyPoint = undefined;
        this.meterData = new Meter();
    }

    showHub() {
        this.editOverideDefault = false;
        this.submitted = false;
        this.expanded = false;
        this.meterExpanded = false;
        this.hubExpanded = true;
        this.endDate = null;
        this.startDate = null;
        this.loadHubClientData();
        this.selectedNetworkId = undefined;
        this.selectedPropertyId = undefined;
        this.editHub = false;
        this.hub = new Hub();
        this.selectedClientId = undefined;
    }

    showEditSupplyPoint(selectedSupplyPoint: SupplyPoint) {
        this.editOverideDefault = true;
        this.editSupply = true;
        this.getSupplyPointBySupplyId(selectedSupplyPoint.supplyId);
        this.expanded = true;
        this.submitted = false;
        this.endDate = null;
        this.startDate = null;
    }

    showEditHub(selectedHub: Hub) {
        this.editOverideDefault = true;
        this.editHub = true;
        this.hubExpanded = true;
        this.getHubById(selectedHub.hubId);
        this.submitted = false;
        this.endDate = null;
        this.startDate = null;
    }
    showEditMeter(SelectedMeter: Meter) {
        this.editOverideDefault = true;
        this.editMeter = true;
        this.endDate = null;
        this.startDate = null;
        this.getMeterByMeterId(SelectedMeter.meterId);
        this.meterExpanded = true;
    }
    showSupplyPoint() {
        this.editSupply = false;
        this.editOverideDefault = false;
        this.supplyData = new SupplyPoint();
        this.expanded = true;
        this.submitted = false;
        this.selectedClientId = undefined;
        this.selectedNetworkId = undefined;
        this.selectedPropertyId = undefined;
    }

    getMeterByMeterId(meterId: number) {
        this.load = true;
        this._tablesDataService.getMeterById(meterId).then((value) => {
            if (value != null && value != undefined) {                
                if (value.client != null && value.client != undefined) {
                    this.selectedClientId = value.client.clientId;
                }
                if (value.network != null && value.network != undefined) {
                    this.selectedNetworkId = value.network.networkId;
                }
                if (value.property != null && value.property != undefined) {
                    this.selectedPropertyId = value.property.propertyId;
                }
                if (value.supply != null && value.supply != undefined) {
                    this.SelectedSupplyPoint = value.supply.supplyId;
                }
                if (value.startDate != null && value.startDate != undefined) {
                    let newDate = new Date(value.startDate);
                    this.startDate = {
                        date: {
                            year: newDate.getFullYear(),
                            month: newDate.getMonth() + 1,
                            day: newDate.getDate()
                        }
                    };
                }
                if (value.endDate != null && value.endDate != undefined) {
                    let newDate = new Date(value.endDate);
                    this.endDate = {
                        date: {
                            year: newDate.getFullYear(),
                            month: newDate.getMonth() + 1,
                            day: newDate.getDate()
                        }
                    };
                }
                if (value.childMeter == true)
                    this.updateTheValidationRule('child');
                else
                    this.updateTheValidationRule('parent');
            }
            this.meterData = value;
            this.load = false;
        });
    }

    getHubById(hubId: number) {
        this.load = true;
        this._tablesDataService.getHubById(hubId).then((value) => {
            if (value != null && value != undefined) {
                if (value.client != null && value.client != undefined) {
                    this.selectedClientId = value.client.clientId;
                }
                if (value.network != null && value.network != undefined) {
                    this.selectedNetworkId = value.network.networkId;
                }
                if (value.property != null && value.property != undefined) {
                    this.selectedPropertyId = value.property.propertyId;
                }
                if (value.startDate != null && value.startDate != undefined) {
                    let newDate = new Date(value.startDate);
                    this.startDate = {
                        date: {
                            year: newDate.getFullYear(),
                            month: newDate.getMonth() + 1,
                            day: newDate.getDate()
                        }
                    };
                }
                if (value.endDate != null && value.endDate != undefined) {
                    let newDate = new Date(value.endDate);
                    this.endDate = {
                        date: {
                            year: newDate.getFullYear(),
                            month: newDate.getMonth() + 1,
                            day: newDate.getDate()
                        }
                    };
                }
            }
            this.hub = value;
            this.load = false;
        });
    }

    getSupplyPointBySupplyId(supplyPointId: number) {
        this.load = true;
        this._tablesDataService.getSupplyPointById(supplyPointId).then((value) => {
            if (value != null && value != undefined) {
                if (value.client != null && value.client != undefined) {
                    this.selectedClientId = value.client.clientId;
                }
                if (value.network != null && value.network != undefined) {
                    this.selectedNetworkId = value.network.networkId;
                }
                if (value.property != null && value.property != undefined) {
                    this.selectedPropertyId = value.property.propertyId;
                }
                if (value.startDate != null && value.startDate != undefined) {
                    let newDate = new Date(value.startDate);
                    this.startDate = {
                        date: {
                            year: newDate.getFullYear(),
                            month: newDate.getMonth() + 1,
                            day: newDate.getDate()
                        }
                    };
                }
                if (value.endDate != null && value.endDate != undefined) {
                    let newDate = new Date(value.endDate);
                    this.endDate = {
                        date: {
                            year: newDate.getFullYear(),
                            month: newDate.getMonth() + 1,
                            day: newDate.getDate()
                        }
                    };
                }
            }
            this.supplyData = value;
            this.load = false;
        });
    }

    ngOnInit() {
        this.authenticationCheck();
        this.getSupplyCount();
        this.loadPropertiesData();
        this.loadClientData();
        this.loadHubClientData();
        this.supplyPointForm = this.formBuilder.group({
            clientName: ['', Validators.required],
            networkName: ['', Validators.required],
            supplyType: ['', Validators.required],
            startDate: ['', Validators.required]
        });
        this.meterForm = this.formBuilder.group({
            client: ['', Validators.required],
            network: ['', Validators.required],
            property: ['', Validators.required],
            supplyPoint: ['', Validators.required],
            unit: ['', Validators.required],
            meterType: ['', Validators.required],
            serialNumber: ['', Validators.required],
            parentMeter: ['', Validators.required],
            pulseInputNumber: ['', Validators.required],
            readingFrequency: ['', Validators.required],
            startDate: ['', Validators.required]
        });
        this.hubForm = this.formBuilder.group({
            client: ['', Validators.required],
            network: ['', Validators.required],
            property: ['', Validators.required],
            hubModel: ['', Validators.required],
            serialNumber: ['', Validators.required],
            identifier: ['', Validators.required],
            startDate: ['', Validators.required]
        });
    }

    updateTheValidationRule(option: string) {
        this.load = true;
        this.ischildOrParent = option;
        if (option != 'child') {
            if (this.meterForm.get("parentMeter") != undefined) {
                this.meterForm.removeControl("parentMeter");
            }
            if (this.meterForm.get("pulseInputNumber") != undefined) {
                this.meterForm.removeControl("pulseInputNumber");
            }
        } else {
            if (this.meterForm.get("parentMeter") == undefined) {
                this.meterForm.setControl('parentMeter', new FormControl('parentMeter'));
                this.meterForm.get('parentMeter').setValidators(Validators.required);
                this.meterForm.get('parentMeter').updateValueAndValidity();
            }
            if (this.meterForm.get("pulseInputNumber") == undefined) {
                this.meterForm.setControl('pulseInputNumber', new FormControl('pulseInputNumber'));
                this.meterForm.get('pulseInputNumber').setValidators(Validators.required);
                this.meterForm.get('pulseInputNumber').updateValueAndValidity();
            }
        }
        this.meterForm.updateValueAndValidity();
        this.load = false;
    }

    get s() { return this.supplyPointForm.controls; }
    get m() { return this.meterForm.controls; }
    get h() { return this.hubForm.controls; }

    pageChanged(pN: number): void {
        this.pageNumber = pN;
        this.loadPropertiesData();
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.meterExpanded = false;
            this.hubExpanded = false;
            this.selectedClientId = undefined;
            this.selectedNetworkId = undefined;
            this.selectedPropertyId = undefined;
            this.SelectedSupplyPoint = undefined;
            this.editOverideDefault = false;
        }
    }

    loadClientData() {
        this._clientSetupService.getClients().then((value) => {
            console.log("Value = " + value);
            this.clientData = value;
        });
    }

    loadHubClientData() {
        this._clientSetupService.getHubClients().then((value) => {
            console.log("Value = " + value);
            this.hubClientData = value;
            this.selectedClientId = undefined;
        });
    }

    fetchHubNetworkData() {
        if (this.hubClientData != null) {
            for (var i = 0; i < this.hubClientData.length; i++) {
                let client = this.hubClientData[i];
                if (this.selectedClientId == client.clientId) {
                    this.hubNetworks = client.network;
                    if (this.editOverideDefault == false) {
                        if (this.hubNetworks != null && this.hubNetworks.length > 0) {
                            this.selectedNetworkId = this.hubNetworks[0].networkId;
                            this.fetchPropertyHubData();
                        } else {
                            this.property = new Array(0);
                        }
                    } else {
                        this.fetchPropertyHubData();
                    }
                }
            }
        }
    }

    fetchPropertyHubData() {
        if (this.networks != null) {
            for (var i = 0; i < this.networks.length; i++) {
                let network = this.networks[i];
                if (this.selectedNetworkId == network.networkId) {
                    this.property = network.property;
                    if (this.editOverideDefault == false) {
                        if (this.property != null && this.property.length > 0) {
                            this.selectedPropertyId = this.property[0].propertyId;
                        }
                    }
                }
            }
        }
    }

    loadSupplyDataByClientAndNetworkAndProperty() {
        if (this.selectedClientId != undefined && this.selectedNetworkId != undefined && this.selectedPropertyId != undefined) {
            this._tablesDataService.getSupplyPointByClientAndNetworkAndProperty(this.selectedClientId, this.selectedNetworkId, this.selectedPropertyId).then((value) => {
                this.supplyPoint = value;
                if (this.editOverideDefault == false) {
                    if (value != null && value.length > 0) {
                        this.SelectedSupplyPoint = value[0].supplyId;                        
                    }
                }
            });
        }
    }

    loadPropertiesData() {
        this.load = true;
        this._tablesDataService.getSupplyProperties(this.pageNumber, this.pageSize).then((value) => {
            for (let i = 0; i < value.length; i++) {
                let meterCount = 0;
                if (value[i].supply != null && value[i].supply != undefined && value[i].supply.length > 0) {
                    value[i].supply.forEach((item) => { if (item.meter != undefined) { meterCount = meterCount + item.meter.length } });
                }
                value[i].noOfMeters = meterCount;
                value[i].showProperty = 'Show';
            }
            this.tableData = value;
            this.load = false;
        });
    }

    fetchNetworkData() {
        if (this.clientData != null) {
            for (var i = 0; i < this.clientData.length; i++) {
                let client = this.clientData[i];
                if (this.selectedClientId == client.clientId) {
                    this.networks = client.network;
                    if (this.editOverideDefault == false) {
                        if (this.networks != null && this.networks.length > 0) {
                            this.selectedNetworkId = this.networks[0].networkId;
                            this.fetchPropertyData();
                        } else {
                            this.property = new Array(0);
                            this.supplyPoint = new Array(0);
                        }
                    } else {
                        this.fetchPropertyData();
                    }
                }
            }
        }
    }



    fetchPropertyData() {
        if (this.networks != null) {
            for (var i = 0; i < this.networks.length; i++) {
                let network = this.networks[i];
                if (this.selectedNetworkId == network.networkId) {
                    this.property = network.property;
                    if (this.editOverideDefault == false) {
                        if (this.property != null && this.property.length > 0) {
                            this.selectedPropertyId = this.property[0].propertyId;
                            this.loadSupplyDataByClientAndNetworkAndProperty();
                        } else {
                            this.supplyPoint = new Array(0);
                        }
                    } else {
                        this.loadSupplyDataByClientAndNetworkAndProperty();
                    }
                }
            }
        }
    }

    fetchHubPropertyData() {
        if (this.hubNetworks != null) {
            for (var i = 0; i < this.hubNetworks.length; i++) {
                let network = this.hubNetworks[i];
                if (this.selectedNetworkId == network.networkId) {
                    this.hubProperty = network.property;
                    this.hubManufacturer = network.hubManufacturer;
                }
            }
        }
    }

    insertSupplyPoint() {
        this.load = true;
        this.submitted = true;
        if (this.supplyPointForm.invalid) {
            this.load = false;
            return;
        }
        if (this.startDate != null) {
            if (this.startDate.date.month == 1) {
                this.supplyData.startDate = new Date(this.startDate.date.year - 1, this.startDate.date.month + 11, this.startDate.date.day);
            } else {
                this.supplyData.startDate = new Date(this.startDate.date.year, this.startDate.date.month - 1, this.startDate.date.day);
            }
        }
        if (this.endDate != null || this.endDate != undefined) {
            if (this.endDate.date.month == 1) {
                this.supplyData.endDate = new Date(this.endDate.date.year - 1, this.endDate.date.month + 11, this.endDate.date.day);
            } else {
                this.supplyData.endDate = new Date(this.endDate.date.year, this.endDate.date.month - 1, this.endDate.date.day);
            }
        } else {
            this.supplyData.endDate = null;
        }
        this.supplyData.client.clientId = this.selectedClientId;
        this.supplyData.network.networkId = this.selectedNetworkId;
        this.supplyData.property.propertyId = this.selectedPropertyId;
        this._tablesDataService.insertSupplyPoint(this.supplyData).subscribe(
            data => {
                this.loadPropertiesData();
                this.expanded = false;
                this.submitted = false;
                this.load = false;                
                swal({ type: 'success', title: 'Supply Point created successfully', showConfirmButton: true });
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
        //window.location.href = "/pages/onboarding/hardware";
    }

    updateHub() {
        this.load = true;
        this.submitted = true;
        if (this.hubForm.invalid) {
            this.load = false;
            return;
        }
        if (this.startDate != null) {
            if (this.startDate.date.month == 1) {
                this.hub.startDate = new Date(this.startDate.date.year - 1, this.startDate.date.month + 11, this.startDate.date.day);
            } else {
                this.hub.startDate = new Date(this.startDate.date.year, this.startDate.date.month - 1, this.startDate.date.day);
            }
        }
        if (this.endDate != null || this.endDate != undefined) {
            if (this.endDate.date.month == 1) {
                this.hub.endDate = new Date(this.endDate.date.year - 1, this.endDate.date.month + 11, this.endDate.date.day);
            } else {
                this.hub.endDate = new Date(this.endDate.date.year, this.endDate.date.month - 1, this.endDate.date.day);
            }
        } else {
            this.hub.endDate = null;
        }
        this.hub.client.clientId = this.selectedClientId;
        this.hub.network.networkId = this.selectedNetworkId;
        this.hub.property.propertyId = this.selectedPropertyId;
        this._tablesDataService.updateHub(this.hub).subscribe(
            data => {
                this.loadPropertiesData();
                this.hubExpanded = false;
                this.submitted = false;
                this.tableData[this.selectedIndex].showProperty = 'Show';
                this.showProperty = false;
                this.load = false;                
                swal({ type: 'success', title: 'Hub updated successfully', showConfirmButton: true });
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    updateSupplyPoint() {
        this.load = true;
        this.submitted = true;
        if (this.supplyPointForm.invalid) {
            this.load = false;
            return;
        }
        if (this.startDate != null) {
            if (this.startDate.date.month == 1) {
                this.supplyData.startDate = new Date(this.startDate.date.year - 1, this.startDate.date.month + 11, this.startDate.date.day);
            } else {
                this.supplyData.startDate = new Date(this.startDate.date.year, this.startDate.date.month - 1, this.startDate.date.day);
            }
        }
        if (this.endDate != null || this.endDate != undefined) {
            if (this.endDate.date.month == 1) {
                this.supplyData.endDate = new Date(this.endDate.date.year - 1, this.endDate.date.month + 11, this.endDate.date.day);
            } else {
                this.supplyData.endDate = new Date(this.endDate.date.year, this.endDate.date.month - 1, this.endDate.date.day);
            }
        } else {
            this.supplyData.endDate = null;
        }
        this.supplyData.client.clientId = this.selectedClientId;
        this.supplyData.network.networkId = this.selectedNetworkId;
        this.supplyData.property.propertyId = this.selectedPropertyId;
        this._tablesDataService.updateSupplyPoint(this.supplyData).subscribe(
            data => {
                this.loadPropertiesData();
                this.expanded = false;
                this.submitted = false;
                this.tableData[this.selectedIndex].showProperty = 'Show';
                this.showProperty = false;
                this.load = false;                
                swal({ type: 'success', title: 'Supply Point updated successfully', showConfirmButton: true });
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }
    doNothing() {
        console.log("Called");
    }//do not delete this

    fetchParentMeter() { 
        this.getParentMeterForSupplyId();
    }
    insertMeter() {
        this.load = true;
        if (this.meterData.childMeter == undefined) {
            this.ischildOrParent = "";
        }
        this.submitted = true;
        if (this.meterForm.invalid) {
            this.load = false;
            return;
        } else if (this.ischildOrParent == "") {
            this.load = false;
            return;
        }

        if (this.startDate != null) {
            if (this.startDate.date.month == 1) {
                this.meterData.startDate = new Date(this.startDate.date.year - 1, this.startDate.date.month + 11, this.startDate.date.day);
            } else {
                this.meterData.startDate = new Date(this.startDate.date.year, this.startDate.date.month - 1, this.startDate.date.day);
            }
        }
        if (this.endDate != null) {
            if (this.endDate.date.month == 1) {
                this.meterData.endDate = new Date(this.endDate.date.year - 1, this.endDate.date.month + 11, this.endDate.date.day);
            } else {
                this.meterData.endDate = new Date(this.endDate.date.year, this.endDate.date.month - 1, this.endDate.date.day);
            }
        }
        if (this.meterData.childMeter == false) {
            this.meterData.parentSerialNumber = undefined;
            this.meterData.pulseInputNumber = undefined;
        }
        this.meterData.client.clientId = this.selectedClientId;
        this.meterData.network.networkId = this.selectedNetworkId;
        this.meterData.property.propertyId = this.selectedPropertyId;
        this.meterData.supply.supplyId = this.SelectedSupplyPoint;
        this._tablesDataService.insertMeter(this.meterData).subscribe(
            data => {
                this.submitted = false;
                this.meterExpanded = false;
                this.loadPropertiesData();
                this.tableData[this.selectedIndex].showProperty = 'Show';
                this.showProperty = false;
                this.load = false;
                swal({ type: 'success', title: 'Meter created successfully', showConfirmButton: true });
            },
            Error => {
                this.submitted = false;
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
        //window.location.href = "/pages/onboarding/hardware";
    }

    updateMeter() {
        this.load = true;
        if (this.meterData.childMeter == undefined) {
            this.ischildOrParent = "";
        }
        this.submitted = true;
        if (this.meterForm.invalid) {
            this.load = false;
            return;
        } else if (this.ischildOrParent == "") {
            this.load = false;
            return;
        }

        if (this.startDate != null) {
            if (this.startDate.date.month == 1) {
                this.meterData.startDate = new Date(this.startDate.date.year - 1, this.startDate.date.month + 11, this.startDate.date.day);
            } else {
                this.meterData.startDate = new Date(this.startDate.date.year, this.startDate.date.month - 1, this.startDate.date.day);
            }
        }
        if (this.endDate != null) {
            if (this.endDate.date.month == 1) {
                this.meterData.endDate = new Date(this.endDate.date.year - 1, this.endDate.date.month + 11, this.endDate.date.day);
            } else {
                this.meterData.endDate = new Date(this.endDate.date.year, this.endDate.date.month - 1, this.endDate.date.day);
            }
        }
        if (this.meterData.childMeter == false) {
            this.meterData.parentSerialNumber = undefined;
            this.meterData.pulseInputNumber = undefined;
        }
        this.meterData.client.clientId = this.selectedClientId;
        this.meterData.network.networkId = this.selectedNetworkId;
        this.meterData.property.propertyId = this.selectedPropertyId;
        this.meterData.supply.supplyId = this.SelectedSupplyPoint;
        this._tablesDataService.updateMeter(this.meterData).subscribe(
            data => {
                this.submitted = false;
                this.meterExpanded = false;
                this.loadPropertiesData();
                this.tableData[this.selectedIndex].showProperty = 'Show';
                this.showProperty = false;
                this.load = false;
                swal({ type: 'success', title: 'Meter updated successfully', showConfirmButton: true });
            },
            Error => {
                this.load = false;
                this.submitted = false;
                this.meterExpanded = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    insertHubData() {
        this.submitted = true;
        this.load = true;
        if (this.hubForm.invalid) {
            this.load = false;
            return;
        }
        if (this.startDate != null) {
            if (this.startDate.date.month == 1) {
                this.hub.startDate = new Date(this.startDate.date.year - 1, this.startDate.date.month + 11, this.startDate.date.day);
            } else {
                this.hub.startDate = new Date(this.startDate.date.year, this.startDate.date.month - 1, this.startDate.date.day);
            }
        }

        if (this.endDate != null) {
            if (this.endDate.date.month == 1) {
                this.hub.endDate = new Date(this.endDate.date.year - 1, this.endDate.date.month + 11, this.endDate.date.day);
            } else {
                this.hub.endDate = new Date(this.endDate.date.year, this.endDate.date.month - 1, this.endDate.date.day);
            }
        }
        this.hub.client.clientId = this.selectedClientId;
        this.hub.network.networkId = this.selectedNetworkId;
        this.hub.property.propertyId = this.selectedPropertyId;
        this.hub.hubManufacturer = this.hubManufacturer;
        this._tablesDataService.insertHub(this.hub).subscribe(
            data => {
                this.submitted = false;
                this.hubExpanded = false;
                this.loadPropertiesData();      
                this.load = false;
                swal({ type: 'success', title: 'Hub created successfully', showConfirmButton: true });
            },
            Error => {
                this.submitted = false;
                this.hubExpanded = false;
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    showDetails(property: IProperty, index: number) {
        debugger;
        //let oldindex = index;
        //index = this.pageSize * (this.pageNumber - 1) + index;
        if (this.selectedIndex == index && this.tableData[index].showProperty == 'Hide') {
            this.tableData[index].showProperty = 'Show';
            this.showProperty = false;
        }
        else if (this.selectedIndex == index && this.tableData[index].showProperty == 'Show') {
            this.tableData[index].showProperty = 'Hide';
            this.showProperty = true;
        }
        else if (this.selectedIndex != index && this.tableData[index].showProperty == 'Show') {
            this.tableData.forEach((obj) => { obj.showProperty = 'Show' });
            this.showProperty = true;
            this.tableData[index].showProperty = 'Hide';
            this.selectedIndex = index;
        } else {
            this.selectedIndex = index;
            this.showProperty = true;
        }
        this.supplies = property.supply;
        if (this.supplies != null && this.supplies != undefined && this.supplies.length > 0) {
            this.supplyPointSelected = this.supplies[0];
            this.meterSelected = this.supplyPointSelected.meter;
            this.getParentMeterForSupplyId();
        }
        else {
            this.supplyPointSelected = undefined;
            this.meterSelected = undefined;
        }   
    }

    selectSuppliesAndMeter(supply: ISupplyPoint) {
        this.supplyPointSelected = supply;
        this.getParentMeterForSupplyId();
        this.meterSelected = supply.meter;
    }

    displaySupply() {
        if (this.dispSupply == true)
            this.dispSupply = false;
        else
            this.dispSupply = true;
    }

    getParentMeterForSupplyId() {
        if (this.supplyPointSelected != undefined && this.supplyPointSelected != null) {
            this._tablesDataService.getParentMeterForSupplyPoint(this.supplyPointSelected.supplyId)
                .then((value) => {
                    this.parentMeters = value;
                });
        } else {
            this.parentMeters = new Array(0);
        }
    }
}