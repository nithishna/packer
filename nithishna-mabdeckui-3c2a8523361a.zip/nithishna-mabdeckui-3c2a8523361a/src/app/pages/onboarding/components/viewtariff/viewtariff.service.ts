﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Band, Tariff } from "../../../../shared/class";
import { Observable } from "rxjs/Observable";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class ViewTariffService {

    constructor(private http: Http) { }
    tariffBaseUrl = environment.host +'tariff/';

    getTariffById(tariffId: string) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.tariffBaseUrl + tariffId, { headers: headers })
            .toPromise()
            .then((res) => res.json() as Tariff);
    }
}