﻿import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IBand, IUnitCharge, IStandingCharge, IPropertyAreaCharge, ITariff } from "../../../../shared/interface";
import { Band, UnitCharge, StandingCharge, PropertyAreaCharge, Tariff } from "../../../../shared/class";
import { ViewTariffService } from "./viewtariff.service";
import { TariffService } from "../tariffandband/tariff.service";
import { GlobalService } from "../../../../shared/services/global.service";
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';
@Component({
    selector: 'app-viewtariff-setup',
    templateUrl: './viewtariff.component.html',
    styleUrls: ['./viewtariff.component.scss'],
    providers: [ViewTariffService, TariffService]
})
export class ViewTariffComponent implements OnInit {
    load: Boolean = false;
    ngOnInit() {
        this.authenticationCheck();
        this.getTariffById();
        this.unitChargeForm = this.formBuilder.group({
            name: ['', Validators.required],
            pricePerUnit: ['', [Validators.required, Validators.pattern("^[0-9]+(.[0-9]{0,10})?$")]],
            unit: ['', Validators.required]
        });
        this.standingChargeForm = this.formBuilder.group({
            name: ['', Validators.required],
            dailyNetCharge: ['', [Validators.required, Validators.pattern("^[0-9]+(.[0-9]{0,10})?$")]]
        });
        this.propertyAreaChargeForm = this.formBuilder.group({
            name: ['', Validators.required],
            pricePerUnit: ['', [Validators.required, Validators.pattern("^[0-9]+(.[0-9]{0,10})?$")]]
        });
    }
    param: string;
    submitted: boolean = false;
    unitChargeExpand: boolean = false;
    standingChargeExpanded: boolean = false;
    propertyChargeExpanded: boolean = false;
    unitCharge: IUnitCharge = new UnitCharge();
    standingCharge: IStandingCharge = new StandingCharge();
    propertyAreaCharge: IPropertyAreaCharge = new PropertyAreaCharge();
    tariff: ITariff = new Tariff();
    tariffDropDown: ITariff = new Tariff();
    unitChargeForm: FormGroup;
    standingChargeForm: FormGroup;
    propertyAreaChargeForm: FormGroup;
    areaError: boolean = false;
    constructor(public router: Router, private _globalService: GlobalService, private route: ActivatedRoute, private viewTariffService: ViewTariffService, private _tablesDataService: TariffService, private formBuilder: FormBuilder) {
        this.route.params.subscribe(
            params => {
                this.param = params['id'];
            }
        );
    }

    get u() { return this.unitChargeForm.controls; }
    get s() { return this.standingChargeForm.controls; }
    get p() { return this.propertyAreaChargeForm.controls; }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.unitChargeExpand = false;
            this.standingChargeExpanded = false;
            this.propertyChargeExpanded = false;
        }
    }
    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }
    createUnitCharge() {
        this.load = true;
        this.submitted = true;
        if (this.unitChargeForm.invalid) {
            this.load = false;
            return;
        } 
        this._tablesDataService.insertUnitCharge(this.unitCharge).subscribe(
            data => {
                this.submitted = false;
                this.unitChargeExpand = false;
                this.getTariffById();
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Unit Charge created Successfully',
                    showConfirmButton: true
                });
            },
            Error => {
                this.load = false;
                this.submitted = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
        //window.location.href = "/pages/onboarding/viewtariff/" + this.tariff.tariffId;
    }

    createStandingCharge() {
        this.load = true;
        this.submitted = true;
        if (this.standingChargeForm.invalid) {
            this.load = false;
            return;
        } 
        this._tablesDataService.insertStandingCharge(this.standingCharge).subscribe(
            data => {
                this.submitted = false;
                this.standingChargeExpanded = false;
                this.getTariffById();
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Standing Charge created Successfully',
                    showConfirmButton: true
                });
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
        //window.location.href = "/pages/onboarding/viewtariff/" + this.tariff.tariffId;
    }

    createPropertyAreaCharge() {
        this.load = true;
        if (this.propertyAreaCharge.areaUnits == undefined) {
            this.areaError = true;
        } else {
            this.areaError = false;
        }
        this.submitted = true;
        if (this.propertyAreaChargeForm.invalid) {
            this.load = false;
            return;
        } else {
            if (this.areaError == true) {
                this.load = false;
                return;
            }
        }
        this.propertyChargeExpanded = false;
        this._tablesDataService.insertPropertyAreaCharge(this.propertyAreaCharge).subscribe(
            data => {
                this.submitted = false;
                this.propertyChargeExpanded = false;
                this.getTariffById();
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Property Area Charge created Successfully',
                    showConfirmButton: true
                });
            },
            Error => {
                this.submitted = false;
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });

            }
        );
        //window.location.href = "/pages/onboarding/viewtariff/" + this.tariff.tariffId;
    }

    getTariffById() {
        this.load = true;
        this.viewTariffService.getTariffById(this.param).then((value) => {
            this.tariff = value;
            if (this.tariff.propertyAreaCharge == undefined || this.tariff.propertyAreaCharge == null) {                
                this.tariff.propertyAreaCharge = new Array(0);
            }
            if (this.tariff.standingCharge == undefined || this.tariff.standingCharge == null) {
                this.tariff.standingCharge = new Array(0);
            }
            if (this.tariff.unitCharge == undefined || this.tariff.unitCharge == null) {
                this.tariff.unitCharge = new Array(0);
            }
            this.tariffDropDown.tariffId = this.tariff.tariffId;
            this.tariffDropDown.tariffName = this.tariff.tariffName;
            this.unitCharge.tariff = this.tariffDropDown;
            this.standingCharge.tariff = this.tariffDropDown;
            this.propertyAreaCharge.tariff = this.tariffDropDown;
            this.load = false;
        }); 
    }
}