﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { IBand, INetwork, ITariff, IAdminCharge, IUnitCharge, IStandingCharge, IPropertyAreaCharge } from "../../../../shared/interface";
import { Band } from "../../../../shared/class";
import { Observable } from "rxjs";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class TariffService {

    constructor(private http: Http) { }

    clientUrl = environment.host +'client/';
    bandBaseUrl = environment.host +'band';
    tariffUrl = environment.host + 'tariff';
    adminChargeUrl = environment.host +'adminCharge';
    unitChargeUrl = environment.host +'unitCharge';
    standingChargeUrl = environment.host +'standingCharge';
    propertyChargeUrl = environment.host +'propertyCharge';
    bandByClientAndNetworkURL = environment.host + 'client/';
    bandBaseV2Url = environment.host + 'band-v2?index=';
    bandCountUrl = environment.host + 'band/count';

    updateBand(band: Band): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.bandBaseUrl, band, {
            headers: headers
        });
    }

    deleteTariff(tariffId: number): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.tariffUrl + "/" + tariffId, "", {
            headers: headers
        });
    }

    updateTariffEndDate(tariff: ITariff): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.tariffUrl, tariff, {
            headers: headers
        });
    }

    getBandsByClientAndNetwork(clientId: number, networkId: number) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let url = this.bandByClientAndNetworkURL + clientId.toString() + '/network/' + networkId.toString() + '/band';
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IBand[]);
    }

    getBandsV2(index: number, size: number) {
        let url = this.bandBaseV2Url + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IBand[]);
    }

    getBandCount() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.bandCountUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as number);
    }

    getBands() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.bandBaseUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IBand[]);

    }

    insertBand(band: IBand): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.bandBaseUrl, band, {
            headers: headers
        });
    }

    insertTariff(tariff: ITariff): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.tariffUrl, tariff, {
            headers: headers
        });
    }

    insertAdminCharge(adminCharge: IAdminCharge): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.adminChargeUrl, adminCharge, {
            headers: headers
        });
    }

    insertUnitCharge(unitCharge: IUnitCharge): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.unitChargeUrl, unitCharge, {
            headers: headers
        });
    }

    insertStandingCharge(standingCharge: IStandingCharge): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.standingChargeUrl, standingCharge, {
            headers: headers
        });
    }

    insertPropertyAreaCharge(propertyCharge: IPropertyAreaCharge): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.propertyChargeUrl, propertyCharge, {
            headers: headers
        });
    }

    initializeBand() {
        return new Band();
    }

    getNetworkForClient(clientId: number) {
        let url = this.clientUrl + clientId + '/network';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as INetwork[]);
    }
}
