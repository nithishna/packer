﻿import { Component, OnInit } from '@angular/core';
import { TariffService } from './tariff.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GlobalService } from "../../../../shared/services/global.service";
import { ITariff, IBand, IClient, INetwork, IAdminCharge, IUnitCharge, IStandingCharge, IPropertyAreaCharge } from "../../../../shared/interface";
import { Band, Client, Network, Tariff, AdminCharge, UnitCharge, StandingCharge, PropertyAreaCharge } from "../../../../shared/class";
import { ClientSetupService } from "../clientsetup/clientSetup.service";
import { IMyDpOptions } from "mydatepicker";
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';
@Component({
    selector: 'app-tariff-setup',
    templateUrl: './tariff.component.html',
    styleUrls: ['./tariff.component.scss'],
    providers: [TariffService, ClientSetupService]
})
export class TariffComponent implements OnInit {
    totalNumberOfItems = 0;
    load: Boolean = false;
    selectedIndex: number; showTariff = false; unitChargeExpand = false;
    tableData: IBand[]; expanded = false; tariffExpand = false; standingChargeExpanded = false;
    propertyChargeExpanded = false; adminblock = false;
    networkList: Network[] = new Array(0);
    bandName: string; adminBandName: string;
    showDelete: boolean = false;
    showEndDate: boolean = false;
    bandForm: FormGroup;
    tariffForm: FormGroup;
    adminForm: FormGroup;
    unitChargeForm: FormGroup;
    standingChargeForm: FormGroup;
    propertyAreaChargeForm: FormGroup;
    showEditBand: boolean = false;
    /* pagination Info */
    pageSize = 10; pageNumber = 1;

    selectedTariff: ITariff;
    band: IBand = new Band();
    currentBand: IBand = new Band();
    admincharge: IAdminCharge = new AdminCharge();
    clientData: IClient[];
    selectedNode: IClient = new Client();
    currentDate: Date = new Date(Date.now());
    day = this.currentDate.getDate();
    activeFromDay = this.currentDate.getDate();
    activeToDay = this.currentDate.getDate();
    year = this.currentDate.getFullYear();
    activeFromYear = this.currentDate.getFullYear();
    activeToYear = this.currentDate.getFullYear();
    month = this.currentDate.getMonth() + 1;
    activeFromMonth = this.currentDate.getMonth() + 1;
    activeToMonth = this.currentDate.getMonth() + 1;
    tariff: ITariff = new Tariff();
    tariffs: ITariff[];
    unitCharge: IUnitCharge = new UnitCharge();
    standingCharge: IStandingCharge = new StandingCharge();
    propertyAreaCharge: IPropertyAreaCharge = new PropertyAreaCharge();
    submitted: boolean = false;
    placeholder: string = 'select a date';
    areaError: boolean = false;

    public model: any = null;
    public activeFromDate: any = null;
    public activeToDate: any = null;
    public endDate: any = null;

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    displayAddBand() {
        this.showEditBand = false;
        this.expanded = true;
        this.adminblock = false;
        this.band = new Band();
        this.currentBand = new Band();
    }

    displayEditBand(selectedBand: Band) {
        this.submitted = false;
        this.endDate = null;
        this.showEditBand = true;
        this.expanded = true;
        this.band = JSON.parse(JSON.stringify(selectedBand));
        this.currentBand = JSON.parse(JSON.stringify(selectedBand));
        if (this.band.startDate != undefined || this.band.startDate != null) {
            let newDate = new Date(this.band.startDate);
            this.model = {
                date: {
                    year: newDate.getFullYear(),
                    month: newDate.getMonth()+1,
                    day: newDate.getDate()
                }
            };
        }
        else {
            this.model = null;
        }
        if (this.band.endDate != undefined || this.band.endDate != null) {
            let newDate = new Date(this.band.endDate);
            this.endDate = {
                date: {
                    year: newDate.getFullYear(),
                    month: newDate.getMonth()+1,
                    day: newDate.getDate()
                }
            };        
        }
        else {
            this.endDate = null;
        }
        if (this.band.client != undefined || this.band.client != null) {
            this.fetchNetworkData();
        } else {
            this.band.client = new Client();
            this.band.network = new Network();
        }
    }

    constructor(public router: Router, private _tablesDataService: TariffService, private formBuilder: FormBuilder, public _globalService: GlobalService, private _clientSetupService: ClientSetupService) {
        this._globalService.dataBusChanged('isActived', { title: 'Tariffs and Property Bands' });
    }

    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy'
    };

    displayDeleteTariff(tariff: ITariff) {
        this.selectedTariff = JSON.parse(JSON.stringify(tariff));;
        this.showDelete = true;
    }

    displayEndDate(tariff: ITariff) {
        this.endDate = null;
        this.selectedTariff = JSON.parse(JSON.stringify(tariff));
        this.showEndDate = true;
    }

    ngOnInit() {
        this.authenticationCheck();
        this.getBandCount();
        this.loadBand();
        this.loadData();
        this.bandForm = this.formBuilder.group({
            bandName: ['', Validators.required],
            startDate: ['', Validators.required]
        });
        this.tariffForm = this.formBuilder.group({
            tariffType: ['', Validators.required],
            supplyType: ['', Validators.required],
            tariffName: ['', Validators.required],
            activeFromDate: ['', Validators.required]
        });
        this.adminForm = this.formBuilder.group({
            chargeTo: ['', Validators.required],
            descriptionOfCharge: ['', Validators.required],
            dailyNetCharge: ['', [Validators.required, Validators.pattern("^[0-9]+(.[0-9]{0,10})?$")]],
            activeFromDate: ['', Validators.required]
        });
        this.unitChargeForm = this.formBuilder.group({
            name: ['', Validators.required],
            pricePerUnit: ['', [Validators.required, Validators.pattern("^[0-9]+(.[0-9]{0,10})?$")]],
            unit: ['', Validators.required]
        });
        this.standingChargeForm = this.formBuilder.group({
            name: ['', Validators.required],
            dailyNetCharge: ['', [Validators.required, Validators.pattern("^[0-9]+(.[0-9]{0,10})?$")]]
        });
        this.propertyAreaChargeForm = this.formBuilder.group({
            name: ['', Validators.required],
            pricePerUnit: ['', [Validators.required, Validators.pattern("^[0-9]+(.[0-9]{0,10})?$")]]
        });
    }

    get t() { return this.bandForm.controls; }
    get tt() { return this.tariffForm.controls; }
    get a() { return this.adminForm.controls; }
    get u() { return this.unitChargeForm.controls; }
    get s() { return this.standingChargeForm.controls; }
    get p() { return this.propertyAreaChargeForm.controls; }

    loadData() {
        this.loadClientData();
    }

    getBandCount() {
        this._tablesDataService.getBandCount().then(
            (data) => {
                this.totalNumberOfItems = data;
                console.log("count=" + data);
            },
            (error) => {
                console.error("Error" + error);
            }
        );
    }

    pageChanged(pN: number): void {
        this.pageNumber = pN;
        //this.tableData[this.lastSelectedIndex].showTariff = 'Show';
        this.showTariff = false;
        this.loadBand();
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false; this.tariffExpand = false;
            this.adminblock = false; this.unitChargeExpand = false;
            this.standingChargeExpanded = false; this.propertyChargeExpanded = false;
            this.showDelete = false; this.showEndDate = false;
            this.endDate = null; this.showEditBand = true;
            this.band = new Band(); this.model = null;
            this.submitted = false;
        }
    }

    deleteTariff() {
        this.load = true;
        this._tablesDataService.deleteTariff(this.selectedTariff.tariffId).subscribe(
            data => {
                this.selectedTariff = undefined;
                this.showDelete = false;
                this.showTariff = false;
                this.loadBand();
                this.load = false;
                swal({ type: 'success', title: 'Tariff deleted successfully', showConfirmButton: true });
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });                
            }
        );
    }

    updateBand() {
        this.submitted = true;
        this.load = true;
        if (this.bandForm.invalid) {
            this.load = false;
            return;
        } 
        if (this.endDate != undefined || this.endDate != null) {
            if (this.endDate.date.month == 1) {
                this.band.endDate = new Date(this.endDate.date.year - 1, this.endDate.date.month + 11, this.endDate.date.day);
            } else {
                this.band.endDate = new Date(this.endDate.date.year, this.endDate.date.month - 1, this.endDate.date.day);
            }
        }
        if (this.model.date.month == 1) {
            this.band.startDate = new Date(this.model.date.year - 1, this.model.date.month + 11, this.model.date.day);
        } else {
            this.band.startDate = new Date(this.model.date.year, this.model.date.month - 1, this.model.date.day);
        }

        if (this.band.network.networkId == undefined) {
            this.band.network = undefined;
        }

        if (this.band.client.clientId == undefined) {
            this.band.client = undefined;
        }
        this._tablesDataService.updateBand(this.band).subscribe(
            data => {
                this.submitted = false;
                this.expanded = false;
                this.showTariff = false;
                this.showEditBand = false;
                this.loadBand();
                this.load = false;                
                swal({ type: 'success', title: 'Band Updated Successfully', showConfirmButton: true });
            },
            Error => {
                this.load = false;
                this.submitted = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
        //window.location.href = "/pages/onboarding/tariff";
    }


    updateEndDate() {
        this.load = true;
        if (this.endDate != undefined || this.endDate != null) {
            if (this.endDate.date.month == 1) {
                this.selectedTariff.activeToDate = new Date(this.endDate.date.year - 1, this.endDate.date.month + 11, this.endDate.date.day);
            } else {
                this.selectedTariff.activeToDate = new Date(this.endDate.date.year, this.endDate.date.month - 1, this.endDate.date.day);
            }
        }
        this._tablesDataService.updateTariffEndDate(this.selectedTariff).subscribe(
            data => {
                this.selectedTariff = undefined;
                this.loadBand();
                this.showEndDate = false;
                this.showTariff = false;
                this.load = false;                
                swal({ type: 'success', title: 'Tariff End Date updated successfully', showConfirmButton: true });
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
        
    }

    loadBand() {
        this.load = true;
        this._tablesDataService.getBandsV2(this.pageNumber, this.pageSize).then((value) => {
            value.forEach((obj) => { obj.showTariff = 'Show' });
            this.tableData = value;
            this.load = false;
        });        
        //console.log(this.tableData);
    }

    loadClientData() {
        this._clientSetupService.getClients().then((value) => {
            console.log("Value = " + value);
            this.clientData = value;
        });
    }

    createBand() {
        this.load = true;
        this.submitted = true;
        if (this.bandForm.invalid) {
            this.load = false;
            return;
        } 
        if (this.model.date.month == 1) {
            this.band.startDate = new Date(this.model.date.year - 1, this.model.date.month + 11, this.model.date.day);
        } else {
            this.band.startDate = new Date(this.model.date.year, this.model.date.month - 1, this.model.date.day);
        }

        if (this.band.network.networkId == undefined) {
            this.band.network = undefined;
        }

        if (this.band.client.clientId == undefined) {
            this.band.client = undefined;
        }
        this.band.tariff = undefined;
        this._tablesDataService.insertBand(this.band).subscribe(
            data => {
                this.loadBand();
                this.expanded = false;
                this.submitted = false;
                this.showTariff = false;
                this.load = false;                
                swal({ type: 'success', title: 'New Band created successfully', showConfirmButton: true });
            },
            Error => {
                this.submitted = false;
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
        //window.location.href = "/pages/onboarding/tariff";
    }

    createTariff() {
        this.load = true;
        this.submitted = true;
        if (this.tariffForm.invalid) {
            this.load = false;
            return;
        }
        if (this.activeFromDate != undefined || this.activeFromDate != null) {
            if (this.activeFromDate.date.month == 1) {
                this.tariff.activeFromDate = new Date(this.activeFromDate.date.year - 1, this.activeFromDate.date.month + 11, this.activeFromDate.date.day);
            } else {
                this.tariff.activeFromDate = new Date(this.activeFromDate.date.year, this.activeFromDate.date.month - 1, this.activeFromDate.date.day);
            }
        }
        if (this.activeToDate != undefined || this.activeToDate != null) {
            if (this.activeToDate.date.month == 1) {
                this.tariff.activeToDate = new Date(this.activeToDate.date.year - 1, this.activeToDate.date.month + 11, this.activeToDate.date.day);
            } else {
                this.tariff.activeToDate = new Date(this.activeToDate.date.year, this.activeToDate.date.month - 1, this.activeToDate.date.day);
            }
        }
        this.tariff.propertyAreaCharge = undefined;
        this.tariff.standingCharge = undefined;
        this.tariff.unitCharge = undefined;
        this._tablesDataService.insertTariff(this.tariff).subscribe(
            data => {
                this.submitted = false;
                this.loadBand();
                this.tariffExpand = false;
                this.showTariff = false;
                this.load = false;  
                var result = data['_body'];
                if (result != null && result != undefined && result != "")
                    swal({ type: 'success', title: 'Tariff created successfully', showConfirmButton: true });
                else
                    swal({ type: 'error', title: 'Oops...', text: 'Tariff overlaps with existing tariff' });
            },
            Error => {
                this.load = false;
                this.submitted = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
        //window.location.href = "/pages/onboarding/tariff";
    }

    createAdminCharge() {
        this.submitted = true;
        this.load = true;
        if (this.adminForm.invalid) {
            this.load = false;
            return;
        }
        if (this.activeFromDate != undefined || this.activeFromDate != null) {
            if (this.activeFromDate.date.month == 1) {
                this.admincharge.activeFromDate = new Date(this.activeFromDate.date.year - 1, this.activeFromDate.date.month + 11, this.activeFromDate.date.day);
            } else {
                this.admincharge.activeFromDate = new Date(this.activeFromDate.date.year, this.activeFromDate.date.month - 1, this.activeFromDate.date.day);
            }
        }
        if (this.activeToDate != undefined || this.activeToDate != null) {
            if (this.activeToDate.date.month == 1) {
                this.admincharge.activeToDate = new Date(this.activeToDate.date.year - 1, this.activeToDate.date.month + 11, this.activeToDate.date.day);
            } else {
                this.admincharge.activeToDate = new Date(this.activeToDate.date.year, this.activeToDate.date.month - 1, this.activeToDate.date.day);
            }
        }
        this._tablesDataService.insertAdminCharge(this.admincharge).subscribe(
            data => {
                this.submitted = false;
                this.loadBand();
                this.adminblock = false;
                this.tariffExpand = false;
                this.showTariff = false;
                this.load = false;                
                swal({ type: 'success', title: 'Admin charge added successfully', showConfirmButton: true });
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
        //window.location.href = "/pages/onboarding/tariff";
    }

    createUnitCharge() {
        this.load = true;
        this.submitted = true;
        if (this.unitChargeForm.invalid) {
            this.load = false;
            return;
        } 
        this.unitChargeExpand = false;
        this._tablesDataService.insertUnitCharge(this.unitCharge).subscribe(
            data => {
                this.submitted = false;
                this.unitChargeExpand = false;
                this.loadBand();
                this.showTariff = false;
                this.load = false;                
                swal({ type: 'success', title: 'Unit Charge added successfully', showConfirmButton: true });
            },
            Error => {
                this.submitted = false;
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
       // window.location.href = "/pages/onboarding/tariff";
    }

    showStandingCharge(tariffSelected: Tariff) {
        this.standingCharge = new StandingCharge()
        this.submitted = false;
        this.standingChargeExpanded = true;
        this.standingCharge.tariff.tariffId = tariffSelected.tariffId;
        this.standingCharge.tariff.tariffName = tariffSelected.tariffName;
    }


    createStandingCharge() {
        this.load = true;
        this.submitted = true;
        if (this.standingChargeForm.invalid) {
            this.load = false;
            return;
        } 
        this.standingChargeExpanded = false;
        this._tablesDataService.insertStandingCharge(this.standingCharge).subscribe(
            data => {
                this.submitted = false;
                this.standingChargeExpanded = false;
                this.loadBand();
                this.showTariff = false;
                this.load = false;                
                swal({ type: 'success', title: 'Standing charge created successfully', showConfirmButton: true });
            },
            Error => {
                this.submitted = false;
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
       // window.location.href = "/pages/onboarding/tariff";
    }

    showUnitCharge(tariffSelected: Tariff) {
        this.submitted = false;
        this.unitChargeExpand = true;
        this.unitCharge = new UnitCharge();
        this.unitCharge.tariff.tariffId = tariffSelected.tariffId;
        this.unitCharge.tariff.tariffName = tariffSelected.tariffName;
    }

    showPropertyAreaCharge(tariffSelected: Tariff) {
        this.areaError = false;
        this.submitted = false;
        this.propertyAreaCharge = new PropertyAreaCharge();
        this.propertyChargeExpanded = true;
        this.propertyAreaCharge.tariff.tariffId = tariffSelected.tariffId;
        this.propertyAreaCharge.tariff.tariffName = tariffSelected.tariffName;
    }

    createPropertyAreaCharge() {
        this.load = true;
        if (this.propertyAreaCharge.areaUnits == undefined) {
            this.areaError = true;
        } else {
            this.areaError = false;
        }
        this.submitted = true;
        if (this.propertyAreaChargeForm.invalid) {
            this.load = false;
            return;
        } else {
            if (this.areaError == true) {
                this.load = false;
                return;
            }
        }
        this.propertyChargeExpanded = false;
        this._tablesDataService.insertPropertyAreaCharge(this.propertyAreaCharge).subscribe(
            data => {
                this.propertyChargeExpanded = false;
                this.submitted = false;
                this.loadBand();
                this.showTariff = false;
                this.load = false;                
                swal({ type: 'success', title: 'Property Area Charge created successfully', showConfirmButton: true });
            },
            Error => {
                this.submitted = false;
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    fetchNetworkData() {
        this._tablesDataService.getNetworkForClient(this.band.client.clientId).then((value) => {
            console.log("Value = " + value);
            this.networkList = value;
        });
    }

    displayTariffBlock(band: string, bandId: number) {
        this.tariff = new Tariff();
        this.tariffExpand = true; 
        this.bandName = band;
        this.submitted = false;
        this.tariff.band.bandId = bandId;
    }

    displayAdminChargeBlock(band: string, bandId: number) {
        this.adminblock = true;
        this.submitted = false;
        this.activeFromYear = this.currentDate.getFullYear();
        this.activeToYear = this.currentDate.getFullYear();
        this.activeFromMonth = this.currentDate.getMonth() + 1;
        this.activeToMonth = this.currentDate.getMonth() + 1;
        this.activeFromDay = this.currentDate.getDate();
        this.activeToDay = this.currentDate.getDate();
        this.adminBandName = band;
        this.admincharge.band.bandId = bandId;
    }

    displayTariffDetails(index: number, pageNumber: number, pageSize: number) {        
        //pageNumber = pageNumber - 1;
        //this.lastPageNumber = pageNumber;
       // this.lastPageSize = pageSize;        
        if (this.selectedIndex == index && this.tableData[index].showTariff == 'Hide') {
            this.tableData[index].showTariff = 'Show';
            this.showTariff = false;
        }
        else if (this.selectedIndex == index && this.tableData[index].showTariff == 'Show') {
            this.tableData[index].showTariff = 'Hide';
            this.showTariff = true;
        }
        else if (this.selectedIndex != index && this.tableData[index].showTariff == 'Show') {
            this.tableData.forEach((obj) => { obj.showTariff = 'Show' });
            this.showTariff = true;
            this.tableData[index].showTariff = 'Hide';
            this.selectedIndex = index;
        } else {
            this.selectedIndex = index;
            this.showTariff = true;
        }
        //this.lastSelectedIndex = this.selectedIndex;
    }

    setBandType() {
        if (this.band != null && this.band != undefined) {
            if (this.band.bandType == '0') {
                this.band.propertyPart1 = undefined;
                this.band.propertyPart2 = undefined;
                this.band.propertyUnit = undefined;
                this.band.numberOfBedroom = undefined;
            } else if (this.band.bandType == '2') {
                this.band.propertyPart1 = this.currentBand.propertyPart1;
                this.band.propertyPart2 = this.currentBand.propertyPart2;
                this.band.propertyUnit = this.currentBand.propertyUnit;
                this.band.numberOfBedroom = undefined;
            } else if (this.band.bandType == '1') {
                this.band.propertyPart1 = undefined;
                this.band.propertyPart2 = undefined;
                this.band.propertyUnit = undefined;
                this.band.numberOfBedroom = this.currentBand.numberOfBedroom;
            }
        }
    }
}