﻿import { Component, OnInit } from '@angular/core';
import { NetworkService } from './network.service';
import { GlobalService } from "../../../../shared/services/global.service";
import { Network } from "../../../../shared/class";
import { INetwork, IClient } from "../../../../shared/interface";
import { ClientSetupService } from "../clientsetup/clientSetup.service";
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';
@Component({
    selector: 'app-network-setup',
    templateUrl: './network.component.html',
    styleUrls: ['./network.component.scss'],
    providers: [NetworkService, ClientSetupService]
})
export class NetworkComponent implements OnInit {

    totalNumberOfItems = 0;
    load: Boolean = false;
    networkForm: FormGroup;
    tableData: Array<any>;
    expanded = false;
    pageSize = 10;
    pageNumber = 1;
    network: INetwork = new Network();
    blockStatus = false;
    clientData: IClient[];
    submitted = false;
    networkEdit = false;
    checkBoxStatus = false;
    viewNetwork = false;
    constructor(public router: Router, private _tablesDataService: NetworkService, public _globalService: GlobalService, private _clientService: ClientSetupService, private formBuilder: FormBuilder) {
        this._globalService.dataBusChanged('isActived', { title: 'Network' });
    }

    get n() { return this.networkForm.controls; }

    ngOnInit() {
        this.authenticationCheck();
        this.loadData();
        this.loadClientData();
        this.getNetworkCount();
        this.networkForm = this.formBuilder.group({
            clientName: ['', Validators.required],
            networkName: ['', Validators.required]
        });
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    editNetwork(networkSelected: Network) {
        this.blockStatus = false;
        this.checkBoxStatus = false;
        this.network = JSON.parse(JSON.stringify(networkSelected));
        this.networkEdit = true;
        this.expanded = true;
        this.viewNetwork = false;
        if (this.network.allowPrepayment == true) {
            this.blockStatus = true;
            this.checkBoxStatus = true;
            if (this.networkForm.get('paymentCardProvider') == undefined) {
                this.networkForm.setControl('paymentCardProvider', new FormControl('paymentCardProvider'));
                this.networkForm.setControl('iin', new FormControl('iin'));
                this.networkForm.setControl('recoveryRate', new FormControl('recoveryRate'));
                this.networkForm.get('paymentCardProvider').setValidators(Validators.required);
                this.networkForm.get('iin').setValidators([Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(8), Validators.maxLength(8)]);
                this.networkForm.get('recoveryRate').setValidators([Validators.required, Validators.min(0), Validators.max(100)]);
                this.networkForm.get('paymentCardProvider').updateValueAndValidity();
                this.networkForm.get('iin').updateValueAndValidity();
                this.networkForm.get('recoveryRate').updateValueAndValidity();
            }
        } else {
            if (this.networkForm.get('paymentCardProvider') != undefined) {
                this.networkForm.removeControl('paymentCardProvider');
            }
            if (this.networkForm.get('iin') != undefined) {
                this.networkForm.removeControl('iin');
            }
            if (this.networkForm.get('recoveryRate') != undefined) {
                this.networkForm.removeControl('recoveryRate');
            }
        }
        this.networkForm.updateValueAndValidity();
    }

    viewNetworkClick(networkSelected: Network) {
        this.blockStatus = false;
        this.network = JSON.parse(JSON.stringify(networkSelected));
        this.networkEdit = false;
        this.expanded = true;
        this.viewNetwork = true;
        this.checkBoxStatus = false;
        if (this.network.allowPrepayment == true) {
            this.blockStatus = true;
            this.checkBoxStatus = true;
            if (this.networkForm.get('paymentCardProvider') == undefined) {
                this.networkForm.setControl('paymentCardProvider', new FormControl('paymentCardProvider'));
                this.networkForm.setControl('iin', new FormControl('iin'));
                this.networkForm.setControl('recoveryRate', new FormControl('recoveryRate'));
                this.networkForm.get('paymentCardProvider').setValidators(Validators.required);
                this.networkForm.get('iin').setValidators([Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(8), Validators.maxLength(8)]);
                this.networkForm.get('recoveryRate').setValidators([Validators.required, Validators.min(0), Validators.max(100)]);
                this.networkForm.get('paymentCardProvider').updateValueAndValidity();
                this.networkForm.get('iin').updateValueAndValidity();
                this.networkForm.get('recoveryRate').updateValueAndValidity();
            }
        } else {
            if (this.networkForm.get('paymentCardProvider') != undefined) {
                this.networkForm.removeControl('paymentCardProvider');
            }
            if (this.networkForm.get('iin') != undefined) {
                this.networkForm.removeControl('iin');
            }
            if (this.networkForm.get('recoveryRate') != undefined) {
                this.networkForm.removeControl('recoveryRate');
            }
        }
        this.networkForm.updateValueAndValidity();
    }

    addNetwork() {
        this.expanded = true;
        this.blockStatus = false;
        this.checkBoxStatus = false;
        this.viewNetwork = false;
        this.network = new Network();
        if (this.networkForm.get('paymentCardProvider') != undefined) {
            this.networkForm.removeControl('paymentCardProvider');
        }
        if (this.networkForm.get('iin') != undefined) {
            this.networkForm.removeControl('iin');
        }
        if (this.networkForm.get('recoveryRate') != undefined) {
            this.networkForm.removeControl('recoveryRate');
        }
        this.networkForm.updateValueAndValidity();
    }

    loadData() {
        this.load = true;        
        this._tablesDataService.getNetworks(this.pageNumber, this.pageSize).then((value) => {
            this.tableData = value;
            this.load = false;
        },
        (error)=>{
            this.load = false;
        }
        );
    }
    getNetworkCount() {
        this._tablesDataService.getNetworkCount().then(
            (data) => {
                this.totalNumberOfItems = data;
                console.log("count=" + data);
            },
            (error) => {
                console.error("Error" + error);
            }
        );
    }
    pageChanged(pN: number): void {
        this.pageNumber = pN;
        this.loadData();
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.submitted = false;
            this.networkEdit = false;
            this.blockStatus = false;
        }
    }

    changeBlockStatus(event: Event) {
        if (this.networkForm.get('paymentCardProvider') == undefined) {
            this.networkForm.setControl('paymentCardProvider', new FormControl('paymentCardProvider'));
            this.networkForm.setControl('iin', new FormControl('iin'));
            this.networkForm.setControl('recoveryRate', new FormControl('recoveryRate'));
            this.networkForm.get('paymentCardProvider').setValidators(Validators.required);
            this.networkForm.get('iin').setValidators([Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(8), Validators.maxLength(8)]);
            this.networkForm.get('recoveryRate').setValidators([Validators.required, Validators.min(0), Validators.max(100)]);
            this.networkForm.get('paymentCardProvider').updateValueAndValidity();
            this.networkForm.get('iin').updateValueAndValidity();
            this.networkForm.get('recoveryRate').updateValueAndValidity();
        } else {
            if (this.networkForm.get('paymentCardProvider') != undefined) {
                this.networkForm.removeControl('paymentCardProvider');
            }
            if (this.networkForm.get('iin') != undefined) {
                this.networkForm.removeControl('iin');
            }
            if (this.networkForm.get('recoveryRate') != undefined) {
                this.networkForm.removeControl('recoveryRate');
            }
            this.networkForm.updateValueAndValidity();
        }

        if (this.blockStatus == false) {
            this.blockStatus = true;
            this.network.allowPrepayment = true;
        }
        else {
            this.blockStatus = false;
            this.network.allowPrepayment = false;
        }
    }

    loadClientData() {
        this._clientService.getClients().then((value) => {
            console.log("Value = " + value);
            this.clientData = value;
        });
    }

    createNetwork() {
        this.load = true;
        this.submitted = true;
        if (this.networkForm.invalid) { 
            this.load = false;
            return;
        }       
        if (this.network.allowPrepayment == false) {
            this.network.allowPrepayment = undefined;
            this.network.paymentCardProvider = undefined;
            this.network.iin = undefined;
            this.network.cardNumberGeneration = undefined;
            this.network.recoveryPercentage = undefined;
        }
        this._tablesDataService.insertNetwork(this.network).subscribe(
            data => {
                this.submitted = false;
                this.loadData();
                this.expanded = false;
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Network created successfully',
                    showConfirmButton: true
                });
            },
            Error => {
                this.load = false;
                this.submitted = false;
                this.expanded = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );        
        //window.location.href = "/pages/onboarding/network";
    }

    updateNetwork() {
        this.submitted = true;
        this.load = true;
        if (this.networkForm.invalid) {
            this.load = false;
            return;
        }
        if (this.network.allowPrepayment == false) {
            this.network.allowPrepayment = undefined;
            this.network.paymentCardProvider = undefined;
            this.network.iin = undefined;
            this.network.cardNumberGeneration = undefined;
            this.network.recoveryPercentage = undefined;
        }
        this._tablesDataService.updateNetwork(this.network).subscribe(
            data => {
                this.submitted = false;
                this.networkEdit = false;
                this.expanded = false;
                this.loadData();
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Network updated successfully',
                    showConfirmButton: true
                });
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
        //window.location.href = "/pages/onboarding/network";
    }
}