﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { INetwork } from "../../../../shared/interface";
import { Observable } from "rxjs";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class NetworkService {

    constructor(private http: Http) { }

    networkBaseUrl = environment.host + 'network';
    networkBase2Url = environment.host + 'network-v2?index=';
    networkCount = environment.host + 'network/count';

    getNetworkCount() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.networkCount, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as number);

    }

    getNetworks(index: number, size: number) {
        let url = this.networkBase2Url + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as INetwork[]);

    }

    insertNetwork(network: INetwork): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.networkBaseUrl, network, {
            headers: headers
        });
    }   

    updateNetwork(network: INetwork): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.networkBaseUrl, network, {
            headers: headers
        });
    }
}
