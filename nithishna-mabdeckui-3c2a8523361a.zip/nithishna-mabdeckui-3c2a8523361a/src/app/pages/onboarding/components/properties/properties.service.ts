﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { IProperty, IClient } from "../../../../shared/interface";
import { Observable } from "rxjs";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class PropertiesService {

    propertiesUrl = environment.host +'property';
    constructor(private http: Http) { }
    propertyV2Url = environment.host + 'property-v2?index=';
    propertyCountUrl = environment.host + 'property/count';
    clientsBaseUrl = environment.host + 'client';
    getPropertyCount() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.propertyCountUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as number);
    }

    getClients() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.clientsBaseUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);

    }

    getPropertiesV2(index: number, size: number) {
        let url = this.propertyV2Url + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IProperty[]);
    }

    getProperties() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.propertiesUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IProperty[]);

    }

    insertProperty(property: IProperty): Observable<any>  {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.propertiesUrl, property, {
            headers: headers
        });
    } 

    updateProperty(property: IProperty): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.propertiesUrl, property, {
            headers: headers
        });
    } 
}
