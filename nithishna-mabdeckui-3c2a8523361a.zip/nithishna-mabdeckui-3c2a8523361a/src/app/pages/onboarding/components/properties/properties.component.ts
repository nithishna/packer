﻿import { Component, OnInit } from '@angular/core';
import { PropertiesService } from './properties.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GlobalService } from "../../../../shared/services/global.service";
import { INetwork, IBand, IClient, IProperty } from "../../../../shared/interface";
import { Property, Client } from "../../../../shared/class";
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';
import { IMyDpOptions } from "mydatepicker";
@Component({
    selector: 'app-properties-setup',
    templateUrl: './properties.component.html',
    styleUrls: ['./properties.component.scss'],
    providers: [PropertiesService]
})
export class PropertiesComponent implements OnInit {
    load: Boolean = false;
    tableData: IProperty[];
    networks: INetwork[];
    bands: IBand[];
    clients: IClient[];
    clientData: IClient[];
    properties: IProperty[];
    property: IProperty = new Property();
    totalNumberOfItems = 0;
    /* pagination Info */
    pageSize = 10;
    pageNumber = 1;
    expanded = false;
    propertyForm: FormGroup;
    submitted: boolean = false;
    updatePropertyValue: boolean = false;
    viewProperty: boolean = false;
    lastBilledDate: any = null;

    public myDatePickerOptions: IMyDpOptions = {
        // other options...
        dateFormat: 'dd/mm/yyyy'
    };

    public model: any = { };

    constructor(public router: Router, private _tablesDataService: PropertiesService, public _globalService: GlobalService, private formBuilder: FormBuilder) {
        this._globalService.dataBusChanged('isActived', { title: 'Properties' });
    }
    get p() { return this.propertyForm.controls; }

    ngOnInit() {
        this.authenticationCheck();
        this.getPropertiesCount();
        this.loadData();
        this.propertyForm = this.formBuilder.group({
            clientName: ['', Validators.required],
            networkName: ['', Validators.required],
            propertyBand: ['', Validators.required],
            addressLine1: ['', Validators.required],
            town: ['', Validators.required],
            postCode: ['', [Validators.required, Validators.maxLength(10)]],
            lastBilledDate: ['', Validators.required]
        });
    }

    loadData() {        
        this.loadPropertiesData();
        this.loadClientData();
    }

    pageChanged(pN: number): void {
        this.pageNumber = pN;
        this.loadPropertiesData();
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    loadClientData() {
        this.load = true;
        this._tablesDataService.getClients().then((value) => {
            console.log("Value = " + value);
            this.clientData = value;
            this.load = false;
        });
    }

    getPropertiesCount() {
        this._tablesDataService.getPropertyCount().then(
            (data) => {
                this.totalNumberOfItems = data;
                console.log("count=" + data);
            },
            (error) => {
                console.error("Error" + error);
            }
        );
    }

    loadPropertiesData() {
        this._tablesDataService.getPropertiesV2(this.pageNumber, this.pageSize).then((value) => {
            console.log("Value = " + value);
            this.tableData = value;
        });
    }

    createProperty() {
        this.load = true;
        this.submitted = true;
        if (this.propertyForm.invalid) {
            this.load = false;
            return;
        }
        if (this.model.date.month == 1) {
            this.property.lastBilledDate = new Date(this.model.date.year - 1, this.model.date.month + 11, this.model.date.day);
        } else {
            this.property.lastBilledDate = new Date(this.model.date.year, this.model.date.month - 1, this.model.date.day);
        }
        this._tablesDataService.insertProperty(this.property).subscribe(
            data => {
                this.load = false;
                this.submitted = false;
                this.expanded = false;
                this.loadData();
                swal({
                    type: 'success',
                    title: 'Property created successfully',
                    showConfirmButton: true
                });
            },
            Error => {
                this.load = false;
                this.submitted = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });

            }
        );
    }

    displayAddProperty() {
        this.submitted = false;
        this.expanded = true;
        this.model = null;
    }

    displayUpdateProperty(selectedProperty: Property) {
        this.viewProperty = false;
        this.updatePropertyValue = true;
        this.property = JSON.parse(JSON.stringify(selectedProperty));
        if (this.property.lastBilledDate != undefined || this.property.lastBilledDate != null) {
            let newDate = new Date(this.property.lastBilledDate);
            this.model = {
                date: {
                    year: newDate.getFullYear(),
                    month: newDate.getMonth() + 1,
                    day: newDate.getDate()
                }
            };
        }
        else {
            this.model = null;
        }
        this.loadClientData();
        this.fetchNetworkData();
        this.fetchBandData();
        this.expanded = true;
    }

    displayViewProperty(selectedProperty: Property) {
        this.updatePropertyValue = false;
        this.viewProperty = true;
        this.property = JSON.parse(JSON.stringify(selectedProperty));
        this.expanded = true;
        if (this.property.lastBilledDate != undefined || this.property.lastBilledDate != null) {
            let newDate = new Date(this.property.lastBilledDate);
            this.model = {
                date: {
                    year: newDate.getFullYear(),
                    month: newDate.getMonth() + 1,
                    day: newDate.getDate()
                }
            };
        }
        else {
            this.model = null;
        }
    }

    updateProperty() {
        this.submitted = true;
        this.load = true;
        if (this.propertyForm.invalid) {
            this.load = false;
            return;
        }
        if (this.model.date.month == 1) {
            this.property.lastBilledDate = new Date(this.model.date.year - 1, this.model.date.month + 11, this.model.date.day);
        } else {
            this.property.lastBilledDate = new Date(this.model.date.year, this.model.date.month - 1, this.model.date.day);
        }
        this._tablesDataService.updateProperty(this.property).subscribe(
            data => {
                this.expanded = false;
                this.updatePropertyValue = false;
                this.submitted = false;
                this.property = new Property();
                this.loadData();
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Property updated successfully',
                    showConfirmButton: true
                });
            },
            Error => {
                this.load = false;
                this.submitted = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });

            }
        );

    }

    fetchNetworkData() {
        for (var i = 0; i < this.clientData.length; i++){
            let client = this.clientData[i];
            if (this.property.client.clientId == client.clientId) {
                this.networks = client.network;
                if (this.networks != undefined && this.networks != null) {
                    this.property.network.networkId = this.networks[0].networkId;
                }
            }
        }
    }

    fetchBandData() {
        for (var i = 0; i < this.networks.length; i++) {
            let network = this.networks[i];
            if (this.property.network.networkId == network.networkId) {
                this.bands = network.band;
                if (this.bands != undefined && this.bands != null) {
                    this.property.band.bandId = this.bands[0].bandId;
                }
            }
        }
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.property = new Property();
            this.viewProperty = false;
            this.updatePropertyValue = false;
        }
    }
}