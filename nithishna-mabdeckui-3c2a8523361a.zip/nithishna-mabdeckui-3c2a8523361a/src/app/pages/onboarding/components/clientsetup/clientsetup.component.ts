﻿import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClientSetupService } from './clientSetup.service';
import { GlobalService } from "../../../../shared/services/global.service";
import { IMyDpOptions } from 'mydatepicker';
import { IAddress, IClient, IBank } from "../../../../shared/interface";
import { Client, MainContact, AccountDetails, CustomerServiceContract } from "../../../../shared/class";
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';
@Component({
    selector: 'app-client-setup',
    templateUrl: './clientsetup.component.html',
    styleUrls: ['./clientsetup.component.scss'],
    providers: [ClientSetupService]
})
export class ClientSetupComponent implements OnInit {
    load: Boolean = false;
    clientUpdate = false;
    updatecontactblock = true;
    updateaccountblock = true;
    updatecustServiceblock = true;
    imageSrc: string;

    submitted = false;
    msubmitted = false;
    csubmitted = false;
    bsubmitted = false;

    clientForm: FormGroup;
    mainContactForm: FormGroup;
    bankAccountForm: FormGroup;
    customerServiceContactForm: FormGroup;
    tableData: IClient[];
    bankData: IBank[];
    expanded = false;
    contactblock = true;
    accountblock = true;
    custServiceblock = true;

    clientView = false;
    viewaccountblock = true;
    viewcontactblock = true;
    viewcustServiceblock = true;
    /* pagination Info */
    pageSize = 10;
    pageNumber = 1;
    totalNumberOfItems = 0;
    currentDate: Date = new Date(Date.now());
    day = this.currentDate.getDate();
    year = this.currentDate.getFullYear();
    month = this.currentDate.getMonth() + 1;
    address: IAddress;
    sortcode = {
        code1: undefined,
        code2: undefined,
        code3: undefined
    };
    client: IClient = new Client();
    viewClient: IClient = new Client();

    addClient() {
        this.expanded = true;
        this.contactblock = true;
        this.accountblock = true;
        this.custServiceblock = true;
        this.sortcode.code1 = undefined;
        this.sortcode.code2 = undefined;
        this.sortcode.code3 = undefined;
    }
    getClientCount() {
        this._clientService.getClientCount().then(
            (data) => {
                this.totalNumberOfItems = data;
                console.log("count=" + data);
            },
            (error) => {
                console.error("Error" + error);
            }
        );
    }
    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
                this.loadClientData();
                this.loadBankData();
                this.clientForm = this.formBuilder.group({
                    clientName: ['', Validators.required],
                    addressLine1: ['', Validators.required],
                    town: ['', Validators.required],
                    postCode: ['', [Validators.required, Validators.minLength(6)]],
                    startDate: ['', Validators.required],
                    paymentTerm: ['', Validators.required]
                });
                this.mainContactForm = this.formBuilder.group({
                    title: ['', Validators.required],
                    firstName: ['', Validators.required],
                    lastName: ['', Validators.required],
                    emailAddress: ['', [Validators.required, Validators.email]],
                    addressLine1: ['', Validators.required],
                    town: ['', Validators.required],
                    postCode: ['', [Validators.required, Validators.minLength(6)]]
                });
                this.customerServiceContactForm = this.formBuilder.group({
                    mainContactNumber: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
                    emailAddress: ['', [Validators.required, Validators.email]],
                    addressLine1: ['', Validators.required],
                    town: ['', Validators.required],
                    postCode: ['', [Validators.required, Validators.minLength(6)]]
                });
                this.bankAccountForm = this.formBuilder.group({
                    accountHolderName: ['', Validators.required],
                    bankName: ['', Validators.required],
                    firstSortCode: ['', [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(2), Validators.maxLength(2)]],
                    secondSortCode: ['', [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(2), Validators.maxLength(2)]],
                    thirdSortCode: ['', [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(2), Validators.maxLength(2)]],
                    accountNumber: ['', [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(8)]]
                });
            },
            Error => {
                this.router.navigate(['/login']);
                return;
            }
        );
    }

    viewClientClickEvent(clientSelected: Client) {
        this.clientView = true;
        this.imageSrc = clientSelected.logo;
        this.viewClient = JSON.parse(JSON.stringify(clientSelected));
        if (this.viewClient.mainContact == undefined || this.viewClient.mainContact == null)
            this.viewClient.mainContact = new MainContact();
        if (this.viewClient.bankAccount == undefined || this.viewClient.bankAccount == null) {
            this.viewClient.bankAccount = new AccountDetails();
            this.sortcode.code1 = undefined;
            this.sortcode.code2 = undefined;
            this.sortcode.code3 = undefined;
        } else {
            this.sortcode.code1 = parseInt(clientSelected.bankAccount.sortCode.toString().substring(0, 2), 10);
            this.sortcode.code2 = parseInt(clientSelected.bankAccount.sortCode.toString().substring(2, 4), 10);
            this.sortcode.code3 = parseInt(clientSelected.bankAccount.sortCode.toString().substring(4, 6), 10);
        }
        if (this.viewClient.customerServiceContact == undefined || this.viewClient.customerServiceContact == null)
            this.viewClient.customerServiceContact = new CustomerServiceContract();
    }

    editClientClickEvent(clientSelected: Client) {
        this.clientUpdate = true;
        this.imageSrc = clientSelected.logo;
        this.client = JSON.parse(JSON.stringify(clientSelected));
        if (this.client.mainContact == undefined || this.client.mainContact == null)
            this.client.mainContact = new MainContact();
        if (this.client.bankAccount == undefined || this.client.bankAccount == null || this.client.bankAccount.sortCode == null) {
            this.client.bankAccount = new AccountDetails();
            this.sortcode.code1 = undefined;
            this.sortcode.code2 = undefined;
            this.sortcode.code3 = undefined;
        } else {
            this.sortcode.code1 = parseInt(clientSelected.bankAccount.sortCode.toString().substring(0, 2), 10);
            this.sortcode.code2 = parseInt(clientSelected.bankAccount.sortCode.toString().substring(2, 4), 10);
            this.sortcode.code3 = parseInt(clientSelected.bankAccount.sortCode.toString().substring(4, 6), 10);
        }
        if (this.client.customerServiceContact == undefined || this.client.customerServiceContact == null)
            this.client.customerServiceContact = new CustomerServiceContract();
    }

    public myDatePickerOptions: IMyDpOptions = {
        // other options...
        dateFormat: 'dd/mm/yyyy'
    };

    public model: any = { date: { year: this.year, month: this.month, day: this.day } };

    constructor(public router: Router, private _clientService: ClientSetupService, public _globalService: GlobalService, private formBuilder: FormBuilder) {
        this._globalService.dataBusChanged('isActived', { title: 'Client' });
    }

    closeWindow() {
        this.clientUpdate = false;
        this.expanded = false;
        this.submitted = false;
        this.client = this._clientService.initializeObject();
        this.imageSrc = null;
        this.clientView = false;
    }
    viewClickEvent(event: Event) {
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModalView") {
            this.clientView = false;
            this.submitted = false;
            this.imageSrc = null;
            this.client = new Client();
            this.expanded = false;
            this.viewaccountblock = true;
            this.viewcontactblock = true;
            this.viewcustServiceblock = true;
            this.clientUpdate = false;
        }
    }
    updateClickEvent(event: Event) {
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModalUpdate") {
            this.clientUpdate = false;
            this.submitted = false;
            this.imageSrc = null;
            this.client = new Client();
            this.expanded = false;
            this.updatecontactblock = true;
            this.updateaccountblock = true;
            this.updatecustServiceblock = true;
        }
    }
    clickEvent(event: Event) {
        //var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.submitted = false;
            this.imageSrc = null;
            this.clientUpdate = false;
            this.client = new Client();
        }
    }
    readUrl(event: any) {
        if (event.target.files && event.target.files[0]) {
            var reader = new FileReader();

            reader.onload = (event: ProgressEvent) => {
                this.imageSrc = (<FileReader>event.target).result;
            }

            reader.readAsDataURL(event.target.files[0]);
        }
    }
    get m() { return this.mainContactForm.controls; }
    get c() { return this.customerServiceContactForm.controls; }
    get b() { return this.bankAccountForm.controls; }

    public validateMainContactPage() {
        this.msubmitted = true;
        if (this.mainContactForm.invalid) {
            return;
        } else {
            this.msubmitted = false;
            this.contactblock = true;
            this.updatecontactblock = true;
        }
    }

    public validateCustomerServiceContactPage() {
        this.csubmitted = true;
        if (this.customerServiceContactForm.invalid) {
            return;
        } else {
            this.csubmitted = false;
            this.custServiceblock = true;
            this.updatecustServiceblock = true;
        }
    }

    public validateBankAccountPage() {
        this.bsubmitted = true;
        if (this.bankAccountForm.invalid) {
            return;
        } else {
            this.bsubmitted = false;
            this.accountblock = true;
            this.updateaccountblock = true;
        }
    }
    public clickForDisplay(event: Event) {
        this.load = true;
        this.submitted = true;
        var idAttr = event.srcElement.getAttribute("id");
        if (this.clientForm.invalid) {
            this.load = false;
            return;
        }
        if (this.model.date.month == 1) {
            this.client.startDate = new Date(this.model.date.year - 1, this.model.date.month + 11, this.model.date.day);
        } else {
            this.client.startDate = new Date(this.model.date.year, this.model.date.month - 1, this.model.date.day);
        }
        if (this.sortcode != undefined || this.sortcode != null) {
            if (this.sortcode.code1 != undefined) {
                this.client.bankAccount.sortCode = this.sortcode.code1 + this.sortcode.code2 + this.sortcode.code3;
            }
        }
        if (this.client.bankAccount != undefined || this.client.bankAccount != null) {
            if (this.client.bankAccount.accountHolderName == undefined) {
                this.client.bankAccount = undefined;
            } else {
                if (this.client.bankAccount.bank.id == undefined) {
                    this.client.bankAccount.bank = undefined;
                }
            }
        }
        if (this.client.customerServiceContact != undefined || this.client.customerServiceContact != null) {
            if (this.client.customerServiceContact.mainContactNumber == undefined) {
                this.client.customerServiceContact = undefined;
            }
        }
        if (this.client.mainContact != undefined || this.client.mainContact != null) {
            if (this.client.mainContact.firstName == undefined) {
                this.client.mainContact = undefined;
            }
        }
        this.client.logo = this.imageSrc;
        if (idAttr == 'newClient') {
            this._clientService.insertClient(this.client)
                .subscribe(
                    data => {
                        this.load = false;
                        swal({
                            type: 'success',
                            title: 'Client Created Succesfully',
                            showConfirmButton: true
                        });
                        this.loadClientData();
                        this.closeWindow();
                    },
                    Error => {
                        this.load = false;
                        swal({
                            type: 'error',
                            title: 'Oops...',
                            text: 'Something went wrong! Please check with the administrator.'
                        });
                        this.closeWindow();
                    }
                );
        } else {
            this._clientService.updateClient(this.client)
                .subscribe(
                    data => {
                        this.load = false;
                        swal({
                            type: 'success',
                            title: 'Client Updated Succesfully',
                            showConfirmButton: true
                        });
                        this.loadClientData();
                        this.closeWindow();
                    },
                    Error => {
                        this.load = false;
                        swal({
                            type: 'error',
                            title: 'Oops...',
                            text: 'Something went wrong! Please check with the administrator.'
                        });
                        this.closeWindow();
                    }
                );
        }
    }

    ngOnInit() {
        this.authenticationCheck();
        this.getClientCount();
        //this.loadClientData();
    }

    get f() { return this.clientForm.controls; }

    loadClientData() {
        // this.load = true;
        this._clientService.getAllClients(this.pageNumber, this.pageSize).then(
            (value) => {
                this.tableData = value;
                //  this.load = false;
            },
            (error) => {
                //  this.load = false;
            }
        );
    }

    loadClientById(id: number, view: boolean) {
        this._clientService.getClientById(id).then(
            (data) => {
                if (view) {
                    this.viewClientClickEvent(data);
                } else {
                    this.editClientClickEvent(data);
                }
            },
            (error) => { }
        );
    }

    /*  loadData() {
          this.load = true;
          this._clientService.getClients().then((value) => {
              console.log("Value = " + value);
              this.tableData = value;
              this.load = false;
          }, (err) => { window.alert("Something went wrong!..Kindly check with IT support team."); this.load = false; });
      }*/

    loadBankData() {
        this._clientService.getAllBankDetails().then((value) => {
            console.log("BankData = " + value);
            this.bankData = value;
        });
        console.log(this.bankData);
    }

    pageChanged(pN: number): void {
        this.pageNumber = pN;
        this.loadClientData();
    }

    copyClientAddress(dest: number) {
        console.log("dest" + dest);
        if (dest == 1) {
            this.client.mainContact.address.addressLine1 = this.client.address.addressLine1;
            this.client.mainContact.address.addressLine2 = this.client.address.addressLine2;
            this.client.mainContact.address.addressLine3 = this.client.address.addressLine3;

            this.client.mainContact.address.country = this.client.address.country;
            this.client.mainContact.address.postCode = this.client.address.postCode;

            this.client.mainContact.address.region = this.client.address.region;
            this.client.mainContact.address.town = this.client.address.town;
        } else {
            this.client.customerServiceContact.address.addressLine1 = this.client.address.addressLine1;
            this.client.customerServiceContact.address.addressLine2 = this.client.address.addressLine2;
            this.client.customerServiceContact.address.addressLine3 = this.client.address.addressLine3;

            this.client.customerServiceContact.address.country = this.client.address.country;
            this.client.customerServiceContact.address.postCode = this.client.address.postCode;

            this.client.customerServiceContact.address.region = this.client.address.region;
            this.client.customerServiceContact.address.town = this.client.address.town;
        }
    }
}