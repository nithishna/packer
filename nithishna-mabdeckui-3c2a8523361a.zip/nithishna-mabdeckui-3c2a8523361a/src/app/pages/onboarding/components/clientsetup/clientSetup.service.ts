﻿import { Injectable } from '@angular/core';
import { IAddress, IClient, IBank } from "../../../../shared/interface";
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/timeout';
import { map, catchError } from 'rxjs/operators';
import { HttpHeaders } from "@angular/common/http";
import { Client } from "../../../../shared/class";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class ClientSetupService {

    clientsBaseUrl = environment.host +'client';
    bankBaseUrl = environment.host +'bank';
    hubClientsUrl = environment.host + 'hub-clients';
    clientsMetaDataUrl = environment.host + 'client-metadata';
    clientCount = environment.host + 'client/count';
    allClientUrl = environment.host + 'all-client?index=';

    constructor(private http: Http) { }



    insertClient(client: IClient): Observable<any>{
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.clientsBaseUrl, client, {
            headers: headers
        });
    }

    updateClient(client: IClient): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.clientsBaseUrl, client, {
            headers: headers
        });
    }

    getHubClients() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.hubClientsUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);
    }

    getClientById(id: number) {
        let url = this.clientsBaseUrl + '/' + id;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient);
    }

    getClients() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.clientsBaseUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);

    }

    getAllClients(index: number, size: number) {
        let url = this.allClientUrl + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);
    }

    getClientCount() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.clientCount, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as number);

    }

    getAllBankDetails() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.bankBaseUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IBank[]);
    }

    initializeObject(): IClient {
        return new Client();
    }

    getAllClientMetadata() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.clientsMetaDataUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);

    }
}