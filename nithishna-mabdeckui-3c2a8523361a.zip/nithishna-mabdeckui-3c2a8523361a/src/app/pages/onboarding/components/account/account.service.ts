﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, URLSearchParams, Headers } from '@angular/http';
import { IAccount } from "../../../../shared/interface";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class AccountService {
    constructor(private http: Http) { }
        
    accountUrl = environment.host + 'account';
    accountV2Url = environment.host + 'account-v2?index=';
    accountCountUrl = environment.host + 'account/count';

    getAllAccountsV2(index: number, size: number) {
        let url = this.accountV2Url + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IAccount[]);
    }

    getAccountCount() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.accountCountUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as number);
    }

    getAllAccounts() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.accountUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IAccount[]);
    }

    createAccount(account: IAccount) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.accountUrl, account, {
            headers: headers
        });
    }      

    updateAccount(account: IAccount) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.accountUrl, account, {
            headers: headers
        });
    }
}
