﻿import { Component, OnInit } from '@angular/core';
import { AccountService } from './account.service';
import { GlobalService } from "../../../../shared/services/global.service";
import { IAccount, INetwork, IClient } from "../../../../shared/interface";
import { Account, BillablePerson } from "../../../../shared/class";
import { ClientSetupService } from "../clientsetup/clientSetup.service";
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import swal from 'sweetalert2';
@Component({
    selector: 'app-account-setup',
    templateUrl: './account.component.html',
    styleUrls: ['./account.component.scss'],
    providers: [AccountService, ClientSetupService]
})
export class AccountComponent implements OnInit {
    load: Boolean = false;
    tableData: IAccount[];
    account: IAccount = new Account();
    expanded = false;
    selectedClientId: number;
    networks: INetwork[];
    clientData: IClient[];
    viewAccount: boolean = false;
    i: number = 0;
    accountForm: FormGroup;
    submitted: boolean = false;
    /*Pagination details*/
    pageSize = 10;
    pageNumber = 1;
    editAccount: boolean = false;

    constructor(public router: Router, private _tablesDataService: AccountService, public _globalService: GlobalService, private _clientSetupService: ClientSetupService, private formBuilder: FormBuilder) {
        this._globalService.dataBusChanged('isActived', { title: 'Accounts' });
    }

    ngOnInit() {
        this.authenticationCheck();
        this.getAccountCount();
        this.loadAccountDetails();
        this.loadClientData();
        this.accountForm = this.formBuilder.group({
            client: ['', Validators.required],
            network: ['', Validators.required],
            accountNumber: ['', Validators.required],
            addressLine1: ['', Validators.required],
            town: ['', Validators.required],
            postcode: ['', Validators.required]
        });
    }
    totalNumberOfItems = 0;
    getAccountCount() {
        this._tablesDataService.getAccountCount().then(
            (data) => {
                this.totalNumberOfItems = data;
                console.log("count=" + data);
            },
            (error) => {
                console.error("Error" + error);
            }
        );
    }
    get a() { return this.accountForm.controls; }
    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }
    loadAccountDetails() {
        this.load = true;
        this._tablesDataService.getAllAccountsV2(this.pageNumber, this.pageSize).then((value) => {
            this.tableData = value;
            this.load = false;
        }, (error)=>{
            this.load = false;
        });           
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.account = new Account();
            this.viewAccount = false;
            this.editAccount = false;
        }
    }

    reinitializeAccount() {
        this.account = new Account();
        this.editAccount = false;
        this.viewAccount = false;
    }

    pageChanged(pN: number): void {
        this.pageNumber = pN;
        this.loadAccountDetails();
    }


    createAccount() {
        this.load = true;
        this.submitted = true;
        if (this.accountForm.invalid) {
            this.load = false;
            return;
        }
        var flag = false;
        if (this.account != undefined) {
            if (this.account.billablePerson != undefined && this.account.billablePerson.length > 0) {
                this.account.billablePerson.forEach((element) => {
                    if (element.firstName == undefined || element.firstName == '')
                    { flag = true; }
                    if (element.lastName == undefined || element.lastName == '')
                    { flag = true; }
                    if (element.titles == undefined)
                    { flag = true; }
                });
            }
        }
        if (flag) {
            this.load = false;
            return;
        }
        this._tablesDataService.createAccount(this.account).subscribe(
            data => {
                this.loadAccountDetails();
                this.expanded = false;
                this.submitted = false;
                this.account = new Account();
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Account created successfully',
                    showConfirmButton: true
                });
            }, Error => {
                this.expanded = false;     
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    showEditAccount(selectedAccount: Account) {
        this.account = JSON.parse(JSON.stringify(selectedAccount));
        this.expanded = true;
        this.editAccount = true;
    }

    showViewAccount(selectedAccount: Account) {
        this.account = JSON.parse(JSON.stringify(selectedAccount));
        this.expanded = true;
        this.viewAccount = true;
    }

    updateAccount() {
        this.load = true;
        this.submitted = true;
        if (this.accountForm.invalid) {
            this.load = false;
            return;
        }
        var flag = false;
        if (this.account != undefined) {
            if (this.account.billablePerson != undefined && this.account.billablePerson.length > 0) {
                this.account.billablePerson.forEach((element) => {
                    if (element.firstName == undefined || element.firstName == '')
                    { flag = true; }
                    if (element.lastName == undefined || element.lastName == '')
                    { flag = true; }
                    if (element.titles == undefined)
                    { flag = true; }
                });
            }
        }
        if (flag) {
            this.load = false;
            return;
        }
        this._tablesDataService.updateAccount(this.account).subscribe(
            data => {
                this.loadAccountDetails();
                this.expanded = false;
                this.submitted = false;
                this.editAccount = false;
                this.account = new Account();
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Account updated successfully',
                    showConfirmButton: true
                });
            }, Error => {
                this.expanded = false;
                this.editAccount = false;
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    loadClientData() {
        this._clientSetupService.getClients().then((value) => {
            console.log("Value = " + value);
            this.clientData = value;
            this.fetchNetworkData();
        });
    }

    fetchNetworkData() {
        if (this.clientData != undefined && this.clientData != null) {
            for (var i = 0; i < this.clientData.length; i++) {
                let client = this.clientData[i];
                if (this.account.client.clientId == client.clientId) {
                    this.networks = client.network;
                    return;
                }
            }
        }
    }

    addNewBillablePerson() {
        this.account.billablePerson.push(new BillablePerson());
    }

    removeLastBillablePerson() {
        this.account.billablePerson.pop();
    }
}