﻿import { Component, OnInit } from '@angular/core';
import { DataloggerService } from './datalogger.service';
import { GlobalService } from "../../../../shared/services/global.service";
import { ClientSetupService } from "../clientsetup/clientSetup.service";
import { IClient, IDataLogger, INetwork } from "../../../../shared/interface";
import { DataLogger } from "../../../../shared/class";
import { IMyDpOptions } from "mydatepicker";
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
    selector: 'app-datalogger-setup',
    templateUrl: './datalogger.component.html',
    styleUrls: ['./datalogger.component.scss'],
    providers: [DataloggerService, ClientSetupService]
})
export class DataloggerComponent implements OnInit {
    load: Boolean = false;
    tableData: INetwork[];
    expanded = false;
    /* pagination Info */
    pageSize = 10;
    pageNumber = 1;
    submitted: boolean = false;
    editDataLogger: boolean = false;
    clientData: IClient[];
    datalogger: IDataLogger = new DataLogger();
    networkList: INetwork[];
    models: Array<string>;
    currentDate: Date = new Date(Date.now());
    startDay = this.currentDate.getDate();
    startYear = this.currentDate.getFullYear();
    startMonth = this.currentDate.getMonth() + 1;
    endDay = this.currentDate.getDate();
    endYear = this.currentDate.getFullYear();
    endMonth = this.currentDate.getMonth() + 1;
    public startDate: any = { date: { year: this.startYear, month: this.startMonth, day: this.startDay } };
    public endDate: any = { date: { year: this.endYear, month: this.endMonth, day: this.endDay } };

    constructor(private formBuilder: FormBuilder, public router: Router, private _tablesDataService: DataloggerService, public _globalService: GlobalService, private _clientService: ClientSetupService) {
        this._globalService.dataBusChanged('isActived', { title: 'Data Loggers' });
    }
    dataLoggerForm: FormGroup;
    get d() { return this.dataLoggerForm.controls; }
    
    showAddDataLogger() {
        this.expanded = true;
        this.submitted = false;
        this.editDataLogger = false;
        this.datalogger = new DataLogger();
    }

    showEditDataLogger(selectedDataLogger: DataLogger) {
        this.expanded = true;
        this.submitted = false;
        this.editDataLogger = true;
        this.datalogger = JSON.parse(JSON.stringify(selectedDataLogger));
    }

    ngOnInit() {
        this.authenticationCheck();
        this.getNetworksByDataLoggers();
        this.loadClientData();
        this.dataLoggerForm = this.formBuilder.group({
            clientName: ['', Validators.required],
            networkName: ['', Validators.required],
            manufacturer: ['', Validators.required],
            model: ['', Validators.required],
            serialNumber: ['', Validators.required],
            communicationType: ['', Validators.required],
            startDate: ['', Validators.required]
        });
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    pageChanged(pN: number): void {
        this.pageNumber = pN;
    }

    loadClientData() {
        this._clientService.getClients().then((value) => {
            console.log("Value = " + value);
            this.clientData = value;
        });
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.submitted = false;
            this.datalogger = new DataLogger();
        }
    }

    fetchNetworkData() {
        this._tablesDataService.getNetworkForClient(this.datalogger.client.clientId).then((value) => {
            this.networkList = value;
        });
    }

    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
    };

    getNetworksByDataLoggers() {
        this.load = true;
        this._tablesDataService.getNetworkByDataLoggers().then((value) => {
            for (let i = 0; i < value.length; i++) {
                value[i].showDataLogger = 'Show';
            }
            this.tableData = value;
            this.load = false;
        });
    }

    insertDataLogger() {
        this.load = true;
        this.submitted = true;
        if (this.dataLoggerForm.invalid) {
            this.load = false;
            return;
        }
        if (this.startDate != null && this.startDate != undefined) {
            if (this.startDate.date.month == 1) {
                this.datalogger.startDate = new Date(this.startDate.date.year - 1, this.startDate.date.month + 11, this.startDate.date.day);
            } else {
                this.datalogger.startDate = new Date(this.startDate.date.year, this.startDate.date.month - 1, this.startDate.date.day);
            }
        }

        if (this.endDate != null && this.endDate != undefined) {
            if (this.endDate.date.month == 1) {
                this.datalogger.endDate = new Date(this.endDate.date.year - 1, this.endDate.date.month + 11, this.endDate.date.day);
            } else {
                this.datalogger.endDate = new Date(this.endDate.date.year, this.endDate.date.month - 1, this.endDate.date.day);
            }
        }
        this._tablesDataService.createDataLogger(this.datalogger).subscribe(
            data => {                
                this.getNetworksByDataLoggers();
                this.expanded = false;
                this.submitted = false;
                this.load = false;
                alert("DataLogger created successfully");
            }, Error => {
                this.expanded = false;
                this.load = false;
                alert("Something went wrong! Please check with the administrator");
            }
        );        
    }

    updateDataLogger() {
        this.submitted = true;
        this.load = true;
        if (this.dataLoggerForm.invalid) {
            this.load = false;
            return;
        }
        if (this.startDate != null && this.startDate != undefined) {
            if (this.startDate.date.month == 1) {
                this.datalogger.startDate = new Date(this.startDate.date.year - 1, this.startDate.date.month + 11, this.startDate.date.day);
            } else {
                this.datalogger.startDate = new Date(this.startDate.date.year, this.startDate.date.month - 1, this.startDate.date.day);
            }
        }

        if (this.endDate != null && this.endDate != undefined) {
            if (this.endDate.date.month == 1) {
                this.datalogger.endDate = new Date(this.endDate.date.year - 1, this.endDate.date.month + 11, this.endDate.date.day);
            } else {
                this.datalogger.endDate = new Date(this.endDate.date.year, this.endDate.date.month - 1, this.endDate.date.day);
            }
        }
        this._tablesDataService.updateDataLogger(this.datalogger).subscribe(
            data => {
                this.getNetworksByDataLoggers();
                this.expanded = false;
                this.submitted = false;
                this.editDataLogger = false;
                this.load = false;
                alert("DataLogger updated successfully");
            }, Error => {
                this.expanded = false;
                this.load = false;
                alert("Something went wrong! Please check with the administrator");
            }
        );
    }

    showDetails(network: INetwork) {
        if (network.showDataLogger == 'Show') {
            network.showDataLogger = 'Hide';
        }
        else {
            network.showDataLogger = 'Show';
        }
    }
}
