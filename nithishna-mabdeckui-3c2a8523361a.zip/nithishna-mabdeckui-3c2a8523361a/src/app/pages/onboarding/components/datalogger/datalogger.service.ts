﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import 'rxjs/add/operator/timeout';
import { INetwork, IDataLogger } from "../../../../shared/interface";
import { Observable } from 'rxjs';
import { environment } from "../../../../../environments/environment";

@Injectable()
export class DataloggerService {
    constructor(private http: Http) {       
    }

    clientUrl = environment.host +'client/';
    dataLoggerUrl = environment.host +'datalogger';
    networkDataLoggerUrl = environment.host +'network-by-datalog';

    getNetworkForClient(clientId: number) {
        let url = this.clientUrl + clientId + '/network';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .timeout(5000)
            .toPromise()
            .then((res) => res.json() as INetwork[]);
    }

    createDataLogger(dataLogger: IDataLogger): Observable<any> { 
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.dataLoggerUrl, dataLogger, {
            headers: headers
        });
    }

    updateDataLogger(dataLogger: IDataLogger): Observable<any> {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.dataLoggerUrl, dataLogger, {
            headers: headers
        });
    }

    getNetworkByDataLoggers() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.networkDataLoggerUrl, {
                headers: headers
            })
            .timeout(5000)
            .toPromise()
            .then((res) => res.json() as INetwork[]);
    }
}
