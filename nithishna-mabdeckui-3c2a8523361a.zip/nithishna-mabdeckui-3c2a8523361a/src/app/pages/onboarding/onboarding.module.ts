﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { routing } from './onboarding.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';
/* components */
import { OnboardingComponent } from './onboarding.component';
import { AccountComponent } from './components/account/account.component';
import { SetupComponent } from './components/setup/setup.component';
import { ClientSetupComponent } from './components/clientsetup/clientsetup.component';
import { DataloggerComponent } from './components/datalogger/datalogger.component';
import { HardwareComponent } from './components/hardwareandsupplies/hardware.component';
import { NetworkComponent } from './components/network/network.component';
import { PropertiesComponent } from './components/properties/properties.component';
import { TariffComponent } from './components/tariffandband/tariff.component';
import { MyDatePickerModule } from 'mydatepicker';
import { AllTariffsComponent } from "./components/alltariffs/alltariffs.component";
import { ViewTariffComponent } from "./components/viewtariff/viewtariff.component";
import { LayoutModule } from "../../shared/layout.module";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        routing,
        NgxPaginationModule,
        MyDatePickerModule,
        LayoutModule
    ],
    declarations: [
        OnboardingComponent,
        AccountComponent,
        SetupComponent,
        ClientSetupComponent,
        DataloggerComponent,
        HardwareComponent,
        NetworkComponent,
        PropertiesComponent,
        TariffComponent,
        AllTariffsComponent,
        ViewTariffComponent
    ]
})
export class OnboardingModule { }
