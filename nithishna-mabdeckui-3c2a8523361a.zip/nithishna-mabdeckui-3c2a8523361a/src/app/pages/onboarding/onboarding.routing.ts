﻿import { Routes, RouterModule } from '@angular/router';
import { OnboardingComponent } from './onboarding.component';
import { AccountComponent } from './components/account/account.component';
import { SetupComponent } from './components/setup/setup.component';
import { ClientSetupComponent } from './components/clientsetup/clientsetup.component';
import { DataloggerComponent } from './components/datalogger/datalogger.component';
import { HardwareComponent } from './components/hardwareandsupplies/hardware.component';
import { NetworkComponent } from './components/network/network.component';
import { PropertiesComponent } from './components/properties/properties.component';
import { TariffComponent } from './components/tariffandband/tariff.component';
import { AllTariffsComponent } from "./components/alltariffs/alltariffs.component";
import { ViewTariffComponent } from "./components/viewtariff/viewtariff.component";

const childRoutes: Routes = [
    {
        path: '',
        component: OnboardingComponent,
        children: [
            { path: '', redirectTo: 'setup', pathMatch: 'full' },
            { path: 'setup', component: SetupComponent },
            { path: 'clientsetup', component: ClientSetupComponent },
            { path: 'network', component: NetworkComponent },
            { path: 'tariff', component: TariffComponent },
            { path: 'properties', component: PropertiesComponent },
            { path: 'hardware', component: HardwareComponent },
            { path: 'datalogger', component: DataloggerComponent },
            { path: 'account', component: AccountComponent },
            { path: 'alltariffs/:id', component: AllTariffsComponent },
            { path: 'viewtariff/:id', component: ViewTariffComponent }
        ]
    }
];

export const routing = RouterModule.forChild(childRoutes);