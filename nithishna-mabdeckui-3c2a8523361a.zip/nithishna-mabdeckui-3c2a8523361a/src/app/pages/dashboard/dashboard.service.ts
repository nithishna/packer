﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions } from '@angular/http';
import { environment } from "../../../environments/environment";

@Injectable()
export class DashboardService {

    baseUrl = environment.host+'user';
    constructor(private http: Http) {
    }

  DATA = [
    {
      name: 'AuraHouse1',
      reference: 'Matt',
      network: 'private',
      client: 'PCS'
    },
    {
      name: 'AuraHouse2',
      reference: 'Matt',
      network: 'public',
      client: 'PCS'
    },
    {
      name: 'AuraHouse3',
      reference: 'Matt',
      network: 'private',
      client: 'PCS'
    },
    {
      name: 'AuraHouse4',
      reference: 'Matt',
      network: 'public',
      client: 'PCS'
    },
    {
      name: 'AuraHouse5',
      reference: 'Matt',
      network: 'private',
      client: 'PCS'
    },
    {
      name: 'AuraHouse6',
      reference: 'Matt',
      network: 'public',
      client: 'PCS'
    },
    {
      name: 'AuraHouse7',
      reference: 'Matt',
      network: 'private',
      client: 'PCS'
    },
    {
      name: 'AuraHouse8',
      reference: 'Matt',
      network: 'public',
      client: 'PCS'
    }
  ];

}
