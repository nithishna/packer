﻿import { Component, OnInit } from '@angular/core';
import { DashboardService } from './dashboard.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Http, RequestOptions, Headers } from '@angular/http';
import { GlobalService } from "../../shared/services/global.service";

@Component({
    selector: 'app-dashboard-setup',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    providers: [DashboardService]
})
export class DashboardComponent implements OnInit {
    tableData: Array<any>;

    constructor(private _globalService: GlobalService, private _tablesDataService: DashboardService, private router: Router) { }
    ngOnInit() {
        this.authenticationCheck();
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }
}
