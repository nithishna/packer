﻿import { Component, OnInit } from '@angular/core';
import { MainService } from './main.service';
import { GlobalService } from "../../../../shared/services/global.service";
import { Router, ActivatedRoute } from '@angular/router';
import { IAccountLimited } from "../../../../shared/interface";

@Component({
    selector: 'app-account-setup',
    templateUrl: './main.component.html',
    styleUrls: ['./main.component.scss'],
    providers: [MainService]
})
export class MainComponent implements OnInit {
    tableData: IAccountLimited[];
    load: Boolean = false;
    /* pagination Info */
    pageSize = 10;
    pageNumber = 1;

    constructor(private router: Router, private _tablesDataService: MainService, public _globalService: GlobalService) { }

    ngOnInit() {
        this.authenticationCheck();
        this.loadData();
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    loadData() {
        this.load = true;
        this._tablesDataService.getAllAccounts().then(
            (value) => {
                this.tableData = value;
                this.load = false;
            },
            (error) => {
                this.load = false;
            }
        );
    }

    pageChanged(pN: number): void {
        this.pageNumber = pN;
    }

}