﻿import { Component, OnInit, Input, Output, EventEmitter, ElementRef, Renderer2 } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { Router, ActivatedRoute } from '@angular/router';
import { IAccount, INetwork, IClient, INotes, ITransaction, IPaymentMethod, IPaymentType } from "../../../../shared/interface";
import { Account, BillablePerson, Address, Notes, PropertyAccountModel, Property, PropertyListItem, SupplyListItem, MeterListItem, MeterReadingItem, MeterReadingSearch, Reading, MeterReading, Transaction, PaymentType, PaymentMethod, AccountBalance, MyDate } from "../../../../shared/class";
import { ViewService } from "./view.service";
import { FormBuilder, FormGroup, Validators, FormsModule } from '@angular/forms';
import { ClientSetupService } from "../../../onboarding/components/clientsetup/clientSetup.service";
import { AccountService } from "../../../onboarding/components/account/account.service";
import { IMyDpOptions, IMyOptions } from 'mydatepicker';
import { DatePipe } from "@angular/common";
import swal from 'sweetalert2';
@Component({
    selector: 'app-view-account',
    templateUrl: './view.component.html',
    styleUrls: ['./view.component.scss'],
    providers: [ViewService, ClientSetupService, AccountService]
})
export class ViewComponent implements OnInit {
    accountBalance: AccountBalance = new AccountBalance();
    submit: boolean = false;
    paymentTypes: IPaymentType[] = new Array(0);
    paymentMethods: IPaymentMethod[] = new Array(0);
    transactions: ITransaction[] = new Array(0);
    transaction: ITransaction = new Transaction();
    load: Boolean = false;
    issue: string = '';
    enable: Boolean = false;
    width: string = '0%';
    progressBarText: string = '';
    param: string;
    networks: INetwork[];
    notes: INotes;
    clientData: IClient[];
    accountForm: FormGroup;
    accountSelected: IAccount = new Account();
    account: IAccount = new Account();
    selectedAccount: IAccount = new Account();
    showProperty: Boolean = false;
    showHub: Boolean = false;
    showSupplies: Boolean = false;
    showFinancials: Boolean = false;
    showLog: Boolean = true;
    showStatements: Boolean = false;
    showCorrespondance: Boolean = false;
    expanded: Boolean = false;
    notesExpanded: Boolean = false;
    notesViewExpanded: Boolean = false;
    fileName: string;
    billablePerson: BillablePerson[] = new Array();
    submitted = false;
    uploadedFile: string;
    propertiesFlag: number = 1;
    progress: boolean = false;
    progressValue: string = undefined;
    meterReadings: MeterReadingItem[] = new Array();
    year = 2019;
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'yyyy-mm-dd',
        sunHighlight: true,
        inline: false,
        selectorHeight: '300px',
        selectorWidth: '300px',
        disableUntil: { year: this.year, month: 5, day: 1 }
    };
    errorList: boolean[] = new Array(0);
    propertiesInAccount: PropertyAccountModel[] = new Array();
    propertiesToMoveInToAccount: Property[] = new Array();
    selectedPropertyId: number = 0;
    selectedPropertyString: string = "";
    selectedAssociationId: number = 0;
    selectedPropertyInAccount: PropertyAccountModel = new PropertyAccountModel();
    propertiesUnderProcessToMoveIn: Property[] = new Array();
    propertiesUnderProcessToMoveOut: Property[] = new Array();
    propertyDropDownList: PropertyListItem[];
    selectedPropertyListItem: PropertyListItem = new PropertyListItem();
    supplierDropDownList: SupplyListItem[];
    selectedSupplierListItem: SupplyListItem = new SupplyListItem();
    meterDropDownList: MeterListItem[];
    selectedMeterListItem: MeterListItem = new MeterListItem();
    selectedPropertyIdForDropDown: number = 0;
    propertyDropDownList2: PropertyListItem[];
    selectedPropertyListItem2: PropertyListItem = new PropertyListItem();
    supplierDropDownList2: SupplyListItem[];
    selectedSupplierListItem2: SupplyListItem = new SupplyListItem();
    meterDropDownList2: MeterListItem[];
    selectedMeterListItem2: MeterListItem = new MeterListItem();
    public readingFromDate: Date = new Date();
    public readingToDate: Date = new Date();
    input: MeterReadingSearch = new MeterReadingSearch();
    public model: any = null;
    public transactionDate: any = null;
    myDate: MyDate = new MyDate();

    constructor(public datepipe: DatePipe, public router: Router, private route: ActivatedRoute, private _globalService: GlobalService, private _viewService: ViewService, private _clientSetupService: ClientSetupService, private _tablesDataService: AccountService, private formBuilder: FormBuilder/*, private elRef: ElementRef, private renderer: Renderer2*/) {
        this.route.params.subscribe(
            params => {
                this.param = params['id'];
            }
        );
    }
    reading: Reading[] = new Array();
    readingDate: Date  = new Date();
    settings = {
        bigBanner: true,
        timePicker: true,
        format: 'dd-MM-yyyy hh:mm',
        defaultOpen: false,
        closeOnSelect: true
    }
    ngOnInit() {
        this.getAccountById();
        this.getPropertyDropDownListItemForAccountId();
        this.billablePerson.push(new BillablePerson());
        this.getAccountBalance();
        this.accountForm = this.formBuilder.group({
            accountNumber: ['', Validators.required],
            addressLine1: ['', Validators.required],
            town: ['', Validators.required],
            postcode: ['', Validators.required]
        });
        for (let i = 0; i < 5; i++) {
            this.errorList.push(false);
        }
    }

    getCopyOfOptions(): IMyOptions {
        return JSON.parse(JSON.stringify(this.myDatePickerOptions));
    }

    getActiveDateForProperty(propertyId: string, isProperty: boolean) {
        this._viewService.getActiveDateForProperty(propertyId, isProperty).then(
            value => {
                this.myDate = value;
                let copy = this.getCopyOfOptions();
                if (value.year != 1970) {                    
                    copy.disableUntil = { year: this.myDate.year, month: this.myDate.month, day: this.myDate.day };
                    this.model = { date: { year: this.myDate.year, month: this.myDate.month, day: (this.myDate.day + 1) } };                    
                }
                else {
                    this.model = null;                    
                    copy.disableUntil = { year: 1970, month: 1, day: 1 };                    
                }
                this.myDatePickerOptions = copy;
            }
        );
    }

    get a() { return this.accountForm.controls; }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal") {
            this.expanded = false;
            this.account = new Account();
        }
    }

    getAccountBalance() {
        this._viewService.getAccountBalance(this.param).then(
            value => {
                this.accountBalance = value;
            }
        );
    }

    showSupplier() {
        this.showSupplies = true;
        this.selectedPropertyListItem2 = new PropertyListItem();
        this.selectedSupplierListItem2 = new SupplyListItem();
        this.selectedMeterListItem2 = new MeterListItem();
        this.reading = new Array();
        this.reading.push(new Reading());
    }

    redirectToPropertyPage(property: Property) {
        this.router.navigate(['/pages/properties/view/' + property.propertyId]);        
    }

    addReading() {
        if (this.reading.length < 5) {
            this.reading.push(new Reading());            
        }
    }

    removeReading(index: number) {
        this.reading.splice(index, 1);
        this.reinitializeErrorList();
    }

    getAllMeterReadings() {
        this.load = true;
        this.issue = '';
        this.input = new MeterReadingSearch();
        this.input.accountId = this.param;
        if (this.selectedPropertyListItem2.propertyId == null || this.selectedPropertyListItem2.propertyId == undefined)
        {
            this.issue = 'property1';
            this.load = false;
            return;
        }
        else
            this.input.propertyId = this.selectedPropertyListItem2.propertyId;
        if (this.selectedSupplierListItem2.supplyId == null || this.selectedSupplierListItem2.supplyId == undefined)
        {
            this.issue = 'supply1';
            this.load = false;
            return;
        }
        else
            this.input.supplyId = this.selectedSupplierListItem2.supplyId;
        if (this.selectedMeterListItem2.meterId == null || this.selectedMeterListItem2.meterId == undefined)
        {
            this.issue = 'meter1';
            this.load = false;
            return;
        }
        else
            this.input.meterId = this.selectedMeterListItem2.meterId;
        if (this.readingFromDate == null || this.readingFromDate == undefined) {
            this.issue = 'fromDate';
            this.load = false;
            return;
        }
        else
            this.input.readingFromDate = this.datepipe.transform(this.readingFromDate, 'yyyy-MM-dd');
        if (this.readingToDate == null || this.readingToDate == undefined) {
            this.issue = 'toDate';
            this.load = false;
            return;
        }
        else
            this.input.readingToDate = this.datepipe.transform(this.readingToDate, 'yyyy-MM-dd');
        this._viewService.getAllMeterReadings(this.input).then(
            value => {
                this.meterReadings = value;
                this.load = false;
            }
        );        
    }

    onDateSelect(date: Date, value: number) {        
        if (value == 1)
            this.readingDate = date;
        else if (value == 2)
            this.readingFromDate = date;
        else
            this.readingToDate = date;
    }

    clickEventForNotes(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "add-note-modal") {
            this.notesExpanded = false;
        }
        if (idAttr == "view-note"){
            this.notesViewExpanded = false;
        }
    }

    viewEditAccount() {
        this.selectedAccount = JSON.parse(JSON.stringify(this.accountSelected));
        this.expanded = true;
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    getAccountById() {
        this.load = true;
        this._viewService.getAccountById(this.param).then(value => {
            this.accountSelected = value;
            if (this.accountSelected.billablePerson == undefined || this.account.billablePerson == null) {
                this.accountSelected.billablePerson = this.billablePerson;
            }
            if (this.accountSelected.address == undefined || this.account.address == null) {
                this.accountSelected.address = new Address();
            }
            this.load = false;
        });
    }

    addNewBillablePerson() {
        this.selectedAccount.billablePerson.push(new BillablePerson());
    }

    removeLastBillablePerson() {
        this.selectedAccount.billablePerson.pop();
    }

    updateAccount() {
        this.load = true;
        this.submitted = true;
        if (this.accountForm.invalid)
            return;
        var flag = false;
        if (this.selectedAccount != undefined) {
            if (this.selectedAccount.billablePerson != undefined && this.selectedAccount.billablePerson.length > 0) {
                this.selectedAccount.billablePerson.forEach((element) => {
                    if (element.firstName == undefined || element.firstName == '')
                    { flag = true; }
                    if (element.lastName == undefined || element.lastName == '')
                    { flag = true; }
                    if (element.titles == undefined)
                    { flag = true; }
                });
            }
        }
        if (flag)
            return;
        this._tablesDataService.updateAccount(this.selectedAccount).subscribe(
            data => {
                this.getAccountById();
                this.expanded = false;
                this.submitted = false;
                this.selectedAccount = new Account();
                this.load = false;
                swal({ type: 'success', title: 'Account updated successfully', showConfirmButton: true });
            }, Error => {
                this.load = false;
                this.expanded = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }

    addNotes() {
        this.load = true;
        this.notes.accountId = Number(this.param);
        this.notes.attachment = this.uploadedFile;
        if ((this.notes.attachment == null || this.notes.attachment == undefined) && (this.notes.summary == null || this.notes.summary == undefined))
        {
            swal({ type: 'info', title: 'No data entered', showConfirmButton: true });
            this.load = false;
            return;
        }
        this._viewService.createNotes(this.notes).subscribe(
            data => {
                this.getAccountById();
                this.load = false;
                this.notesExpanded = false;
                swal({ type: 'success', title: 'Notes added successfully', showConfirmButton: true });
            },
            Error => {
                this.notesExpanded = false;
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }

    viewAddNote() {
        this.notes = new Notes();
        this.notesExpanded = true;
        this.uploadedFile = null;
        this.fileName = null;
        this.notes.fileName = null;
        this.notes.attachment = null;
    }

    removeAttachment() {
        let message: string = "";
        if (this.uploadedFile != null || this.uploadedFile != undefined) {
            message = "Attachment removed successfully";
        } else {
            message = "There is no attachment to remove!";
        }
        this.uploadedFile = null;
        this.fileName = null;
        this.notes.fileName = null;
        this.notes.attachment = null;
        swal({ type: 'info', title: message, showConfirmButton: true });
    }

    viewNote(item: Notes) {
        this.notesViewExpanded = true;
        this.notes = item;
    }

    onFileChanged(event) {
        if (event.target.files && event.target.files[0]) {
            this.fileName = event.target.files[0].name;            
            if (!this.validateFile(this.fileName)) {
                this.notes.fileName = undefined;
                this.notes.attachment = undefined;
                this.fileName = undefined;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Selected file format is not supported. Kindly upload a csv file'
                });
                return;
            }
            this.notes.fileName = this.fileName;
            var reader = new FileReader();
            reader.onload = (event: ProgressEvent) => {
                this.uploadedFile = (<FileReader>event.target).result;
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    }
    validateFile(name: string) {        
        var ext = name.substring(name.lastIndexOf('.') + 1);
        if (ext.toLowerCase() == 'txt') {
            return true;
        }
        else {
            return false;
        }
    }

    downloadNotesAttachment() {
        this._viewService.getAttachmentForNoteId(this.notes.fileName, this.notes.noteId);
    }

    updatePinStatus(pin: boolean, noteId: number) {
        this._viewService.updatePinStatus(noteId, pin).subscribe(
            data => {
                this.getAccountById();
            },
            Error => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }

    updateCustomerMood(mood: string) {
        this._viewService.updateCustomermood(this.param, mood).subscribe(
            data => {
                this.getAccountById();
            },
            Error => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }

    updateAccountStatus(status: string) {
        this._viewService.updateAccountStatus(this.param, status).subscribe(
            data => {
                this.getAccountById();
            },
            Error => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }

    setWidth(wid: string, text: string) {
        this.width = wid + '%';
        this.progressBarText = text;
    }

    getAllPropertiesToMoveInToTheAccount() {
        if (this.accountSelected != null && this.accountSelected != undefined && this.accountSelected.network != null && this.accountSelected.network != undefined) {
            this._viewService.getAllPropertyToMoveInForAccount(this.param, this.accountSelected.network.networkId).then(
                value => {
                    this.propertiesToMoveInToAccount = value;
                }
            );
        }
    }

    getAllPropertiesInAccount(page: number) {
        this._viewService.getAllPropertiesForAccount(this.param).then(value => {
            this.propertiesInAccount = value;
            this.selectedPropertyString = "";
            this.selectedAssociationId = undefined;
            this.propertiesFlag = page;
        });
    }

    displayViewProperties(page: number) {
        this.model = null;
        this.getAllPropertiesInAccount(page);
    }

    getAllPropertiesToMoveIn() {        
        this._viewService.getAllPropertyToMoveInForAccount(this.param, this.accountSelected.network.networkId).then(
            value => {
                this.propertiesToMoveInToAccount = value;
                this.selectedPropertyString = "";
                this.selectedPropertyId = undefined;
                this.propertiesFlag = 3;
            }
        );
    }
    displayProgressBarForDrop(value: number) {
        if (this.selectedPropertyIdForDropDown != undefined && this.selectedPropertyIdForDropDown != null && this.selectedPropertyIdForDropDown != 0) {
            this.displayProgressBar(value, this.selectedPropertyIdForDropDown);
        }
    }
    displayViewPropertiesToMoveIn() {
        this.selectedPropertyInAccount = new PropertyAccountModel();
        this.model = null;
        this.getAllPropertiesToMoveIn();
    }

    updatePropertyAddressString() {
        this.selectedPropertyString = "";
        if (this.selectedPropertyId == null || this.selectedPropertyId == undefined)
            return;
        this.getActiveDateForProperty(this.selectedPropertyId.toString(), true);
        this.propertiesToMoveInToAccount.forEach(item => {
            if (item.propertyId == this.selectedPropertyId) {
                if (item.address != null && item.address != undefined) {
                    this.selectedPropertyString = item.address.addressLine1 + item.address.addressLine2;
                }                  
            }
        });
    }

    updateAssociationAddressString() {
        this.selectedPropertyString = "";
        if (this.selectedAssociationId == null || this.selectedAssociationId == undefined)
            return;
        this.getActiveDateForProperty(this.selectedAssociationId.toString(), false);
        this.propertiesInAccount.forEach(item => {
            if (item.associationId == this.selectedAssociationId) {
                if (item.propertyAddress != null && item.propertyAddress != undefined) {
                    this.selectedPropertyString = item.propertyAddress.addressLine1 + item.propertyAddress.addressLine2;
                }
            }
        });
    }

    moveOutFromProperty() {
        let endDate: Date = null;
        let endDateString: string = null;
        if (this.selectedAssociationId == null || this.selectedAssociationId == undefined) {
            swal({ type: 'info', title: 'Kindly select a property to move out from!', showConfirmButton: true });
            return;
        }
        if (this.model == null || this.model == undefined)
        {
            swal({ type: 'info', title: 'Kindly select the date', showConfirmButton: true });
            return;
        }
        if (this.model.date.month == 1) {
            endDate = new Date(this.model.date.year - 1, this.model.date.month + 11, this.model.date.day);
        } else {
            endDate = new Date(this.model.date.year, this.model.date.month - 1, this.model.date.day);
        }
        endDateString = endDate.getDate().toString() + '/' + (endDate.getMonth() + 1) + '/' + endDate.getFullYear().toString();
        this._viewService.moveOutFromPropertyForAccount(this.selectedAssociationId, endDateString).subscribe(
            data => {
                swal({ type: 'success', title: 'MoveOut process started for the Property', showConfirmButton: true });
            },
            Error => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }

    moveInToProperty() {
        if (this.selectedPropertyId == null || this.selectedPropertyId == undefined || this.selectedPropertyId == 0) {
            swal({ type: 'info', title: 'Kindly select a property to move into!', showConfirmButton: true });
            return
        } else {
            this.selectedPropertyInAccount.propertyId = this.selectedPropertyId;
        }
        if (this.model == null || this.model == undefined) {
            swal({ type: 'info', title: 'Kindly select the date', showConfirmButton: true });
            return;
        } else {
            if (this.model.date.month == 1) {
                this.selectedPropertyInAccount.startDate = new Date(this.model.date.year - 1, this.model.date.month + 11, this.model.date.day);
            } else {
                this.selectedPropertyInAccount.startDate = new Date(this.model.date.year, this.model.date.month - 1, this.model.date.day);
            }
        }
        if (this.param != null) {
            this.selectedPropertyInAccount.accountId = parseInt(this.param);
        }else {
            swal({ type: 'info', title: 'Account id is not set, Kindly reload the page', showConfirmButton: true });
            return;
        }
           
        this._viewService.postPropertyToMoveIn(this.selectedPropertyInAccount).subscribe(
            data => {
                //alert(data['_body']);
                swal({ type: 'info', title: data['_body'], showConfirmButton: true });
            },
            Error => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                });
            }
        );
    }

    addMeterReading() {     
        this.load = true;
        this.reinitializeErrorList();
        this.issue = '';
        let meterReading = new MeterReading();
        if (this.selectedPropertyListItem.propertyId == null || this.selectedPropertyListItem.propertyId == undefined) {
            this.issue = 'property';
            this.load = false;
            return;
        }
        if (this.selectedSupplierListItem.supplyId == null || this.selectedSupplierListItem.supplyId == undefined) {
            this.issue = 'supply';
            this.load = false;
            return;
        } 
        if (this.selectedMeterListItem.meterId == null || this.selectedMeterListItem.meterId == undefined) {
            this.issue = 'meter';
            this.load = false;
            return;
        } else {
            meterReading.meter.meterId = this.selectedMeterListItem.meterId;
        }
        if (this.readingDate == null || this.readingDate == undefined)
        {
            this.load = false;
            this.issue = 'date';
            return;
        } else {
            meterReading.readingDateTime = this.datepipe.transform(this.readingDate, "dd-MM-yyyy hh:mm:ss");
        }
        if (!this.validateMeterReading()) {
            this.load = false;
            return;
        }
        meterReading.method = 'Client Manual';
        for (let i = 0; i < this.reading.length; i++) {
            if (this.reading[i] != null && this.reading[i] != undefined) {
                if (this.reading[i].reading == 'MeterReading')
                    meterReading.meterReading = this.reading[i].value;
                if (this.reading[i].reading == 'FlowTemp')
                    meterReading.flowTemperature = this.reading[i].value;
                if (this.reading[i].reading == 'ReturnTemp')
                    meterReading.returnTemperature = this.reading[i].value;
                if (this.reading[i].reading == 'InstantaneousFlow')
                    meterReading.instantaneousFlow = this.reading[i].value;
                if (this.reading[i].reading == 'TotalVolume')
                    meterReading.totalVolume = this.reading[i].value;
            }
        }
        this._viewService.addMeterReading(meterReading).subscribe(
            data => {
                this.load = false;
                swal({ type: 'success', title: 'Meter reading added successfully', showConfirmButton: true });
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                });
            }
        );
    }

    reinitializeErrorList() {
        for (let i = 0; i < this.errorList.length; i++) {
            this.errorList[i] = false;
        }
    }

    validateMeterReading() {
        if (this.reading.length == 1)
        {
            if (this.reading[0] == null || this.reading[0] == undefined) {
                this.errorList[0] = true;
                return false;
            }
            if (this.reading[0].value == null || this.reading[0].value == undefined || this.reading[0].value == 0) {
                this.errorList[0] = true;
                return false;
            }
            if (this.reading[0].reading == null || this.reading[0].reading == undefined) {
                this.errorList[0] = true;
                return false;
            }
        }
        for (let i = 0; i < this.reading.length; i++) {
            let item = this.reading[i];
            for (let j = i + 1; j < this.reading.length; j++) {
                if (this.reading[i].reading == this.reading[j].reading) {
                    this.errorList[i] = true;
                    this.errorList[j] = true;
                    return false;
                }
            }
        }
        return true;
    }

    getListOfPropertiesUnderMovementInside() {
        this.selectedPropertyIdForDropDown = 0;
        this.progress = false;
        this.progressValue = undefined;

        this.propertiesFlag = 4;
        var defaultValue = new Property();
        defaultValue.propertyId = 0;
        defaultValue.address.addressLine1 = "Select";
        this._viewService.getAllPropertyUnderMovementInside(this.param, this.accountSelected.network.networkId).then(
            value => {
                this.propertiesUnderProcessToMoveIn = value;
                this.propertiesUnderProcessToMoveIn.push(defaultValue);
            }
        );
    }

    displayProgressBar(value: number, propertyId: number) {
        this.progress = true;
        if (value == 1)
            this.getMoveInStatusForAccountAndProperty(propertyId, value);
        else if (value == 2)
            this.getMoveOutStatusForAccountAndProperty(propertyId, value);
    }

    getListOfPropertiesUnderMovementOutside() {
        this.selectedPropertyIdForDropDown = 0;
        this.progress = false;
        this.progressValue = undefined;

        this.propertiesFlag = 5;
        var defaultValue = new Property();
        defaultValue.propertyId = 0;
        defaultValue.address.addressLine1 = "Select";
        this._viewService.getAllPropertyUnderMovementOutside(this.param, this.accountSelected.network.networkId).then(
            value => {
                this.propertiesUnderProcessToMoveOut = value;
                this.propertiesUnderProcessToMoveOut.push(defaultValue);
            }
        );
    }

    getPropertyDropDownListItemForAccountId() {
        this._viewService.getPropertyDropdownListForAccountId(this.param).then(
            value => {
                this.propertyDropDownList = value;
                this.propertyDropDownList2 = value;
            }
        );
    }

    fetchSupplyListItems(value: number) {
        if (value == 1) {
            for (var i = 0; i < this.propertyDropDownList.length; i++) {
                let propertyDropSelected = this.propertyDropDownList[i];
                if (this.selectedPropertyListItem != null) {
                    if (this.selectedPropertyListItem.propertyId == propertyDropSelected.propertyId) {
                        this.supplierDropDownList = propertyDropSelected.supplyList;
                        this.fetchMeterListItems(1);
                        break;
                    }
                }
            }
        } else {
            for (var i = 0; i < this.propertyDropDownList2.length; i++) {
                let propertyDropSelected = this.propertyDropDownList2[i];
                if (this.selectedPropertyListItem2 != null) {
                    if (this.selectedPropertyListItem2.propertyId == propertyDropSelected.propertyId) {
                        this.supplierDropDownList2 = propertyDropSelected.supplyList;
                        this.fetchMeterListItems(2);
                        break;
                    }
                }
            }
        }
    }

    fetchMeterListItems(value: number) {
        if (value == 1) {
            for (var i = 0; i < this.supplierDropDownList.length; i++) {
                let supplierDropSelected = this.supplierDropDownList[i];
                if (this.selectedSupplierListItem != null && this.selectedSupplierListItem != undefined) {
                    if (this.selectedSupplierListItem.supplyId == supplierDropSelected.supplyId) {
                        this.meterDropDownList = supplierDropSelected.meterList;
                        if (this.meterDropDownList != undefined && this.meterDropDownList != null && this.meterDropDownList.length > 0) {
                            this.selectedMeterListItem = this.meterDropDownList[0];
                        }
                        break;
                    }
                }
            }
        } else {
            for (var i = 0; i < this.supplierDropDownList2.length; i++) {
                let supplierDropSelected = this.supplierDropDownList2[i];
                if (this.selectedSupplierListItem2 != null && this.selectedSupplierListItem2 != undefined) {
                    if (this.selectedSupplierListItem2.supplyId == supplierDropSelected.supplyId) {
                        this.meterDropDownList2 = supplierDropSelected.meterList;
                        if (this.meterDropDownList2 != undefined && this.meterDropDownList2 != null && this.meterDropDownList2.length > 0) {
                            this.selectedMeterListItem2 = this.meterDropDownList2[0];
                        }
                        break;
                    }
                }
            }
        }
    }

    getMoveOutStatusForAccountAndProperty(propertyId: number, value: number) {
        this._viewService.getStatusForAccountAndProperty(this.param, propertyId, value).then(
            value => {
                this.progressValue = value['_body'];
                if (this.progressValue == undefined || this.progressValue == null) {
                    this.setWidth('0', '');
                } else if (this.progressValue == 'Pending') {
                    this.setWidth('30', 'Initiated');                
                } else if (this.progressValue == 'PreviousReading') {
                    this.setWidth('60', 'Waiting for Current meter reading');
                } else if (this.progressValue == 'CurrentReading') {
                    this.setWidth('90', 'Waiting to Complete');
                }
            }
        );
    }

    getMoveInStatusForAccountAndProperty(propertyId: number, value: number) {
        this._viewService.getStatusForAccountAndProperty(this.param, propertyId, value).then(
            value => {
                this.progressValue = value['_body'];
                if (this.progressValue == undefined || this.progressValue == null) {
                    this.setWidth('0', '');
                } else if (this.progressValue == 'Pending') {
                    this.setWidth('10', 'Initiated');
                } else if (this.progressValue == 'SanityCheck') {
                    this.setWidth('20', 'Waiting to close previous active Tenant');
                } else if (this.progressValue == 'PreviousTenant') {
                    this.setWidth('40', 'Waiting for previous meter reading');
                } else if (this.progressValue == 'PreviousReading') {
                    this.setWidth('60', 'Waiting for Current meter reading');
                } else if (this.progressValue == 'CurrentReading') {
                    this.setWidth('80', 'Waiting to Complete');
                }
            }
        );
    }

    updatePendingToSanityCheck() {
        this.load = true;
        this._viewService.changePendingToSanityCheck(this.param, this.selectedPropertyIdForDropDown).then(            
            value => {
                this.load = false;
                //alert(value['_body']);
                swal({ type: 'info', title: value['_body'], showConfirmButton: true });
                this.getMoveInStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 1);
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }

    updateSanityToPreviousTenant() {
        this.load = true;
        this._viewService.changeSanityToPreviousTenant(this.param, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                //alert(value['_body']);
                swal({ type: 'info', title: value['_body'], showConfirmButton: true });
                this.getMoveInStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 1);
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }
    updatePreviousTenantToPreviousMeterReading() {
        this.load = true;
        this._viewService.changePreviousTenantToPreviousMeterReading(this.param, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                //alert(value['_body']);
                swal({ type: 'info', title: value['_body'], showConfirmButton: true });
                this.getMoveInStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 1);
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }
    updatePreviousMeterReadingToCurrentMeterReading() {
        this.load = true;
        this._viewService.changePreviousMeterReadingToCurrentMeterReading(this.param, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                //alert(value['_body']);
                swal({ type: 'info', title: value['_body'], showConfirmButton: true });
                this.getMoveInStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 1);
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }
    updateCurrentReadingToCompleted() {
        this.load = true;
        this._viewService.changeCurrentReadingToCompleted(this.param, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                //alert(value['_body']);
                swal({ type: 'info', title: value['_body'], showConfirmButton: true });
                //this.getMoveInStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 1);
                this.getListOfPropertiesUnderMovementInside();
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }
    updatePendingToPreviousMeterReadingForTenantOut() {
        this.load = true;
        this._viewService.changePendingToPreviousMeterReadingForTenantOut(this.param, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                //alert(value['_body']);
                swal({ type: 'info', title: value['_body'], showConfirmButton: true });
                this.getMoveOutStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 2);
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }
    updatePreviousMeterReadingToCurrentMeterReadingForTenantOut() {
        this.load = true;
        this._viewService.changePreviousMeterReadingToCurrentMeterReadingForTenantOut(this.param, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                //alert(value['_body']);
                swal({ type: 'info', title: value['_body'], showConfirmButton: true });
                this.getMoveOutStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 2);
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }

    updateCurrentReadingToCompletedForTenantOut() {
        this.load = true;
        this._viewService.changeCurrentReadingToCompletedForTenantOut(this.param, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                //alert(value['_body']);
                swal({ type: 'info', title: value['_body'], showConfirmButton: true });
                //this.getMoveOutStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 2);
                this.getListOfPropertiesUnderMovementOutside();
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }

    getAllTransactionsForAccount() {
        this._viewService.getAllTransactionsForAccount(this.param).then(
            value => {
                this.transactions = value;
            }
        );
    }

    addNewTransaction() {
        this.load = true;
        this.submit = false;
        if (this.transaction.amount == null || this.transaction.amount == undefined) {
            this.load = false;
            this.submit = true;
            return;
        }
        if (this.transaction.paymentTypeId == null || this.transaction.paymentTypeId == undefined) {
            this.load = false;
            this.submit = true;
            return;
        }
        if (this.transaction.paymentMethodId == null || this.transaction.paymentMethodId == undefined)
        {
            this.load = false;
            this.submit = true;
            return;
        }
        if (this.transactionDate != null) {
            if (this.transactionDate.date.month == 1) {
                this.transaction.date = new Date(this.transactionDate.date.year - 1, this.transactionDate.date.month + 11, this.transactionDate.date.day);
            } else {
                this.transaction.date = new Date(this.transactionDate.date.year, this.transactionDate.date.month - 1, this.transactionDate.date.day);
            }
        } else {
            this.load = false;
            this.submit = true;
            return;
        }
        this.transaction.accountId = Number.parseInt(this.param);
        this._viewService.createNewTransaction(this.transaction).subscribe(
            data => {
                this.load = false;
                this.getAllTransactionsForAccount();
                this.getAccountBalance();
                swal({ type: 'success', title: 'Transaction added successfully', showConfirmButton: true });
            },
            Error => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }

    getAllPaymentTypes() {
        this._viewService.getAllPaymentTypes().then(
            value => {
                this.paymentTypes = value;
            }
        );
    }

    getAllPaymentMethods() {
        this._viewService.getAllPaymentMethods().then(
            value => {
                this.paymentMethods = value;
            }                
        )
    }

    viewAddTransaction() {
        this.showFinancials = true;
        this.transaction = new Transaction();
        let date = new Date();        
        this.getAllPaymentMethods();
        this.getAllPaymentTypes();
        this.getAllTransactionsForAccount();
    }
}