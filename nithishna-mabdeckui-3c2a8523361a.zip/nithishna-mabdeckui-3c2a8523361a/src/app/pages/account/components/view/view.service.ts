﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, URLSearchParams, Headers } from '@angular/http';
import { environment } from "../../../../../environments/environment";
import { IAccount, INotes } from "../../../../shared/interface";
import { Account, PropertyAccountModel, Property, PropertyListItem, MeterReadingItem, MeterReadingSearch, MeterReading, Transaction, PaymentType, PaymentMethod, AccountBalance, MyDate } from "../../../../shared/class";

@Injectable()
export class ViewService {
    constructor(private http: Http) { }
    financeUrl = environment.host + 'financial';
    accountUrl = environment.host + 'account/';
    notesUrl = environment.host + 'notes';
    attachmentUrl = environment.host + 'notes-attachment?note_id=';
    accountStatusUrl = environment.host + 'account_status?account_id=';
    customerMoodUrl = environment.host + 'account_holder_mood?account_id=';
    getmoveInPropertyUrl = environment.host + 'property-to-move-in?account_id=';
    paymentMethodUrl = environment.host + 'payment-method';
    paymentTypeUrl = environment.host + 'payment-type';
    getMoveInUnderPropertyUrl = environment.host + 'properties-under-movement-inside?account_id=';
    getMoveOutUnderPropertyUrl = environment.host + 'properties-under-movement-outside?account_id=';

    viewPropertyUrl = environment.host + 'property-association?account_id=';
    moveOutPropertyUrl = environment.host + 'property-moveout?association_id=';
    postPropertyMovein = environment.host + 'property-movein';
    propertyDropListUrl = environment.host + 'property-drop-list?account_id=';
    meterReadingsUrl = environment.host + 'meter-reading-details';
    createMeterReadingUrl = environment.host + 'meter-reading';
    propertyStatusUrl = environment.host + 'property-status?property_id=';
    changePendingToSanityCheckUrl = environment.host + 'pending-to-sanity?property_id=';
    changeSanityToPreviousTenantUrl = environment.host + 'sanity-to-previous-tenant?property_id=';
    changePreviousTenantToPreviousMeterReadingUrl = environment.host + 'previous-tenant-to-previous-reading?property_id=';
    changePreviousMeterReadingToCurrentMeterReadingUrl = environment.host + 'previous-reading-to-current-reading?property_id=';
    changeCurrentReadingToCompletedUrl = environment.host + 'current-reading-to-completed?property_id=';
    changePendingToPreviousMeterReadingForTenantOutUrl = environment.host + 'tenant-out-pending-to-previous-reading?property_id=';
    changePreviousMeterReadingToCurrentMeterReadingForTenantOutUrl = environment.host + 'tenant-out-previous-to-current-reading?property_id=';
    changeCurrentReadingToCompletedForTenantOutUrl = environment.host + 'tenant-out-current-reading-to-completed?property_id=';
    accountBalanceUrl = environment.host + 'account-balance?account_id=';
    tenureTypeParam = "&tenureType=tenant";
    activeDateUrl = environment.host + 'active_property_date?propertyId=';

    getActiveDateForProperty(propertyId: string, isProperty: boolean) {
        let url = this.activeDateUrl + propertyId + "&isProperty=" + isProperty;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as MyDate);
    }

    getAccountBalance(accountId: String) {
        let URL = this.accountBalanceUrl + accountId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(URL, { headers: headers }).
            toPromise().then((res) => res.json() as AccountBalance);
    }

    getAllPaymentTypes() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.paymentTypeUrl, { headers: headers })
            .toPromise()
            .then((res) => res.json() as PaymentType[]);
    }

    getAllPaymentMethods() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.paymentMethodUrl, { headers: headers })
            .toPromise()
            .then((res) => res.json() as PaymentMethod[]);
    }

    getAllTransactionsForAccount(accountId: string) {
        let url = this.financeUrl + "?account_id=" + accountId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, { headers: headers })
            .toPromise()
            .then((res) => res.json() as Transaction[]);
    }

    createNewTransaction(transaction: Transaction) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .post(this.financeUrl, transaction, { headers: headers });
    }

    changePendingToSanityCheck(accountId: string, propertyId: number) {
        let url = this.changePendingToSanityCheckUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url,'', { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    changeSanityToPreviousTenant(accountId: string, propertyId: number) {
        let url = this.changeSanityToPreviousTenantUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    changePreviousTenantToPreviousMeterReading(accountId: string, propertyId: number) {
        let url = this.changePreviousTenantToPreviousMeterReadingUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    changePreviousMeterReadingToCurrentMeterReading(accountId: string, propertyId: number) {
        let url = this.changePreviousMeterReadingToCurrentMeterReadingUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }


    changeCurrentReadingToCompleted(accountId: string, propertyId: number) {
        let url = this.changeCurrentReadingToCompletedUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }


    changePendingToPreviousMeterReadingForTenantOut(accountId: string, propertyId: number) {
        let url = this.changePendingToPreviousMeterReadingForTenantOutUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }


    changePreviousMeterReadingToCurrentMeterReadingForTenantOut(accountId: string, propertyId: number) {
        let url = this.changePreviousMeterReadingToCurrentMeterReadingForTenantOutUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    changeCurrentReadingToCompletedForTenantOut(accountId: string, propertyId: number) {
        let url = this.changeCurrentReadingToCompletedForTenantOutUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    getStatusForAccountAndProperty(accountId: string, propertyId: number, value: number) {
        let url = this.propertyStatusUrl + propertyId + '&account_id=' + accountId + '&value='+value;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    postPropertyToMoveIn(propertyAccount: PropertyAccountModel) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.postPropertyMovein, propertyAccount, { headers: headers });
    }

    moveOutFromPropertyForAccount(associationId: number, endDate: string) {
        let url = this.moveOutPropertyUrl + associationId + '&end_date=' + endDate;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, "", {
            headers: headers
        });
    }

    addMeterReading(meterReading: MeterReading) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .post(this.createMeterReadingUrl, meterReading, { headers: headers });
    }

    getAllMeterReadings(input: MeterReadingSearch) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .post(this.meterReadingsUrl, input, { headers: headers })
            .toPromise()
            .then((res) => res.json() as MeterReadingItem[]);
    }

    getAllPropertiesForAccount(accountId: string) {
        let url = this.viewPropertyUrl + accountId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as PropertyAccountModel[]);
    }

    getAllPropertyToMoveInForAccount(accountId: string, networkId: number) {
        let url = this.getmoveInPropertyUrl + accountId + "&network_id=" + networkId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as Property[]);
    }

    getAllPropertyUnderMovementOutside(accountId: string, networkId: number) {
        let url = this.getMoveOutUnderPropertyUrl + accountId + "&network_id=" + networkId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as Property[]);
    }

    getAllPropertyUnderMovementInside(accountId: string, networkId: number) {
        let url = this.getMoveInUnderPropertyUrl + accountId + "&network_id=" + networkId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as Property[]);
    }

    getAccountById(accountId: string) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let url = this.accountUrl + accountId.toString();
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as Account);
    }


    createNotes(notes: INotes) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.notesUrl, notes, {
            headers: headers
        });
    }

    updatePinStatus(noteId: number, pin: boolean) {
        let url = this.notesUrl + '?pin=' + pin + '&note_id=' + noteId;
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, "", {
            headers: headers
        });
    }

    updateCustomermood(accountId: string, mood: string) {
        let url = this.customerMoodUrl + accountId + '&mood=' + mood;
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, "", {
            headers: headers
        });
    }

    updateAccountStatus(accountId: string, status: string) {
        let url = this.accountStatusUrl + accountId + '&status=' + status;
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, "", {
            headers: headers
        });
    }

    downloadFile(data: any, filename: string) {
        var blob = new Blob([data], { type: 'text/plain' });
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    getAttachmentForNoteId(filename: string, noteId: number) {
        let url = this.attachmentUrl + noteId.toString();
        this.getFile(url).subscribe(data => {
            let parsedResponse = data.text();
            this.downloadFile(parsedResponse, filename)
        }, error => console.log("Error downloading the file."),
            () => console.info("OK"));
    }

    getFile(url: string) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(url, { headers: headers });
    }

    getPropertyDropdownListForAccountId(accountId: string) {
        let url = this.propertyDropListUrl + accountId;
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' + localStorage.getItem('token'));
        return this.http.get(url, { headers: headers }).toPromise().then((res) => res.json() as PropertyListItem[]);
    }
}
