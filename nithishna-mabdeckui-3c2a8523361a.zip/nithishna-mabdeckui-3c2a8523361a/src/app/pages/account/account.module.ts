﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { routing } from './account.routing';
import { SharedModule } from '../../shared/shared.module';
import { AccountComponent } from './account.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { MainComponent } from "./components/main/main.component";
import { ViewComponent } from "./components/view/view.component";
import { LayoutModule } from "../../shared/layout.module";
import { MyDatePickerModule } from 'mydatepicker';
import { AngularDateTimePickerModule } from 'angular2-datetimepicker';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        routing,
        NgxPaginationModule,        
        LayoutModule,
        MyDatePickerModule,
        AngularDateTimePickerModule
    ],
    declarations: [
        AccountComponent,
        MainComponent,
        ViewComponent
    ]
})
export class AccountModule { }
