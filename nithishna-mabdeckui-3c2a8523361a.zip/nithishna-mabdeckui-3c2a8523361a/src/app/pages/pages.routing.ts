﻿import { Routes, RouterModule } from '@angular/router';
import { PagesComponent } from './pages.component';

export const childRoutes: Routes = [
    {
        path: 'pages',
        component: PagesComponent,
        children: [
            { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
            { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
            { path: 'imports', loadChildren: './importsgroup/importsgroup.module#ImportsGroupModule' },
            { path: 'reports', loadChildren: './reportsgroup/reportsgroup.module#ReportsGroupModule' },
            { path: 'validation', loadChildren: './validationgroup/validationgroup.module#ValidationGroupModule' },
            { path: 'finance', loadChildren: './financegroup/financegroup.module#FinanceGroupModule' },
            { path: 'correspondence', loadChildren: './correspondence/correspondence.module#CorrespondenceModule' },
            { path: 'statements', loadChildren: './statementsgroup/statementsgroup.module#StatementsGroupModule' },
            { path: 'account', loadChildren: './account/account.module#AccountModule' },
            { path: 'properties', loadChildren: './properties/properties.module#PropertiesModule' },
            { path: 'onboarding', loadChildren: './onboarding/onboarding.module#OnboardingModule' },
            { path: 'icon', loadChildren: './icon/icon.module#IconModule' }
        ]
    }
];

export const routing = RouterModule.forChild(childRoutes);
