﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, URLSearchParams, Headers } from '@angular/http';
import { environment } from "../../../../../environments/environment";
import { IPropertyWithOwner } from "../../../../shared/interface";

@Injectable()
export class MainService {
    constructor(private http: Http) { }
    properiesUrl = environment.host + 'property-owner-list';

    getAllPropertiesWithOwnerAndTenant() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.properiesUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IPropertyWithOwner[]);
    }
}
