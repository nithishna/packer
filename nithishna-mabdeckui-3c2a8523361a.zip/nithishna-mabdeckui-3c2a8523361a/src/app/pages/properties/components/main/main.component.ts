﻿import { Component, OnInit } from '@angular/core';
import { MainService } from './main.service';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalService } from "../../../../shared/services/global.service";
import { IPropertyWithOwner } from "../../../../shared/interface";
@Component({
    selector: 'app-properties-main',
    templateUrl: './main.component.html',
    styleUrls: ['./main.component.scss'],
    providers: [MainService]
})
export class MainComponent implements OnInit {
    tableData: IPropertyWithOwner[];

    /* pagination Info */
    pageSize = 10;
    pageNumber = 1;
    load: Boolean = false;

    constructor(private _tablesDataService: MainService, public router: Router, private _globalService: GlobalService) { }

    ngOnInit() {
        this.authenticationCheck();
        this.loadData();
    }

    loadData() {
        this.load = true;        
        this._tablesDataService.getAllPropertiesWithOwnerAndTenant().then(
            value => {
            this.tableData = value;
            this.load = false;}
        );
    }

    pageChanged(pN: number): void {
        this.pageNumber = pN;
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

}