﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, URLSearchParams, Headers } from '@angular/http';
import { environment } from "../../../../../environments/environment";
import { IAccount, INotes, IAccountLimited } from "../../../../shared/interface";
import { Account, PropertyAccountModel, Property, PropertyListItem, MeterReadingItem, MeterReadingSearch, MeterReading, AccountOwnerTenant, PropertyAccountAssociation, MyDate, PropertyAccountAssociationLimited, Notes } from "../../../../shared/class";

@Injectable()
export class ViewService {
    constructor(private http: Http) { }
    createMeterReadingUrl = environment.host + 'meter-reading';
    meterReadingsUrl = environment.host + 'meter-reading-for-property';
    propertyListUrl = environment.host + 'property-list/';
    accountDropDownUrl = environment.host + 'all-account/';
    ownerforPropertyUrl = environment.host + 'owner?propertyId=';
    ownerAndTenantForPropertyUrl = environment.host + 'owner-and-tenant?property_id=';
    notesUrl = environment.host + 'notes';
    attachmentUrl = environment.host + 'notes-attachment?note_id=';
    ownerPropertyUrl = environment.host + 'owner-property';
    activeDateUrl = environment.host + 'active_property_date?propertyId=';
    allOwnerForAccountUrl = environment.host + 'property';
    deletePropertyAssociation = environment.host + 'delete-association?association_id=';
    notesForAccountUrl = environment.host + 'notes?account_id=';
    getMoveInUnderPropertyUrl = environment.host + 'properties-under-movement-inside-owner?account_id=';
    getMoveOutUnderPropertyUrl = environment.host + 'properties-under-movement-outside-owner?account_id=';
    propertyStatusUrl = environment.host + 'owner-property-status?association_id=';

    changePendingToSanityCheckUrl = environment.host + 'pending-to-sanity?property_id=';
    changeSanityToPreviousTenantUrl = environment.host + 'sanity-to-previous-tenant?property_id=';
    changePreviousTenantToPreviousMeterReadingUrl = environment.host + 'previous-tenant-to-previous-reading?property_id=';
    changePreviousMeterReadingToCurrentMeterReadingUrl = environment.host + 'previous-reading-to-current-reading?property_id=';
    changeCurrentReadingToCompletedUrl = environment.host + 'current-reading-to-completed?property_id=';
    changePendingToPreviousMeterReadingForTenantOutUrl = environment.host + 'tenant-out-pending-to-previous-reading?property_id=';
    changePreviousMeterReadingToCurrentMeterReadingForTenantOutUrl = environment.host + 'tenant-out-previous-to-current-reading?property_id=';
    changeCurrentReadingToCompletedForTenantOutUrl = environment.host + 'tenant-out-current-reading-to-completed?property_id=';
    tenureTypeParam = "&tenureType=owner";

    getAllNotesForAccountId(accountId: number) {
        let url = this.notesForAccountUrl + accountId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(url, {
            headers: headers
        })
        .toPromise()
        .then((res) => res.json() as Notes[]);
    }

    updateAssociationToDeleted(associationId: number) {
        let url = this.deletePropertyAssociation + associationId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url,"", {
            headers: headers
        });
    }

    getAllTenantsForAccount(propertyId: string) {
        let url = this.allOwnerForAccountUrl + '/' + propertyId + '/tenant';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(url, {
            headers: headers
        })
            .toPromise()
            .then((res) => res.json() as PropertyAccountAssociationLimited[]);
    }

    getAllOwnerForAccount(propertyId: string) {
        let url = this.allOwnerForAccountUrl + '/' + propertyId + '/owner';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(url, {
            headers: headers
        })
        .toPromise()
        .then((res) => res.json() as PropertyAccountAssociationLimited[]);
    }

    getActiveDateForProperty(propertyId: string) {
        let url = this.activeDateUrl + propertyId + "&isProperty=true";
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as MyDate);
    }

    getOwnerForProperty(propertyId: string) {
        let url = this.ownerforPropertyUrl + propertyId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res);
    }

    getOwnerAndTenantForProperty(propertyId: string) {
        let url = this.ownerAndTenantForPropertyUrl + propertyId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as AccountOwnerTenant);
    }

    getAccountDropDownListForPropertyId(propertyId: string) {
        let url = this.accountDropDownUrl + propertyId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IAccountLimited[]);
    }

    getPropertyDropDownListItemForPropertyId(propertyId: string) {
        let url = this.propertyListUrl + propertyId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as PropertyListItem[]);
    }

    addMeterReading(meterReading: MeterReading) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .post(this.createMeterReadingUrl, meterReading, { headers: headers });
    }

    getAllMeterReadings(input: MeterReadingSearch) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .post(this.meterReadingsUrl, input, { headers: headers })
            .toPromise()
            .then((res) => res.json() as MeterReadingItem[]);
    }

    createNotes(notes: INotes) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.notesUrl, notes, {
            headers: headers
        });
    }

    updatePinStatus(noteId: number, pin: boolean) {
        let url = this.notesUrl + '?pin=' + pin + '&note_id=' + noteId;
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, "", {
            headers: headers
        });
    }

    getAttachmentForNoteId(filename: string, noteId: number) {
        let url = this.attachmentUrl + noteId.toString();
        this.getFile(url).subscribe(data => {
            let parsedResponse = data.text();
            this.downloadFile(parsedResponse, filename)
        }, error => console.log("Error downloading the file."),
            () => console.info("OK"));
    }

    getFile(url: string) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(url, { headers: headers });
    }

    downloadFile(data: any, filename: string) {
        var blob = new Blob([data], { type: 'text/plain' });
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    updateOwnerPropertyAssociation(association: PropertyAccountAssociationLimited) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.ownerPropertyUrl, association, {
            headers: headers
        });
    }

    getAllPropertyUnderMovementOutside(accountId: number) {
        let url = this.getMoveOutUnderPropertyUrl + accountId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as Property[]);
    }

    getAllPropertyUnderMovementInside(accountId: number) {
        let url = this.getMoveInUnderPropertyUrl + accountId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as Property[]);
    }

    getStatusForAccountAndProperty(propertyId: number, value: number) {
        let url = this.propertyStatusUrl + propertyId + '&value=' + value;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    changePendingToSanityCheck(accountId: number, propertyId: number) {
        let url = this.changePendingToSanityCheckUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    changeSanityToPreviousTenant(accountId: number, propertyId: number) {
        let url = this.changeSanityToPreviousTenantUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    changePreviousTenantToPreviousMeterReading(accountId: number, propertyId: number) {
        let url = this.changePreviousTenantToPreviousMeterReadingUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    changePreviousMeterReadingToCurrentMeterReading(accountId: number, propertyId: number) {
        let url = this.changePreviousMeterReadingToCurrentMeterReadingUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }


    changeCurrentReadingToCompleted(accountId: number, propertyId: number) {
        let url = this.changeCurrentReadingToCompletedUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }


    changePendingToPreviousMeterReadingForTenantOut(accountId: number, propertyId: number) {
        let url = this.changePendingToPreviousMeterReadingForTenantOutUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }


    changePreviousMeterReadingToCurrentMeterReadingForTenantOut(accountId: number, propertyId: number) {
        let url = this.changePreviousMeterReadingToCurrentMeterReadingForTenantOutUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }

    changeCurrentReadingToCompletedForTenantOut(accountId: number, propertyId: number) {
        let url = this.changeCurrentReadingToCompletedForTenantOutUrl + propertyId + '&account_id=' + accountId;
        url = url + this.tenureTypeParam;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(url, '', { headers: headers })
            .toPromise()
            .then((res) => res);
    }
}