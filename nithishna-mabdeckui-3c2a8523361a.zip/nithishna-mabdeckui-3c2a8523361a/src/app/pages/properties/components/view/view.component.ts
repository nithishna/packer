﻿import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { Router, ActivatedRoute } from '@angular/router';
import { ViewService } from "./view.service";
import { FormBuilder, FormGroup, Validators, FormsModule} from '@angular/forms';
import { IMyDpOptions } from 'mydatepicker';
import { DatePipe } from "@angular/common";
import { PropertyListItem, SupplyListItem, MeterListItem, MeterReadingItem, Reading, MeterReading, MeterReadingSearch, AccountOwnerTenant, PropertyAccountAssociation, MyDate, PropertyAccountAssociationLimited, Notes, Property } from "../../../../shared/class";
import { IAccountLimited, INotes } from "../../../../shared/interface";
@Component({
    selector: 'app-view-property',
    templateUrl: './view.component.html',
    styleUrls: ['./view.component.scss'],
    providers: [ViewService]
})
export class ViewComponent implements OnInit {
    notes: INotes;
    fileName: string;
    param: string;
    issue: string = '';
    viewNotes: boolean = false;
    edit: boolean = false;
    checked: boolean = false;
    ownerHistory: boolean = false;
    associationsFlag: boolean = false;
    accountSelectFlag: boolean = false;
    dateFlag: boolean = false;
    notesViewExpanded: Boolean = false;
    notesList: Notes[] = new Array(0);
    selectedPropertyListItem: PropertyListItem = new PropertyListItem();
    propertyDropDownList: PropertyListItem[];
    selectedSupplierListItem: SupplyListItem = new SupplyListItem();
    supplierDropDownList: SupplyListItem[];
    selectedMeterListItem: MeterListItem = new MeterListItem();
    meterDropDownList: MeterListItem[];
    associations: PropertyAccountAssociationLimited[] = new Array(0);
    readingDate: Date = new Date();
    accountOwner: AccountOwnerTenant = new AccountOwnerTenant();
    settings = {
        bigBanner: true,
        timePicker: true,
        format: 'dd-MM-yyyy hh:mm',
        defaultOpen: false,
        closeOnSelect: true
    }
    width: string = '0%';
    selectedPropertyIdForDropDown: number = 0;
    progress: boolean = false;
    progressValue: string = undefined;
    propertiesUnderProcessToMoveIn: Property[] = new Array();
    propertiesUnderProcessToMoveOut: Property[] = new Array();
    errorList: boolean[] = new Array(0);
    selectedPropertyListItem2: PropertyListItem = new PropertyListItem();
    supplierDropDownList2: SupplyListItem[];
    propertyDropDownList2: PropertyListItem[];
    selectedSupplierListItem2: SupplyListItem = new SupplyListItem();
    selectedMeterListItem2: MeterListItem = new MeterListItem();
    meterDropDownList2: MeterListItem[];
    public readingFromDate: Date = new Date();
    public readingToDate: Date = new Date();
    meterReadings: MeterReadingItem[] = new Array();
    input: MeterReadingSearch = new MeterReadingSearch();
    reading: Reading[] = new Array();
    accountItems: IAccountLimited[] = new Array();
    selectedAccountId: number = undefined;
    load: Boolean = false;
    owner: string;
    uploadedFile: string;
    notesExpanded: Boolean = false;
    viewMoveIn: Boolean = false;
    viewMoveOut: Boolean = false;
    myDate: MyDate = new MyDate();
    year = 2019;    
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
        disableUntil: { year: this.year, month: 6, day: 2 }
    };
    public model: any = null;
    association: PropertyAccountAssociationLimited = new PropertyAccountAssociationLimited();
    progressBarText: string = '';

    constructor(public datepipe: DatePipe, public router: Router, private route: ActivatedRoute, private service: ViewService, private _globalService: GlobalService) {
        this.route.params.subscribe(
            params => {
                this.param = params['id'];
            }
        );
        this.accountOwner.tenant = new AccountOwnerTenant();
    }
    ngOnInit() {
        this.getPropertyDropDownListItemForPropertyId();
        this.getOwnerAndTenantForProperty();
        this.reading = new Array();
        this.reading.push(new Reading());
        for (let i = 0; i < 5; i++) {
            this.errorList.push(false);
        }
        this.getActiveDateForProperty();
    }

    getActiveDateForProperty() {
        this.service.getActiveDateForProperty(this.param).then(
            value => {
                this.myDate = value;
                if (value.year != 1970) {
                    this.myDatePickerOptions.disableUntil = { year: this.myDate.year, month: this.myDate.month, day: this.myDate.day };
                    this.model = { date: { year: this.myDate.year, month: this.myDate.month, day: (this.myDate.day + 1) } };
                }
                else {
                    this.model = null;
                    this.myDatePickerOptions.disableUntil = { year: 1970, month: 1, day: 1 };
                }
            }
        );
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal" || idAttr == "myModal-l1") {
            this.edit = false;
        }
    }

    getOwnerAndTenantForProperty() {
        this.service.getOwnerAndTenantForProperty(this.param).then(
            value => {
                this.accountOwner = value;
            }
        );
    }

    getOwnerForProperty() {
        this.service.getOwnerForProperty(this.param).then(
            value => {
                this.owner = value['_body'];
            }
        );
    }

    displayEditPropertyAccountAssociation() {
        this.getAccountDropDownListItemForPropertyId();
        this.getOwnerForProperty();
        this.edit = true;
    }

    removeReading(index: number) {
        this.reading.splice(index, 1);
        this.reinitializeErrorList();
    }

    getAccountDropDownListItemForPropertyId() {
        this.service.getAccountDropDownListForPropertyId(this.param).then(
            value => {
                this.accountItems = value;
            }
        );
    }

    getPropertyDropDownListItemForPropertyId() {
        this.service.getPropertyDropDownListItemForPropertyId(this.param).then(
            value => {
                this.propertyDropDownList = value;
                this.propertyDropDownList2 = value;
            }
        );
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    onDateSelect(date: Date, value: number) {
        if (value == 1)
            this.readingDate = date;
        else if (value == 2)
            this.readingFromDate = date;
        else
            this.readingToDate = date;
    }

    fetchSupplyListItems(value: number) {
        if (value == 1) {
            for (var i = 0; i < this.propertyDropDownList.length; i++) {
                let propertyDropSelected = this.propertyDropDownList[i];
                if (this.selectedPropertyListItem != null) {
                    if (this.selectedPropertyListItem.propertyId == propertyDropSelected.propertyId) {
                        this.supplierDropDownList = propertyDropSelected.supplyList;
                        this.fetchMeterListItems(1);
                        break;
                    }
                }
            }
        } else {
            for (var i = 0; i < this.propertyDropDownList2.length; i++) {
                let propertyDropSelected = this.propertyDropDownList2[i];
                if (this.selectedPropertyListItem2 != null) {
                    if (this.selectedPropertyListItem2.propertyId == propertyDropSelected.propertyId) {
                        this.supplierDropDownList2 = propertyDropSelected.supplyList;
                        this.fetchMeterListItems(2);
                        break;
                    }
                }
            }
        }
    }

    fetchMeterListItems(value: number) {
        if (value == 1) {
            for (var i = 0; i < this.supplierDropDownList.length; i++) {
                let supplierDropSelected = this.supplierDropDownList[i];
                if (this.selectedSupplierListItem != null && this.selectedSupplierListItem != undefined) {
                    if (this.selectedSupplierListItem.supplyId == supplierDropSelected.supplyId) {
                        this.meterDropDownList = supplierDropSelected.meterList;
                        if (this.meterDropDownList != undefined && this.meterDropDownList != null && this.meterDropDownList.length > 0) {
                            this.selectedMeterListItem = this.meterDropDownList[0];
                        }
                        break;
                    }
                }
            }
        } else {
            for (var i = 0; i < this.supplierDropDownList2.length; i++) {
                let supplierDropSelected = this.supplierDropDownList2[i];
                if (this.selectedSupplierListItem2 != null && this.selectedSupplierListItem2 != undefined) {
                    if (this.selectedSupplierListItem2.supplyId == supplierDropSelected.supplyId) {
                        this.meterDropDownList2 = supplierDropSelected.meterList;
                        if (this.meterDropDownList2 != undefined && this.meterDropDownList2 != null && this.meterDropDownList2.length > 0) {
                            this.selectedMeterListItem2 = this.meterDropDownList2[0];
                        }
                        break;
                    }
                }
            }
        }
    }

    addReading() {
        if (this.reading.length < 5) {
            this.reading.push(new Reading());
        }
    }

    reinitializeErrorList() {
        for (let i = 0; i < this.errorList.length; i++) {
            this.errorList[i] = false;
        }
    }

    validateMeterReading() {
        if (this.reading.length == 1) {
            if (this.reading[0] == null || this.reading[0] == undefined) {
                this.errorList[0] = true;
                return false;
            }
            if (this.reading[0].value == null || this.reading[0].value == undefined || this.reading[0].value == 0) {
                this.errorList[0] = true;
                return false;
            }
            if (this.reading[0].reading == null || this.reading[0].reading == undefined) {
                this.errorList[0] = true;
                return false;
            }
        }
        for (let i = 0; i < this.reading.length; i++) {
            let item = this.reading[i];
            for (let j = i + 1; j < this.reading.length; j++) {
                if (this.reading[i].reading == this.reading[j].reading) {
                    this.errorList[i] = true;
                    this.errorList[j] = true;
                    return false;
                }
            }
        }
        return true;
    }

    addMeterReading() {
        this.load = true;
        this.reinitializeErrorList();
        this.issue = '';
        let meterReading = new MeterReading();
        if (this.selectedPropertyListItem.propertyId == null || this.selectedPropertyListItem.propertyId == undefined) {
            this.issue = 'property';
            this.load = false;
            return;
        }
        if (this.selectedSupplierListItem.supplyId == null || this.selectedSupplierListItem.supplyId == undefined) {
            this.issue = 'supply';
            this.load = false;
            return;
        }
        if (this.selectedMeterListItem.meterId == null || this.selectedMeterListItem.meterId == undefined) {
            this.issue = 'meter';
            this.load = false;
            return;
        } else {
            meterReading.meter.meterId = this.selectedMeterListItem.meterId;
        }
        if (this.readingDate == null || this.readingDate == undefined) {
            this.load = false;
            this.issue = 'date';
            return;
        } else {
            meterReading.readingDateTime = this.datepipe.transform(this.readingDate, "dd-MM-yyyy hh:mm:ss");
        }
        if (!this.validateMeterReading()) {
            this.load = false;
            return;
        }
        meterReading.method = 'Client Manual';
        for (let i = 0; i < this.reading.length; i++) {
            if (this.reading[i] != null && this.reading[i] != undefined) {
                if (this.reading[i].reading == 'MeterReading')
                    meterReading.meterReading = this.reading[i].value;
                if (this.reading[i].reading == 'FlowTemp')
                    meterReading.flowTemperature = this.reading[i].value;
                if (this.reading[i].reading == 'ReturnTemp')
                    meterReading.returnTemperature = this.reading[i].value;
                if (this.reading[i].reading == 'InstantaneousFlow')
                    meterReading.instantaneousFlow = this.reading[i].value;
                if (this.reading[i].reading == 'TotalVolume')
                    meterReading.totalVolume = this.reading[i].value;
            }
        }
        this.service.addMeterReading(meterReading).subscribe(
            data => {
                this.load = false;
                alert("Meter reading added successfully");
            },
            Error => {
                this.load = false;
                alert("Something went wrong. Kindly check with the administrator");
            }
        );
    }

    getAllMeterReadings() {
        this.load = true;
        this.issue = '';
        this.input = new MeterReadingSearch();
        if (this.selectedPropertyListItem2.propertyId == null || this.selectedPropertyListItem2.propertyId == undefined) {
            this.issue = 'property1';
            this.load = false;
            return;
        }
        else
            this.input.propertyId = this.selectedPropertyListItem2.propertyId;
        if (this.selectedSupplierListItem2.supplyId == null || this.selectedSupplierListItem2.supplyId == undefined) {
            this.issue = 'supply1';
            this.load = false;
            return;
        }
        else
            this.input.supplyId = this.selectedSupplierListItem2.supplyId;
        if (this.selectedMeterListItem2.meterId == null || this.selectedMeterListItem2.meterId == undefined) {
            this.issue = 'meter1';
            this.load = false;
            return;
        }
        else
            this.input.meterId = this.selectedMeterListItem2.meterId;
        if (this.readingFromDate == null || this.readingFromDate == undefined) {
            this.issue = 'fromDate';
            this.load = false;
            return;
        }
        else
            this.input.readingFromDate = this.datepipe.transform(this.readingFromDate, 'yyyy-MM-dd');
        if (this.readingToDate == null || this.readingToDate == undefined) {
            this.issue = 'toDate';
            this.load = false;
            return;
        }
        else
            this.input.readingToDate = this.datepipe.transform(this.readingToDate, 'yyyy-MM-dd');
        this.service.getAllMeterReadings(this.input).then(
            value => {
                this.meterReadings = value;
                this.load = false;
            }
        );
    }

    addNotes() {
        this.load = true;
        this.notes.accountId = this.accountOwner.tenant.accountId;
        this.notes.attachment = this.uploadedFile;
        if ((this.notes.attachment == null || this.notes.attachment == undefined) && (this.notes.summary == null || this.notes.summary == undefined)) {
            alert("No data entered");
            this.load = false;
            return;
        }
        this.service.createNotes(this.notes).subscribe(
            data => {
                this.load = false;
                this.notesExpanded = false;
                alert("Note added successfully");
            },
            Error => {
                this.notesExpanded = false;
                this.load = false;
                alert("Something went wrong! Please check with the administrator");
            }
        );
    }

    updatePinStatus(pin: boolean, noteId: number) {
        this.service.updatePinStatus(noteId, pin).subscribe(
            data => {
                alert("Notes pinged to account");
            },
            Error => {
                alert("Something went wrong. Kindly check with the administrator");
            }
        );
    }

    downloadNotesAttachment() {
        this.service.getAttachmentForNoteId(this.notes.fileName, this.notes.noteId);
    }

    getAllOwnerForAccount() {
        this.service.getAllOwnerForAccount(this.param).then(
            value => {
                this.associations = value;
                if (value == null || value == undefined || value.length == 0) {
                    this.associationsFlag = true;
                }
            }
        );
    }

    getAllTenantsForAccount() {
        this.service.getAllTenantsForAccount(this.param).then(
            value => {
                this.associations = value;
                if (value == null || value == undefined || value.length == 0){
                   this.associationsFlag = true;
                }
            }
        );
    }

    updateOwnerPropertyAssociation() {
        this.load = true;
        if (this.selectedAccountId == null || this.selectedAccountId == undefined)
        {
            this.accountSelectFlag = true;
            this.load = false;
            return;
        }

        if (this.model == null || this.model == undefined) {
            this.dateFlag = true;
            this.load = false;
            return;
        }        
        this.association.accountId = this.selectedAccountId;
        this.association.propertyId = Number.parseInt(this.param);
        this.association.owner = 1;
        if (this.checked)
        {
            this.association.tenant = 1;
        } else {
            this.association.tenant = 0;
        }
        this.association.startDate = this.model.date.day + '/' + this.model.date.month + '/' + this.model.date.year;
        this.service.updateOwnerPropertyAssociation(this.association).subscribe(
            data => {
                this.load = false;  
                this.getOwnerAndTenantForProperty();
                this.getActiveDateForProperty();
                alert("Request submitted successfully");                
            },
            Error => {
                this.load = false;
                alert("Something went wrong! Please check with the administrator");
            }
        );
    }

    validateFile(name: string) {
        var ext = name.substring(name.lastIndexOf('.') + 1);
        if (ext.toLowerCase() == 'txt') {
            return true;
        }
        else {
            return false;
        }
    }

    onFileChanged(event) {
        if (event.target.files && event.target.files[0]) {
            this.fileName = event.target.files[0].name;
            if (!this.validateFile(this.fileName)) {
                this.notes.fileName = undefined;
                this.notes.attachment = undefined;
                this.fileName = undefined;
                alert("Selected file format is not supported. Kindly upload a text file");
                return;
            }
            this.notes.fileName = this.fileName;
            var reader = new FileReader();
            reader.onload = (event: ProgressEvent) => {
                this.uploadedFile = (<FileReader>event.target).result;
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    }


    clickEventForNotes(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "add-note-modal") {
            this.notesExpanded = false;
        }
        if (idAttr == "view-note") {
            this.notesViewExpanded = false;
        }

    }

    viewAddNote() {
        this.notes = new Notes();
        this.notesExpanded = true;
        this.uploadedFile = null;
        this.fileName = null;
        this.notes.fileName = null;
        this.notes.attachment = null;
    }

    removeAttachment() {
        let message: string = "";
        if (this.uploadedFile != null || this.uploadedFile != undefined) {
            message = "Attachment removed successfully";
        } else {
            message = "There is no attachment to remove!";
        }
        this.uploadedFile = null;
        this.fileName = null;
        this.notes.fileName = null;
        this.notes.attachment = null;
        alert(message);
    }

    viewNote(item: Notes) {
        this.notesViewExpanded = true;
        this.notes = item;
    }

    updateAssociationToDeleted(associationId: number) {
        this.load = true;
        this.service.updateAssociationToDeleted(associationId).subscribe(
            data => {
                this.load = false;
                this.getAllOwnerForAccount();
                this.getActiveDateForProperty();
                alert("Account association with property removed");
            },
            Error => {
                this.load = false;
                alert("Something went wrong! Please check with the administrator");
            }
        );
    }

    getAllNotesForAccountId(accountId: number) {        
        this.service.getAllNotesForAccountId(accountId).then(
            value => {
                this.notesList = value;
            }
        );
    }

    getListOfPropertiesUnderMovementInside() {
        this.selectedPropertyIdForDropDown = 0;
        this.progress = false;
        this.progressValue = undefined;
        this.viewMoveIn = true;
        var defaultValue = new Property();
        defaultValue.propertyId = 0;
        defaultValue.address.addressLine1 = "Select";
        this.service.getAllPropertyUnderMovementInside(this.accountOwner.accountId).then(
            value => {
                this.propertiesUnderProcessToMoveIn = value;
                this.propertiesUnderProcessToMoveIn.push(defaultValue);
            }
        );
    }

    getListOfPropertiesUnderMovementOutside() {
        this.selectedPropertyIdForDropDown = 0;
        this.progress = false;
        this.progressValue = undefined;
        this.viewMoveOut = true;
        var defaultValue = new Property();
        defaultValue.propertyId = 0;
        defaultValue.address.addressLine1 = "Select";
        this.service.getAllPropertyUnderMovementOutside(this.accountOwner.accountId).then(
            value => {
                this.propertiesUnderProcessToMoveOut = value;
                this.propertiesUnderProcessToMoveOut.push(defaultValue);
            }
        );
    }

    displayProgressBarForDrop(value: number) {
        if (this.selectedPropertyIdForDropDown != undefined && this.selectedPropertyIdForDropDown != null && this.selectedPropertyIdForDropDown != 0) {
            this.displayProgressBar(value, this.selectedPropertyIdForDropDown);
        }
    }

    displayProgressBar(value: number, propertyId: number) {
        this.progress = true;
        if (value == 1)
            this.getMoveInStatusForAccountAndProperty(propertyId, value);
        else if (value == 2)
            this.getMoveOutStatusForAccountAndProperty(propertyId, value);
    }

    setWidth(wid: string, text: string) {
        this.width = wid + '%';
        this.progressBarText = text;
    }

    getMoveInStatusForAccountAndProperty(propertyId: number, value: number) {
        this.service.getStatusForAccountAndProperty(propertyId, value).then(
            value => {
                this.progressValue = value['_body'];
                if (this.progressValue == undefined || this.progressValue == null) {
                    this.setWidth('0', '');
                } else if (this.progressValue == 'Pending') {
                    this.setWidth('10', 'Initiated');
                } else if (this.progressValue == 'SanityCheck') {
                    this.setWidth('20', 'Waiting to close previous active Owner');
                } else if (this.progressValue == 'PreviousOwner') {
                    this.setWidth('40', 'Waiting for previous meter reading');
                } else if (this.progressValue == 'PreviousReading') {
                    this.setWidth('60', 'Waiting for Current meter reading');
                } else if (this.progressValue == 'CurrentReading') {
                    this.setWidth('80', 'Waiting to Complete');
                }
            }
        );
    }

    getMoveOutStatusForAccountAndProperty(propertyId: number, value: number) {
        this.service.getStatusForAccountAndProperty(propertyId, value).then(
            value => {
                this.progressValue = value['_body'];
                if (this.progressValue == undefined || this.progressValue == null) {
                    this.setWidth('0', '');
                } else if (this.progressValue == 'Pending') {
                    this.setWidth('30', 'Initiated');
                } else if (this.progressValue == 'PreviousReading') {
                    this.setWidth('60', 'Waiting for Current meter reading');
                } else if (this.progressValue == 'CurrentReading') {
                    this.setWidth('90', 'Waiting to Complete');
                }
            }
        );
    }

    updatePendingToSanityCheck() {
        this.load = true;
        this.service.changePendingToSanityCheck(this.accountOwner.accountId, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                alert(value['_body']);
                this.getMoveInStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 1);
            },
            Error => {
                this.load = false;
                alert("Something went wrong. Kindly check with the administrator");
            }
        );
    }

    updateSanityToPreviousTenant() {
        this.load = true;
        this.service.changeSanityToPreviousTenant(this.accountOwner.accountId, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                alert(value['_body']);
                this.getMoveInStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 1);
            },
            Error => {
                this.load = false;
                alert("Something went wrong. Kindly check with the administrator");
            }
        );
    }
    updatePreviousTenantToPreviousMeterReading() {
        this.load = true;
        this.service.changePreviousTenantToPreviousMeterReading(this.accountOwner.accountId, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                alert(value['_body']);
                this.getMoveInStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 1);
            },
            Error => {
                this.load = false;
                alert("Something went wrong. Kindly check with the administrator");
            }
        );
    }
    updatePreviousMeterReadingToCurrentMeterReading() {
        this.load = true;
        this.service.changePreviousMeterReadingToCurrentMeterReading(this.accountOwner.accountId, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                alert(value['_body']);
                this.getMoveInStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 1);
            },
            Error => {
                this.load = false;
                alert("Something went wrong. Kindly check with the administrator");
            }
        );
    }
    updateCurrentReadingToCompleted() {
        this.load = true;
        this.service.changeCurrentReadingToCompleted(this.accountOwner.accountId, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                alert(value['_body']);
                this.getListOfPropertiesUnderMovementInside();
            },
            Error => {
                this.load = false;
                alert("Something went wrong. Kindly check with the administrator");
            }
        );
    }


    updatePendingToPreviousMeterReadingForTenantOut() {
        this.load = true;
        this.service.changePendingToPreviousMeterReadingForTenantOut(this.accountOwner.accountId, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                alert(value['_body']);
                this.getMoveOutStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 2);
            },
            Error => {
                this.load = false;
                alert("Something went wrong. Kindly check with the administrator");
            }
        );
    }
    updatePreviousMeterReadingToCurrentMeterReadingForTenantOut() {
        this.load = true;
        this.service.changePreviousMeterReadingToCurrentMeterReadingForTenantOut(this.accountOwner.accountId, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                alert(value['_body']);
                this.getMoveOutStatusForAccountAndProperty(this.selectedPropertyIdForDropDown, 2);
            },
            Error => {
                this.load = false;
                alert("Something went wrong. Kindly check with the administrator");
            }
        );
    }

    updateCurrentReadingToCompletedForTenantOut() {
        this.load = true;
        this.service.changeCurrentReadingToCompletedForTenantOut(this.accountOwner.accountId, this.selectedPropertyIdForDropDown).then(
            value => {
                this.load = false;
                alert(value['_body']);                
                this.getListOfPropertiesUnderMovementOutside();
            },
            Error => {
                this.load = false;
                alert("Something went wrong. Kindly check with the administrator");
            }
        );
    }
}