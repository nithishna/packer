﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-properties',
    template: `<router-outlet></router-outlet>`
})
export class PropertiesComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }  
}