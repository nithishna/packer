﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { routing } from './properties.routing';
import { SharedModule } from '../../shared/shared.module';
import { PropertiesComponent } from './properties.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { MainComponent } from "./components/main/main.component";
import { LayoutModule } from "../../shared/layout.module";
import { MyDatePickerModule } from 'mydatepicker';
import { AngularDateTimePickerModule } from 'angular2-datetimepicker';
import { ViewComponent } from "./components/view/view.component";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        routing,
        NgxPaginationModule,
        LayoutModule,
        MyDatePickerModule,
        AngularDateTimePickerModule
    ],
    declarations: [
        PropertiesComponent,
        MainComponent,
        ViewComponent
    ]
})
export class PropertiesModule { }
