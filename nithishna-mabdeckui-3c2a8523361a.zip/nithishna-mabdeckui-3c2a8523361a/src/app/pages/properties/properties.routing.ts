﻿import { Routes, RouterModule } from '@angular/router';
import { PropertiesComponent } from './properties.component';
import { MainComponent } from "./components/main/main.component";
import { ViewComponent } from "./components/view/view.component";

const childRoutes: Routes = [
    {
        path: '',
        component: PropertiesComponent,
        children: [
            { path: '', redirectTo: 'main', pathMatch: 'full' },
            { path: 'main', component: MainComponent },
            { path: 'view/:id', component: ViewComponent }
        ]
    }
];

export const routing = RouterModule.forChild(childRoutes);