﻿import { Routes, RouterModule } from '@angular/router';
import { FinanceGroupComponent } from './financegroup.component';
import { FinanceComponent } from './components/finance/finance.component';
import { DirectDebitComponent } from './components/direct-debit/direct-debit.component';
import { DDSetupComponent } from './components/setup/setup.component';
import { CreditControlComponent } from './components/credit-control/credit-control.component';
import { CreditControlCorrespondenceComponent } from './components/credit-control-correspondence/credit-control-correspondence.component';

const childRoutes: Routes = [
    {
        path: '',
        component: FinanceGroupComponent,
        children: [
            { path: '', redirectTo: 'finance', pathMatch: 'full' },
            { path: 'finance', component: FinanceComponent },
            { path: 'direct-debit', component: DirectDebitComponent },
            { path: 'setup', component: DDSetupComponent },
            { path: 'credit-control', component: CreditControlComponent },
            { path: 'correspondence', component: CreditControlCorrespondenceComponent }
        ]
    }
];

export const routing = RouterModule.forChild(childRoutes);