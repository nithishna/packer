import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { environment } from "../../../../../environments/environment";
import { ICreditControlSetup, IStage, IAction, ICreditCorrespondence, ICreditNotes, IClient, IActionFlag, IActionLetter, IActionEmail } from '../../../../shared/interface';

@Injectable()
export class DDSetupService {
    clientMetaDataUrl = environment.host + 'client-metadata';
    creditSetup = environment.host + 'credit/setup';
    creditStage = environment.host + 'client';
    creditStageEdit = environment.host + 'credit/stage';
    creditAction = environment.host + 'credit/stage';
    creditControl = environment.host + 'credit-control';
    creditControlCorrespondence = environment.host + 'credit-control-correspondence';
    creditControlNoteAttachment = environment.host + 'credit-note-attachment';
    creditActionDeleted = environment.host + 'credit_action';

    constructor(private http: Http) { }

    deleteCreditAction(id: number, type: number) {
        let url = this.creditActionDeleted + '?id=' + id + '&type=' + type;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .delete(url, { headers: headers });
    }

    getClients() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.clientMetaDataUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);
    }

    getCreditControlSetupByClientId(clientId: number) {
        let url = this.creditSetup + '?clientId=' + clientId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as ICreditControlSetup);
    }

    addStage(stage: IStage, clientId: number, setupId: number) {
        let url = this.creditStage + '/' + clientId + '/credit/' + setupId + '/stage';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .post(url, stage, { headers: headers });
    }

    updateStage(stage: IStage) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .put(this.creditStageEdit, stage, { headers: headers });
    }

    addActionEmail(action: IActionEmail, stageId: number) {
        let url = this.creditAction + '/' + stageId + '/action-email';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .post(url, action, { headers: headers });
    }

    addActionLetter(action: IActionLetter, stageId: number) {
        let url = this.creditAction + '/' + stageId + '/action-letter';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .post(url, action, { headers: headers });
    }

    addActionFlag(action: IActionFlag, stageId: number) {
        let url = this.creditAction + '/' + stageId + '/action-flag';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .post(url, action, { headers: headers });
    }

    getAllCreditControl(index: number, size: number) {
        let url = this.creditControl + '?index=' + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as ICreditCorrespondence[]);
    }

    getAllCreditControlCorrespondence(index: number, size: number) {
        let url = this.creditControlCorrespondence + '?index=' + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as ICreditCorrespondence[]);
    }

    getAllNotesForCorrespondenceId(correspondenceId: number) {
        let url = this.creditControlCorrespondence + '/' + correspondenceId + '/notes';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as ICreditNotes[]);
    }

    createNote(note: ICreditNotes, correspondenceId: number) {
        let url = this.creditControlCorrespondence + '/' + correspondenceId + '/notes';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .post(url, note, {
                headers: headers
            });
    }

    downloadFile(data: any, filename: string) {
        var blob = new Blob([data], { type: 'text/plain' });
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    getAttachmentForNoteId(filename: string, noteId: number) {
        let url = this.creditControlNoteAttachment + '?note_id=' + noteId.toString();
        this.getFile(url).subscribe(data => {
            let parsedResponse = data.text();
            this.downloadFile(parsedResponse, filename)
        }, error => console.log("Error downloading the file."),
            () => console.info("OK"));
    }

    getFile(url: string) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(url, { headers: headers });
    }
}