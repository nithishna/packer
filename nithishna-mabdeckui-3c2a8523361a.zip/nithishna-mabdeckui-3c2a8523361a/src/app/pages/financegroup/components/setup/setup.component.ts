import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { Router } from '@angular/router';
import { IDirectDebitConfigDto, IClient, INetwork, ICreditControlSetup, IStage, IAction, IActionEmail, IActionLetter, IActionFlag } from '../../../../shared/interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import swal from 'sweetalert2';
import { DDSetupService } from './setup.service';
@Component({
    selector: 'app-direct-debit-setup',
    templateUrl: './setup.component.html',
    styleUrls: ['./setup.component.scss'],
    providers: [DDSetupService]
})
export class DDSetupComponent implements OnInit {
    selectedStageId: number = 0;
    creditControlSetup: ICreditControlSetup = {
        controlId: 0,
        stages: null
    };
    stage: IStage = {
        actions: null,
        name: null,
        noOfDays: null,
        overDue: null,
        stageId: 0,
    };
    actionEmail: IActionEmail = {
        id: 0,
        owner: null,
        stage: null,
        body: null,
        emailIds: null,
        subject: null,
        type: 1
    };
    actionLetter: IActionLetter = {
        id: 0,
        owner: null,
        stage: null,
        templateName: null,
        type: 2
    };
    actionFlag: IActionFlag = {
        id: 0,
        owner: null,
        stage: null,
        flag: true,
        type: 3
    };
    client: IClient[] = [];
    load = false;
    selectedClientId: number = 0;
    stageExpanded = false;
    stageEditExpanded = false;
    actionExpanded = false;
    actionEditExpanded = false;
    constructor(public _globalService: GlobalService, public router: Router, private formBuilder: FormBuilder, private service: DDSetupService) { }
    ngOnInit() {
        this.authenticationCheck();
        this.getAllClients();
    }
    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal" || idAttr == "myModal1" || idAttr == "myModal2" || idAttr == "myModal3") {
            this.stageExpanded = false;
            this.stageEditExpanded = false;
            this.actionEditExpanded = false;
            this.actionExpanded = false;
        }
    }

    initializeCreditControlSetup() {
        this.creditControlSetup = {
            controlId: 0,
            stages: null
        }
    }

    initializeStage() {
        this.stageExpanded = true;
        this.stage = {
            actions: null,
            name: null,
            noOfDays: null,
            overDue: null,
            stageId: 0
        };
    }

    editStage(stage: IStage) {
        this.stageEditExpanded = true;
        this.stage = stage;
    }

    initializeAction(stageId: number) {
        this.selectedStageId = stageId;
        this.actionExpanded = true;
        this.actionEmail = {
            id: 0,
            owner: null,
            stage: null,
            body: null,
            emailIds: null,
            subject: null,
            type: 1
        };
        this.actionLetter = {
            id: 0,
            owner: null,
            stage: null,
            templateName: null,
            type: 2
        };
        this.actionFlag = {
            id: 0,
            owner: null,
            stage: null,
            flag: true,
            type: 3
        };
    }

    getAllClients() {
        this.load = true;
        this.service.getClients().then(
            (value) => {
                this.client = value;
                if (this.client && this.client.length > 0) {
                    this.selectedClientId = this.client[0].clientId;
                    this.getCreditControlSetupByClientId();
                }
                this.load = false;
            },
            (error) => {
                this.load = false;
            }
        )
    }

    getCreditControlSetupByClientId() {
        this.load = true;
        this.service.getCreditControlSetupByClientId(this.selectedClientId).then(
            (value) => {
                this.creditControlSetup = value;
                this.load = false;
            },
            (error) => {
                this.initializeCreditControlSetup();
                this.load = false;
            }
        );
    }

    updateStage() {
        this.load = true;
        this.service.updateStage(this.stage).subscribe(
            (value) => {
                this.load = false;
                this.getCreditControlSetupByClientId();
                swal({
                    type: 'success',
                    title: 'Data updated!',
                    showConfirmButton: true
                });
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    addActionEmail() {
        this.service.addActionEmail(this.actionEmail, this.selectedStageId).subscribe(
            (value) => {
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Data added!',
                    showConfirmButton: true
                });
                this.getCreditControlSetupByClientId();
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    addActionLetter() {
        this.service.addActionLetter(this.actionLetter, this.selectedStageId).subscribe(
            (value) => {
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Data added!',
                    showConfirmButton: true
                });
                this.getCreditControlSetupByClientId();
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    addActionFlag() {
        this.service.addActionFlag(this.actionFlag, this.selectedStageId).subscribe(
            (value) => {
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Data added!',
                    showConfirmButton: true
                });
                this.getCreditControlSetupByClientId();
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    addStage() {
        this.load = true;
        this.service.addStage(this.stage, this.selectedClientId, this.creditControlSetup.controlId).subscribe(
            (value) => {
                this.load = false;
                this.getCreditControlSetupByClientId();
                swal({
                    type: 'success',
                    title: 'Data saved!',
                    showConfirmButton: true
                });
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    deleteCreditAction(id: number, type: number){
        this.load = true;
        this.service.deleteCreditAction(id, type).subscribe(
            (value)=>{
                this.load = false;
                this.getCreditControlSetupByClientId();
            },
            (error)=>{
                this.load = false;
            }
        )
    }
}