import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { Router } from '@angular/router';
import { IDirectDebitConfigDto, IClient, INetwork, ICreditCorrespondence, ICreditNotes } from '../../../../shared/interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import swal from 'sweetalert2';
import { DDSetupService } from '../setup/setup.service';
@Component({
    selector: 'app-credit-control-correspondence',
    templateUrl: './credit-control-correspondence.component.html',
    styleUrls: ['./credit-control-correspondence.component.scss'],
    providers: [DDSetupService]
})
export class CreditControlCorrespondenceComponent implements OnInit {
    load = false;
    notes: ICreditNotes = {
        attachment: null,
        author: null,
        fileName: null,
        id: null,
        isAttachment: null,
        modifiedDate: null,
        summary: null
    };
    notesList: ICreditNotes[] = [];
    viewNotes = false;
    selectedCorrespondenceId = 0;
    uploadedFile: string;
    fileName: string;
    data: ICreditCorrespondence[] = [];
    pageSize = 10;
    pageNumber = 1;
    totalNumberOfItems = 5;
    notesExpanded = false;
    notesViewExpanded = false;
    constructor(public _globalService: GlobalService, public router: Router, private service: DDSetupService, private formBuilder: FormBuilder, ) { }
    ngOnInit() {
        this.authenticationCheck();
        this.getAllCreditControl();
    }
    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }
    removeAttachment() {
        let message: string = "";
        if (this.uploadedFile != null || this.uploadedFile != undefined) {
            message = "Attachment removed successfully";
        } else {
            message = "There is no attachment to remove!";
        }
        this.uploadedFile = null;
        this.fileName = null;
        this.notes.fileName = null;
        this.notes.attachment = null;
        swal({ type: 'info', title: message, showConfirmButton: true });
    }
    pageChanged(pN: number): void {
        this.pageNumber = pN;
    }
    onFileChanged(event) {
        if (event.target.files && event.target.files[0]) {
            this.fileName = event.target.files[0].name;            
            if (!this.validateFile(this.fileName)) {
                this.notes.fileName = undefined;
                this.notes.attachment = undefined;
                this.fileName = undefined;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Selected file format is not supported. Kindly upload a csv file'
                });
                return;
            }
            this.notes.fileName = this.fileName;
            var reader = new FileReader();
            reader.onload = (event: ProgressEvent) => {
                this.uploadedFile = (<FileReader>event.target).result;
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    }
    viewAddNote(correspondenceId: number) {
        this.selectedCorrespondenceId = correspondenceId;
        this.notes = {
            attachment: null,
            author: null,
            fileName: null,
            id: null,
            isAttachment: null,
            modifiedDate: null,
            summary: null
        };
        this.notesExpanded = true;
        this.uploadedFile = null;
        this.fileName = null;
    }
    validateFile(name: string) {        
        var ext = name.substring(name.lastIndexOf('.') + 1);
        if (ext.toLowerCase() == 'txt') {
            return true;
        }
        else {
            return false;
        }
    }
    clickEventForNotes(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "add-note-modal") {
            this.notesExpanded = false;
        }
        if (idAttr == "view-note"){
            this.notesViewExpanded = false;
        }
    }

    downloadNotesAttachment() {
        this.service.getAttachmentForNoteId(this.notes.fileName, this.notes.id);
    }

    getAllCreditControl() {
        this.load = true;
        this.service.getAllCreditControlCorrespondence(this.pageNumber,this.pageSize).then(
            (value) =>{
                this.data = value;
                this.load = false;
            },
            (error)=>{
                this.load = false;
            }
        );
    }

    viewNote(item: ICreditNotes){
        this.notes = item;
        this.notesViewExpanded = true;

    }

    getAllNotesForCorrespondenceId(id: number) {
        this.viewNotes = true;
        this.service.getAllNotesForCorrespondenceId(id).then(
            (value)=>{
                if(value && value.length>0)
                    this.notesList = value;
                else
                    this.notesList = [];
            },
            (error)=>{
                this.notesList = [];
            }
        )
    }

    addNotes() {
        this.load = true;
        this.notes.attachment = this.uploadedFile;
        if ((this.notes.attachment == null || this.notes.attachment == undefined) && (this.notes.summary == null || this.notes.summary == undefined))
        {
            swal({ type: 'info', title: 'No data entered', showConfirmButton: true });
            this.load = false;
            return;
        }
        this.service.createNote(this.notes, this.selectedCorrespondenceId).subscribe(
            data => {
                this.load = false;
                this.notesExpanded = false;
                swal({ type: 'success', title: 'Notes added successfully', showConfirmButton: true });
            },
            Error => {
                this.notesExpanded = false;
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator'
                }); 
            }
        );
    }
}