import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { environment } from "../../../../../environments/environment";
import { IDirectDebitConfigDto, IClient, INetwork } from '../../../../shared/interface';

@Injectable()
export class DirectDebitService {
    clientUrl = environment.host +'client/';
    clientMetaDataUrl = environment.host + 'client-metadata';
    directDebitUrl = environment.host + 'direct-debit-config';
    constructor(private http: Http) { }

    getClients() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.clientMetaDataUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);
    }

    getNetworkForClient(clientId: number) {
        let url = this.clientUrl + clientId + '/network';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as INetwork[]);
    }

    getAllDirectDebits() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.directDebitUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IDirectDebitConfigDto[]);
    }

    insertDirectDebit(directDebit: IDirectDebitConfigDto) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.directDebitUrl, directDebit, {
            headers: headers
        });
    }

    updateDirectDebit(directDebit: IDirectDebitConfigDto) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.directDebitUrl, directDebit, {
            headers: headers
        });
    }
}