import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { Router } from '@angular/router';
import { IDirectDebitConfigDto, IClient, INetwork } from '../../../../shared/interface';
import { DirectDebitService } from './direct-debit.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import swal from 'sweetalert2';
@Component({
    selector: 'app-direct-debit',
    templateUrl: './direct-debit.component.html',
    styleUrls: ['./direct-debit.component.scss'],
    providers: [DirectDebitService]
})
export class DirectDebitComponent implements OnInit {

    data: IDirectDebitConfigDto[] = [];
    load: boolean = false;
    clients: IClient[] = [];
    networks: INetwork[] = [];
    selectedClientId: number = 0;
    selectedNetworkId: number = 0;
    expanded = false;
    updateExpanded = false;
    directDebitForm: FormGroup;
    permissibleDay: String = '1';
    permissiblePaymentDays: String[] = [];
    submitted: boolean = false;
    directDebit: IDirectDebitConfigDto = {
        auddisFile: false,
        billingFrequency: null,
        claimOffset: null,
        clientId: 0,
        clientName: null,
        collectionFile: false,
        directDebitLetter: false,
        emailForLetter: 'help@welcomeenergy.co.uk',
        id: 0,
        networkId: 0,
        networkName: null,
        permissibleDirectDebitOptions: 0,
        permissiblePaymentDays: null,
        phoneForLetter: '0800 368 9590',
        transactionsForDirectDebit: false
    };
    constructor(public _globalService: GlobalService, public router: Router, private service: DirectDebitService, private formBuilder: FormBuilder, ) { }
    ngOnInit() {
        this.authenticationCheck();
        this.getAllDirectDebit();
        this.getAllClients();
        this.directDebitForm = this.formBuilder.group({
            client: ['', Validators.required],
            network: ['', Validators.required],
            claimOffset: ['', Validators.required],
            billingFrequency: ['', Validators.required],
            permissiblePaymentDays: ['', Validators.required],
            phoneForLetter: ['', Validators.required],
            emailForLetter: ['', Validators.required]
        });
    }

    get c() { return this.directDebitForm.controls; }

    addDays() {
        let val = this.permissiblePaymentDays.find(x => x == this.permissibleDay);
        if (!val)
            this.permissiblePaymentDays.push(this.permissibleDay);
    }

    removeDay(day: string) {
        let index = this.permissiblePaymentDays.indexOf(day, 0);
        if (index > -1) {
            this.permissiblePaymentDays.splice(index, 1);
        }
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    getAllClients() {
        this.service.getClients().then(
            (value) => {
                this.clients = value;
                if (value && value.length > 0) {
                    this.selectedClientId = value[0].clientId;
                    this.getAllNetworksByClientId();
                } else {
                    this.selectedClientId = 0;
                }
            },
            (error) => {
                console.error(error);
            }
        );
    }

    getAllNetworksByClientId() {
        this.service.getNetworkForClient(this.selectedClientId).then(
            (value) => {
                this.networks = value;
                if (value && value.length > 0) {
                    this.selectedNetworkId = value[0].networkId;
                } else {
                    this.selectedNetworkId = 0;
                }
            },
            (error) => {
                this.networks = [];
            }
        );
    }

    getAllDirectDebit() {
        this.load = true;
        this.service.getAllDirectDebits().then(
            (value) => {
                this.load = false;
                this.data = value;
            },
            (error) => {
                this.load = false;
                console.error(error);
            }
        );
    }

    initializeDirectDebit() {
        this.directDebit = {
            auddisFile: false,
            billingFrequency: null,
            claimOffset: null,
            clientId: 0,
            clientName: null,
            collectionFile: false,
            directDebitLetter: false,
            emailForLetter: 'help@welcomeenergy.co.uk',
            id: 0,
            networkId: 0,
            networkName: null,
            permissibleDirectDebitOptions: 0,
            permissiblePaymentDays: null,
            phoneForLetter: '0800 368 9590',
            transactionsForDirectDebit: false
        };
    }

    add() {
        this.permissibleDay = '1';
        this.permissiblePaymentDays = [];
        this.expanded = true;
        this.submitted = false;
        this.initializeDirectDebit();
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal" || idAttr == "myModal1") {
            this.expanded = false;
            this.updateExpanded = false;
        }
    }

    addDirectDebit() {
        this.load = true;
        this.submitted = true;
        if (this.directDebitForm.invalid) {
            this.load = false;
            return;
        }
        this.directDebit.clientId = this.selectedClientId;
        this.directDebit.networkId = this.selectedNetworkId;
        let perDay = '';
        if(this.permissiblePaymentDays && this.permissiblePaymentDays.length>0) {
            for(let index=0; index<this.permissiblePaymentDays.length; index++) {
                perDay += this.permissiblePaymentDays[index];
                if(index < this.permissiblePaymentDays.length -1)
                    perDay += ',';
            }
        }
        this.directDebit.permissiblePaymentDays = perDay;
        this.service.insertDirectDebit(this.directDebit).subscribe(
            (value) => {
                this.load = false;
                this.getAllDirectDebit();
                swal({
                    type: 'success',
                    title: 'Data saved!',
                    showConfirmButton: true
                });
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    update(directDebit: IDirectDebitConfigDto) {
        this.directDebit = directDebit;
        this.submitted = false;
        this.updateExpanded = true;
        if(directDebit.permissiblePaymentDays && directDebit.permissiblePaymentDays != "") {
            this.permissiblePaymentDays = directDebit.permissiblePaymentDays.split(',');
            this.permissibleDay = this.permissiblePaymentDays[0];
        }else{
            this.permissiblePaymentDays = [];
        }
    }

    updateDirectDebit() {
        this.load = true;
        this.submitted = true;
        if (this.directDebitForm.invalid) {
            this.load = false;
            return;
        }
        this.directDebit.clientId = this.selectedClientId;
        this.directDebit.networkId = this.selectedNetworkId;
        let perDay = '';
        if(this.permissiblePaymentDays && this.permissiblePaymentDays.length>0) {
            for(let index=0; index<this.permissiblePaymentDays.length; index++) {
                perDay += this.permissiblePaymentDays[index];
                if(index < this.permissiblePaymentDays.length -1)
                    perDay += ',';
            }
        }
        this.directDebit.permissiblePaymentDays = perDay;
        this.service.updateDirectDebit(this.directDebit).subscribe(
            (value) => {
                this.load = false;
                this.getAllDirectDebit();
                swal({
                    type: 'success',
                    title: 'Data updated!',
                    showConfirmButton: true
                });
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }
}
