﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { routing } from './financegroup.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { LayoutModule } from '../../shared/layout.module';
import { NgxPaginationModule } from 'ngx-pagination';
/* components */
import { FinanceGroupComponent } from './financegroup.component';
import { FinanceComponent } from './components/finance/finance.component';
import { DirectDebitComponent } from './components/direct-debit/direct-debit.component';
import { DDSetupComponent } from './components/setup/setup.component';
import { CreditControlComponent } from './components/credit-control/credit-control.component';
import { CreditControlCorrespondenceComponent } from './components/credit-control-correspondence/credit-control-correspondence.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        routing,
        NgxPaginationModule,
        LayoutModule
    ],
    declarations: [
        FinanceGroupComponent,
        FinanceComponent,
        DirectDebitComponent,
        DDSetupComponent,
        CreditControlComponent,
        CreditControlCorrespondenceComponent
    ]
})
export class FinanceGroupModule { }
