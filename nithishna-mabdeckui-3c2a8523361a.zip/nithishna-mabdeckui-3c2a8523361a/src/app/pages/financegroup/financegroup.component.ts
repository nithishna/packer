﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-financegroup',
    template: `<router-outlet></router-outlet>`
})
export class FinanceGroupComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}