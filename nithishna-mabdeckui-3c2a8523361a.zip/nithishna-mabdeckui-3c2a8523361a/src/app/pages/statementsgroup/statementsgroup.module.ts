﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { routing } from './statementsgroup.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';
/* components */
import { StatementsGroupComponent } from './statementsgroup.component';
import { StatementsComponent } from './components/statements/statements.component';
import { GenerateStatementComponent } from "./components/generate/generate.component";
import { MyDatePickerModule } from "mydatepicker";
import { LayoutModule } from "../../shared/layout.module";
import { PreStatementComponent } from "./components/Prestatement/Prestatement.component";
import { ViewPreStatementComponent } from "./components/ViewPrestatement/ViewPrestatement.component";
import { ManualStatementComponent } from "./components/manualReview/manual.component";
import { ArchivedStatementComponent } from "./components/archived/archived.component";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        routing,
        NgxPaginationModule,
        LayoutModule,
        MyDatePickerModule
    ],
    declarations: [
        StatementsGroupComponent,
        StatementsComponent,
        GenerateStatementComponent,
        PreStatementComponent,
        ViewPreStatementComponent,
        ManualStatementComponent,
        ArchivedStatementComponent
    ]
})
export class StatementsGroupModule { }
