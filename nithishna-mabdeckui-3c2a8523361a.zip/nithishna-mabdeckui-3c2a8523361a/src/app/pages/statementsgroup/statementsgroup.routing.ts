﻿import { Routes, RouterModule } from '@angular/router';
import { StatementsGroupComponent } from './statementsgroup.component';
import { StatementsComponent } from './components/statements/statements.component';
import { GenerateStatementComponent } from "./components/generate/generate.component";
import { PreStatementComponent } from "./components/Prestatement/Prestatement.component";
import { ViewPreStatementComponent } from "./components/ViewPrestatement/ViewPrestatement.component";
import { ManualStatementComponent } from "./components/manualReview/manual.component";
import { ArchivedStatementComponent } from "./components/archived/archived.component";

const childRoutes: Routes = [
    {
        path: '',
        component: StatementsGroupComponent,
        children: [
            { path: '', redirectTo: 'statements', pathMatch: 'full' },
            { path: 'statements', component: StatementsComponent },
            { path: 'generate', component: GenerateStatementComponent },
            { path: 'prestatement', component: PreStatementComponent },
            { path: 'viewPreStatement/:id', component: ViewPreStatementComponent },
            { path: 'manual', component: ManualStatementComponent },
            { path: 'archived', component: ArchivedStatementComponent }
        ]
    }
];

export const routing = RouterModule.forChild(childRoutes);