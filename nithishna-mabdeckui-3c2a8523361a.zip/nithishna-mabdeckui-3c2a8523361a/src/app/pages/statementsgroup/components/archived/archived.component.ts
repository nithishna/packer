﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalService } from "../../../../shared/services/global.service";
import { IClient, INetwork, IProperty, IStatement } from "../../../../shared/interface";
import swal from 'sweetalert2';
import { Statement } from "../../../../shared/class";
import { ArchivedStatementService } from "./archived.service";
@Component({
    selector: 'app-archived-statements',
    templateUrl: './archived.component.html',
    styleUrls: ['./archived.component.scss'],
    providers: [ArchivedStatementService]
})
export class ArchivedStatementComponent implements OnInit {
    load: Boolean = false;
    statements: IStatement[] = new Array();
    selectedStatement: IStatement = new Statement();

    constructor(public router: Router, private service: ArchivedStatementService) {
    }
    ngOnInit(): void {
        this.fetchStatements();
    }

    fetchStatements() {
        this.load = true;
        this.service.fetchAllApprovedstatements().then(
            (data) => {
                this.load = false;
                this.statements = data;
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    downloadPdf(statement: IStatement) {
        this.selectedStatement = statement;
        this.service.downloadPdf(statement.statementId).subscribe(
            data => {
                debugger;
                let parsedResponse = data.text();
                this.downloadFile(parsedResponse);
            },
            error => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            },
            () => console.info("OK"));
    }
    downloadFile(data: any) {
        let binaryString = window.atob(data);

        let binaryLen = binaryString.length;

        let bytes = new Uint8Array(binaryLen);

        for (let i = 0; i < binaryLen; i++) {
            let ascii = binaryString.charCodeAt(i);
            bytes[i] = ascii;
        }

        var blob = new Blob([bytes], { type: 'application/pdf' });
        var exportFilename = this.selectedStatement.fileName;
        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.setAttribute('download', exportFilename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}