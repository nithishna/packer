﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers, ResponseContentType } from '@angular/http';
import { Observable } from "rxjs";
import { environment } from "../../../../../environments/environment";
import { IStatement } from "../../../../shared/interface";
import { HttpParams } from "@angular/common/http";

@Injectable()
export class ArchivedStatementService {
    constructor(private http: Http) { }
    statementUrl = environment.host + 'statement/approved';
    downloadUrl = environment.host + 'statement-download?statement_id=';

    downloadPdf(id: number) {
        let url = this.downloadUrl + id;
        return this.getFile(url);
    }

    getFile(url: string) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(url, { headers: headers });
    }
    fetchAllApprovedstatements() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.statementUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IStatement[]);
    }
}