﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers, ResponseContentType } from '@angular/http';
import { Observable } from "rxjs";
import { environment } from "../../../../../environments/environment";
import { IStatement } from "../../../../shared/interface";
import { HttpParams } from "@angular/common/http";

@Injectable()
export class ManualStatementService {
    constructor(private http: Http) { }
    statementUrl = environment.host + 'statement';
    downloadUrl = environment.host + 'statement-download?statement_id=';
    approveUrl = environment.host + 'statement/approval?';

    updateApprovalState(statementId: number, state: number) {
        let url = this.approveUrl + "statement_id=" + statementId + "&state=" + state;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, "", {
            headers: headers
        });
    }

    downloadPdf(id: number) {
        let url = this.downloadUrl + id;
        return this.getFile(url);
    }

    getFile(url: string) {
        var headers = new Headers();
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.get(url, { headers: headers });
    }
    fetchPrestatements() {
        var headers = new Headers();        
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.statementUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IStatement[]);
    }
}