﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from "rxjs";
import { environment } from "../../../../../environments/environment";
import { IClient, INetwork, IProperty } from "../../../../shared/interface";
import { PropertyWithOwner, StatementGenerationInput } from "../../../../shared/class";

@Injectable()
export class GenerateStatementService {
    constructor(private http: Http) { }

    clientMetaDataUrl = environment.host + 'client-metadata';
    networkBaseUrl = environment.host + 'network-by-client?clientId=';
    propertyUrl = environment.host + 'property-by-network';
    clientSearchUrl = environment.host + 'client-metadata-by-name?name=';
    networkSearchUrl = environment.host + 'network-by-name?name=';
    propertySearchUrl = environment.host + 'property-by-name?name=';
    generateStatementQueueUrl = environment.host + 'generate-pre-statement-queue';

    generateStatementQueue(input: StatementGenerationInput) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.generateStatementQueueUrl, input, {
            headers: headers
        });
    }

    getClients() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.clientMetaDataUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);
    }

    getClientByName(name: string) {
        let url = this.clientSearchUrl + name;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);
    }

    getAllNetworksForClient(clientId: number) {
        var url = this.networkBaseUrl + clientId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as INetwork[]);
    }

    getNetworkByName(network: string) {
        let url = this.networkSearchUrl + network;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as INetwork[]);
    }

    getAllPropertiesForNetwork(networkIds: number[]) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.propertyUrl, networkIds, {
            headers: headers
        });
    }

    getAllPropertiesByName(propertyName: string) {
        let url = this.propertySearchUrl + propertyName;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as PropertyWithOwner[]);
    }
}