﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalService } from "../../../../shared/services/global.service";
import { IMyDpOptions } from 'mydatepicker';
import { IClient, INetwork, IProperty } from "../../../../shared/interface";
import { GenerateStatementService } from "./generate.service";
import swal from 'sweetalert2';
import { PropertyWithOwner, StatementGenerationInput } from "../../../../shared/class";
@Component({
    selector: 'app-generate-statements',
    templateUrl: './generate.component.html',
    styleUrls: ['./generate.component.scss'],
    providers: [GenerateStatementService]
})
export class GenerateStatementComponent implements OnInit {
    displayErrorMessage: boolean = false;
    clientIds: IClient[];
    networks: INetwork[];
    isSearch: boolean = false;
    searchSelected: number = 1;
    searchText: string = "";
    selectedNetworks: number[];
    properties: PropertyWithOwner[];
    selectedProperties: number[];
    clientSelected: boolean = false;
    networkSelected: boolean = false;
    allNetworks: boolean = false;
    allProperties: boolean = false;
    load: boolean = false;
    isgenerate: boolean = false;
    constructor(public router: Router, private service: GenerateStatementService) {
    }
    ngOnInit(): void {
        this.loadClientData();
        this.clientSelected = false;
        this.load = false;
        this.isSearch = false;
        this.isgenerate = false;
    }
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy'
    };
    public model: any = null;

    generateStatement() {
        this.isgenerate = false;
        this.displayErrorMessage = false;
        let input = new StatementGenerationInput();
        if (this.model == null || this.model == undefined) {
            this.isgenerate = true;
            return;
        } else {
            if (this.model.date.month == 1) {
                input.billDate = new Date(this.model.date.year - 1, this.model.date.month + 11, this.model.date.day);
            } else {
                input.billDate = new Date(this.model.date.year, this.model.date.month - 1, this.model.date.day);
            }
        }        
        if (this.selectedProperties == null || this.selectedProperties.length == 0) {
            swal({
                type: 'error',
                title: 'Oops...',
                text: 'Please select the properties.'
            });
            return;
        } else {
            input.propertyIDs = this.selectedProperties;
        }
        var result = this.validatePropertiesLastBilledDate(input.billDate);
        if (result == true)
            return;
        this.service.generateStatementQueue(input).subscribe(
            (value) => {
                swal({ type: 'success', title: 'Statement generation request submitted!', showConfirmButton: true });
            },
            (Error) => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong. Please check with administrator.'
                });
            }
        );
    }

    search() {
        this.displayErrorMessage = false;
        if (this.searchText == null || this.searchText == undefined || this.searchText == "")
        {
            this.loadClientData();
            this.clientSelected = false;
            this.networkSelected = false;
            this.load = false;
            this.isSearch = false;
            this.allNetworks = false;
            return;
        }
        if (this.searchSelected == 1)
            this.searchClientByName(this.searchText);
        else if (this.searchSelected == 2)
            this.searchNetworkByName(this.searchText);
        else if (this.searchSelected == 3)
            this.searchPropertyByName(this.searchText);
        else {
            this.loadClientData();
            this.clientSelected = false;
            this.networkSelected = false;
            this.load = false;
            this.isSearch = false;
            this.allNetworks = false;
            return;
        }
    }

    loadClientData() {
        this.isgenerate = false;
        this.load = true;
        this.service.getClients().then(
            (value) => {
                this.clientIds = value;
                this.load = false;
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    searchClientByName(name: string) {
        this.load = true;
        this.clientSelected = false;
        this.allNetworks = false;
        this.service.getClientByName(name).then(
            (value) => {
                this.clientIds = value;
                this.load = false;
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    searchNetworkByName(network: string) {
        this.isSearch = true;
        this.clientSelected = true;
        this.networkSelected = false;
        this.clientIds = null;
        this.allNetworks = false;
        this.service.getNetworkByName(network).then(
            (value) => {
                this.networks = value;
            },
            (error) => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    getNetworkDetails(clientId: number) {
        this.displayErrorMessage = false;
        this.clientSelected = true;
        this.networkSelected = false;
        this.allNetworks = false;
        this.service.getAllNetworksForClient(clientId).then(
            (value) => {                
                this.networks = value;
                console.log(this.networks);
            },
            (error) => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    } 
    addOrRemoveNetworkToList(networkId: number) {
        this.networkSelected = true;
        if (networkId == -1) {
            this.selectedNetworks = new Array();
            this.networkSelected = false;            
        }
        else if (networkId == 0) {
            this.selectedNetworks = new Array();
            if (this.networks != null && this.networks != undefined) {
                let i = 0;
                for (i = 0; i < this.networks.length; i++) {
                    this.selectedNetworks[i] = this.networks[i].networkId;
                }
            }
            this.getPropertyDetails();
        } else {
            if (this.selectedNetworks == undefined || this.selectedNetworks == null || this.selectedNetworks.length==0) {
                this.selectedNetworks = new Array();
                this.selectedNetworks.push(networkId);
                this.getPropertyDetails();
            }
            else if (this.selectedNetworks.find(x => x == networkId) == networkId) {
                const index = this.selectedNetworks.indexOf(networkId, 0);
                if (index > -1) {
                    this.selectedNetworks.splice(index, 1);
                }
                if (this.selectedNetworks.length > 0)
                    this.getPropertyDetails();
                else
                    this.networkSelected = false;
            } else {
                this.selectedNetworks.push(networkId);
                this.getPropertyDetails();
            }
        }        
    }
    addOrRemovePropertyToList(propertyId: number) {
        if (this.selectedProperties == undefined || this.selectedProperties == null)
            this.selectedProperties = new Array();
        if (propertyId == -1) {
            this.selectedProperties = new Array();
        } else if (propertyId == 0) {
            if (this.properties != null && this.properties != undefined) {
                let i = 0;
                for (i = 0; i < this.properties.length; i++) {
                    this.selectedProperties[i] = this.properties[i].pid;
                }
            }
        } else {
            if (this.selectedProperties == null || this.selectedProperties == undefined || this.selectedProperties.length == 0) {
                this.selectedProperties = new Array();
                this.selectedProperties.push(propertyId);
            } else if (this.selectedProperties.find(x => x == propertyId) == propertyId) {
                const index = this.selectedProperties.indexOf(propertyId, 0);
                if (index > -1) {
                    this.selectedProperties.splice(index, 1);
                }
            } else {
                this.selectedProperties.push(propertyId);
            }
        }
    }

    searchPropertyByName(name: string) {
        this.clientIds = null;
        this.networks = null;
        this.networkSelected = true;
        this.allNetworks = false;
        this.service.getAllPropertiesByName(name).then(
            (value) => {
                this.properties = value;
            },
            (error) => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    getPropertyDetails() {
        this.displayErrorMessage = false;
        this.load = true;
        this.service.getAllPropertiesForNetwork(this.selectedNetworks).subscribe(
            (value) => {
                this.properties = JSON.parse(value['_body']);
                this.load = false;
            },
            (error) => {
                this.properties = new Array();
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    checkAllNetworks() {        
        if (!this.allNetworks) {
            this.networks.forEach(function (value) { value.allowPrepayment = true; });
            this.addOrRemoveNetworkToList(0);
        }
        else {
            this.networks.forEach(function (value) { value.allowPrepayment = false; });
            this.addOrRemoveNetworkToList(-1);
        }
    }

    checkAllProperties() {
        if (!this.allProperties) {
            this.properties.forEach(function (value) {
                value.isSelected = true;                
            });
            this.addOrRemovePropertyToList(0);
        } else {
            this.properties.forEach(function (value) {
                value.isSelected = false;                
            });            
            this.addOrRemovePropertyToList(-1);
        }
    }

    validatePropertiesLastBilledDate(billDate: Date) {
        var flag = false;
        for (var i = 0; i < this.properties.length; i++) {
            if (this.properties[i].isSelected) {                
                var res = this.isGreaterThanOrEqualTo(new Date(this.properties[i].lastBilledDate), billDate);
                console.log(res);
                if (res) {
                    this.properties[i].isError = true;
                    this.displayErrorMessage = true;
                    flag = true;
                } else {
                    this.properties[i].isError = false;
                }
            }
        }
        return flag;
    }

    isGreaterThanOrEqualTo(date1: Date, date2: Date) {
        var result = false;        
        if (date1.getFullYear() > date2.getFullYear()) {
            return true;
        } else {
            if (date1.getFullYear() == date2.getFullYear()) {
                if (date1.getMonth() > date2.getMonth()) {
                    return true;
                } else if (date1.getMonth() < date2.getMonth()) {
                    return false;
                } else {
                    if (date1.getDate() >= date2.getDate())
                        return true;
                    else
                        return false;
                }
            } else
                return false;
        }
    }
}