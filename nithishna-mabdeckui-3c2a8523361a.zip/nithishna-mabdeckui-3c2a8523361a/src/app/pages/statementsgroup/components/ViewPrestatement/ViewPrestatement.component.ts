﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalService } from "../../../../shared/services/global.service";
import { IClient, INetwork, IProperty, IPreStatement } from "../../../../shared/interface";
import swal from 'sweetalert2';
import { ViewPreStatementService } from "./ViewPrestatement.service";
@Component({
    selector: 'app-viewprestatements',
    templateUrl: './ViewPrestatement.component.html',
    styleUrls: ['./ViewPrestatement.component.scss'],
    providers: [ViewPreStatementService]
})
export class ViewPreStatementComponent implements OnInit {
    load: Boolean = false;
    param: string;
    data: IPreStatement[];
    constructor(public router: Router, private service: ViewPreStatementService, private route: ActivatedRoute) {
        this.route.params.subscribe(
            params => {
                this.param = params['id'];
            }
        );
    }
    ngOnInit(): void {
        this.fetchPreStatements();
    }

    fetchPreStatements() {
        this.load = true;
        this.service.fetchPrestatement(this.param).then(
            (value) => {
                this.data = value;
                this.load = false;
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }
}