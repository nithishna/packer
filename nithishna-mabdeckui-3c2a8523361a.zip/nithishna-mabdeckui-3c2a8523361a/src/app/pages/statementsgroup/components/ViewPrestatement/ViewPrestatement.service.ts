import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from "rxjs";
import { environment } from "../../../../../environments/environment";
import { IClient, INetwork, IProperty, IPreStatement } from "../../../../shared/interface";
import { PropertyWithOwner, StatementGenerationInput, PreStatementQueue } from "../../../../shared/class";

@Injectable()
export class ViewPreStatementService {
    constructor(private http: Http) { }
    preStatementUrl = environment.host + 'pre-statement?queueId=';

    fetchPrestatement(queueId: string) {
        let url = this.preStatementUrl + queueId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));  
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IPreStatement[]);
    }
}