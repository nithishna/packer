﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalService } from "../../../../shared/services/global.service";
import { IClient, INetwork, IProperty } from "../../../../shared/interface";
import swal from 'sweetalert2';
import { PreStatementService } from "./Prestatement.service";
import { PreStatementQueue } from "../../../../shared/class";
@Component({
    selector: 'app-pre-statements',
    templateUrl: './Prestatement.component.html',
    styleUrls: ['./Prestatement.component.scss'],
    providers: [PreStatementService]
})
export class PreStatementComponent implements OnInit {
    data: PreStatementQueue[];
    load: Boolean = false;
    constructor(public router: Router, private service: PreStatementService) {
    }
    ngOnInit(): void {
        this.fetchPrestatementQueue();
    }

    fetchPrestatementQueue() {
        this.load = true;
        this.service.fetchPrestatements().then(
            (value) => {
                this.load = false;
                this.data = value;                
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });  
            }
        );
    }

    deletePreStatementQueueById(id: number) {
        this.load = true;
        this.service.deletePreStatementById(id).subscribe(
            (data) => {
                this.load = false;
                swal({ type: 'success', title: 'Queue entry cleared!', showConfirmButton: true });
                this.fetchPrestatementQueue();
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    generateStatements(id: number) {
        this.load = true;
        this.service.generateStatements(id).subscribe(
            (data) => {
                this.load = false;
                swal({ type: 'success', title: 'Statements generated successfully!', showConfirmButton: true });
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }

    updatePreStatementQueueById(id: number) {
        this.load = true;
        this.service.updatePreStatementById(id).subscribe(
            (data) => {
                this.load = false;
                swal({ type: 'success', title: 'Queue status updated!', showConfirmButton: true });
                this.fetchPrestatementQueue();
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with system administrator.'
                });
            }
        );
    }
}