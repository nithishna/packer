﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from "rxjs";
import { environment } from "../../../../../environments/environment";
import { IClient, INetwork, IProperty } from "../../../../shared/interface";
import { PropertyWithOwner, StatementGenerationInput, PreStatementQueue } from "../../../../shared/class";

@Injectable()
export class PreStatementService {
    constructor(private http: Http) { }
    preStatementUrl = environment.host + 'pre-statement-queue';
    generateStatementUrl = environment.host + 'generate-statement?id=';

    generateStatements(id: number) {
        let url = this.generateStatementUrl + id;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Authorization", 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(url, "", {
            headers: headers
        });
    }

    fetchPrestatements() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));    
        return this.http
            .get(this.preStatementUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as PreStatementQueue[]);
    }

    deletePreStatementById(id: number) {
        let url = this.preStatementUrl + '?id=' + id;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Authorization", 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(url,"", {
            headers: headers
        });
    }

    updatePreStatementById(id: number) {
        let url = this.preStatementUrl + '?id=' + id;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Authorization", 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, "", {
            headers: headers
        });
    }
}