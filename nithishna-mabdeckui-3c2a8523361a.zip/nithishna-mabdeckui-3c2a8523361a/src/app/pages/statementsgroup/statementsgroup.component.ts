﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-statementsgroup',
    template: `<router-outlet></router-outlet>`
})
export class StatementsGroupComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
