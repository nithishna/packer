﻿export let MENU_ITEM = [
    {
        path: 'dashboard',
        title: 'Dashboard',
        icon: 'dashboard'
    },
    {
        path: 'imports',
        title: 'Imports',
        icon: 'exchange'
    },
    {
        path: 'account',
        title: 'Accounts',
        icon: 'archive'
    },
    {
        path: 'properties',
        title: 'Properties',
        icon: 'home'
    },
    {
        path: 'statements',
        title: 'Statements',
        icon: 'file'
    },
    {
        path: 'reports',
        title: 'Reports',
        icon: 'line-chart'
    },
    {
        path: 'validation',
        title: 'Validation',
        icon: 'check-square-o'
    },
    {
        path: 'finance',
        title: 'Finance',
        icon: 'gbp'
    },
    {
        path: 'correspondence',
        title: 'Correspondence',
        icon: 'envelope'
    },
    {
        path: 'onboarding',
        title: 'Setup',
        icon: 'wrench'
    }
];
