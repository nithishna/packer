﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { routing } from './validationgroup.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { ValidationGroupComponent } from './validationgroup.component';
import { ValidationComponent } from './components/validation/validation.component';
import { ValidationSettingsComponent } from './components/settings/settings.component';
import { LayoutModule } from '../../shared/layout.module';
import { ErrorsComponent } from './components/errors/errors.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        routing,
        LayoutModule,
        NgxPaginationModule
    ],
    declarations: [
        ValidationGroupComponent,
        ValidationComponent,
        ValidationSettingsComponent,
        ErrorsComponent
    ]
})
export class ValidationGroupModule { }
