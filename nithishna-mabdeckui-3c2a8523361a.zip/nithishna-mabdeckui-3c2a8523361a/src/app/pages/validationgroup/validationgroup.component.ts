﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-validationgroup',
    template: `<router-outlet></router-outlet>`
})
export class ValidationGroupComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
