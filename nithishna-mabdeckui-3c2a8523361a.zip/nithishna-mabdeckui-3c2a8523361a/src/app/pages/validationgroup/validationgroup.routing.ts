﻿import { Routes, RouterModule } from '@angular/router';
import { ValidationGroupComponent } from './validationgroup.component';
import { ValidationComponent } from './components/validation/validation.component';
import { ValidationSettingsComponent } from './components/settings/settings.component';
import { ErrorsComponent } from './components/errors/errors.component';

const childRoutes: Routes = [
    {
        path: '',
        component: ValidationGroupComponent,
        children: [
            { path: '', redirectTo: 'validation', pathMatch: 'full' },
            { path: 'validation', component: ValidationComponent },
            { path: 'settings', component: ValidationSettingsComponent },
            { path: 'errors', component: ErrorsComponent }
        ]
    }
];

export const routing = RouterModule.forChild(childRoutes);