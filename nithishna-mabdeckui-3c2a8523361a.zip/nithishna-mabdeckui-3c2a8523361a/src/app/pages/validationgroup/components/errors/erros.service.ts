import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { environment } from '../../../../../environments/environment';
import { IValidationErrors, INegativeConsumptionValidationError, INegativeReadingValidationError, ITempDifferenceError, IZeroReadingValidationError } from '../../../../shared/interface';

@Injectable()
export class ErrorService {

    validationApproveUrl = environment.host + 'validation/approve';
    validationBulkApproveUrl = environment.host + 'validation/approve/bulk';
    validationRejectUrl = environment.host + 'validation/reject';
    validationBulkRejectUrl = environment.host + 'validation/reject/bulk';
    negativeValidationList = environment.host + 'negative-validation';
    negativeReadingList = environment.host + 'negative-reading';
    zeroValidationList = environment.host + 'zero-validation';
    tempDiffValidationList = environment.host + 'temp-validation';
    constructor(private http: Http) { }

    approve(id:number, type: number) {
        let url = this.validationApproveUrl + '?id=' + id + '&type=' + type;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, {
            headers: headers
        });
    }

    bulkApprove(ids: number[], type: number) {
        let url = this.validationBulkApproveUrl + '?type=' + type;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, ids, {
            headers: headers
        });
    }

    reject(id:number, type: number) {
        let url = this.validationRejectUrl + '?id=' + id + '&type=' + type;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, {
            headers: headers
        });
    }

    bulkReject(ids: number[], type: number) {
        let url = this.validationBulkRejectUrl + '?type=' + type;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(url, ids, {
            headers: headers
        });
    }

    getAllNegativeConsumptionHistory(index: number, size: number) {
        let url = this.negativeValidationList + '?index=' + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as INegativeConsumptionValidationError[]);
    }

    getAllNegativeReading(index: number, size: number) {
        let url = this.negativeReadingList + '?index=' + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as INegativeReadingValidationError[]);
    }

    getAllTemperatureDifferenceValidationErrors(index: number, size: number) {
        let url = this.tempDiffValidationList + '?index=' + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as ITempDifferenceError[]);
    }

    getAllZeroReadingValidationErrors(index: number, size: number) {
        let url = this.zeroValidationList + '?index=' + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IZeroReadingValidationError[]);
    }

    getAllNegativeConsumptionHistoryCount() {
        let url = this.negativeValidationList + "/count"
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as number);
    }

    getAllNegativeReadingCount() {
        let url = this.negativeReadingList + "/count"
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as number);
    }

    getAllTemperatureDifferenceValidationErrorsCount() {
        let url = this.tempDiffValidationList + "/count"
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as number);
    }

    getAllZeroReadingValidationErrorsCount() {
        let url = this.zeroValidationList + "/count"
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as number);
    }
}