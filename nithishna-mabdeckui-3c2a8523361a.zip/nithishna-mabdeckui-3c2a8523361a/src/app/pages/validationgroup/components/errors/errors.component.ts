import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalService } from "../../../../shared/services/global.service";
import { Network, Client } from "../../../../shared/class";
import { IClient } from '../../../../shared/interface';
import swal from 'sweetalert2';
import { ErrorService } from './erros.service';
import { IValidationErrors, INegativeConsumptionValidationError, INegativeReadingValidationError, ITempDifferenceError, IZeroReadingValidationError } from '../../../../shared/interface';
@Component({
    selector: 'app-validation-errors',
    templateUrl: './errors.component.html',
    styleUrls: ['./errors.component.scss'],
    providers: [ErrorService]
})
export class ErrorsComponent implements OnInit {
    load: boolean = false
    pageSize = 10;
    pageNumber = 1;
    totalNumberOfItems = 5;
    selectAll: boolean = false;
    negativeConsumptionValidation: INegativeConsumptionValidationError[] = [];
    negativeReadingValidation: INegativeReadingValidationError[] = [];
    tempDifferenceValidation: ITempDifferenceError[] = [];
    zeroReadingValidation: IZeroReadingValidationError[] = [];
    ncCount = 0;
    nrCount = 0;
    tdCount = 0;
    zrCount = 0;
    navigate = 1;
    aggregatedIds: number[] = [];
    constructor(private router: Router, private _globalService: GlobalService, private service: ErrorService) { }

    pageChanged(pN: number): void {
        this.pageNumber = pN;
    }
    ngOnInit() {
        this.authenticationCheck();
        this.tabNavigate();
        this.getAllNegativeConsumptionHistoryCount();
        this.getAllTemperatureDifferenceValidationErrorsCount();
        this.getAllNegativeReadingCount();
        this.getAllZeroReadingValidationErrorsCount();
    }

    aggregate(item: IValidationErrors) {
        if (item.selected) {
            this.aggregatedIds.push(item.validationId);
        } else {
            const index = this.aggregatedIds.indexOf(item.validationId, 0);
            if (index > -1) {
                this.aggregatedIds.splice(index, 1);
            }
        }
    }

    approve() {
        if (this.selectAll) {
            this.bulkApprove();
            this.aggregatedIds = [];
        } else {
            if (this.aggregatedIds && this.aggregatedIds.length > 0) {
                this.load = true;
                this.service.bulkApprove(this.aggregatedIds, this.navigate).subscribe(
                    (value) => {
                        this.load = false;
                        this.tabNavigate();
                        swal({
                            type: 'success',
                            title: 'Approved!',
                            showConfirmButton: true
                        });
                        this.aggregatedIds = [];
                    },
                    (error) => {
                        this.load = false;
                        swal({
                            type: 'error',
                            title: 'Oops...',
                            text: 'Something went wrong! Please check with the administrator.'
                        });
                    }
                );
            } else {
                swal({
                    title: 'Kindly make a selection and try again!',
                    showConfirmButton: true
                });
            }
        }
        this.updateCount();
    }

    updateCount(){
        switch(this.navigate){
            case 1:
                this.getAllNegativeConsumptionHistoryCount();
                break;
            case 2:
                this.getAllNegativeReadingCount();
                break;
            case 3:
                this.getAllTemperatureDifferenceValidationErrorsCount();
                break;
            case 4:
                this.getAllZeroReadingValidationErrorsCount();
                break;
        }
    }

    reject() {
        if (this.selectAll) {
            this.bulkReject();
            this.aggregatedIds = [];
        } else {
            if (this.aggregatedIds && this.aggregatedIds.length > 0) {
                this.load = true;
                this.service.bulkReject(this.aggregatedIds, this.navigate).subscribe(
                    (value) => {
                        this.load = false;
                        this.tabNavigate();
                        swal({
                            type: 'success',
                            title: 'Rejected!',
                            showConfirmButton: true
                        });
                        this.aggregatedIds = [];
                    },
                    (error) => {
                        this.load = false;
                        swal({
                            type: 'error',
                            title: 'Oops...',
                            text: 'Something went wrong! Please check with the administrator.'
                        });
                    }
                );
            } else {
                swal({
                    title: 'Kindly make a selection and try again!',
                    showConfirmButton: true
                });
            }
        }
        this.updateCount();
    }

    selectEntireList() {
        if (this.selectAll) {
            switch (this.navigate) {
                case 1:
                    if (this.negativeConsumptionValidation) {
                        this.negativeConsumptionValidation.forEach(function (value) {
                            value.selected = true;
                        });
                    }
                    break;
                case 2:
                    if (this.negativeReadingValidation) {
                        this.negativeReadingValidation.forEach(function (value) {
                            value.selected = true;
                        });
                    }
                    break;
                case 3:
                    if (this.tempDifferenceValidation) {
                        this.tempDifferenceValidation.forEach(function (value) {
                            value.selected = true;
                        });
                    }
                    break;
                case 4:
                    if (this.zeroReadingValidation) {
                        this.zeroReadingValidation.forEach(function (value) {
                            value.selected = true;
                        });
                    }
                    break;
            }
        } else {
            switch (this.navigate) {
                case 1:
                    if (this.negativeConsumptionValidation) {
                        this.negativeConsumptionValidation.forEach(function (value) {
                            value.selected = false;
                        });
                    }
                    break;
                case 2:
                    if (this.negativeReadingValidation) {
                        this.negativeReadingValidation.forEach(function (value) {
                            value.selected = false;
                        });
                    }
                    break;
                case 3:
                    if (this.tempDifferenceValidation) {
                        this.tempDifferenceValidation.forEach(function (value) {
                            value.selected = false;
                        });
                    }
                    break;
                case 4:
                    if (this.zeroReadingValidation) {
                        this.zeroReadingValidation.forEach(function (value) {
                            value.selected = false;
                        });
                    }
                    break;
            }
        }
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    bulkApprove() {
        switch (this.navigate) {
            case 1:
                this.bulkApproveNC();
                break;
            case 2:
                this.bulkApproveNR();
                break;
            case 3:
                this.bulkApproveTD();
                break;
            case 4:
                this.bulkApproveZR();
                break;
        }
    }

    bulkApproveNC() {
        let ids: number[] = [];
        if (this.negativeConsumptionValidation) {
            this.load = true;
            for (let index = 0; index < this.negativeConsumptionValidation.length; index++) {
                ids.push(this.negativeConsumptionValidation[index].validationId);
            }
            this.service.bulkApprove(ids, this.navigate).subscribe(
                (value) => {
                    this.load = false;
                    this.tabNavigate();
                    swal({
                        type: 'success',
                        title: 'Approved!',
                        showConfirmButton: true
                    });
                },
                (error) => {
                    this.load = false;
                    swal({
                        type: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong! Please check with the administrator.'
                    });
                }
            );
        }

    }
    bulkApproveNR() {
        let ids: number[] = [];
        if (this.negativeReadingValidation) {
            this.load = true;
            for (let index = 0; index < this.negativeReadingValidation.length; index++) {
                ids.push(this.negativeReadingValidation[index].validationId);
            }
            this.service.bulkApprove(ids, this.navigate).subscribe(
                (value) => {
                    this.load = false;
                    this.tabNavigate();
                    swal({
                        type: 'success',
                        title: 'Approved!',
                        showConfirmButton: true
                    });
                },
                (error) => {
                    this.load = false;
                    swal({
                        type: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong! Please check with the administrator.'
                    });
                }
            );
        }
    }
    bulkApproveTD() {
        let ids: number[] = [];
        if (this.tempDifferenceValidation) {
            this.load = true;
            for (let index = 0; index < this.tempDifferenceValidation.length; index++) {
                ids.push(this.tempDifferenceValidation[index].validationId);
            }
            this.service.bulkApprove(ids, this.navigate).subscribe(
                (value) => {
                    this.load = false;
                    this.tabNavigate();
                    swal({
                        type: 'success',
                        title: 'Approved!',
                        showConfirmButton: true
                    });
                },
                (error) => {
                    this.load = false;
                    swal({
                        type: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong! Please check with the administrator.'
                    });
                }
            );
        }
    }
    bulkApproveZR() {
        let ids: number[] = [];
        if (this.zeroReadingValidation) {
            this.load = true;
            for (let index = 0; index < this.zeroReadingValidation.length; index++) {
                ids.push(this.zeroReadingValidation[index].validationId);
            }
            this.service.bulkApprove(ids, this.navigate).subscribe(
                (value) => {
                    this.load = false;
                    this.tabNavigate();
                    swal({
                        type: 'success',
                        title: 'Approved!',
                        showConfirmButton: true
                    });
                },
                (error) => {
                    this.load = false;
                    swal({
                        type: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong! Please check with the administrator.'
                    });
                }
            );
        }
    }
    /*approve(id: number) {
        this.service.approve(id, this.navigate).subscribe(
            (value) => {
                this.tabNavigate();
                swal({
                    type: 'success',
                    title: 'Approved!',
                    showConfirmButton: true
                });
            },
            (error) => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }*/

    doNavigate(value: number) {
        this.aggregatedIds = [];
        this.selectAll = false;
        this.navigate = value;
        this.tabNavigate();        
    }

    tabNavigate() {
        switch (this.navigate) {
            case 1:
                this.getAllNegativeConsumptionHistory();
                break;
            case 2:
                this.getAllNegativeReading();
                break;
            case 3:
                this.getAllTemperatureDifferenceValidationErrors();
                break;
            case 4:
                this.getAllZeroReadingValidationErrors();
                break;
        }
    }

    /*reject(id: number) {
        this.service.reject(id, this.navigate).subscribe(
            (value) => {
                swal({
                    type: 'success',
                    title: 'Rejected!',
                    showConfirmButton: true
                });
            },
            (error) => {
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }*/

    bulkReject() {
        switch (this.navigate) {
            case 1:
                this.bulkRejectNC();
                break;
            case 2:
                this.bulkRejectNR();
                break;
            case 3:
                this.bulkRejectTD();
                break;
            case 4:
                this.bulkRejectZR();
                break;
        }
    }

    bulkRejectNC() {
        let ids: number[] = [];
        if (this.negativeConsumptionValidation) {
            this.load = true;
            for (let index = 0; index < this.negativeConsumptionValidation.length; index++) {
                ids.push(this.negativeConsumptionValidation[index].validationId);
            }
            this.service.bulkReject(ids, this.navigate).subscribe(
                (value) => {
                    this.load = false;
                    this.tabNavigate();
                    swal({
                        type: 'success',
                        title: 'Rejectd!',
                        showConfirmButton: true
                    });
                },
                (error) => {
                    this.load = false;
                    swal({
                        type: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong! Please check with the administrator.'
                    });
                }
            );
        }

    }
    bulkRejectNR() {
        let ids: number[] = [];
        if (this.negativeReadingValidation) {
            this.load = true;
            for (let index = 0; index < this.negativeReadingValidation.length; index++) {
                ids.push(this.negativeReadingValidation[index].validationId);
            }
            this.service.bulkReject(ids, this.navigate).subscribe(
                (value) => {
                    this.load = false;
                    this.tabNavigate();
                    swal({
                        type: 'success',
                        title: 'Rejectd!',
                        showConfirmButton: true
                    });
                },
                (error) => {
                    this.load = false;
                    swal({
                        type: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong! Please check with the administrator.'
                    });
                }
            );
        }
    }
    bulkRejectTD() {
        let ids: number[] = [];
        if (this.tempDifferenceValidation) {
            this.load = true;
            for (let index = 0; index < this.tempDifferenceValidation.length; index++) {
                ids.push(this.tempDifferenceValidation[index].validationId);
            }
            this.service.bulkReject(ids, this.navigate).subscribe(
                (value) => {
                    this.load = false;
                    this.tabNavigate();
                    swal({
                        type: 'success',
                        title: 'Rejectd!',
                        showConfirmButton: true
                    });
                },
                (error) => {
                    this.load = false;
                    swal({
                        type: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong! Please check with the administrator.'
                    });
                }
            );
        }
    }
    bulkRejectZR() {
        let ids: number[] = [];
        if (this.zeroReadingValidation) {
            this.load = true;
            for (let index = 0; index < this.zeroReadingValidation.length; index++) {
                ids.push(this.zeroReadingValidation[index].validationId);
            }
            this.service.bulkReject(ids, this.navigate).subscribe(
                (value) => {
                    this.load = false;
                    this.tabNavigate();
                    swal({
                        type: 'success',
                        title: 'Rejectd!',
                        showConfirmButton: true
                    });
                },
                (error) => {
                    this.load = false;
                    swal({
                        type: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong! Please check with the administrator.'
                    });
                }
            );
        }
    }


    getAllNegativeConsumptionHistory() {
        this.load = true;
        this.service.getAllNegativeConsumptionHistory(this.pageNumber, this.pageSize).then(
            (value) => {
                this.negativeConsumptionValidation = value;
                this.load = false;
                this.updateCount();
            },
            (error) => {
                this.load = false;
            }
        );
    }

    getAllNegativeReading() {
        this.load = true;
        this.service.getAllNegativeReading(this.pageNumber, this.pageSize).then(
            (value) => {
                this.negativeReadingValidation = value;
                this.load = false;
                this.updateCount();
            },
            (error) => {
                this.load = false;
            }
        );
    }

    getAllTemperatureDifferenceValidationErrors() {
        this.load = true;
        this.service.getAllTemperatureDifferenceValidationErrors(this.pageNumber, this.pageSize).then(
            (value) => {
                this.tempDifferenceValidation = value;
                this.load = false;
                this.updateCount();
            },
            (error) => {
                this.load = false;
            }
        );
    }

    getAllZeroReadingValidationErrors() {
        this.load = true;
        this.service.getAllZeroReadingValidationErrors(this.pageNumber, this.pageSize).then(
            (value) => {
                this.zeroReadingValidation = value;
                this.load = false;
                this.updateCount();
            },
            (error) => {
                this.load = false;
            }
        );
    }

    getAllNegativeConsumptionHistoryCount() {
        this.service.getAllNegativeConsumptionHistoryCount().then(
            (value) => {
                this.ncCount = value;
                if(this.ncCount == 0)
                    this.selectAll = false;
            },
            (error) => {
                console.error(error);
            }
        );
    }

    getAllNegativeReadingCount() {
        this.service.getAllNegativeReadingCount().then(
            (value) => {
                this.nrCount = value;
                if(this.nrCount==0)
                    this.selectAll = false;
            },
            (error) => {
                console.error(error);
            }
        );
    }

    getAllTemperatureDifferenceValidationErrorsCount() {
        this.service.getAllTemperatureDifferenceValidationErrorsCount().then(
            (value) => {
                this.tdCount = value;
                if(this.tdCount == 0)
                    this.selectAll = false;
            },
            (error) => {
                console.error(error);
            }
        );
    }

    getAllZeroReadingValidationErrorsCount() {
        this.service.getAllZeroReadingValidationErrorsCount().then(
            (value) => {
                this.zrCount = value;
                if(this.zrCount == 0)
                    this.selectAll = false;
            },
            (error) => {
                console.error(error);
            }
        );
    }

}