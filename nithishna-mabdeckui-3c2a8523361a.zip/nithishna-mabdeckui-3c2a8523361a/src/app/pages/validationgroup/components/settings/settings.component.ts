import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalService } from "../../../../shared/services/global.service";
import { SettingService } from './settings.service';
import { Network, Client } from "../../../../shared/class";
import { IClient, IValidation, ITempDifferenceValidation, IZeroConsumptionValidation, INegativeConsumptionValidation } from '../../../../shared/interface';
import swal from 'sweetalert2';
@Component({
    selector: 'app-validation-settings',
    templateUrl: './settings.component.html',
    styleUrls: ['./settings.component.scss'],
    providers: [SettingService]
})
export class ValidationSettingsComponent implements OnInit {
    load: boolean = false;
    flag: boolean= false;
    negativeValId: number = 0;
    selectedSupplyId: number = 2;
    enabled: boolean = false;
    tolerance: number = 0;
    networkList: Network[] = new Array(0);
    clientData: IClient[];
    selectedClientId: number = 0;
    selectedNetworkId: number = 0;
    validation: IValidation = {
        client: new Client(),
        emailNotification: null,
        negativeValidation: null,
        network: new Network(),
        tempValidation: {
            enabled: false,
            tolerance: null,
            validation: null,
            validationId: null
        },
        validId: null,
        zeroConsumptionValidation: {
            enabled: false,
            tolerance: null,
            validation: null,
            validationId: null
        }
    };
    emailIds: string[] = [];
    email: string = null;

    initializeValidation(){
        this.emailIds = [];
        this.enabled = false;
        this.tolerance = 0;
        this.selectedSupplyId = 2;
        this.validation = {
            client: new Client(),
            emailNotification: null,
            negativeValidation: null,
            network: new Network(),
            tempValidation: {
                enabled: false,
                tolerance: null,
                validation: null,
                validationId: null
            },
            validId: null,
            zeroConsumptionValidation: {
                enabled: false,
                tolerance: null,
                validation: null,
                validationId: null
            }
        };
    }

    constructor(private router: Router, private _globalService: GlobalService, private settingService: SettingService) { }

    ngOnInit() {
        this.authenticationCheck();
        this.loadClientData();
    }

    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    loadClientData() {
        this.settingService.getClients().then((value) => {
            console.log("Value = " + value);
            this.clientData = value;
            if(value != null && value.length>0){
                this.selectedClientId = value[0].clientId;
                this.fetchNetworkData();
            }
        });
    }

    fetchNetworkData() {
        this.flag = false;
        this.settingService.getNetworkForClient(this.selectedClientId).then((value) => {
            console.log("Value = " + value);
            this.networkList = value;
            if(value == null || value.length == 0) {
                this.initializeValidation();
                this.flag = true;
            } else {
                this.selectedNetworkId = value[0].networkId;
                this.getValidation();
            }
        });
    }

    addEmail() {
        if(this.email)
            this.emailIds.push(this.email);
        this.email = null;
    }

    removeEmail(email: string) {
        const index = this.emailIds.indexOf(email, 0);
        if (index > -1) {
            this.emailIds.splice(index, 1);
        }
    }

    saveNotification(){
        let emailId : string = "";
        for(let index=0; index<this.emailIds.length; index++){
            emailId += this.emailIds[index];
            if(index<this.emailIds.length-1){
                emailId += ",";
            }
        }
        let val: IValidation = {
            client: new Client(),
            emailNotification: emailId,
            negativeValidation: null,
            network: new Network(),
            tempValidation: null,
            validId: this.validation.validId,
            zeroConsumptionValidation: null
        }
        val.client.clientId = this.selectedClientId;
        val.network.networkId = this.selectedNetworkId;
        this.settingService.addNotification(val).subscribe(
            (value)=>{
                this.getValidation();
                swal({
                    type: 'success',
                    title: 'Data saved successfully',
                    showConfirmButton: true
                });
            },
            (error)=>{
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    saveTempValidation(){
        this.validation.client.clientId = this.selectedClientId;
        this.validation.network.networkId = this.selectedNetworkId;
        const tempVal: ITempDifferenceValidation = {
            enabled: this.validation.tempValidation.enabled,
            tolerance: this.validation.tempValidation.tolerance,
            validation: this.validation,
            validationId: this.validation.tempValidation.validationId
        }
        this.settingService.addTempValidation(tempVal).subscribe(
            (value)=>{
                this.getValidation();
                swal({
                    type: 'success',
                    title: 'Data saved successfully',
                    showConfirmButton: true
                });
            },
            (error)=>{
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    saveZeroConsumptionValidation(){
        this.validation.client.clientId = this.selectedClientId;
        this.validation.network.networkId = this.selectedNetworkId;
        const zeroVal: IZeroConsumptionValidation = {
            enabled: this.validation.zeroConsumptionValidation.enabled,
            tolerance: this.validation.zeroConsumptionValidation.tolerance,
            validation: this.validation,
            validationId: this.validation.zeroConsumptionValidation.validationId
        };
        this.settingService.addZeroValidation(zeroVal).subscribe(
            (value)=>{
                this.getValidation();
                swal({
                    type: 'success',
                    title: 'Data saved successfully',
                    showConfirmButton: true
                });
            },
            (error)=>{
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    addNegativeValidation(){
        this.validation.client.clientId = this.selectedClientId;
        this.validation.network.networkId = this.selectedNetworkId;
        const val : INegativeConsumptionValidation = {
            enabled: this.enabled,
            supplyId: this.selectedSupplyId,
            tolerance: this.tolerance,
            validation: this.validation,
            validationId: this.negativeValId
        }
        this.settingService.addNegativeValidation(val).subscribe(
            (value)=>{
                this.getValidation();
                swal({
                    type: 'success',
                    title: 'Data saved successfully',
                    showConfirmButton: true
                });
            },
            (error)=>{
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    updateNegativeValidation(){
        this.enabled = false;
        this.tolerance = 0;
        this.negativeValId = 0;
        if(this.validation.negativeValidation != null && this.validation.negativeValidation.length > 0){
            for(let index=0; index<this.validation.negativeValidation.length;index++){
                if(this.validation.negativeValidation[index].supplyId == this.selectedSupplyId){
                    this.enabled = this.validation.negativeValidation[index].enabled;
                    this.tolerance = this.validation.negativeValidation[index].tolerance;
                    this.negativeValId = this.validation.negativeValidation[index].validationId;
                    break;
                }
            }
        }
    }

    getValidation() {
        this.settingService.getValidation(this.selectedClientId, this.selectedNetworkId).then(
            (value) => {
                this.validation = value;
                if (!this.validation) {
                    this.initializeValidation();
                }else{
                    if(this.validation.tempValidation==undefined || this.validation.tempValidation==null ){
                        this.validation.tempValidation = {
                            enabled: false,
                            tolerance: null,
                            validation: null,
                            validationId: null
                        };
                    }
                    if(!this.validation.zeroConsumptionValidation){
                        this.validation.zeroConsumptionValidation = {
                            enabled: false,
                            tolerance: null,
                            validation: null,
                            validationId: null
                        };
                    }
                    if(this.validation.emailNotification){
                        this.emailIds = this.validation.emailNotification.split(',');
                    }
                }
                this.updateNegativeValidation();
            },
            (error) => {

            }
        );
    }

}
