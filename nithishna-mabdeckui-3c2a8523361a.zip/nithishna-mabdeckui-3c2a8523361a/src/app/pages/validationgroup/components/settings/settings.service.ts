import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { IClient, INetwork, IValidation, INegativeConsumptionValidation, ITempDifferenceValidation, IZeroConsumptionValidation } from "../../../../shared/interface";
import { environment } from "../../../../../environments/environment";

@Injectable()
export class SettingService {

    constructor(private http: Http) { }

    clientsBaseUrl = environment.host + 'client';
    clientUrl = environment.host +'client/';
    validationUrl = environment.host + 'validation';
    negativeValidationUrl = environment.host + 'validation/negative';
    tempValidationUrl = environment.host + 'validation/temp';
    zeroValidationUrl = environment.host + 'validation/zero';
    notificationUrl = environment.host + 'validation/notification';

    getClients() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.clientsBaseUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);

    }

    getNetworkForClient(clientId: number) {
        let url = this.clientUrl + clientId + '/network';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as INetwork[]);
    }

    getValidation(clientId: number, networkId: number){
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let url = this.validationUrl + "?clientId="+clientId+"&networkId="+networkId;
        return this.http.get(url, {
            headers: headers
        })
        .toPromise()
        .then((res)=>res.json() as IValidation);
    }

    addNegativeValidation(negativeValidation: INegativeConsumptionValidation){
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.negativeValidationUrl, negativeValidation, {
            headers: headers
        });
    }

    updateNegativeValidation(negativeValidation: INegativeConsumptionValidation){
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.negativeValidationUrl, negativeValidation, {
            headers: headers
        });
    }

    addTempValidation(tempVal: ITempDifferenceValidation){
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.tempValidationUrl, tempVal, {
            headers: headers
        });
    }

    updateTempValidation(tempVal: ITempDifferenceValidation){
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.tempValidationUrl, tempVal, {
            headers: headers
        });
    }

    addZeroValidation(zeroVal: IZeroConsumptionValidation){
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.zeroValidationUrl, zeroVal, {
            headers: headers
        });
    }

    updateZeroValidation(zeroVal: IZeroConsumptionValidation){
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.put(this.zeroValidationUrl, zeroVal, {
            headers: headers
        });
    }

    addNotification(val: IValidation){
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http.post(this.notificationUrl, val, {
            headers: headers
        });
    }
    
}