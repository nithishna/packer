﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-reportsgroup',
    template: `<router-outlet></router-outlet>`
})
export class ReportsGroupComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
