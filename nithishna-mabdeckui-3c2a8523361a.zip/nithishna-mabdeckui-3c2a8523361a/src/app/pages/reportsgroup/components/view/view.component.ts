import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { IAccount, INetwork, IClient, IReportHistory } from "../../../../shared/interface";
import { Account, BillablePerson } from "../../../../shared/class";
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import swal from 'sweetalert2';
import { ViewConfigService } from './view.service';
@Component({
    selector: 'app-report-view-and-download',
    templateUrl: './view.component.html',
    styleUrls: ['./view.component.scss'],
    providers: [ViewConfigService]
})
export class ViewAndDownloadComponent implements OnInit {
    pageSize = 10;
    pageNumber = 1;
    totalNumberOfItems = 0;
    load = false;
    reportHistoryList: IReportHistory[] = [];
    constructor(private router: Router, private _globalService: GlobalService, private service: ViewConfigService) { }
    pageChanged(pN: number): void {
        this.pageNumber = pN;
    }
    ngOnInit() {
        this.authenticationCheck();
        this.getAllReportHistory();
    }
    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    getAllReportHistory(){
        this.load = true;
        this.service.getAllReportHistory(this.pageNumber, this.pageSize).then(
            (value)=>{
                this.reportHistoryList = value;
                this.load = false;
            },
            (error)=>{
                this.load = false;
            }
        )
    }
}