﻿import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { environment } from "../../../../../environments/environment";
import { IClient, IBand, INetwork, IProperty, IReportType, IReportConfiguration, IReportConfig, ISchedule, IReportHistory } from '../../../../shared/interface';

@Injectable()
export class ConfigureService {
    clientUrl = environment.host + 'client/';
    clientsMetaDataUrl = environment.host + 'client-metadata';
    reportTypeUrl = environment.host + 'report-type';
    reportConfigUrl = environment.host + 'report/config';
    reportUrl = environment.host + 'report';
    reportRunUrl = environment.host + 'report/run';
    constructor(private http: Http) { }

    getAllReportConfigurations(index: number, size: number) {
        let url = this.reportConfigUrl + "?index=" + index + '&size=' + size;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IReportConfig[]);
    }

    getAllReportTypes() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.reportTypeUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IReportType[]);
    }

    getAllClientMetadata() {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(this.clientsMetaDataUrl, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IClient[]);
    }

    getNetworkForClient(clientId: number) {
        let url = this.clientUrl + clientId + '/network';
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as INetwork[]);
    }

    getBandsByClientAndNetwork(clientId: number, networkId: number) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let url = this.clientUrl + clientId.toString() + '/network/' + networkId.toString() + '/band';
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IBand[]);
    }

    getPropertyByClientAndNetworkAndBand(clientId: number, networkId: number, bandId: number) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
        let url = this.clientUrl + clientId.toString() + '/network/' + networkId.toString() + '/band/' + bandId.toString() + '/property';
        return this.http
            .get(url, {
                headers: headers
            })
            .toPromise()
            .then((res) => res.json() as IProperty[]);
    }

    addReportConfiguration(reportConfig: IReportConfiguration) {
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' + localStorage.getItem('token'));
        return this.http.post(this.reportConfigUrl, reportConfig, {
            headers: headers
        });
    }

    addScheduleToConfig(schedule: ISchedule, reportId: number) {
        let url = this.reportUrl + '?id=' + reportId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' + localStorage.getItem('token'));
        return this.http.put(url, schedule, {
            headers: headers
        });
    }

    deleteReportConfiguration(reportId: number) {
        let url = this.reportUrl + '?id=' + reportId;
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' + localStorage.getItem('token'));
        return this.http.delete(url, {
            headers: headers
        });
    }

    runReport(reportHistory: IReportHistory){
        var headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append('Authorization', 'Basic ' + localStorage.getItem('token'));
        return this.http.post(this.reportRunUrl, reportHistory, {
            headers: headers
        });
    }
}