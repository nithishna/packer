﻿import { Component, OnInit } from '@angular/core';
import { GlobalService } from "../../../../shared/services/global.service";
import { IAccount, INetwork, IClient, IReportConfiguration, IBand, IProperty, IAddress, IReportType, IReportConfig, IReportHistory, ISchedule } from "../../../../shared/interface";
import { Account, BillablePerson, Network, Address } from "../../../../shared/class";
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import swal from 'sweetalert2';
import { ConfigureService } from './configure.service';
import { IMyDpOptions } from 'mydatepicker';
@Component({
    selector: 'app-report-configure',
    templateUrl: './configure.component.html',
    styleUrls: ['./configure.component.scss'],
    providers: [ConfigureService]
})
export class ConfigureComponent implements OnInit {
    constructor(private router: Router, private _globalService: GlobalService, private formBuilder: FormBuilder, private service: ConfigureService) { }
    pageSize = 10;
    pageNumber = 1;
    totalNumberOfItems = 0;
    selectedConfigId: number = 0;
    scheduleExpanded: boolean = false;
    historyExpanded: boolean = false;
    isEdit = false;
    expanded: boolean = false;
    submitted: boolean = false;
    load: Boolean = false;
    time: string;
    configForm: FormGroup;
    historyForm: FormGroup;
    scheduleForm: FormGroup;
    networkList: Network[] = new Array(0);
    clientData: IClient[];
    bandList: IBand[] = [];
    propertyList: IProperty[] = [];
    reportTypes: IReportType[] = [];
    reportConfigList: IReportConfig[] = [];
    reportConfig: IReportConfiguration = {
        bandId: null,
        clientId: null,
        id: 0,
        isSingleMeter: false,
        meterSerialNumber: null,
        networkId: null,
        propertyId: null,
        reportName: null,
        reportTypeId: null,
        supplyId: 0
    };
    reportHistory: IReportHistory = {
        configuration: null,
        creationDate: null,
        fromDate: null,
        id: null,
        toDate: null,
        status: null
    };

    schedule: ISchedule = {
        emailIds: null,
        offset: null,
        period: null,
        recursionType: null,
        scheduleId: null,
        recursionOffset: null,
        hour: null,
        minute: null
    }
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy'
    };

    public fromDate: any = null;
    public toDate: any = null;
    ngOnInit() {
        this.loadReportConfiguration();
        this.authenticationCheck();
        this.loadClientData();
        this.getAllReportTypes();
        this.configForm = this.formBuilder.group({
            reportName: ['', Validators.required],
            reportType: ['', Validators.required],
            client: ['', Validators.required],
            network: ['', Validators.required],
            property: ['', Validators.required],
            band: ['', Validators.required]
        });

        this.historyForm = this.formBuilder.group(
            {
                fromDate: ['', Validators.required],
                toDate: ['', Validators.required]
            }
        );

        this.scheduleForm = this.formBuilder.group({
            offset: ['', Validators.required],
            period: ['', Validators.required],
            recursionType: ['', Validators.required],
            time: ['', Validators.required]
        });
    }
    pageChanged(pN: number): void {
        this.pageNumber = pN;
    }
    get c() { return this.configForm.controls; }
    get h() { return this.historyForm.controls; }
    get s() { return this.scheduleForm.controls; }
    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }

    clickEvent(event: Event) {
        var target = event.target || event.srcElement || event.currentTarget;
        var idAttr = event.srcElement.getAttribute("id");
        if (idAttr == "myModal" || idAttr == "myModal1" || idAttr == "myModal2") {
            this.expanded = false;
            this.submitted = false;
            this.historyExpanded = false;
        }
    }

    getAllReportTypes() {
        this.service.getAllReportTypes().then(
            (value) => {
                this.reportTypes = value;
            }
        );
    }
    loadClientData() {
        this.service.getAllClientMetadata().then((value) => {
            this.clientData = value;
        });
    }
    fetchNetworkData() {
        if (this.reportConfig.clientId) {
            this.service.getNetworkForClient(this.reportConfig.clientId).then((value) => {
                this.networkList = value;
            });
        }
    }
    getBandsByClientAndNetwork() {
        if (this.reportConfig.clientId && this.reportConfig.networkId) {
            this.service.getBandsByClientAndNetwork(this.reportConfig.clientId, this.reportConfig.networkId).then(
                (value) => {
                    this.bandList = value;
                }
            );
        }
    }

    getPropertyByClientAndNetworkAndBand() {
        if (this.reportConfig.clientId && this.reportConfig.networkId && this.reportConfig.bandId) {
            this.service.getPropertyByClientAndNetworkAndBand(this.reportConfig.clientId, this.reportConfig.networkId, this.reportConfig.bandId).then(
                (value) => {
                    this.propertyList = value;
                    for (let index = 0; index < value.length; index++) {
                        let address: IAddress = this.propertyList[index].address;
                        let name: string = address.addressLine1;
                        if (address.addressLine2) {
                            name = name + " " + address.addressLine2;
                        }
                        if (address.addressLine3) {
                            name = name + " " + address.addressLine3;
                        }
                        name = name + " " + address.town;
                        name = name + " " + address.postCode;
                        this.propertyList[index].name = name;
                    }
                }
            )
        }
    }

    addReportConfig() {
        this.expanded = true;
        this.submitted = false;
        this.reportConfig = {
            bandId: null,
            clientId: null,
            id: 0,
            isSingleMeter: false,
            meterSerialNumber: null,
            networkId: null,
            propertyId: null,
            reportName: null,
            reportTypeId: null,
            supplyId: 0
        };
    }

    addReportHistory(id: number) {
        this.historyExpanded = true;
        this.selectedConfigId = id;
        this.submitted = false;
        this.reportHistory = {
            configuration: null,
            creationDate: null,
            fromDate: null,
            id: null,
            toDate: null,
            status: null
        };
    }

    addSchedule(reportConfig: IReportConfig) {
        this.scheduleExpanded = true;
        this.submitted = false;
        this.selectedConfigId = reportConfig.id;

        if (reportConfig.schedule) {
            this.schedule = reportConfig.schedule;
            this.time = this.schedule.hour + ':' + this.schedule.minute;
            this.isEdit = true;
        } else {
            this.isEdit = false;
            this.schedule = {
                emailIds: null,
                offset: null,
                period: null,
                recursionType: null,
                scheduleId: null,
                recursionOffset: null,
                hour: null,
                minute: null
            };
        }
    }

    runReport() {
        this.submitted = true;
        this.load = true;
        if (this.historyForm.invalid) {
            this.load = false;
            return;
        }
        this.reportHistory.configuration = {
            clientName: null,
            id: this.selectedConfigId,
            networkName: null,
            reportName: null,
            reportType: null,
            schedule: null
        }
        if (this.fromDate.date.month == 1) {
            this.reportHistory.fromDate = new Date(this.fromDate.date.year - 1, this.fromDate.date.month + 11, this.fromDate.date.day);
        } else {
            this.reportHistory.fromDate = new Date(this.fromDate.date.year, this.fromDate.date.month - 1, this.fromDate.date.day);
        }
        if (this.toDate.date.month == 1) {
            this.reportHistory.toDate = new Date(this.toDate.date.year - 1, this.toDate.date.month + 11, this.toDate.date.day);
        } else {
            this.reportHistory.toDate = new Date(this.toDate.date.year, this.toDate.date.month - 1, this.toDate.date.day);
        }

        this.service.runReport(this.reportHistory).subscribe(
            (value) => {
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Report added to queue',
                    showConfirmButton: true
                });
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        )
    }


    saveReportConfiguration() {
        this.submitted = true;
        this.load = true;
        if (this.configForm.invalid) {
            this.load = false;
            return;
        }
        this.service.addReportConfiguration(this.reportConfig).subscribe(
            (value) => {
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Report configuration added succesfully',
                    showConfirmButton: true
                });
                this.loadReportConfiguration();
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }

        );
    }

    saveSchedule() {
        this.load = true;
        this.submitted = true;
        if (this.scheduleForm.invalid || !this.schedule.recursionOffset) {
            this.load = false;
            return;
        }
        this.schedule.hour = Number(this.time.split(':')[0]);
        this.schedule.minute = Number(this.time.split(':')[1]);
        this.service.addScheduleToConfig(this.schedule, this.selectedConfigId).subscribe(
            (value) => {
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Schedule added succesfully',
                    showConfirmButton: true
                });
                this.loadReportConfiguration();
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }

    loadReportConfiguration() {
        this.load = true;
        this.service.getAllReportConfigurations(this.pageNumber, this.pageSize).then(
            (value) => {
                this.load = false;
                this.reportConfigList = value;
                this.totalNumberOfItems = value.length;
            },
            (error) => {
                this.load = false;
                this.totalNumberOfItems = 0;
            }
        );
    }

    deleteReportConfiguration(reportId: number) {
        this.load = true;
        this.service.deleteReportConfiguration(reportId).subscribe(
            (value) => {
                this.load = false;
                swal({
                    type: 'success',
                    title: 'Report configuration deleted succesfully',
                    showConfirmButton: true
                });
                this.loadReportConfiguration();
            },
            (error) => {
                this.load = false;
                swal({
                    type: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Please check with the administrator.'
                });
            }
        );
    }
}