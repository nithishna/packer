﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalService } from "../../../../shared/services/global.service";
@Component({
    selector: 'app-reports',
    templateUrl: './reports.component.html',
    styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {

    constructor(private router: Router, private _globalService: GlobalService) { }

    ngOnInit() {
        this.authenticationCheck();
    }
    authenticationCheck() {
        this._globalService.authenticateUser().subscribe(
            principal => {
            },
            Error => {
                this.router.navigate(['/login']);
            }
        );
    }
}