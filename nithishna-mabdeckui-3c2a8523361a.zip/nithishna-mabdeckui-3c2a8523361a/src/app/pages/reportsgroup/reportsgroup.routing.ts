﻿import { Routes, RouterModule } from '@angular/router';
import { ReportsGroupComponent } from './reportsgroup.component';
import { ReportsComponent } from './components/reports/reports.component';
import { ConfigureComponent } from './components/configure/configure.component';
import { ViewAndDownloadComponent } from './components/view/view.component';

const childRoutes: Routes = [
    {
        path: '',
        component: ReportsGroupComponent,
        children: [
            { path: '', redirectTo: 'reports', pathMatch: 'full' },
            { path: 'reports', component: ReportsComponent },
            { path: 'configure', component: ConfigureComponent },
            { path: 'download', component: ViewAndDownloadComponent }
        ]
    }
];

export const routing = RouterModule.forChild(childRoutes);