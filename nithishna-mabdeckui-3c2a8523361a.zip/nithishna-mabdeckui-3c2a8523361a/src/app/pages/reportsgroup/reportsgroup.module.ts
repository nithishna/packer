﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { routing } from './reportsgroup.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { MyDatePickerModule } from 'mydatepicker';
import { ReportsGroupComponent } from './reportsgroup.component';
import { ReportsComponent } from './components/reports/reports.component';
import { ViewAndDownloadComponent } from './components/view/view.component';
import { ConfigureComponent } from './components/configure/configure.component';
import { LayoutModule } from '../../shared/layout.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        routing,
        NgxPaginationModule,
        LayoutModule,
        MyDatePickerModule
    ],
    declarations: [
        ReportsGroupComponent,
        ReportsComponent,
        ViewAndDownloadComponent,
        ConfigureComponent
    ]
})
export class ReportsGroupModule { }