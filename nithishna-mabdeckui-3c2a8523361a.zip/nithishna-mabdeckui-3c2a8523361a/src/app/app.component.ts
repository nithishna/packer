﻿import { Component, OnInit } from '@angular/core';
import 'rxjs/add/operator/map'
@Component({
  selector: 'app-root',
  template: `<router-outlet></router-outlet>`
})
export class AppComponent implements OnInit{
    title = 'app';
    ngOnInit() {
        console.log("I am running");
    }    
}
