﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { routing } from './error.routing';

import { LayoutModule } from '../shared/layout.module';
import { SharedModule } from '../shared/shared.module';

/* components */
import { ErrorComponent } from './error.component';

@NgModule({
    imports: [
        CommonModule,
        LayoutModule,
        SharedModule,
        routing
    ],
    declarations: [
        ErrorComponent
    ]
})
export class ErrorModule { }