﻿import { Routes, RouterModule } from '@angular/router';
import { ErrorComponent } from './error.component';

export const childRoutes: Routes = [
    {
        path: 'error',
        component: ErrorComponent,
    }
];

export const routing = RouterModule.forChild(childRoutes);
