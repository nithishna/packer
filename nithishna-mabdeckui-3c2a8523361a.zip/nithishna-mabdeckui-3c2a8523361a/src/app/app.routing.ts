﻿import { Routes, RouterModule } from '@angular/router';
import { PagesComponent } from './pages/pages.component';

const appRoutes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'login'
  },
  {
      path: 'error',
      redirectTo: 'error'
  }
];

export const routing = RouterModule.forRoot(appRoutes);
