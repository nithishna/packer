﻿import { ModuleWithProviders } from '@angular/core'
import { Routes } from '@angular/router'
import { IClient, IAddress, IAccountDetails, IMainContact, ICustomerServiceContract, IBank, INetwork, IPropertyAreaCharge, IUnitCharge, IStandingCharge, IAdminCharge, IBand, ITariff, IProperty, ISupplyPoint, IHub, IMeter, IDataLogger, IAccount, IBillablePerson, IMeterTemplate, IHubTemplate, IAccountLimited, INotes, IPropertyAccountModel, IPropertyAccountAssociation, IPropertyListItem, ISupplyListItem, IMeterListItem, IMeterReadingItem, IMeterReadingSearch, IMeterReading, IPropertyWithOwner, IAccountOwnerTenant, ITransaction, IPaymentType, IPaymentMethod, IStatementGenerationInput, IPreStatement, IPreStatementEnergy, IPreReadings, IPreStandingCharge, IStatement } from "./interface";


export class Client implements IClient {
    clientName: string;
    logo: string;
    address: Address;
    startDate: Date;
    companyNumber: number;
    vatNumber: number;
    currency: string;
    paymentTerm: number;
    numberOfNetworks: number;
    bankAccount: AccountDetails;
    mainContact: MainContact;
    customerServiceContact: CustomerServiceContract;
    clientId: number;
    network: Network[];
    property: IProperty[];

    constructor() {
        this.clientId = undefined;
        this.clientName = '';
        this.address = new Address();
        this.startDate = new Date();
        this.companyNumber = 0;
        this.vatNumber = 0;
        this.currency = '';
        this.paymentTerm = 0;
        this.bankAccount = new AccountDetails();
        this.mainContact = new MainContact();
        this.customerServiceContact = new CustomerServiceContract();
        this.numberOfNetworks = 0;
        this.network = new Array(0);
        this.property = new Array(0);
    }
}

export class Address implements IAddress {
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    town: string;
    region: string;
    postCode: string;
    country: string;

    constructor() {
        this.addressLine1 = '';
        this.addressLine2 = '';
        this.addressLine3 = '';
        this.town = '';
        this.region = '';
        this.postCode = '';
        this.country = '';
    }
}

export class Bank implements IBank {
    id: number;
    name: String;

    constructor() {
        this.id = undefined;
        this.name = '';
    }
}

export class MainContact implements IMainContact {
    id: number;
    title: string;
    firstName: string;
    lastName: string;
    landlineNumber: string;
    mobileNumber: string;
    emailAddress: string;
    address: Address;

    constructor() {
        this.id = undefined;
        this.title = '';
        this.firstName = undefined;
        this.lastName = '';
        this.landlineNumber = '';
        this.mobileNumber = '';
        this.emailAddress = '';
        this.address = new Address();
    }
}

export class AccountDetails implements IAccountDetails {
    id: number;
    accountHolderName: string;
    bankName: string;
    sortCode: string;
    accountNumber: number;
    bank: Bank;

    constructor() {
        this.id = undefined;
        this.accountHolderName = undefined;
        this.bankName = '';
        this.sortCode = '';
        this.accountNumber = undefined;
        this.bank = new Bank();
    }
}

export class CustomerServiceContract implements ICustomerServiceContract {
    custServiceId: number;
    mainContactNumber: number;
    emailAddress: string;
    address: Address;

    constructor() {
        this.custServiceId = undefined;
        this.mainContactNumber = undefined;
        this.emailAddress = '';
        this.address = new Address();
    }
}

export class Network implements INetwork {
    numberOfProperties: number;
    network: string;
    networkType: string;
    manualReview: boolean;
    peerComparison: boolean;
    hubManufacturer: string;
    allowPrepayment: boolean;
    iin: number;
    cardNumberGeneration: boolean;
    recoveryPercentage: number;
    client: Client;
    estimationMethod: string;
    paymentCardProvider: string;
    networkId: number;
    band: Band[];
    property: Property[];
    dataLogger: DataLogger[];
    showDataLogger: string;

    constructor() {
        this.network = undefined;
        this.networkType = undefined;
        this.manualReview = undefined;
        this.hubManufacturer = 'None';
        this.allowPrepayment = false;
        this.iin = undefined;
        this.cardNumberGeneration = undefined;
        this.recoveryPercentage = undefined;
        this.estimationMethod = undefined;
        this.paymentCardProvider = undefined;
        this.client = new Client();
        this.networkId = undefined;
        this.band = new Array(0);
        this.property = new Array(0);
        this.dataLogger = new Array(0);
        this.showDataLogger = undefined;
    }
}

export class Tariff implements ITariff{
    tariffId: number;
    tariffType: string;
    supplyType: string;
    tariffName: string;
    varRate: number;
    activeFromDate: Date;
    activeToDate: Date;
    unitCharge: UnitCharge[];
    standingCharge: StandingCharge[];
    propertyAreaCharge: PropertyAreaCharge[];
    band: Band;
    tariffCode: string;

    constructor() {
        this.tariffId = undefined;
        this.tariffType = undefined;
        this.supplyType = undefined;
        this.tariffName = undefined;
        this.varRate = undefined;
        this.activeFromDate = undefined;
        this.activeToDate = undefined;
        this.unitCharge = new Array(0);
        this.standingCharge = new Array(0);
        this.propertyAreaCharge = new Array(0);
        this.band = new Band();
        this.tariffCode = undefined;
    }
}

export class PropertyAreaCharge implements IPropertyAreaCharge{
    propertyChargeId: number;
    name: string;
    pricePerUnit: number;
    areaUnits: string;
    tariff: Tariff;
    constructor() {
        this.propertyChargeId = undefined;
        this.name = undefined;
        this.pricePerUnit = undefined;
        this.areaUnits = undefined;
        this.tariff = new Tariff();
    }
}

export class UnitCharge implements IUnitCharge{
    unitChargeId: number;
    name: string;
    pricePerUnit: number;
    unit: string;
    tariff: Tariff;

    constructor() {
        this.unitChargeId = undefined;
        this.name = undefined;
        this.pricePerUnit = undefined;
        this.unit = undefined;
        this.tariff = new Tariff();
    }

}

export class StandingCharge implements IStandingCharge{
    standingChargeId: number;
    name: string;
    dailyNetCharge: number;
    tariff: Tariff;
    constructor() {
        this.standingChargeId = undefined;
        this.name = undefined;
        this.dailyNetCharge = undefined;
        this.tariff = new Tariff();
    }
}

export class AdminCharge implements IAdminCharge{
    adminChargeId: number;
    chargeTo: string;
    description: string;
    dailyCharge: number;
    vatRate: number;
    activeFromDate: Date;
    activeToDate: Date;
    band: Band;

    constructor() {
        this.adminChargeId = undefined;
        this.chargeTo = undefined;
        this.description = undefined;
        this.dailyCharge = undefined;
        this.vatRate = undefined;
        this.activeFromDate = undefined;
        this.activeToDate = undefined;
        this.band = new Band();
    }
}

export class Band implements IBand{
    bandId: number;
    bandName: string;
    bandType: string;
    startDate: Date;
    endDate: Date;
    tariff: Tariff[];
    network: Network;
    propertyPart1: number;
    propertyPart2: number;
    propertyUnit: string;
    numberOfBedroom: number;
    client: Client;
    showTariff: string;
    adminCharge: AdminCharge[];
    noOfTariffs: number;

    constructor() {
        this.bandId = undefined;
        this.bandName = undefined;
        this.bandType = undefined;
        this.startDate = undefined;
        this.endDate = undefined;
        this.tariff = new Array(0);
        this.network = new Network();
        this.propertyPart1 = undefined;
        this.propertyPart2 = undefined;
        this.propertyUnit = undefined;
        this.numberOfBedroom = undefined;
        this.client = new Client();
        this.showTariff = 'Show';
        this.adminCharge = new Array(0);
        this.noOfTariffs = 0;
    }
}

export class Property implements IProperty {
    propertyId: number;
    client: Client;
    network: Network;
    band: Band;
    reference: string;
    area: string;
    address: Address;
    name: string;
    supply: SupplyPoint[];
    noOfMeters: number;
    showProperty: string;
    hub: Hub[];
    perDayUsage: number;
    lastBilledDate: Date; 
    constructor() {
        this.propertyId = undefined;
        this.client = new Client();
        this.network = new Network();
        this.band = new Band();
        this.reference = undefined;
        this.area = undefined;
        this.address = new Address();
        this.name = undefined;
        this.supply = new Array(0);
        this.noOfMeters = 0;
        this.showProperty = 'Show';
        this.hub = new Array(0);
        this.perDayUsage = undefined;
        this.lastBilledDate = undefined;
    }
}

export class SupplyPoint implements ISupplyPoint {
    supplyId: number;
    client: IClient;
    network: INetwork;
    property: IProperty;
    startDate: Date;
    endDate: Date;
    supplyType: String;
    weightFactor: String;
    technicalFactor: String;
    location: String;
    meter: Meter[];

    constructor() {
        this.supplyId = undefined;
        this.client = new Client();
        this.network = new Network();
        this.property = new Property();
        this.startDate = undefined;
        this.endDate = undefined;
        this.supplyType = undefined;
        this.weightFactor = undefined;
        this.technicalFactor = undefined;
        this.location = undefined;
        this.meter = new Array(0);
    }
}

export class Hub implements IHub {
    hubId: number;
    client: IClient;
    network: INetwork;
    property: IProperty;
    startDate: Date;
    endDate: Date;
    hubManufacturer: string;
    serialNumber: string;
    identifier: string;
    hubModel: string;

    constructor() {
        this.hubId = undefined;
        this.client = new Client();
        this.network = new Network();
        this.property = new Property();
        this.startDate = undefined;
        this.endDate = undefined;
        this.hubManufacturer = undefined;
        this.serialNumber = undefined;
        this.identifier = undefined;
        this.hubModel = undefined;
    }
}

export class Meter implements IMeter {
    meterId: number;
    client: IClient;
    network: INetwork;
    property: IProperty;
    startDate: Date;
    endDate: Date;
    unit: string;
    meterType: string;
    manufacturer: string;
    model: string;
    location: string;
    serialNumber: string;
    readingFrequency: string;
    readingImportFactor: string;
    initialReading: string;
    offset: string;
    childMeter: boolean;
    parentSerialNumber: string;
    pulseInputNumber: number;
    supply: SupplyPoint;

    constructor() {
        this.meterId = undefined;
        this.client = new Client();
        this.network = new Network();
        this.property = new Property();
        this.startDate = undefined;
        this.endDate = undefined;
        this.unit = undefined;
        this.meterType = undefined;
        this.manufacturer = undefined;
        this.model = undefined;
        this.location = undefined;
        this.serialNumber = undefined;
        this.readingFrequency = undefined;
        this.readingImportFactor = undefined;
        this.initialReading = undefined;
        this.offset = undefined;
        this.childMeter = undefined;
        this.parentSerialNumber = undefined;
        this.pulseInputNumber = undefined;
        this.supply = new SupplyPoint();
    }
}

export class DataLogger implements IDataLogger {
    id: number;
    client: IClient;
    network: INetwork;
    manufacturer: string;
    model: string;
    serialNumber: string;
    communicationType: string;
    phoneNumber: string;
    imei: string;
    location: string;
    startDate: Date;
    endDate: Date;
    ipAddress: string;
    portNumber: number;
    username: string;
    password: string;

    constructor() {
        this.id = undefined;
        this.client = new Client();
        this.network = new Network();
        this.manufacturer = undefined;
        this.model = undefined;
        this.serialNumber = undefined;
        this.communicationType = undefined;
        this.phoneNumber = undefined;
        this.imei = undefined;
        this.location = undefined;
        this.startDate = undefined;
        this.endDate = undefined;
        this.ipAddress = undefined;
        this.portNumber = undefined;
        this.username = undefined;
        this.password = undefined;
    }
}

export class BillablePerson implements IBillablePerson {
    billablePersonId: number;
    titles: string;
    firstName: string;
    lastName: string;
    preferredName: string;
    landlineNumber: string;
    mobileNumber: string;
    emailAddress: string;

    constructor() {
        this.billablePersonId = undefined;
        this.titles = undefined;
        this.firstName = undefined;
        this.lastName = undefined;
        this.preferredName = undefined;
        this.landlineNumber = undefined;
        this.mobileNumber = undefined;
        this.emailAddress = undefined;
    }
}

export class Account implements IAccount {
    accountId: number;
    client: IClient;
    network: INetwork;
    accountNumber: string;
    paymentCardNumber: string;
    address: IAddress;
    billablePerson: IBillablePerson[] = [];
    notes: INotes[] = [];
    vulnerable: boolean;
    redFlag: boolean;
    onHold: boolean;
    mood: string;
    constructor() {
        this.accountId = undefined;
        this.client = new Client();
        this.network = new Network();
        this.accountNumber = undefined;
        this.paymentCardNumber = undefined;
        this.address = new Address();
        this.billablePerson[0] = new BillablePerson();
        this.notes[0] = new Notes();
        this.vulnerable = false;
        this.redFlag = false;
        this.onHold = false;
        this.mood = undefined;
    }
}

export class AccountLimited implements IAccountLimited {
    accountId: number;
    firstName: string;
    lastName: string;
    accountNumber: string;
    network: string;
    clientName: string;
    startDate: string;
    endDate: string;
    constructor() {
        this.accountId = undefined;
        this.firstName = undefined;
        this.lastName = undefined;
        this.accountNumber = undefined;
        this.network = undefined;
        this.clientName = undefined;
        this.startDate = undefined;
        this.endDate = undefined;
    }
}

export class MeterTemplate implements IMeterTemplate {
    clientId: number;
    networkId: number;
    supplyTypeId: number;
    unitId: number;
    readingFrequencyId: number;
    meterUseId: number; 

    constructor() {
        this.clientId = undefined;
        this.networkId = undefined;
        this.supplyTypeId = undefined;
        this.unitId = undefined;
        this.readingFrequencyId = undefined;
        this.meterUseId = undefined;
    }
}

export class HubTemplate implements IHubTemplate {
    clientId: number;
    networkId: number;
    hubManufacturer: string;
    hubModel: string;

    constructor() {
        this.clientId = undefined;
        this.networkId = undefined;
        this.hubManufacturer = undefined;
        this.hubModel = undefined;
    }
}

export class Notes implements INotes {
    noteId: number;
    modifiedDate: string;
    author: string;
    summary: string;
    attachment: string;
    fileName: string;
    accountId: number;
    pin: boolean;

    constructor() {
        this.noteId = undefined;
        this.modifiedDate = undefined;
        this.author = undefined;
        this.summary = undefined;
        this.attachment = undefined;
        this.fileName = undefined;
        this.accountId = undefined;
        this.pin = false;
    }
}

export class PropertyAccountModel implements IPropertyAccountModel {
    propertyId: number;
    accountId: number;
    reference: string;
    area: string;
    propertyAddress: IAddress;
    billingAddress: IAddress;
    name: string;
    startDate: Date;
    endDate: Date;
    deleted: boolean;
    moveInStatus: string;
    moveOutStatus: string;
    associationId: number;
    generateLetter: boolean;
    constructor() {
        this.propertyId = undefined;
        this.accountId = undefined;
        this.reference = undefined;
        this.propertyAddress = new Address();
        this.billingAddress = new Address();
        this.name = undefined;
        this.startDate = undefined;
        this.endDate = undefined;
        this.deleted = false;
        this.moveInStatus = undefined;
        this.moveOutStatus = undefined;
        this.associationId = undefined;
        this.generateLetter = false;
    }
}

export class PropertyAccountAssociation implements IPropertyAccountAssociation {
    associationId: number;
    property: IProperty;
    account: IAccount;
    startDate: string;
    endDate: string;
    tenureType: string;
    deleted: Boolean;
    moveInStatus: string;
    moveOutStatus: string;

    constructor() {
        this.associationId = undefined;
        this.property = new Property();
        this.account = new Account();
        this.startDate = undefined;
        this.endDate = undefined;
        this.tenureType = undefined;
        this.deleted = false;
        this.moveInStatus = undefined;
        this.moveOutStatus = undefined;
    }
}

export class PropertyListItem implements IPropertyListItem {
    propertyId: number;
    propertyName: string;
    supplyList: SupplyListItem[] = [];
    constructor() {
        this.propertyId = undefined;
        this.propertyName = undefined;
        this.supplyList[0] = new SupplyListItem(); 
    }
}

export class SupplyListItem implements ISupplyListItem {
    supplyId: number;
    supplyName: string;
    meterList: MeterListItem[] = [];
    constructor() {
        this.supplyId = undefined;
        this.supplyName = undefined;
        this.meterList[0] = new MeterListItem();
    }
}

export class MeterListItem implements IMeterListItem {
    meterId: number;
    meterName: string;
    constructor() {
        this.meterId = undefined;
        this.meterName = undefined;
    }
}

export class MeterReadingItem implements IMeterReadingItem {
    meterReadingId: number;
    reading: number;
    method: string;
    readingDateTime: string;
    createdDate: string;
    createdUser: string;
    type: string;
    approved: string;

    constructor() {
        this.meterReadingId = undefined;
        this.reading = undefined;
        this.method = undefined;
        this.readingDateTime = undefined;
        this.createdDate = undefined;
        this.createdUser = undefined;
        this.type = undefined;
        this.approved = undefined;
    }
}

export class MeterReadingSearch implements IMeterReadingSearch {
    accountId: string;
    meterId: number;
    supplyId: number;
    propertyId: number;
    readingFromDate: string;
    readingToDate: string;

    constructor() {
        this.accountId = undefined;
        this.meterId = undefined;
        this.supplyId = undefined;
        this.propertyId = undefined;
        this.readingFromDate = undefined;
        this.readingToDate = undefined;
    }
}

export class Reading {
    value: number;
    reading: string;

    constructor() {
        this.value = undefined;
        this.reading = undefined;
    }
}

export class MeterReading implements IMeterReading {
    meterReadingId: number
    network: INetwork
    meter: IMeter
    method: string
    meterReading: number
    flowTemperature: number
    returnTemperature: number
    instantaneousFlow: number
    totalVolume: number
    readingDateTime: string

    constructor() {
        this.meterReadingId = undefined;
        this.network = new Network();
        this.meter = new Meter();
        this.method = undefined;
        this.meterReading = undefined;
        this.flowTemperature = undefined;
        this.returnTemperature = undefined;
        this.instantaneousFlow = undefined;
        this.totalVolume = undefined;
        this.readingDateTime = undefined;
    }
}

export class PropertyWithOwner implements IPropertyWithOwner {
    isError: boolean;
    propertyId: number;
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    postCode: string;
    networkName: string;
    clientName: string;
    currentOwner: string;
    currentTenant: string;
    reference: string;
    lastBilledDate: Date;
    pid: number;
    isSelected: boolean;
    constructor() {
        this.propertyId = undefined;
        this.addressLine1 = undefined;
        this.addressLine2 = undefined;
        this.addressLine3 = undefined;
        this.postCode = undefined;
        this.networkName = undefined;
        this.clientName = undefined;
        this.currentOwner = undefined;
        this.currentTenant = undefined;
        this.reference = undefined;
        this.lastBilledDate = undefined;
        this.pid = undefined;
        this.isSelected = false;
        this.isError = false;
    }
}

export class AccountOwnerTenant implements IAccountOwnerTenant {
    name: string;
    accountNumber: string;
    bandName: string;
    numberOfTariffs: number;
    clientName: string;
    networkName: string;
    numberOfProperties: number;
    tenant: IAccountOwnerTenant;
    billingAddress: IAddress;
    propertyAddress: IAddress;
    accountId: number;

    constructor() {
        this.name = undefined;
        this.accountNumber = undefined;
        this.bandName = undefined;
        this.numberOfTariffs = undefined;
        this.clientName = undefined;
        this.networkName = undefined;
        this.numberOfProperties = undefined;
        this.tenant = undefined;
        this.billingAddress = new Address();
        this.propertyAddress = new Address();
        this.accountId = undefined;
    }
}

export class MyDate {
    day: number;
    month: number;
    year: number;

    constructor() {
        this.day = undefined;
        this.month = undefined;
        this.year = undefined;
    }
}

export class PropertyAccountAssociationLimited {
    associationId: number;
    propertyId: number;
    accountId: number;
    startDate: string;
    tenant: number;
    owner: number;
    endDate: string;
    delete: number;
    accountName: string;
    constructor() {
        this.associationId = undefined;
        this.propertyId = undefined;
        this.accountId = undefined;
        this.startDate = undefined;
        this.tenant = undefined;
        this.owner = undefined;
        this.endDate = undefined;
        this.delete = undefined;
        this.accountName = undefined;
    }
}

export class Transaction implements ITransaction {
    id: number;
    amount: number;
    credt: number;
    debit: number;
    balance: number;
    paymentType: string;
    paymentTypeId: number;
    paymentMethod: string;
    paymentMethodId: number;
    date: Date;
    reference: string;
    accountId: number;

    constructor() {
        this.id = undefined;
        this.amount = undefined;
        this.credt = undefined;
        this.debit = undefined;
        this.balance = undefined;
        this.paymentType = undefined;
        this.paymentTypeId = undefined;
        this.paymentMethod = undefined;
        this.paymentMethodId = undefined;
        this.date = undefined;
        this.reference = undefined;
        this.accountId = undefined;
    }
}

export class PaymentType implements IPaymentType {
    id: number;
    type: string;

    constructor() {
        this.id = undefined;
        this.type = undefined;
    }
}

export class PaymentMethod implements IPaymentMethod {
    id: number;
    method: string;

    constructor() {
        this.id = undefined;
        this.method = undefined;
    }
}

export class AccountBalance {
    accountId: number;
    balance: number;

    constructor() {
        this.accountId = undefined;
        this.balance = undefined;
    }
}

export class StatementGenerationInput implements IStatementGenerationInput {
    clientIDs: number[];
    networkIDs: number[];
    propertyIDs: number[];
    billDate: Date;

    constructor() {
        this.clientIDs = new Array();
        this.networkIDs = new Array();
        this.propertyIDs = new Array();
        this.billDate = new Date();
    }
}

export class PreStatementQueue {
    createdDate: Date;
    createdUser: string;
    status: string;
    message: string;
    id: number;
    property: PropertyWithOwner[] = [];

    constructor() {
        this.createdDate = undefined;
        this.createdUser = undefined;
        this.status = undefined;
        this.message = undefined;
        this.id = undefined;
        this.property = new Array();
    }
}

export class PreStatement implements IPreStatement {
    preStatementId: number;
    queueId: number;
    billablePerson: String;
    clientName: String;
    networkName: String;
    propertyAddress: IAddress;
    fromDate: String;
    toDate: String;
    generationDate: String;
    energyList: PreStatementEnergy[];
    valid: boolean;
    validityReason: String;
    adminCharge: number;
    totalAdminCharge: number;
    totalCharge: number;
    noOfDays: number;

    constructor() {
        this.preStatementId = undefined;
        this.queueId = undefined;
        this.billablePerson = undefined;
        this.clientName = undefined;
        this.networkName = undefined;
        this.propertyAddress = new Address();
        this.fromDate = undefined;
        this.toDate = undefined;
        this.generationDate = undefined;
        this.energyList = new Array();
        this.valid = false;
        this.validityReason = undefined;
        this.adminCharge = undefined;
        this.totalAdminCharge = undefined;
        this.totalCharge = undefined;
        this.noOfDays = undefined;
    }
}

export class PreStatementEnergy implements IPreStatementEnergy {
    preStatementEnergyId: number;
    unitPricePerUnit: number;
    unitsUsed: number;
    totalUnitsUsed: number;
    totalCost: number;
    adminCharge: number;
    adminVat: number;
    unitChargeVat: number;
    energy: string;
    reading: PreReadings[];
    standingChargeList: PreStandingCharge[];

    constructor() {
        this.preStatementEnergyId = undefined;
        this.unitPricePerUnit = undefined;
        this.unitsUsed = undefined;
        this.totalUnitsUsed = undefined;
        this.totalCost = undefined;
        this.adminCharge = undefined;
        this.adminVat = undefined;
        this.unitChargeVat = undefined;
        this.energy = undefined;
        this.reading = new Array();
        this.standingChargeList = new Array();
    }
}

export class PreReadings implements IPreReadings {
    readingId: number;
    readingDate: string;
    value: number;

    constructor() {
        this.readingId = undefined;
        this.readingDate = undefined;
        this.value = undefined;
    }
}

export class PreStandingCharge implements IPreStandingCharge {
    standingChargeId: number;
    standingChargeName: string;
    standingCharge: number;
    totalStandingCharge: number;
    noOfDays: number;

    constructor() {
        this.standingChargeId = undefined;
        this.standingChargeName = undefined;
        this.standingCharge = undefined;
        this.totalStandingCharge = undefined;
        this.noOfDays = undefined;
    }
}

export class Statement implements IStatement {
    statementId: number;
    billablePerson: string;
    client: string;
    network: string;
    propertyAddress: string;
    fromDate: string;
    toDate: string;
    generationDate: string;
    netAmount: number;
    vat: number;
    grossAmount: number;
    fileName: string;

    constructor() {
        this.statementId = undefined;
        this.billablePerson = undefined;
        this.client = undefined;
        this.network = undefined;
        this.propertyAddress = undefined;
        this.fromDate = undefined;
        this.toDate = undefined;
        this.generationDate = undefined;
        this.netAmount = undefined;
        this.vat = undefined;
        this.grossAmount = undefined;
        this.fileName = undefined;
    }
}