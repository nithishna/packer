﻿import { ModuleWithProviders } from '@angular/core'
import { Routes } from '@angular/router'

export interface IAddress {
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    town: string;
    region: string;
    postCode: string;
    country: string;
}

export interface IClient {
    clientId: number;
    logo: string;
    clientName: string;
    address: IAddress;
    startDate: Date;
    companyNumber: number;
    vatNumber: number;
    currency: string;
    paymentTerm: number;
    bankAccount: IAccountDetails;
    mainContact: IMainContact;
    customerServiceContact: ICustomerServiceContract;
    numberOfNetworks: number;
    network: INetwork[];
    property: IProperty[];
}

export interface IBank {
    id: number;
    name: String;
}

export interface IMainContact {
    id: number;
    title: string;
    firstName: string;
    lastName: string;
    landlineNumber: string;
    mobileNumber: string;
    emailAddress: string;
    address: IAddress;
}

export interface IAccountDetails {
    id: number;
    accountHolderName: string;
    bankName: string;
    sortCode: string;
    accountNumber: number;
    bank: IBank;
}

export interface ICustomerServiceContract {
    custServiceId: number;
    mainContactNumber: number;
    emailAddress: string;
    address: IAddress;
}

export interface INetwork {
    networkId: number;
    network: string;
    networkType: string;
    manualReview: boolean;
    peerComparison: boolean;
    hubManufacturer: string;
    allowPrepayment: boolean;
    iin: number;
    cardNumberGeneration: boolean;
    recoveryPercentage: number;
    client: IClient;
    estimationMethod: string;
    paymentCardProvider: string;
    band: IBand[];
    property: IProperty[];
    dataLogger: IDataLogger[];
    showDataLogger: string;
    numberOfProperties: number;
}

export interface ITariff {
    tariffId: number;
    tariffType: string;
    supplyType: string;
    tariffName: string;
    tariffCode: string;
    varRate: number;
    activeFromDate: Date;
    activeToDate: Date;
    unitCharge: IUnitCharge[];
    standingCharge: IStandingCharge[];
    propertyAreaCharge: IPropertyAreaCharge[];
    band: IBand;
}

export interface IPropertyAreaCharge {
    propertyChargeId: number;
    name: string;
    pricePerUnit: number;
    areaUnits: string;
    tariff: ITariff;
}

export interface IUnitCharge {
    unitChargeId: number;
    name: string;
    pricePerUnit: number;
    unit: string;
    tariff: ITariff;
}

export interface IStandingCharge {
    standingChargeId: number;
    name: string;
    dailyNetCharge: number;
    tariff: ITariff;
}

export interface IAdminCharge {
    adminChargeId: number;
    chargeTo: string;
    description: string;
    dailyCharge: number;
    vatRate: number;
    activeFromDate: Date;
    activeToDate: Date;
    band: IBand;
}

export interface IBand {
    bandId: number;
    bandName: string;
    bandType: string;
    startDate: Date;
    endDate: Date;
    network: INetwork;
    tariff: ITariff[];
    propertyPart1: number;
    propertyPart2: number;
    propertyUnit: string;
    numberOfBedroom: number;
    client: IClient;
    showTariff: string;
    adminCharge: IAdminCharge[];
    noOfTariffs: number;
}

export interface IProperty {
    propertyId: number;
    name: string;
    client: IClient;
    network: INetwork;
    band: IBand;
    reference: string;
    area: string;
    address: IAddress;
    supply: ISupplyPoint[];
    noOfMeters: number;
    showProperty: string;
    hub: IHub[];
    perDayUsage: number;
    lastBilledDate: Date;
}

export interface ISupplyPoint {
    supplyId: number;
    client: IClient;
    network: INetwork;
    property: IProperty;
    startDate: Date;
    endDate: Date;
    supplyType: String;
    weightFactor: String;
    technicalFactor: String;
    location: String;
    meter: IMeter[];
}

export interface IHub {
    hubId: number;
    hubModel: string;
    client: IClient;
    network: INetwork;
    property: IProperty;
    startDate: Date;
    endDate: Date;
    hubManufacturer: string;
    serialNumber: string;
    identifier: string;
}

export interface IMeter {
    meterId: number;
    client: IClient;
    network: INetwork;
    property: IProperty;
    startDate: Date;
    endDate: Date;
    unit: string;
    meterType: string;
    manufacturer: string;
    model: string;
    location: string;
    serialNumber: string;
    readingFrequency: string;
    readingImportFactor: string;
    initialReading: string;
    offset: string;
    childMeter: boolean;
    parentSerialNumber: string;
    pulseInputNumber: number;
    supply: ISupplyPoint;
}

export interface IDataLogger {
    id: number;
    client: IClient;
    network: INetwork;
    manufacturer: string;
    model: string;
    serialNumber: string;
    communicationType: string;
    phoneNumber: string;
    imei: string;
    location: string;
    startDate: Date;
    endDate: Date;
    ipAddress: string;
    portNumber: number;
    username: string;
    password: string;
}

export interface IAccount {
    accountId: number;
    client: IClient;
    network: INetwork;
    accountNumber: string;
    paymentCardNumber: string;
    address: IAddress;
    billablePerson: IBillablePerson[];
    notes: INotes[];
    vulnerable: boolean;
    redFlag: boolean;
    onHold: boolean;
    mood: string;
}

export interface IAccountLimited {
    accountId: number;
    firstName: string;
    lastName: string;
    accountNumber: string;
    network: string;
    clientName: string;
    startDate: string;
    endDate: string;
}

export interface IBillablePerson {
    billablePersonId: number;
    titles: string;
    firstName: string;
    lastName: string;
    preferredName: string;
    landlineNumber: string;
    mobileNumber: string;
    emailAddress: string;
}

export interface IMeterTemplate {
    clientId: number;
    networkId: number;
    supplyTypeId: number;
    unitId: number;
    readingFrequencyId: number;
    meterUseId: number;
}

export interface IHubTemplate {
    clientId: number;
    networkId: number;
    hubManufacturer: string;
    hubModel: string;
}

export interface INotes {
    noteId: number;
    modifiedDate: string;
    author: string;
    summary: string;
    attachment: string;
    fileName: string;
    accountId: number;
    pin: boolean;
}

export interface IPropertyAccountModel {
    propertyId: number;
    accountId: number;
    reference: string;
    area: string;
    propertyAddress: IAddress;
    billingAddress: IAddress;
    name: string;
    startDate: Date;
    endDate: Date;
    deleted: boolean;
    moveInStatus: string;
    moveOutStatus: string;
    associationId: number;
    generateLetter: boolean;
}

export interface IPropertyAccountAssociation {
    associationId: number;
    property: IProperty;
    account: IAccount;
    startDate: string;
    endDate: string;
    tenureType: string;
    deleted: Boolean;
    moveInStatus: string;
    moveOutStatus: string;
}

export interface IPropertyListItem {
    propertyId: number;
    propertyName: string;
    supplyList: ISupplyListItem[];
}

export interface ISupplyListItem {
    supplyId: number;
    supplyName: string;
    meterList: IMeterListItem[];
}

export interface IMeterListItem {
    meterId: number;
    meterName: string;
}

export interface IMeterReadingItem {
    meterReadingId: number;
    reading: number;
    method: string;
    readingDateTime: string;
    createdDate: string;
    createdUser: string;
    type: string;
    approved: string;
}

export interface IMeterReadingSearch {
    accountId: string;
    meterId: number;
    supplyId: number;
    propertyId: number;
    readingFromDate: string;
    readingToDate: string;
}

export interface IMeterReading {
    meterReadingId: number
    network: INetwork
    meter: IMeter
    method: string
    meterReading: number
    flowTemperature: number
    returnTemperature: number
    instantaneousFlow: number
    totalVolume: number
    readingDateTime: string
}

export interface IPropertyWithOwner {
    propertyId: number;
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    networkName: string;
    clientName: string;
    currentOwner: string;
    currentTenant: string;
    reference: string;
    lastBilledDate: Date;
    pid: number;
    postCode: string;
}

export interface IAccountOwnerTenant {
    name: string;
    accountNumber: string;
    bandName: string;
    numberOfTariffs: number;
    clientName: string;
    networkName: string;
    numberOfProperties: number;
    tenant: IAccountOwnerTenant;
    billingAddress: IAddress;
    propertyAddress: IAddress;
    accountId: number;
}

export interface ITransaction {
    id: number;
    amount: number;
    credt: number;
    debit: number;
    balance: number;
    paymentType: string;
    paymentTypeId: number;
    paymentMethod: string;
    paymentMethodId: number;
    date: Date;
    reference: string;
    accountId: number;
}

export interface IPaymentMethod {
    id: number;
    method: string;
}

export interface IPaymentType {
    id: number;
    type: string;
}

export interface IStatementGenerationInput {
    clientIDs: number[];
    networkIDs: number[];
    propertyIDs: number[];
    billDate: Date;
}

export interface IPreStatement {
    preStatementId: number;
    queueId: number;
    billablePerson: String;
    clientName: String;
    networkName: String;
    propertyAddress: IAddress;
    fromDate: String;
    toDate: String;
    generationDate: String;
    energyList: IPreStatementEnergy[];
    valid: boolean;
    validityReason: String;
    adminCharge: number;
    totalAdminCharge: number;
    totalCharge: number;
    noOfDays: number;
}

export interface IPreStatementEnergy {
    preStatementEnergyId: number;
    unitPricePerUnit: number;
    unitsUsed: number;
    totalUnitsUsed: number;
    totalCost: number;
    adminCharge: number;
    adminVat: number;
    unitChargeVat: number;
    energy: string;
    reading: IPreReadings[];
    standingChargeList: IPreStandingCharge[];
}

export interface IPreReadings {
    readingId: number;
    readingDate: string;
    value: number;
}

export interface IPreStandingCharge {
    standingChargeId: number;
    standingChargeName: string;
    standingCharge: number;
    totalStandingCharge: number;
    noOfDays: number;
}

export interface IStatement {
    statementId: number;
    billablePerson: string;
    client: string;
    network: string;
    propertyAddress: string;
    fromDate: string;
    toDate: string;
    generationDate: string;
    netAmount: number;
    vat: number;
    grossAmount: number;
    fileName: string;
}

export interface IReportConfiguration {
    id: number;
    clientId: number;
    networkId: number;
    propertyId: number;
    bandId: number;
    isSingleMeter: boolean;
    supplyId: number;
    reportName: string;
    reportTypeId: number;
    meterSerialNumber: string;
}

export interface IReportConfig {
    id: number;
    clientName: string;
    networkName: string;
    reportName: string;
    reportType: string;
    schedule: ISchedule;
}

export interface ISchedule {
    scheduleId: number;
    recursionType: string;
    period: number;
    offset: number;
    emailIds: string;
    recursionOffset: number;
    hour: number;
    minute: number;
}

export interface IReportType {
    id: number;
    name: string;
}

export interface IReportHistory {
    id: number;
    fromDate: Date;
    toDate: Date;
    creationDate: Date;
    configuration: IReportConfig;
    status: String;
}

export interface IValidation {
    validId: number;
    tempValidation: ITempDifferenceValidation;
    negativeValidation: INegativeConsumptionValidation[];
    zeroConsumptionValidation: IZeroConsumptionValidation;
    client: IClient;
    network: INetwork;
    emailNotification: String;
}

export interface ITempDifferenceValidation {
    validationId: number;
    enabled: boolean;
    tolerance: number;
    validation: IValidation;
}

export interface INegativeConsumptionValidation {
    validationId: number;
    supplyId: number;
    enabled: boolean;
    tolerance: number;
    validation: IValidation;
}

export interface IZeroConsumptionValidation {
    validationId: number;
    enabled: boolean;
    tolerance: number;
    validation: IValidation;
}
export interface IValidationErrors{
	clientName: String;
	networkName: String;
	propertyName: String;
	meterSerialNumber: String;
	supplyType: String;
	validationType: String;
	meterReadingId: number;
    validationId: number;
    selected: boolean;
}

export interface INegativeConsumptionValidationError extends IValidationErrors {
    previousReading: number;
    previousReadingDate: String;
    failedReading: number;
    failedReadingDate: String;
}

export interface INegativeReadingValidationError extends IValidationErrors {
    reading : number;
	flaggedDate: String;
}

export interface ITempDifferenceError extends IValidationErrors {
    flowTemperature: number;
	returnTemperature: number;
	readingDate: String;
}

export interface IZeroReadingValidationError extends  IValidationErrors {
    reading: number;
	flaggedDate: String;
}

export interface IDirectDebitConfigDto {
    id: number;
	clientId: number;
	clientName: String;
	networkId: number;
	networkName: String;
	claimOffset: number;
	billingFrequency: number;
	permissiblePaymentDays: String;
	permissibleDirectDebitOptions: number;
	transactionsForDirectDebit: boolean;
	directDebitLetter: boolean;
	auddisFile: boolean;
	collectionFile: boolean;
	emailForLetter: String;
	phoneForLetter: String;
}

export interface IAction {
    id: number;
    owner: boolean;
    stage: IStage;
    type: number;
}

export interface  IActionEmail extends IAction {
    subject: String;
	body: String;
	emailIds: String;
}

export interface IActionFlag extends IAction {
    flag: boolean;
}

export interface IActionLetter extends IAction {
    templateName: String;
}

export interface IStage {
    stageId: number;
    name: String;
    overDue: boolean;
    noOfDays: number;
    actions: IAction[];
}

export interface ICreditControlSetup {
    controlId: number;
    stages: IStage[];
}

export interface ICreditNotes {
    id: number;
	modifiedDate: Date;
	author: String;
	summary: String;
	fileName: string;
	attachment: String;
	isAttachment: boolean;
}

export interface ICreditCorrespondence {
    correspondenceId: number;
	clientName: String;
	networkName: String;
	propertyName: String;
	billablePerson: String;
	type: String;
	correspondenceDate: Date;
	fileName: String;
	accountBalance: number;
	daysOverdue: number;	
	stage: String;
	letter: boolean;
	notes: ICreditNotes[];
}