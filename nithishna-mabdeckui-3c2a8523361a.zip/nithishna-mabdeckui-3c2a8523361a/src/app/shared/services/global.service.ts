﻿import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Http, RequestOptions, Headers } from '@angular/http';
import { environment } from "../../../environments/environment";

@Injectable()
export class GlobalService {

    baseUrl = environment.host+'user';
    constructor(private http: Http) {
    }

    createAuthorizationHeader(headers: Headers) {
        headers.append('Authorization', 'Basic ' +
            localStorage.getItem('token'));
    }
    authenticateUser() {
        var headers = new Headers();
        this.createAuthorizationHeader(headers);
        return this.http.post(this.baseUrl, {}, {
            headers: headers
        });
    }

    private dataSource = new Subject<DataSourceClass>();

    data$ = this.dataSource.asObservable();

    public dataBusChanged(ev, value) {
        this.dataSource.next({
            ev: ev,
            value: value
        })
    }
}


export class DataSourceClass {
    ev: string;
    value: any
}