﻿import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { PagesModule } from './pages/pages.module';
import { ErrorModule } from './error/error.module';
import { LoginModule } from './login/login.module';
import { routing } from './app.routing';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MyDatePickerModule } from 'mydatepicker';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { Routes, RouterModule } from '@angular/router';
import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { IconModule } from "./pages/icon/icon.module";
import { LoadingComponent } from "./shared/components/loading/loading.component";
import { DatePipe } from '@angular/common'

@NgModule({
  imports: [
      BrowserModule,
      BrowserAnimationsModule,
      FormsModule,
      PagesModule,
      routing,
      MyDatePickerModule,
      HttpClientModule,
      HttpModule,
      ErrorModule,
      LoginModule,
      IconModule      
    ],
    declarations: [
        AppComponent        
    ],
    bootstrap: [AppComponent],
    providers: [DatePipe]
})
export class AppModule { }
