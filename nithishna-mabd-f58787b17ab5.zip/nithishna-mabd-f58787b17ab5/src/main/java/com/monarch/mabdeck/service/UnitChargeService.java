package com.monarch.mabdeck.service;

import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.UnitChargeDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Tariff;
import com.monarch.mabdeck.entity.UnitCharge;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.UnitChargeMapper;
import com.monarch.mabdeck.repository.TariffRepository;
import com.monarch.mabdeck.repository.UnitChargeRepository;

@Component
public class UnitChargeService extends CommonServiceImpl<UnitChargeDto, UnitCharge>{
	
	private Logger logger = LoggerFactory.getLogger(UnitChargeService.class);
	
	@Resource
	private UnitChargeRepository repository;
	
	@Resource
	private TariffRepository tariffRepository;
	
	@Override
	public JpaRepository<UnitCharge, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<UnitChargeDto, UnitCharge> getMapper() {
		return UnitChargeMapper.INSTANCE;
	}
	
	@Override
	public void updateAudit(UnitCharge entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
			}else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
	
	@Override
	public UnitChargeDto create(UnitChargeDto dto, String username) {
		UnitCharge entity = this.getMapper().convertToEntity(dto);
		updateAudit(entity, username);
		if(dto.getTariff()!= null) {
			Tariff tariff = tariffRepository.findOne(dto.getTariff().getTariffId());
			entity.setTariff(tariff);
		}
		repository.saveAndFlush(entity);
		return dto;
	}
}