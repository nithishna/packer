package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.CustomerServiceContactDto;
import com.monarch.mabdeck.entity.CustomerServiceContact;

@Mapper(uses= {AddressMapper.class})
public abstract class CustomerServiceContactMapper implements IBaseMapper<CustomerServiceContactDto, CustomerServiceContact>{
	public static final CustomerServiceContactMapper INSTANCE = Mappers.getMapper(CustomerServiceContactMapper.class);
	
	@Mappings({
		@Mapping(target = "audit", ignore = true)
	})
	public abstract CustomerServiceContact convertToEntity(CustomerServiceContactDto dto);
}