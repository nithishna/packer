package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.AdminCharge;
import com.monarch.mabdeck.entity.AdminChargeHistory;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.repository.AdminChargeHistoryRepository;

@Component
public class AdminChargeHistoryService {

	@Resource
	private AdminChargeHistoryRepository historyRepository;
	
	public void updateAdminChargeHistory(AdminCharge adminCharge, String username) {
		AdminChargeHistory history = new AdminChargeHistory();
		if(adminCharge != null) {
			history.setActiveFromDate(adminCharge.getActiveFromDate());
			history.setActiveToDate(adminCharge.getActiveToDate());
			history.setAdminChargeId(adminCharge.getAdminChargeId());
			history.setAudit(adminCharge.getAudit());
			history.setBandId(adminCharge.getBand()!=null? adminCharge.getBand().getBandId() : null);
			history.setDescription(adminCharge.getDescription());
			history.setChargeTo(adminCharge.getChargeTo());
			history.setDailyCharge(adminCharge.getDailyCharge());
			history.setVatRate(adminCharge.getVatRate());
			
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
