package com.monarch.mabdeck.dto;

import java.math.BigDecimal;
import java.sql.Date;

public class PropertyLimited implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private BigDecimal propertyId;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String postCode;
	private String networkName;
	private String clientName;
	private String currentOwner;
	private String currentTenant;
	private String reference;
	private Date lastBilledDate;
	private long pid;
	public BigDecimal getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(BigDecimal propertyId) {
		this.propertyId = propertyId;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public String getNetworkName() {
		return networkName;
	}
	public String getClientName() {
		return clientName;
	}
	public String getCurrentOwner() {
		return currentOwner;
	}
	public String getCurrentTenant() {
		return currentTenant;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public void setCurrentOwner(String currentOwner) {
		this.currentOwner = currentOwner;
	}
	public void setCurrentTenant(String currentTenant) {
		this.currentTenant = currentTenant;
	}
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public Date getLastBilledDate() {
		return lastBilledDate;
	}
	public void setLastBilledDate(Date lastBilledDate) {
		this.lastBilledDate = lastBilledDate;
	}
	public long getPid() {
		return pid;
	}
	public void setPid(long pid) {
		this.pid = pid;
	}
}
