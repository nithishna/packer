package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.SupplyPoint;
import com.monarch.mabdeck.entity.SupplyPointHistory;
import com.monarch.mabdeck.repository.SupplyPointHistoryRepository;

@Component
public class SupplyPointHistoryService {

	@Resource
	private SupplyPointHistoryRepository historyRepository;
	
	public void updateSupplyPointHistory(SupplyPoint supply, String username) {
		if(supply != null) {
			SupplyPointHistory history = new SupplyPointHistory();
			history.setAudit(supply.getAudit());
			history.setClientId(supply.getClient() != null? supply.getClient().getClientId() : null);
			history.setEndDate(supply.getEndDate());
			history.setLocation(supply.getLocation());
			history.setNetworkId(supply.getNetwork()!=null? supply.getNetwork().getNetworkId(): null);
			history.setPropertyId(supply.getProperty() != null? supply.getProperty().getPropertyId() : null);
			history.setStartDate(supply.getStartDate());
			history.setSupplyId(supply.getSupplyId());
			history.setSupplyType(supply.getSupplyType());
			history.setTechnicalFactor(supply.getTechnicalFactor());
			history.setWeightFactor(supply.getWeightFactor());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
