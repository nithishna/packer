package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.BankAccount;
import com.monarch.mabdeck.entity.BankAccountHistory;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.ClientHistory;
import com.monarch.mabdeck.entity.CustomerServiceContact;
import com.monarch.mabdeck.entity.MainContact;
import com.monarch.mabdeck.entity.MainContactHistory;
import com.monarch.mabdeck.repository.BankAccountHistoryRepository;
import com.monarch.mabdeck.repository.ClientHistoryRepository;
import com.monarch.mabdeck.repository.MainContactHistoryRepository;


@Component
public class ClientHistoryService {

	@Resource
	private ClientHistoryRepository historyRepository;
	
	@Resource
	private BankAccountHistoryRepository bankAccountHistoryRepository;
	
	@Autowired
	private CustomerContactHistoryService contactHistoryService;
	
	@Resource
	private MainContactHistoryRepository mainContactHistoryRepository;
	
	
	public void updateBankAccountHistory(BankAccount account, String username) {
		BankAccountHistory bankHistory = new BankAccountHistory();
		if(account != null) {
			bankHistory.setAccountHolderName(account.getAccountHolderName());
			bankHistory.setAccountNumber(account.getAccountNumber());
			bankHistory.setAudit(account.getAudit());
			bankHistory.setBankId(account.getBank() != null? account.getBank().getId() : null);
			bankHistory.setClientId(account.getClient() != null? account.getClient().getClientId(): null);
			bankHistory.setId(account.getId());
			bankHistory.setSortCode(account.getSortCode());
			Calendar cal = Calendar.getInstance();
			if(bankHistory.getAudit() != null) {
				bankHistory.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				bankHistory.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				bankHistory.setAudit(audit);
			}
			bankAccountHistoryRepository.saveAndFlush(bankHistory);
		}
	}
	
	public void updateCustomerContactHistory(CustomerServiceContact contact, String username) {
		contactHistoryService.updateCustomerServiceContactHistory(contact, username);
	}
	
	public void updateMainContactHistory(MainContact mainContact, String username) {
		MainContactHistory history = new MainContactHistory();
		if(mainContact != null) {
			history.setAddress(mainContact.getAddress());
			history.setAudit(mainContact.getAudit());
			history.setClientId(mainContact.getClient()!=null? mainContact.getClient().getClientId(): null);
			history.setEmailAddress(mainContact.getEmailAddress());
			history.setFirstName(mainContact.getFirstName());
			history.setId(mainContact.getId());
			history.setLandlineNumber(mainContact.getLandlineNumber());
			history.setLastName(mainContact.getLastName());
			history.setMobileNumber(mainContact.getMobileNumber());
			history.setTitle(mainContact.getTitle());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			mainContactHistoryRepository.saveAndFlush(history);
		}
	}
	
	public void updateClientHistory(Client client, String username) {
		ClientHistory history = new ClientHistory();
		if(client != null) {
			history.setAddress(client.getAddress());
			history.setAudit(client.getAudit());
			history.setBankAccountId(client.getBankAccount()!= null? client.getBankAccount().getId(): null);
			history.setClientId(client.getClientId());
			history.setClientName(client.getClientName());
			history.setCompanyNumber(client.getCompanyNumber());
			history.setContactId(client.getMainContact()!= null? client.getMainContact().getId(): null);
			history.setCurrency(client.getCurrency());
			history.setLogo(client.getLogo());
			history.setPaymentTerm(client.getPaymentTerm());
			history.setServiceId(client.getCustomerServiceContact()!= null?client.getCustomerServiceContact().getCustServiceId(): null);
			history.setStartDate(client.getStartDate());
			history.setVatNumber(client.getVatNumber());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);			
		}
	}
}
