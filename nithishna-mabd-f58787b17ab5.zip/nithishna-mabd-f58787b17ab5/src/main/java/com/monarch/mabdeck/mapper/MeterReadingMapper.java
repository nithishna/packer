package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.MeterReadingDto;
import com.monarch.mabdeck.entity.MeterReading;

@Mapper
public abstract class MeterReadingMapper implements IBaseMapper<MeterReadingDto, MeterReading> {
	public static final MeterReadingMapper INSTANCE = Mappers.getMapper(MeterReadingMapper.class);

	@Mappings({ @Mapping(target = "meter", ignore = true), @Mapping(target = "network", ignore = true),
			@Mapping(target = "audit", ignore = true), @Mapping(target="readingDateTime", ignore = true) })
	public abstract MeterReading convertToEntity(MeterReadingDto dto);

	@Mappings({ @Mapping(target = "meter", ignore = true), @Mapping(target = "network", ignore = true), @Mapping(target="readingDateTime", ignore = true) })
	public abstract MeterReadingDto convertToDTO(MeterReading entity);

}