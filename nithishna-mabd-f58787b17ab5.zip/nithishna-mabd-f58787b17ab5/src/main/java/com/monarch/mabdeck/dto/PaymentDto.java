package com.monarch.mabdeck.dto;

public class PaymentDto implements IDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String paymentDate;
	private String paymentMethod;
	private double amount;
	private String reference;
	public String getPaymentDate() {
		return paymentDate;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public double getAmount() {
		return amount;
	}
	public String getReference() {
		return reference;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
}
