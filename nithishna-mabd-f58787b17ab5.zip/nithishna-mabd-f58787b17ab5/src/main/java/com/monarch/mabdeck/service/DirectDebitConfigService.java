package com.monarch.mabdeck.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.DirectDebitConfigDto;
import com.monarch.mabdeck.entity.DirectDebitConfig;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.DirectDebitConfigRepository;
import com.monarch.mabdeck.repository.NetworkRepository;

import javassist.NotFoundException;

@Component
public class DirectDebitConfigService {

	@Resource
	private DirectDebitConfigRepository repository;
	
	@Resource
	private ClientRepository clientRepository;
	
	@Resource
	private NetworkRepository networkRepository;
	
	public List<DirectDebitConfigDto> getAllDirectDebitConfigs(){
		List<DirectDebitConfigDto> dtos = new ArrayList<>();
		List<DirectDebitConfig> entities = repository.findAll();
		for(DirectDebitConfig entity : entities) {
			DirectDebitConfigDto dto = new DirectDebitConfigDto();
			dto.setAuddisFile(entity.isAuddisFile());
			dto.setBillingFrequency(entity.getBillingFrequency());
			dto.setClaimOffset(entity.getClaimOffset());
			dto.setClientId(entity.getClient().getClientId());
			dto.setClientName(entity.getClient().getClientName());
			dto.setNetworkId(entity.getNetwork().getNetworkId());
			dto.setNetworkName(entity.getNetwork().getNetwork());
			dto.setCollectionFile(entity.isCollectionFile());
			dto.setDirectDebitLetter(entity.isDirectDebitLetter());
			dto.setEmailForLetter(entity.getEmailForLetter());
			dto.setId(entity.getId());
			dto.setPermissibleDirectDebitOptions(entity.getPermissibleDirectDebitOptions());
			dto.setPermissiblePaymentDays(entity.getPermissiblePaymentDays());
			dto.setPhoneForLetter(entity.getPhoneForLetter());
			dto.setTransactionsForDirectDebit(entity.isTransactionsForDirectDebit());
			dtos.add(dto);
		}
		return dtos;
	}
	
	public DirectDebitConfigDto create(DirectDebitConfigDto dto) throws Exception {
		DirectDebitConfig config = new DirectDebitConfig();
		
		if(dto.getNetworkId()>0) {
			if(this.repository.findByNetworkNetworkId(dto.getNetworkId()) != null)
				throw new Exception("There is already a config for this network");
			config.setNetwork(this.networkRepository.findOne(dto.getNetworkId()));
		}
		else
			throw new InvalidFormatException("Network details required");
		config.setAuddisFile(dto.isAuddisFile());
		config.setBillingFrequency(dto.getBillingFrequency());
		config.setClaimOffset(dto.getClaimOffset());
		if(dto.getClientId() > 0)
			config.setClient(this.clientRepository.findOne(dto.getClientId()));
		else
			throw new InvalidFormatException("Client details required");
		config.setCollectionFile(dto.isCollectionFile());
		config.setDirectDebitLetter(dto.isDirectDebitLetter());
		config.setEmailForLetter(dto.getEmailForLetter());

		config.setPermissibleDirectDebitOptions(dto.getPermissibleDirectDebitOptions());
		config.setPermissiblePaymentDays(dto.getPermissiblePaymentDays());
		config.setPhoneForLetter(dto.getPhoneForLetter());
		config.setTransactionsForDirectDebit(dto.isTransactionsForDirectDebit());
		config = this.repository.save(config);
		dto.setId(config.getId());
		return dto;
	}
	
	public void update(DirectDebitConfigDto dto) throws InvalidFormatException, NotFoundException {
		if(dto.getId()==0)
			throw new InvalidFormatException("Invalid data");
		DirectDebitConfig config = this.repository.findOne(dto.getId());
		if(config == null)
			throw new NotFoundException("No data found");
		config.setAuddisFile(dto.isAuddisFile());
		config.setBillingFrequency(dto.getBillingFrequency());
		config.setClaimOffset(dto.getClaimOffset());
		config.setCollectionFile(dto.isCollectionFile());
		config.setDirectDebitLetter(dto.isDirectDebitLetter());
		config.setEmailForLetter(dto.getEmailForLetter());
		config.setPermissibleDirectDebitOptions(dto.getPermissibleDirectDebitOptions());
		config.setPermissiblePaymentDays(dto.getPermissiblePaymentDays());
		config.setPhoneForLetter(dto.getPhoneForLetter());
		config.setTransactionsForDirectDebit(dto.isTransactionsForDirectDebit());
		this.repository.save(config);
	}
}
