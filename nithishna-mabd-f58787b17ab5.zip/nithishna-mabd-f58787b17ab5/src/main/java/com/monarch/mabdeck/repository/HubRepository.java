package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Hub;

@Repository
public interface HubRepository extends JpaRepository<Hub, Long>{

	@Query(value="select distinct hub_model from hub where client_id=?1 and network_id=?2", nativeQuery = true)
	List<String> getAllHubModelsForClient(Long clientId, Long networkId);
	
	@Query(value="select * from hub where property_id=?1", nativeQuery = true)
	List<Hub> getAllHubsForProperty(Long propertyId);
}
