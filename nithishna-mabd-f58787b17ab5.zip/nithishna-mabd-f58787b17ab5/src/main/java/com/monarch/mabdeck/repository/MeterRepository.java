package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Meter;

@Repository
public interface MeterRepository extends JpaRepository<Meter, Long> {

	@Query(value = "select count(*) from meter where property_id=?1", nativeQuery = true)
	int getCount(Long propertyId);

	@Query(value = "select * from meter where supply_id=?1 and child_meter=0", nativeQuery = true)
	List<Meter> getMeterForTheSupplyId(Long supplyId);
	
	@Query(value = "select m from Meter m where m.client.clientId=:clientId and m.network.networkId=:networkId and m.supply.supplyId in :sId")
	List<Meter> getMeterForClientAndNetworkAndSupplyId(@Param("clientId") Long clientId,@Param("networkId")  Long networkId, @Param("sId") List<Long> sId);
	
	@Query(value = "select * from meter where client_id=?1 and network_id=?2 order by property_id asc", nativeQuery = true)
	List<Meter> getMeterForClientAndNetwork(Long clientId, Long networkId);
	
	@Query(value = "select * from meter where serial_number=?1 and network_id=?2", nativeQuery = true)
	Meter findMeterByNetworkAndSerialNumber(String serialNumber, Long networkId);

	Meter findBySerialNumber(String serialNumber);
	
	@Query(value = "select * from meter where property_id=?1", nativeQuery = true)
	List<Meter> findMeterByPropertyId(long prpoertyId);
	
	@Query(value = "select serial_number from meter where meter_id=?1", nativeQuery = true)
	String getMeterSerialForMeterId(long meterId);
	
	@Query(value="select * from meter where supply_id in (select supply_id from supply_point where property_id=(select property_id from property_account_association where association_id=?1))", nativeQuery = true)
	List<Meter> getAllMetersForAssociatedProperty(long associationId);
}
