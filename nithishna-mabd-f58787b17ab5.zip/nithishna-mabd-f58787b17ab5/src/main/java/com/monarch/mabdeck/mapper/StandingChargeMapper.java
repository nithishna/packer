package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.StandingChargeDto;
import com.monarch.mabdeck.entity.StandingCharge;

@Mapper
public abstract class StandingChargeMapper implements IBaseMapper<StandingChargeDto, StandingCharge>{
	public static final StandingChargeMapper INSTANCE = Mappers.getMapper(StandingChargeMapper.class);
	
	@Mappings({
		@Mapping(target = "tariff", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract StandingCharge convertToEntity(StandingChargeDto dto);
	
	
	@Mappings({
		@Mapping(target = "tariff", ignore = true)
	})
	public abstract StandingChargeDto convertToDTO(StandingCharge entity);

}
