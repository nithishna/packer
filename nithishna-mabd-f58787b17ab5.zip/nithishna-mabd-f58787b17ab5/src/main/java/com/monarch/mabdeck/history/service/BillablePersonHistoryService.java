package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.BillablePerson;
import com.monarch.mabdeck.entity.BillablePersonHistory;
import com.monarch.mabdeck.repository.BillablePersonHistoryRepository;

@Component
public class BillablePersonHistoryService {

	@Resource
	private BillablePersonHistoryRepository historyRepository;
	
	
	public void updateBillablePersonHistoryList(List<BillablePerson> billablePersonList, String username) {
		for(BillablePerson person: billablePersonList) {
			if(!person.isDeleted())
				this.updateBillablePersonHistory(person, username);
		}
	}
	
	public void updateBillablePersonHistory(BillablePerson billablePerson, String username) {
		if(billablePerson != null) {
			BillablePersonHistory history = new BillablePersonHistory();
			history.setAccountId(billablePerson.getAccount().getAccountId());
			history.setAudit(billablePerson.getAudit());
			history.setBillablePersonId(billablePerson.getBillablePersonId());
			history.setDeleted(billablePerson.isDeleted());
			history.setEmailAddress(billablePerson.getEmailAddress());
			history.setFirstName(billablePerson.getFirstName());
			history.setLandlineNumber(billablePerson.getLandlineNumber());
			history.setLastName(billablePerson.getLastName());
			history.setMobileNumber(billablePerson.getMobileNumber());
			history.setPreferredName(billablePerson.getPreferredName());
			history.setTitles(billablePerson.getTitles());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}		
	}
}
