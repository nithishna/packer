package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.MainContactDto;
import com.monarch.mabdeck.entity.MainContact;

@Mapper(uses= {AddressMapper.class})
public abstract class MainContactMapper implements IBaseMapper<MainContactDto, MainContact>{

	public static final MainContactMapper INSTANCE = Mappers.getMapper(MainContactMapper.class);
	
	@Mappings({
		@Mapping(target = "client", ignore = true),
		@Mapping(target = "id", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract MainContact convertToEntity(MainContactDto dto);
	
	
	public abstract MainContactDto convertToDTO(MainContact entity);

}
