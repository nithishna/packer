package com.monarch.mabdeck.dto;

import java.sql.Date;

public class CreditNotesDto implements IDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private Date modifiedDate;
	private String author;
	private String summary;
	private String fileName;
	private String attachment;
	private boolean isAttachment;
	public long getId() {
		return id;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public String getAuthor() {
		return author;
	}
	public String getSummary() {
		return summary;
	}
	public String getFileName() {
		return fileName;
	}
	public String getAttachment() {
		return attachment;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	public boolean isAttachment() {
		return isAttachment;
	}
	public void setIsAttachment(boolean isAttachment) {
		this.isAttachment = isAttachment;
	}
}
