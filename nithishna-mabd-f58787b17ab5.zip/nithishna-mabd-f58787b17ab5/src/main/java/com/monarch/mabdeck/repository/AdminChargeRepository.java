package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.AdminCharge;

@Repository
public interface AdminChargeRepository extends JpaRepository<AdminCharge, Long>{

	@Query(value="select * from\r\n" + 
			"admin_charge \r\n" + 
			"where (cast(active_from_date as date)<=?1 and (cast(active_to_date as date)>=?2 or active_to_date is null))", nativeQuery=true)
	List<AdminCharge> getAdminChargeForPeriod(String startDate, String endDate);
}
