package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.NetworkDto;
import com.monarch.mabdeck.entity.Network;

@Mapper(uses = {BandMapper.class, ClientMapper.class})
public abstract class NetworkMapper implements IBaseMapper<NetworkDto, Network>{
	public static final NetworkMapper INSTANCE = Mappers.getMapper(NetworkMapper.class);
	
	@Mappings({
		@Mapping(target = "band", ignore = true),
		@Mapping(target = "property", ignore = true),
		@Mapping(target = "dataLogger", ignore = true)
	})
	public abstract NetworkDto convertToDTO(Network entity);
		
	@Mappings({
		@Mapping(target = "band", ignore = true),
		@Mapping(target = "property", ignore = true),
		@Mapping(target = "dataLogger", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract Network convertToEntity(NetworkDto dto);
	
}
