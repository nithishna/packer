package com.monarch.mabdeck.controller;

import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.AdminChargeDto;
import com.monarch.mabdeck.service.AdminChargeService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class AdminChargeController {

	private Logger logger = LoggerFactory.getLogger(BandController.class);

	@Autowired
	private AdminChargeService adminChargeService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ADMIN_CHARGE, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createAdminCharge(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody AdminChargeDto adminCharge) {
		logger.info("AdminChargeController: createAdminCharge - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("AdminChargeController: createAdminCharge - Service Call, Usename : " + username);
		adminChargeService.create(adminCharge, username);
		logger.info("AdminChargeController: createAdminCharge - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ADMIN_CHARGE_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody AdminChargeDto getAdminChargeById(@PathVariable("admincharge_id") Long adminChargeId)
			throws NotFoundException {
		logger.info("AdminChargeController: getAdminChargeById - Start");
		return adminChargeService.read(adminChargeId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ADMIN_CHARGE, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<AdminChargeDto> getAllAdminCharges() throws NotFoundException {
		logger.info("AdminChargeController: getAllAdminCharges - Start");
		return adminChargeService.readAll();
	}
}
