package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Financials implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private double credit;
	private double debit;
	private double balance;
	private Date date;
	private String reference;
	
	@Embedded
	private Audit audit;
	
    @ManyToOne
    @JoinColumn(name = "account_id", insertable = true, updatable = true)
	private Account account;
	
	@OneToOne
	@JoinColumn(name = "payment_Type_id")
	private PaymentType paymentType;
	
	@OneToOne
	@JoinColumn(name = "payment_method_id")
	private PaymentMethod paymentMethod;
	
	public Long getId() {
		return id;
	}
	public Date getDate() {
		return date;
	}
	public String getReference() {
		return reference;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public PaymentType getPaymentType() {
		return paymentType;
	}
	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}
	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public double getCredit() {
		return credit;
	}
	public double getDebit() {
		return debit;
	}
	public double getBalance() {
		return balance;
	}
	public void setCredit(double credit) {
		this.credit = credit;
	}
	public void setDebit(double debit) {
		this.debit = debit;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}

}
