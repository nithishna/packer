package com.monarch.mabdeck.dto;

import java.util.Date;
import java.util.List;

public class SupplyPointDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long supplyId;
	private String supplyType;
	private String weightFactor;
	private String technicalFactor;
	private String location;
	private List<MeterDto> meter;
	private ClientDto client;
	private NetworkDto network;
	private PropertyDto property;
	private Date startDate;
	private Date endDate;

	public ClientDto getClient() {
		return client;
	}
	public void setClient(ClientDto client) {
		this.client = client;
	}
	public NetworkDto getNetwork() {
		return network;
	}
	public void setNetwork(NetworkDto network) {
		this.network = network;
	}
	public PropertyDto getProperty() {
		return property;
	}
	public void setProperty(PropertyDto property) {
		this.property = property;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getSupplyType() {
		return supplyType;
	}
	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}
	public String getWeightFactor() {
		return weightFactor;
	}
	public void setWeightFactor(String weightFactor) {
		this.weightFactor = weightFactor;
	}
	public String getTechnicalFactor() {
		return technicalFactor;
	}
	public void setTechnicalFactor(String technicalFactor) {
		this.technicalFactor = technicalFactor;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public List<MeterDto> getMeter() {
		return meter;
	}
	public void setMeter(List<MeterDto> meter) {
		this.meter = meter;
	}
	public Long getSupplyId() {
		return supplyId;
	}
	public void setSupplyId(Long supplyId) {
		this.supplyId = supplyId;
	}
}
