package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.PropertyAreaChargeDto;
import com.monarch.mabdeck.entity.PropertyAreaCharge;

@Mapper
public abstract class PropertyAreaChargeMapper implements IBaseMapper<PropertyAreaChargeDto, PropertyAreaCharge>{
	public static final PropertyAreaChargeMapper INSTANCE = Mappers.getMapper(PropertyAreaChargeMapper.class);
	
	@Mappings({
		@Mapping(target = "tariff", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract PropertyAreaCharge convertToEntity(PropertyAreaChargeDto dto);
	
	@Mappings({
		@Mapping(target = "tariff", ignore = true)
	})
	public abstract PropertyAreaChargeDto convertToDTO(PropertyAreaCharge entity);

}
