package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class CustomerServiceContactHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private Long custServiceId;
	
	@Embedded
	private Address address;
	private long mainContactNumber;
	private String emailAddress;

	@Embedded
	private Audit audit;

	public Long getId() {
		return id;
	}

	public Long getCustServiceId() {
		return custServiceId;
	}

	public Address getAddress() {
		return address;
	}

	public long getMainContactNumber() {
		return mainContactNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public Audit getAudit() {
		return audit;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setCustServiceId(Long custServiceId) {
		this.custServiceId = custServiceId;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void setMainContactNumber(long mainContactNumber) {
		this.mainContactNumber = mainContactNumber;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}
}
