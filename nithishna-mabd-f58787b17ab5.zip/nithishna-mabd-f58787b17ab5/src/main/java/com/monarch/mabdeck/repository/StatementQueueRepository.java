package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.StatementQueue;

@Repository
public interface StatementQueueRepository extends JpaRepository<StatementQueue, Long>{
	List<StatementQueue> findByStatusIn(List<String> status);
	
	@Query(value="select * from statement_queue where status in (?1) and deleted=?2", nativeQuery=true)
	List<StatementQueue> findByStatusAndDeleted(List<String> status, boolean deleted);
}