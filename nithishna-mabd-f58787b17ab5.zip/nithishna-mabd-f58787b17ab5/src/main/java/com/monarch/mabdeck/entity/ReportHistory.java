package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class ReportHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	private Date fromDate;
	private Date toDate;
	
	@ManyToOne(targetEntity = ReportConfiguration.class, fetch = FetchType.EAGER)
	@JoinColumn(name="config_id",referencedColumnName="id", insertable = true, updatable = true)
	private ReportConfiguration configuration;
	private String location;
	private String status;
	
	@Embedded
	private Audit audit;

	public long getId() {
		return id;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public ReportConfiguration getConfiguration() {
		return configuration;
	}

	public Audit getAudit() {
		return audit;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public void setConfiguration(ReportConfiguration configuration) {
		this.configuration = configuration;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
