package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PropertyHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long propertyId;
	private Long clientId;
	private Long networkId;
	private Long bandId;
	
	@Embedded
	private Address address;
	
	private String reference;
	private String area;
	
	@Embedded
	private Audit audit;

	public Long getId() {
		return id;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public Long getClientId() {
		return clientId;
	}

	public Long getNetworkId() {
		return networkId;
	}

	public Long getBandId() {
		return bandId;
	}

	public Address getAddress() {
		return address;
	}

	public String getReference() {
		return reference;
	}

	public String getArea() {
		return area;
	}

	public Audit getAudit() {
		return audit;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public void setBandId(Long bandId) {
		this.bandId = bandId;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}
}
