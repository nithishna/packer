package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.PropertyDto;
import com.monarch.mabdeck.entity.Property;

@Mapper(uses = { AddressMapper.class })
public abstract class PropertyMapper implements IBaseMapper<PropertyDto, Property> {
	public static final PropertyMapper INSTANCE = Mappers.getMapper(PropertyMapper.class);

	@Mappings({ @Mapping(target = "client", ignore = true), @Mapping(target = "network", ignore = true),
			@Mapping(target = "band", ignore = true), @Mapping(target = "name", ignore = true),
			@Mapping(target = "supply", ignore = true), @Mapping(target = "hub", ignore = true) })
	public abstract PropertyDto convertToDTO(Property entity);

	@Mappings({ @Mapping(target = "client", ignore = true), @Mapping(target = "network", ignore = true),
			@Mapping(target = "band", ignore = true), @Mapping(target = "supply", ignore = true),
			@Mapping(target = "audit", ignore = true) })
	public abstract Property convertToEntity(PropertyDto dto);
	
}
