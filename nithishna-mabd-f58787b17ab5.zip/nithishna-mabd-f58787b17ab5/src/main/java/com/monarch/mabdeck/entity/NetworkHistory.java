package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class NetworkHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long networkId;
	private Long clientId;
	private String network;
	private String networkType;
	private boolean manualReview;
	private String hubManufacturer;
	private String estimationMethod;
	private boolean peerComparison;
	private String paymentCardProvider;
	private boolean allowPrepayment;
	private long iin;
	private boolean cardNumberGeneration;
	private float recoveryPercentage;
	@Embedded
	private Audit audit;
	public Long getId() {
		return id;
	}
	public Long getNetworkId() {
		return networkId;
	}
	public Long getClientId() {
		return clientId;
	}
	public String getNetwork() {
		return network;
	}
	public String getNetworkType() {
		return networkType;
	}
	public boolean isManualReview() {
		return manualReview;
	}
	public String getHubManufacturer() {
		return hubManufacturer;
	}
	public String getEstimationMethod() {
		return estimationMethod;
	}
	public boolean isPeerComparison() {
		return peerComparison;
	}
	public String getPaymentCardProvider() {
		return paymentCardProvider;
	}
	public boolean isAllowPrepayment() {
		return allowPrepayment;
	}
	public long getIin() {
		return iin;
	}
	public boolean isCardNumberGeneration() {
		return cardNumberGeneration;
	}
	public float getRecoveryPercentage() {
		return recoveryPercentage;
	}
	public Audit getAudit() {
		return audit;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}
	public void setManualReview(boolean manualReview) {
		this.manualReview = manualReview;
	}
	public void setHubManufacturer(String hubManufacturer) {
		this.hubManufacturer = hubManufacturer;
	}
	public void setEstimationMethod(String estimationMethod) {
		this.estimationMethod = estimationMethod;
	}
	public void setPeerComparison(boolean peerComparison) {
		this.peerComparison = peerComparison;
	}
	public void setPaymentCardProvider(String paymentCardProvider) {
		this.paymentCardProvider = paymentCardProvider;
	}
	public void setAllowPrepayment(boolean allowPrepayment) {
		this.allowPrepayment = allowPrepayment;
	}
	public void setIin(long iin) {
		this.iin = iin;
	}
	public void setCardNumberGeneration(boolean cardNumberGeneration) {
		this.cardNumberGeneration = cardNumberGeneration;
	}
	public void setRecoveryPercentage(float recoveryPercentage) {
		this.recoveryPercentage = recoveryPercentage;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
}
