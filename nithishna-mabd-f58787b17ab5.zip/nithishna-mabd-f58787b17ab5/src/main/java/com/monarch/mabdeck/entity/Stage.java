package com.monarch.mabdeck.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Stage implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long stageId;
	private String name;
	private boolean overDue;
	private int noOfDays;
	
	@OneToMany(mappedBy="stage", cascade = CascadeType.ALL)
	private List<Action> actions;
	
	
	@ManyToOne(cascade = CascadeType.ALL, targetEntity = CreditControlSetup.class, fetch = FetchType.EAGER)
	@JoinColumn(name="controlId",referencedColumnName="controlId", insertable = true, updatable = true)
	private CreditControlSetup setup;
	
	public String getName() {
		return name;
	}
	public boolean isOverDue() {
		return overDue;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setOverDue(boolean overDue) {
		this.overDue = overDue;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public List<Action> getActions() {
		return actions;
	}
	public void setActions(List<Action> actions) {
		this.actions = actions;
	}
	public long getStageId() {
		return stageId;
	}
	public CreditControlSetup getSetup() {
		return setup;
	}
	public void setStageId(long stageId) {
		this.stageId = stageId;
	}
	public void setSetup(CreditControlSetup setup) {
		this.setup = setup;
	}
	
}
