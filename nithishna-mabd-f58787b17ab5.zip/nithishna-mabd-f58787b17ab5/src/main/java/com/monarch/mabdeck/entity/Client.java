package com.monarch.mabdeck.entity;

import java.math.BigInteger;
import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Client implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long clientId;
	private String clientName;
	private String logo;
	
	@Embedded
	private Address address;
	private Date startDate;
	private String companyNumber;
	private BigInteger vatNumber;
	private String currency;
	private int paymentTerm;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "service_id")
	private CustomerServiceContact customerServiceContact;
	
    @OneToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "contact_id")
	private MainContact mainContact;
		
	@OneToMany(mappedBy = "client")
	private List<Band> band;
	
	@OneToMany(mappedBy="client", cascade = CascadeType.ALL)
	private List<Network> network;
	
	@OneToMany(mappedBy = "client")
	private List<Property> property;
	
    @OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "bank_account_id")
	private BankAccount bankAccount;
	
	@Embedded
	private Audit audit;
	
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public String getCompanyNumber() {
		return companyNumber;
	}
	public void setCompanyNumber(String companyNumber) {
		this.companyNumber = companyNumber;
	}
	public BigInteger getVatNumber() {
		return vatNumber;
	}
	public void setVatNumber(BigInteger vatNumber) {
		this.vatNumber = vatNumber;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public int getPaymentTerm() {
		return paymentTerm;
	}
	public void setPaymentTerm(int paymentTerm) {
		this.paymentTerm = paymentTerm;
	}
	public MainContact getMainContact() {
		return mainContact;
	}
	public void setMainContact(MainContact mainContact) {
		this.mainContact = mainContact;
	}
	public long getClientId() {
		return clientId;
	}
	public void setClientId(long clientId) {
		this.clientId = clientId;
	}
	public List<Network> getNetwork() {
		return network;
	}
	public void setNetwork(List<Network> network) {
		this.network = network;
	}
	public List<Band> getBand() {
		return band;
	}
	public void setBand(List<Band> band) {
		this.band = band;
	}
	public BankAccount getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}
	public CustomerServiceContact getCustomerServiceContact() {
		return customerServiceContact;
	}
	public void setCustomerServiceContact(CustomerServiceContact customerServiceContact) {
		this.customerServiceContact = customerServiceContact;
	}
	public List<Property> getProperty() {
		return property;
	}
	public void setProperty(List<Property> property) {
		this.property = property;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
}
