package com.monarch.mabdeck.dto;

public class AccountLimitedDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long accountId;
	private String firstName;
	private String lastName;
	private String accountNumber;
	private String network;
	private String clientName;
	private String startDate;
	private String endDate;
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public String getNetwork() {
		return network;
	}
	public String getClientName() {
		return clientName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public String getStartDate() {
		return startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
}
