package com.monarch.mabdeck.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class CreditCorrespondence implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long correspondenceId;
	private long clientId;
	private long networkId;
	private long propertyId;
	private long accountId;
	private String type;
	private Date correspondenceDate;
	private String fileName;
	private double accountBalance;
	private int daysOverdue;	
	private String stage;
	private boolean letter;
	private boolean deleted;
	@OneToMany(mappedBy = "creditCorrespondence", cascade = CascadeType.ALL)
	private List<CorrespondenceNotes> notes;
	
	public long getCorrespondenceId() {
		return correspondenceId;
	}
	public long getClientId() {
		return clientId;
	}
	public long getNetworkId() {
		return networkId;
	}
	public long getPropertyId() {
		return propertyId;
	}
	public long getAccountId() {
		return accountId;
	}
	public String getType() {
		return type;
	}
	public Date getCorrespondenceDate() {
		return correspondenceDate;
	}
	public String getFileName() {
		return fileName;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public int getDaysOverdue() {
		return daysOverdue;
	}
	public String getStage() {
		return stage;
	}
	public void setCorrespondenceId(long correspondenceId) {
		this.correspondenceId = correspondenceId;
	}
	public void setClientId(long clientId) {
		this.clientId = clientId;
	}
	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}
	public void setPropertyId(long propertyId) {
		this.propertyId = propertyId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setCorrespondenceDate(Date correspondenceDate) {
		this.correspondenceDate = correspondenceDate;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public void setDaysOverdue(int daysOverdue) {
		this.daysOverdue = daysOverdue;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public boolean isLetter() {
		return letter;
	}
	public void setLetter(boolean letter) {
		this.letter = letter;
	}
	public List<CorrespondenceNotes> getNotes() {
		return notes;
	}
	public void setNotes(List<CorrespondenceNotes> notes) {
		this.notes = notes;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
}
