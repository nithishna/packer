package com.monarch.mabdeck.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Network implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long networkId;
	
	@ManyToOne(cascade = CascadeType.ALL, targetEntity = Client.class, fetch = FetchType.EAGER)
	@JoinColumn(name="clientId",referencedColumnName="clientId", insertable = true, updatable = true)
	private Client client;
	
	private String network;
	private String networkType;
	private boolean manualReview;
	private String hubManufacturer;
	private String estimationMethod;
	private boolean peerComparison;
	
	@OneToMany(mappedBy="network")
	private List<Band> band;
	private String paymentCardProvider;
	private boolean allowPrepayment;
	private long iin;
	private boolean cardNumberGeneration;
	private float recoveryPercentage;
	
	@OneToMany(mappedBy = "network")
	private List<Property> property;
	
	@OneToMany(mappedBy = "network")
	private List<DataLogger> dataLogger;
	
	@Embedded
	private Audit audit;
	
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public String getNetworkType() {
		return networkType;
	}
	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}
	public boolean isManualReview() {
		return manualReview;
	}
	public void setManualReview(boolean manualReview) {
		this.manualReview = manualReview;
	}
	public String getHubManufacturer() {
		return hubManufacturer;
	}
	public void setHubManufacturer(String hubManufacturer) {
		this.hubManufacturer = hubManufacturer;
	}
	public long getNetworkId() {
		return networkId;
	}
	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}

	public List<Band> getBand() {
		return band;
	}
	public void setBand(List<Band> band) {
		this.band = band;
	}
	public boolean isAllowPrepayment() {
		return allowPrepayment;
	}
	public void setAllowPrepayment(boolean allowPrepayment) {
		this.allowPrepayment = allowPrepayment;
	}
	public long getIin() {
		return iin;
	}
	public void setIin(long iin) {
		this.iin = iin;
	}
	public boolean isCardNumberGeneration() {
		return cardNumberGeneration;
	}
	public void setCardNumberGeneration(boolean cardNumberGeneration) {
		this.cardNumberGeneration = cardNumberGeneration;
	}
	public float getRecoveryPercentage() {
		return recoveryPercentage;
	}
	public void setRecoveryPercentage(float recoveryPercentage) {
		this.recoveryPercentage = recoveryPercentage;
	}
	public String getEstimationMethod() {
		return estimationMethod;
	}
	public void setEstimationMethod(String estimationMethod) {
		this.estimationMethod = estimationMethod;
	}
	public String getPaymentCardProvider() {
		return paymentCardProvider;
	}
	public void setPaymentCardProvider(String paymentCardProvider) {
		this.paymentCardProvider = paymentCardProvider;
	}
	public List<Property> getProperty() {
		return property;
	}
	public void setProperty(List<Property> property) {
		this.property = property;
	}
	public List<DataLogger> getDataLogger() {
		return dataLogger;
	}
	public void setDataLogger(List<DataLogger> dataLogger) {
		this.dataLogger = dataLogger;
	}
	public boolean isPeerComparison() {
		return peerComparison;
	}
	public void setPeerComparison(boolean peerComparison) {
		this.peerComparison = peerComparison;
	}
}
