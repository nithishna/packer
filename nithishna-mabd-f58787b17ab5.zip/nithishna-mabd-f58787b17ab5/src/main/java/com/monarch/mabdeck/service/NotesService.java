package com.monarch.mabdeck.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;

import org.apache.poi.util.IOUtils;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.NotesDto;
import com.monarch.mabdeck.entity.Account;
import com.monarch.mabdeck.entity.Notes;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.NotesMapper;
import com.monarch.mabdeck.repository.AccountRepository;
import com.monarch.mabdeck.repository.NotesRepository;

@Component
public class NotesService extends CommonServiceImpl<NotesDto, Notes> {
	
	@Resource
	private NotesRepository repository;
	
	@Resource 
	private AccountRepository accountRepository;

	@Override
	public JpaRepository<Notes, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<NotesDto, Notes> getMapper() {
		return NotesMapper.INSTANCE;
	}

	@Override
	public void updateAudit(Notes entity, String username) {
		//do nothing		
	}	
	
	public byte[] getAttachmentForNote(Long noteId) throws IOException {
		byte[] result = null;
		byte[] attachment = repository.getAttachmentForId(noteId);
		String encodedAttachement = new String(attachment);
		byte[] decoded = Base64.getDecoder().decode(encodedAttachement.split(",")[1]);
		File file = null;
		FileOutputStream fileOuputStream = null;
		FileInputStream inputStream = null;
		try {
		file = new File("attachment.txt");
		fileOuputStream = new FileOutputStream(file);
		fileOuputStream.write(decoded);
		fileOuputStream.close();
		inputStream = new FileInputStream(file);
		result = IOUtils.toByteArray(inputStream);		
		}catch(IOException e) {
			throw new IOException("Could not read the attachment for Notes. Kindly check with the administrator");
		}finally {
			if (inputStream != null) {
                try {
                	inputStream.close();
                	file.delete();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
		}
		return result;		
	}
		
	public void createNote(NotesDto dto, String username) {
		if(dto != null) {
			Notes notes = new Notes();
			if(dto.getAccountId() != null) {
				Account account = accountRepository.findOne(dto.getAccountId());
				notes.setAccount(account);
			}
			notes.setAttachment(dto.getAttachment() != null? dto.getAttachment().getBytes():null);
			notes.setAuthor(username);
			notes.setFileName(dto.getFileName());
			Calendar cal = Calendar.getInstance();			
			notes.setModifiedDate(new Date(cal.getTime().getTime()));
			notes.setSummary(dto.getSummary());
			repository.saveAndFlush(notes);
		}
	}
	
	public List<NotesDto> getAllNotesForAccount(long accountId) {
		List<Notes> notes = repository.findByAccountId(accountId);
		List<NotesDto> dtos = new ArrayList<>();
		for(Notes note: notes) {
			NotesDto dto = new NotesDto();
			if(note.getAccount() != null)
				dto.setAccountId(note.getAccount().getAccountId());
			dto.setAuthor(note.getAuthor());
			dto.setSummary(note.getSummary());
			dto.setModifiedDate(note.getModifiedDate());
			dto.setNoteId(note.getNoteId());
			if(note.getAttachment() != null)
				dto.setAttachment("Yes");
			else
				dto.setAttachment("No");
			dtos.add(dto);
		}
		return dtos;
	}
	
	public void updateNotePinStatus(boolean pin, Long noteId) {
		Notes notes = repository.findOne(noteId);
		notes.setPin(pin);		
	}
}
