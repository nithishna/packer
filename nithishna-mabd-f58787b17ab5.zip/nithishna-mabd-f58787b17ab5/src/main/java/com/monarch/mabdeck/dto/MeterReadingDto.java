package com.monarch.mabdeck.dto;

public class MeterReadingDto implements IDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long meterReadingId;
	private NetworkDto network;
	private MeterDto meter;
	private String method;
	private float meterReading;
	private float flowTemperature;
	private float returnTemperature;
	private float instantaneousFlow;
	private float totalVolume;
	
	private String readingDateTime;
	public Long getMeterReadingId() {
		return meterReadingId;
	}
	public NetworkDto getNetwork() {
		return network;
	}
	public MeterDto getMeter() {
		return meter;
	}
	public String getMethod() {
		return method;
	}
	public float getMeterReading() {
		return meterReading;
	}
	public float getFlowTemperature() {
		return flowTemperature;
	}
	public float getReturnTemperature() {
		return returnTemperature;
	}
	public float getInstantaneousFlow() {
		return instantaneousFlow;
	}
	public float getTotalVolume() {
		return totalVolume;
	}
	public String getReadingDateTime() {
		return readingDateTime;
	}
	public void setMeterReadingId(Long meterReadingId) {
		this.meterReadingId = meterReadingId;
	}
	public void setNetwork(NetworkDto network) {
		this.network = network;
	}
	public void setMeter(MeterDto meter) {
		this.meter = meter;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public void setMeterReading(float meterReading) {
		this.meterReading = meterReading;
	}
	public void setFlowTemperature(float flowTemperature) {
		this.flowTemperature = flowTemperature;
	}
	public void setReturnTemperature(float returnTemperature) {
		this.returnTemperature = returnTemperature;
	}
	public void setInstantaneousFlow(float instantaneousFlow) {
		this.instantaneousFlow = instantaneousFlow;
	}
	public void setTotalVolume(float totalVolume) {
		this.totalVolume = totalVolume;
	}
	public void setReadingDateTime(String readingDateTime) {
		this.readingDateTime = readingDateTime;
	}
	
}
