package com.monarch.mabdeck.dto;

import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

public class StatementGenerationInput implements IDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<Long> clientIDs = new ArrayList<>();
	private List<Long> networkIDs = new ArrayList<>();
	private List<Long> propertyIDs = new ArrayList<>();
	private String username;
	private Date billDate;
	private Long queueId;
	public List<Long> getClientIDs() {
		return clientIDs;
	}
	public List<Long> getNetworkIDs() {
		return networkIDs;
	}
	public List<Long> getPropertyIDs() {
		return propertyIDs;
	}
	public void setClientIDs(List<Long> clientIDs) {
		this.clientIDs = clientIDs;
	}
	public void setNetworkIDs(List<Long> networkIDs) {
		this.networkIDs = networkIDs;
	}
	public void setPropertyIDs(List<Long> propertyIDs) {
		this.propertyIDs = propertyIDs;
	}
	
	public void addClientID(Long clientId) {
		this.clientIDs.add(clientId);		
	}
	public void addNetworkID(Long networkId) {
		this.networkIDs.add(networkId);
	}	
	public void addPropertyID(Long propertyId) {
		this.propertyIDs.add(propertyId);
	}
	public Date getBillDate() {
		return billDate;
	}
	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Long getQueueId() {
		return queueId;
	}
	public void setQueueId(Long queueId) {
		this.queueId = queueId;
	}
}
