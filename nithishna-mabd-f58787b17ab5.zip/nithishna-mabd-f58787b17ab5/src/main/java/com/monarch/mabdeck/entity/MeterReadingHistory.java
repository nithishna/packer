package com.monarch.mabdeck.entity;

import java.util.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MeterReadingHistory implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long meterReadingId;	
	private Long networkId;
	private Long meterId;
	private String method;
	private float meterReading;
	private float flowTemperature;
	private float returnTemperature;
	private float instantaneousFlow;
	private float totalVolume;
	private Date readingDateTime;
	
	@Embedded
	private Audit audit;

	public Long getId() {
		return id;
	}

	public Long getMeterReadingId() {
		return meterReadingId;
	}

	public Long getNetworkId() {
		return networkId;
	}

	public Long getMeterId() {
		return meterId;
	}

	public String getMethod() {
		return method;
	}

	public float getMeterReading() {
		return meterReading;
	}

	public float getFlowTemperature() {
		return flowTemperature;
	}

	public float getReturnTemperature() {
		return returnTemperature;
	}

	public float getInstantaneousFlow() {
		return instantaneousFlow;
	}

	public float getTotalVolume() {
		return totalVolume;
	}

	public Date getReadingDateTime() {
		return readingDateTime;
	}

	public Audit getAudit() {
		return audit;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setMeterReadingId(Long meterReadingId) {
		this.meterReadingId = meterReadingId;
	}

	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public void setMeterId(Long meterId) {
		this.meterId = meterId;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public void setMeterReading(float meterReading) {
		this.meterReading = meterReading;
	}

	public void setFlowTemperature(float flowTemperature) {
		this.flowTemperature = flowTemperature;
	}

	public void setReturnTemperature(float returnTemperature) {
		this.returnTemperature = returnTemperature;
	}

	public void setInstantaneousFlow(float instantaneousFlow) {
		this.instantaneousFlow = instantaneousFlow;
	}

	public void setTotalVolume(float totalVolume) {
		this.totalVolume = totalVolume;
	}

	public void setReadingDateTime(Date readingDateTime) {
		this.readingDateTime = readingDateTime;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}

}
