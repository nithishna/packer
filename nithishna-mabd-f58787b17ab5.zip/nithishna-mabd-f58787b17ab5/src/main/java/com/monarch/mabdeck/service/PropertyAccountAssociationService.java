package com.monarch.mabdeck.service;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.activity.InvalidActivityException;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.AccountAssociatedUser;
import com.monarch.mabdeck.dto.AccountBalanceDto;
import com.monarch.mabdeck.dto.AccountLimitedDto;
import com.monarch.mabdeck.dto.AddressDto;
import com.monarch.mabdeck.dto.MyDate;
import com.monarch.mabdeck.dto.PropertyAccountAssociationDto;
import com.monarch.mabdeck.dto.PropertyAccountAssociationLimitedDto;
import com.monarch.mabdeck.dto.PropertyAccountDto;
import com.monarch.mabdeck.entity.Account;
import com.monarch.mabdeck.entity.AccountBalance;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.BillablePerson;
import com.monarch.mabdeck.entity.Meter;
import com.monarch.mabdeck.entity.Property;
import com.monarch.mabdeck.entity.PropertyAccountAssociation;
import com.monarch.mabdeck.history.service.PropertyAccountAssociationHistoryService;
import com.monarch.mabdeck.mapper.AddressMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.repository.AccountBalanceRepository;
import com.monarch.mabdeck.repository.AccountRepository;
import com.monarch.mabdeck.repository.MeterReadingRepository;
import com.monarch.mabdeck.repository.MeterRepository;
import com.monarch.mabdeck.repository.PropertyAccountAssociationRepository;
import com.monarch.mabdeck.repository.PropertyRepository;
import com.monarch.mabdeck.repository.TariffRepository;

@Component
public class PropertyAccountAssociationService
		extends CommonServiceImpl<PropertyAccountAssociationDto, PropertyAccountAssociation> {

	@Autowired
	private PropertyAccountAssociationHistoryService historyService;

	@Resource
	private PropertyAccountAssociationRepository repository;

	@Resource
	private AccountRepository accountRepository;

	@Resource
	private PropertyRepository propertyRepository;

	@Resource
	private TariffRepository tariffRepository;

	@Resource
	private MeterRepository meterRepository;

	@Resource
	private AccountBalanceRepository accountBalanceRepository;

	@Resource
	private MeterReadingRepository meterReadingRepository;

	@Override
	public JpaRepository<PropertyAccountAssociation, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<PropertyAccountAssociationDto, PropertyAccountAssociation> getMapper() {
		return null;
	}

	public List<PropertyAccountDto> getAllPropertyAssociations(Long accountId) {
		List<PropertyAccountDto> dtos = new ArrayList<>();
		Account account = accountRepository.findOne(accountId);
		Set<Long> propertyIds = new HashSet<>();
		List<PropertyAccountAssociation> entities = repository.getAllAssociationsForAccountId(accountId, "tenant");
		for (PropertyAccountAssociation entity : entities) {
			Property prop = entity.getProperty();
			if (propertyIds.contains(prop.getPropertyId()))
				continue;
			else
				propertyIds.add(prop.getPropertyId());
			PropertyAccountDto dto = new PropertyAccountDto();
			dto.setAccountId(accountId);
			Property property = entity.getProperty();
			AddressDto propertyAddress = AddressMapper.INSTANCE.convertToDTO(property.getAddress());
			dto.setPropertyAddress(propertyAddress);
			AddressDto billingAddress = AddressMapper.INSTANCE.convertToDTO(account.getAddress());
			dto.setBillingAddress(billingAddress);
			dto.setArea(property.getArea());
			dto.setReference(property.getReference());
			dto.setStartDate(entity.getStartDate());
			dto.setEndDate(entity.getEndDate());
			dto.setAssociationId(entity.getAssociationId());
			if (entity.getProperty() != null)
				dto.setPropertyId(entity.getProperty().getPropertyId());
			dtos.add(dto);
		}
		return dtos;
	}

	public void updateMoveOutStatusForProperties(Long associationId, String dateString, String username)
			throws InvalidActivityException, ParseException {
		if (associationId == null)
			throw new InvalidActivityException("Supply valid information");
		PropertyAccountAssociation association = repository.findOne(associationId);
		java.util.Date date = null;
		if (dateString != null) {
			date = new SimpleDateFormat("dd/MM/yyyy").parse(dateString);
		}
		if (association != null) {
			if (association.getMoveOutStatus() != null)
				return;
			historyService.updatePropertyAccountAssociationHistory(association, username);
			association.setMoveOutStatus("Pending");
			if (date != null)
				association.setEndDate(new Date(date.getTime()));
			else
				association.setEndDate(null);
			Audit audit = association.getAudit();
			Calendar cal = Calendar.getInstance();
			if (audit != null) {
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
			} else {
				audit = new Audit();
				audit.setCreatedDate(new Date(cal.getTime().getTime()));
				audit.setCreatedUser(username);
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
			}
			association.setAudit(audit);
		}
	}

	public String updateMoveInStatusForProperties(PropertyAccountDto dto, String username)
			throws InvalidActivityException {
		String tenantPropertyIds = "";
		boolean newData = false;
		if (dto == null)
			throw new InvalidActivityException("Supply valid information");
		Account account = accountRepository.findOne(dto.getAccountId());
		if (account == null)
			throw new InvalidActivityException("No such Account");
		Property property = propertyRepository.findOne(dto.getPropertyId());
		if (property == null)
			throw new InvalidActivityException("No such Property");
		//PropertyAccountAssociation old = repository.getAssociationForProperty(dto.getPropertyId(), "tenant");
		PropertyAccountAssociation existingAssociationForSameAccount = repository.getAssociationForAccountIdAndPropertyId(dto.getAccountId(), dto.getPropertyId(), "tenant");
		if (existingAssociationForSameAccount != null) {
			return "Already this account is in the process of moving into this Property";
		}
		boolean flag = true;
		List<PropertyAccountAssociation> existingActiveTenant = repository.getActiveOrInprogressOwnerToProperty(dto.getPropertyId(), "tenant");
		if (existingActiveTenant != null && existingActiveTenant.size() > 0) {
			for (PropertyAccountAssociation tenantAssociation : existingActiveTenant) {
				historyService.updatePropertyAccountAssociationHistory(tenantAssociation, username);
				tenantAssociation.setMoveOutStatus("Pending");
				this.updateAudit(tenantAssociation, username);
				tenantAssociation.setEndDate(new Date(dto.getStartDate().getTime()));
				if(flag) {
					if(tenantAssociation.getAssociatedIds()== null || tenantAssociation.getAssociatedIds().equals("") || tenantAssociation.getAssociatedIds().isEmpty()) {
						tenantPropertyIds = tenantAssociation.getAssociationId() + "";
						flag = false;
					}else {
						tenantPropertyIds = tenantAssociation.getAssociatedIds() + "," + tenantAssociation.getAssociationId();
						flag = false;
					}
				}
				else {
					tenantPropertyIds = tenantPropertyIds + ",";
					if(tenantAssociation.getAssociatedIds() != null && !tenantAssociation.getAssociatedIds().equals("") && !tenantAssociation.getAssociatedIds().isEmpty()) {
						tenantPropertyIds = tenantPropertyIds + tenantAssociation.getAssociatedIds() + "," + tenantAssociation.getAssociationId();
					}else {
						tenantPropertyIds = tenantPropertyIds + tenantAssociation.getAssociationId();
					}
				}
			}
		} else {
			newData = true;
		}
		
		PropertyAccountAssociation association = new PropertyAccountAssociation();
		association.setAccount(account);
		association.setProperty(property);
		association.setMoveInStatus(newData ? "Completed" : "Pending");
		association.setTenureType("tenant");
		association.setCounter(0);
		if (dto.getStartDate() != null)
			association.setStartDate(new Date(dto.getStartDate().getTime()));
		if (dto.getEndDate() != null)
			association.setEndDate(new Date(dto.getEndDate().getTime()));
		else
			association.setEndDate(null);
		association.setDeleted(false);
		// association.setMoveOutStatus(null);
		association.setAssociatedIds(tenantPropertyIds);
		Audit audit = new Audit();
		Calendar cal = Calendar.getInstance();
		audit.setCreatedDate(new Date(cal.getTime().getTime()));
		audit.setCreatedUser(username);
		association.setAudit(audit);
		repository.saveAndFlush(association);
		/*
		 * PropertyAccountAssociation association =
		 * repository.getAssociationForPropertyAndAccount(dto.getAccountId(),
		 * dto.getPropertyId()); if (association == null) { association = new
		 * PropertyAccountAssociation(); newData = true; } else
		 * historyService.updatePropertyAccountAssociationHistory(association,
		 * username); association.setAccount(account);
		 * association.setProperty(property); association.setMoveInStatus("Pending");
		 * association.setTenureType("owner"); association.setCounter(0); if
		 * (dto.getStartDate() != null) association.setStartDate(new
		 * Date(dto.getStartDate().getTime())); if (dto.getEndDate() != null)
		 * association.setEndDate(new Date(dto.getEndDate().getTime())); else
		 * association.setEndDate(null); association.setDeleted(false); //
		 * association.setMoveOutStatus(null); Audit audit = new Audit(); Calendar cal =
		 * Calendar.getInstance(); audit.setCreatedDate(new
		 * Date(cal.getTime().getTime())); audit.setCreatedUser(username);
		 * association.setAudit(audit); if (newData)
		 * repository.saveAndFlush(association);
		 */
		return "Process initiated";
	}

	public String getStatusForPropertyAndAccount(Long propertyId, Long accountId, int value) {
		PropertyAccountAssociation association = repository.getAssociationForPropertyAndAccount(accountId, propertyId,
				"tenant");
		if (association != null)
			return (value == 1 ? association.getMoveInStatus() : association.getMoveOutStatus());
		else
			return null;
	}

	public String getStatusForAssociationId(Long associationId, int value) {
		PropertyAccountAssociation association = repository.getAssociationByAssociationIdForOwner(associationId,
				"owner");
		if (association != null)
			return (value == 1 ? association.getMoveInStatus() : association.getMoveOutStatus());
		else
			return null;
	}

	public String changePendingToSanityCheck(Long accountId, Long propertyId, String username, String tenure) {
		if (propertyId == null)
			return "Invalid Property ID";
		if (accountId == null)
			return "Invalid Account ID";
		int meterCount = repository.sanityCheckForMeterAssociatedToProperty(accountId, propertyId);
		if (meterCount < 1)
			return "No supply/meter associated with the property";
		int ownerCount = repository.sanityCheckForUserAssociatedToProperty(propertyId, "owner");
		if (ownerCount < 1)
			return "No owner associated with the property";
		PropertyAccountAssociation association = repository.getAssociationForPropertyAndAccount(accountId, propertyId,
				tenure);
		if (association == null)
			return "Invalid Data";
		historyService.updatePropertyAccountAssociationHistory(association, username);
		association.setMoveInStatus("SanityCheck");
		Calendar cal = Calendar.getInstance();
		if (association.getAudit() != null) {
			association.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
			association.getAudit().setUpdatedUser(username);
		} else {
			Audit audit = new Audit();
			audit.setCreatedDate(new Date(cal.getTime().getTime()));
			audit.setCreatedUser(username);
			audit.setUpdatedDate(new Date(cal.getTime().getTime()));
			audit.setUpdatedUser(username);
		}
		return "Success";
	}

	public String changeSanityToPreviousTenant(Long accountId, Long associationId, String username, String tenureType) {
		if (accountId == null)
			return "Invalid Account ID";
		if (associationId == null)
			return "Invalid Association ID";
		int activeTenantsCount = repository.previousTenancyCheck(associationId, tenureType);
		PropertyAccountAssociation association = repository.getAssociationForPropertyAndAccount(accountId,
				associationId, tenureType);
		if (association == null)
			return "Invalid Input";
		if (activeTenantsCount > 1) {
			String result = this.endTenancyForExistingTenants(associationId, username, association.getStartDate(),
					tenureType);
			if (result == null || !result.equalsIgnoreCase("Success")) {
				return result;
			}
		}
		historyService.updatePropertyAccountAssociationHistory(association, username);
		if (tenureType.equalsIgnoreCase("tenant"))
			association.setMoveInStatus("PreviousTenant");
		else
			association.setMoveInStatus("PreviousOwner");
		Calendar cal = Calendar.getInstance();
		if (association.getAudit() != null) {
			association.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
			association.getAudit().setUpdatedUser(username);
		} else {
			Audit audit = new Audit();
			audit.setCreatedDate(new Date(cal.getTime().getTime()));
			audit.setCreatedUser(username);
			audit.setUpdatedDate(new Date(cal.getTime().getTime()));
			audit.setUpdatedUser(username);
			association.setAudit(audit);
		}
		return "Status updated successfully";
	}

	private String endTenancyForExistingTenants(Long associationId, String username, Date startDate,
			String tenureType) {
		if (startDate == null)
			return "Invalid Start Date for new " + tenureType;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		List<PropertyAccountAssociation> activeTenants = repository.getActiveTenantForProperty(associationId,
				tenureType, formatter.format(startDate));
		/**
		 * Validation on the existing tenants
		 */
		if (activeTenants != null && activeTenants.size() > 0) {
			int existingMeterReading = repository.getPreviousDayMeterReadingForAssociation(formatter.format(startDate),
					associationId);
			if (existingMeterReading < 1) {
				String previousDay = repository.getStartDateForAssociationId(associationId);
				return "No meter reading for previous day: " + previousDay;
			}
			int currentMeterReading = repository.getCurrentDayMeterReadingFromAssociation(formatter.format(startDate),
					associationId);
			if (currentMeterReading < 1)
				return "No meter reading for current day: " + formatter.format(startDate);
		}
		for (PropertyAccountAssociation tenant : activeTenants) {
			historyService.updatePropertyAccountAssociationHistory(tenant, username);
			tenant.setEndDate(new Date(cal.getTime().getTime()));
			tenant.setMoveOutStatus("Pending");
			// ToDo generate end statement for previous tenant here
			/*
			 * 
			 * To Do
			 * 
			 */
			if (tenant.getAudit() != null) {
				tenant.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				tenant.getAudit().setUpdatedUser(username);
			} else {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				audit.setCreatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				tenant.setAudit(audit);
			}
		}
		return "Success";
	}

	public String changePreviousTenantToPreviousMeterReading(Long accountId, Long associationId, String username,
			String tenureType) {
		if (accountId == null)
			return "Invalid Account ID";
		if (associationId == null)
			return "Invalid Association";

		List<Meter> meters = meterRepository.getAllMetersForAssociatedProperty(associationId);
		if (meters != null && meters.size() > 0) {
			for (Meter meter : meters) {
				int count = meterReadingRepository.getMeterReadingsCount(meter.getMeterId(), associationId);
				if (count <= 0)
					return "No meter reading for meter serial number:" + meter.getSerialNumber() + " for date:"
							+ repository.getStartDateForAssociationId(associationId);
			}

		}
		PropertyAccountAssociation association = repository.findOne(associationId);
		if (association == null)
			return "Invalid Data";
		historyService.updatePropertyAccountAssociationHistory(association, username);
		association.setMoveInStatus("PreviousReading");
		updateAudit(association, username);
		return "Status changed successfully";

		/*
		 * int previousMeterReadingCount =
		 * repository.getPreviousMeterReadingForAccountAndProperty(accountId,
		 * associationId); if (previousMeterReadingCount > 0) {
		 * PropertyAccountAssociation association =
		 * repository.getAssociationForPropertyAndAccount(accountId, associationId,
		 * tenureType); if (association == null) return "Invalid Data";
		 * historyService.updatePropertyAccountAssociationHistory(association,
		 * username); association.setMoveInStatus("PreviousReading"); Calendar cal =
		 * Calendar.getInstance(); if (association.getAudit() != null) {
		 * association.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
		 * association.getAudit().setUpdatedUser(username); } else { Audit audit = new
		 * Audit(); audit.setCreatedDate(new Date(cal.getTime().getTime()));
		 * audit.setCreatedUser(username); audit.setUpdatedDate(new
		 * Date(cal.getTime().getTime())); audit.setUpdatedUser(username);
		 * association.setAudit(audit); } return "Status changed successfully"; } else {
		 * String startDate = repository.getStartDateForAssociationId(associationId);
		 * return "No meter reading for previous day = " + startDate; }
		 */
	}

	public String changePreviousMeterReadingToCurrentMeterReading(Long accountId, Long associationId, String username,
			String tenureType) {

		if (accountId == null)
			return "Invalid Account ID";
		if (associationId == null)
			return "Invalid Association";

		List<Meter> meters = meterRepository.getAllMetersForAssociatedProperty(associationId);
		if (meters != null && meters.size() > 0) {
			for (Meter meter : meters) {
				int count = meterReadingRepository.getMeterReadingsCountForCurrent(meter.getMeterId(), associationId);
				if (count <= 0)
					return "No meter reading for meter serial number:" + meter.getSerialNumber() + " for date:"
							+ repository.getStartDate(associationId);
			}

		}
		PropertyAccountAssociation association = repository.findOne(associationId);
		if (association == null)
			return "Invalid Data";
		historyService.updatePropertyAccountAssociationHistory(association, username);
		association.setMoveInStatus("CurrentReading");
		updateAudit(association, username);
		return "Status changed successfully";
		/*
		 * if (accountId == null) return "Invalid Account ID"; if (associationId ==
		 * null) return "Invalid Association"; int currentMeterReadingCount =
		 * repository.getCurrentMeterReadingForAccountAndProperty(accountId,
		 * associationId); if (currentMeterReadingCount > 0) {
		 * PropertyAccountAssociation association =
		 * repository.getAssociationForPropertyAndAccount(accountId, associationId,
		 * tenureType); if (association == null) return "Invalid data";
		 * historyService.updatePropertyAccountAssociationHistory(association,
		 * username); association.setMoveInStatus("CurrentReading"); Calendar cal =
		 * Calendar.getInstance(); if (association.getAudit() != null) {
		 * association.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
		 * association.getAudit().setUpdatedUser(username); } else { Audit audit = new
		 * Audit(); audit.setCreatedDate(new Date(cal.getTime().getTime()));
		 * audit.setCreatedUser(username); audit.setUpdatedDate(new
		 * Date(cal.getTime().getTime())); audit.setUpdatedUser(username);
		 * association.setAudit(audit); } return "Status changed successfully"; } else {
		 * return "No meter reading for current day"; }
		 */
	}

	public String changeCurrentReadingToCompleted(Long accountId, Long propertyId, String username, String tenureType) {
		if (accountId == null)
			return "Invalid Account ID";
		if (propertyId == null)
			return "Invalid Property ID";
		PropertyAccountAssociation association = repository.getAssociationForPropertyAndAccount(accountId, propertyId,
				tenureType);
		if (association == null)
			return "No such Property and Account association";
		historyService.updatePropertyAccountAssociationHistory(association, username);
		association.setMoveInStatus("Completed");
		updateAudit(association, username);
		return "Status changed successfully";
	}

	public String changePendingToPreviousMeterReadingForTenantOut(Long accountId, Long associationId, String username,
			String tenureType) {
		if (accountId == null)
			return "Invalid Account ID";
		if (associationId == null)
			return "Invalid Association";

		PropertyAccountAssociation association = repository.findOne(associationId);
		if (association == null)
			return "No such Property and Account association";

		if (association.getEndDate() == null)
			return "There is no end date for this association";

		List<Meter> meters = meterRepository.getAllMetersForAssociatedProperty(associationId);
		if (meters != null && meters.size() > 0) {
			for (Meter meter : meters) {
				int count = meterReadingRepository.getPreviousDayMeterReadingsCountForMoveOutTenant(meter.getMeterId(),
						associationId);
				if (count <= 0)
					return "No meter reading for meter serial number:" + meter.getSerialNumber() + " for date:"
							+ repository.getPreviousDayToEndDateForAssociation(associationId);
			}
		}

		historyService.updatePropertyAccountAssociationHistory(association, username);
		association.setMoveOutStatus("PreviousReading");
		updateAudit(association, username);
		return "Status changed successfully";
		/*
		 * PropertyAccountAssociation association =
		 * repository.getAssociationForPropertyAndAccount(accountId, associationId,
		 * tenureType); if (association == null) return "Invalid Data";
		 * if(association.getEndDate()== null) return "End date not specified"; int
		 * previousDayMeterReadingCount =
		 * repository.getPreviousDayMeterReadingForMoveOutTenant(accountId,
		 * associationId); if (previousDayMeterReadingCount > 0) {
		 * historyService.updatePropertyAccountAssociationHistory(association,
		 * username); association.setMoveOutStatus("PreviousReading");
		 * updateAudit(association, username); return "Status changed successfully"; }
		 * else { String message = "No meter reading for "; if(association.getEndDate()
		 * != null) message = message + new java.sql.Date(
		 * association.getEndDate().getTime() - 24*60*60*1000); else message = message +
		 * "previous day"; return message; }
		 */
	}

	public String changePreviousMeterReadingToCurrentMeterReadingForTenantOut(Long accountId, Long associationId,
			String username, String tenureType) {
		if (accountId == null)
			return "Invalid Account ID";
		if (associationId == null)
			return "Invalid Association";

		PropertyAccountAssociation association = repository.findOne(associationId);
		if (association == null)
			return "No such Property and Account association";
		if (association.getEndDate() == null)
			return "There is no end date for this association";

		List<Meter> meters = meterRepository.getAllMetersForAssociatedProperty(associationId);
		if (meters != null && meters.size() > 0) {
			for (Meter meter : meters) {
				int count = meterReadingRepository.getCurrentDayMeterReadingsCountForMoveOutTenant(meter.getMeterId(),
						associationId);
				if (count <= 0)
					return "No meter reading for meter serial number:" + meter.getSerialNumber() + " for date:"
							+ repository.getCurrentEndDateForAssociation(associationId);
			}
		}

		historyService.updatePropertyAccountAssociationHistory(association, username);
		association.setMoveOutStatus("CurrentReading");
		updateAudit(association, username);
		return "Status changed successfully";
		/*
		 * if (accountId == null) return "Invalid Account ID"; if (associationId ==
		 * null) return "Invalid Association"; PropertyAccountAssociation association =
		 * repository.getAssociationForPropertyAndAccount(accountId, associationId,
		 * tenureType); if (association == null) return "Invalid Data"; int
		 * currentDayMeterReadingCount =
		 * repository.getCurrentDayMeterReadingForMoveOutTenant(accountId,
		 * associationId); if (currentDayMeterReadingCount > 0) {
		 * historyService.updatePropertyAccountAssociationHistory(association,
		 * username); association.setMoveOutStatus("CurrentReading"); Calendar cal =
		 * Calendar.getInstance(); if (association.getAudit() != null) {
		 * association.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
		 * association.getAudit().setUpdatedUser(username); } else { Audit audit = new
		 * Audit(); audit.setCreatedDate(new Date(cal.getTime().getTime()));
		 * audit.setCreatedUser(username); audit.setUpdatedDate(new
		 * Date(cal.getTime().getTime())); audit.setUpdatedUser(username);
		 * association.setAudit(audit); } return "Status changed successfully"; } else {
		 * String message = "No meter reading for "; if(association.getEndDate() !=
		 * null) message = message + association.getEndDate(); else message = message +
		 * "current day"; return message; }
		 */
	}

	public String changeCurrentReadingToCompletedForTenantOut(Long accountId, Long propertyId, String username,
			String tenureType) {
		if (accountId == null)
			return "Invalid Account ID";
		if (propertyId == null)
			return "Invalid Property ID";
		PropertyAccountAssociation association = repository.getAssociationForPropertyAndAccount(accountId, propertyId,
				tenureType);
		if (association == null)
			return "No such Property and Account association";
		historyService.updatePropertyAccountAssociationHistory(association, username);
		association.setMoveOutStatus("Completed");
		updateAudit(association, username);
		return "Status changed successfully";
	}

	public String getOwnerForPropertyId(Long propertyId) {
		String owner = repository.getAccountOwnerForProperty(propertyId);
		return owner == null ? "No Owner" : owner;
	}

	public AccountAssociatedUser getOwnerAndTenantAssociatedWithProperty(Long propertyId) {
		AccountAssociatedUser owner = new AccountAssociatedUser();
		Long accountId = repository.getAccountAssociationDetails(propertyId, "owner");
		if (accountId == null)
			accountId = repository.getAccountAssociationDetailsInProgress(propertyId, "owner");
		if (accountId == null) {
			if (accountId == null) {
				owner.setAccountNumber("No Owner");
				owner.setName("No Owner");
			}
		} else {
			String ownerName = repository.getBillablePersonNameForAccount(accountId);
			owner.setName(ownerName == null ? "No Owner" : ownerName);
			owner.setAccountId(accountId);
			List<Object[]> ownerDetails = accountRepository.getAccountDetailsForAccountId(accountId);
			if (ownerDetails != null && ownerDetails.size() > 0) {
				Object[] element = ownerDetails.get(0);
				owner.setAccountNumber(element[0] == null ? "" : "" + element[0]);
				owner.setBillingAddress(convertObjectToAddressDto(element, 1));
			} else {
				owner.setAccountNumber("No Owner");
				owner.setBillingAddress(null);
			}
		}
		List<Object[]> propertyDetails = propertyRepository.getPropertyDetailsForPropertyId(propertyId);
		if (propertyDetails != null && propertyDetails.size() > 0)
			owner.setPropertyAddress(convertObjectToAddressDto(propertyDetails.get(0), 0));
		if (propertyDetails != null && propertyDetails.size() > 0 && propertyDetails.get(0) != null) {
			Object[] elements = propertyDetails.get(0);
			owner.setBandName(elements[7] == null ? "" : "" + elements[7]);
		}
		owner.setNumberOfTariffs(tariffRepository.getTariffCountForPropertyId(propertyId));
		AccountAssociatedUser tenant = new AccountAssociatedUser();
		Long tenantAccountId = repository.getAccountAssociationDetails(propertyId, "tenant");
		if (tenantAccountId == null) {
			owner.setTenant(null);
		} else {
			String tenantName = repository.getBillablePersonNameForAccount(tenantAccountId);
			tenant.setName(tenantName == null ? "No Tenant" : tenantName);
			List<Object[]> tenantDetails = repository.getTenantDetailsForProperty(tenantAccountId, "tenant");
			if (tenantDetails == null || tenantDetails.size() < 1) {
				owner.setTenant(null);
			} else {
				Object[] tenancyArray = tenantDetails.get(0);
				if (tenancyArray != null && tenancyArray.length > 0) {
					tenant.setAccountId(tenantAccountId);
					tenant.setAccountNumber(tenancyArray[0] == null ? "" : "" + tenancyArray[0]);
					tenant.setClientName(tenancyArray[1] == null ? "" : "" + tenancyArray[1]);
					tenant.setNetworkName(tenancyArray[2] == null ? "" : "" + tenancyArray[2]);
					tenant.setNumberOfProperties(tenancyArray[3] == null ? 0 : (int) tenancyArray[3]);
					owner.setTenant(tenant);
				}
			}
		}
		return owner;
	}

	private AddressDto convertObjectToAddressDto(Object[] object, int counter) {
		if (object == null)
			return null;
		AddressDto addressDto = new AddressDto();
		addressDto.setAddressLine1(object[counter] == null ? "" : "" + object[counter]);
		counter++;
		addressDto.setAddressLine2(object[counter] == null ? "" : "" + object[counter]);
		counter++;
		addressDto.setAddressLine3(object[counter] == null ? "" : "" + object[counter]);
		counter++;
		addressDto.setRegion(object[counter] == null ? "" : "" + object[counter]);
		counter++;
		addressDto.setTown(object[counter] == null ? "" : "" + object[counter]);
		counter++;
		addressDto.setCountry(object[counter] == null ? "" : "" + object[counter]);
		counter++;
		addressDto.setPostCode(object[counter] == null ? "" : "" + object[counter]);
		return addressDto;
	}

	public List<AccountLimitedDto> getAllAccountsForProperty(Long propertyId, String tenureType) {
		List<AccountLimitedDto> result = new ArrayList<>();
		List<Object[]> accounts = repository.getAccountHistoryForProperty(propertyId, tenureType);
		if (accounts != null && accounts.size() > 0) {
			for (Object[] element : accounts) {
				if (element != null && element.length > 0) {
					AccountLimitedDto account = new AccountLimitedDto();
					int counter = 0;
					account.setAccountId(
							element[counter] == null ? 0 : Long.parseLong(String.valueOf(element[counter])));
					counter++;
					account.setFirstName(element[counter] == null ? "" : "" + element[counter]);
					counter++;
					account.setStartDate(element[counter] == null ? "" : "" + element[counter]);
					counter++;
					account.setEndDate(element[counter] == null ? "" : "" + element[counter]);
					result.add(account);
				}
			}
		}
		return result;
	}

	private String validateInputForAccountAssociation(PropertyAccountAssociationLimitedDto dto) {
		String result = "Success";
		if (dto == null)
			return "Invalid input";

		if (dto.getPropertyId() <= 0)
			return "Invalid Property";

		if (dto.getAccountId() <= 0)
			return "Invalid Account";

		if (dto.getOwner() <= 0 && dto.getTenant() <= 0)
			return "Invalid Tenancy";

		if (dto.getStartDate() == null)
			return "Invalid start date";

		return result;
	}

	public String updatePropertyAccountAssociationForOwnerV2(PropertyAccountAssociationLimitedDto dto, String username)
			throws ParseException {
		boolean newOwner = false, newTenant = false;
		String validationResult = this.validateInputForAccountAssociation(dto);
		if (!validationResult.equalsIgnoreCase("Success"))
			return validationResult;

		Account account = accountRepository.findOne(dto.getAccountId());
		if (account == null)
			return "Invalid Account";

		Property property = propertyRepository.findOne(dto.getPropertyId());
		if (property == null)
			return "Invalid Property";

		List<PropertyAccountAssociation> existingActiveAssociation = repository
				.getActiveOrInprogressOwnerToProperty(dto.getPropertyId(), "owner");
		java.util.Date dateTemp = new SimpleDateFormat("dd/MM/yyyy").parse(dto.getStartDate());
		Date currentStartDate = new Date(dateTemp.getTime());
		String ownerPropertyIds = "";
		String tenantPropertyIds = "";
		boolean flag = true;
		if (existingActiveAssociation != null && existingActiveAssociation.size() > 0) {
			for (PropertyAccountAssociation existingAssociation : existingActiveAssociation) {
				historyService.updatePropertyAccountAssociationHistory(existingAssociation, username);
				existingAssociation.setMoveOutStatus("Pending");
				this.updateAudit(existingAssociation, username);
				existingAssociation.setEndDate(currentStartDate);
				if(flag) {
					if(existingAssociation.getAssociatedIds()== null || existingAssociation.getAssociatedIds().equals("") || existingAssociation.getAssociatedIds().isEmpty()) {
						ownerPropertyIds = existingAssociation.getAssociationId() + "";
						flag = false;
					}else {
						ownerPropertyIds = existingAssociation.getAssociatedIds() + "," + existingAssociation.getAssociationId();
						flag = false;
					}
				}
				else
					ownerPropertyIds = ownerPropertyIds + "," + existingAssociation.getAssociatedIds() + ","
						+ existingAssociation.getAssociationId();
			}
		} else {
			newOwner = true;
		}

		if (dto.getTenant() == 0) {
			List<PropertyAccountAssociation> existingActiveTenant = repository
					.getActiveOrInprogressOwnerToProperty(dto.getPropertyId(), "tenant");
			flag = true;
			if (existingActiveTenant != null && existingActiveTenant.size() > 0) {
				for (PropertyAccountAssociation tenantAssociation : existingActiveTenant) {
					historyService.updatePropertyAccountAssociationHistory(tenantAssociation, username);
					tenantAssociation.setMoveOutStatus("Pending");
					this.updateAudit(tenantAssociation, username);
					tenantAssociation.setEndDate(currentStartDate);
					if(flag) {
						if(tenantAssociation.getAssociatedIds()== null || tenantAssociation.getAssociatedIds().equals("") || tenantAssociation.getAssociatedIds().isEmpty()) {
							tenantPropertyIds = tenantAssociation.getAssociationId() + "";
							flag = false;
						}else {
							tenantPropertyIds = tenantAssociation.getAssociatedIds() + "," + tenantAssociation.getAssociationId();
							flag = false;
						}
					}
					else {
						tenantPropertyIds = tenantPropertyIds + ",";
						if(tenantAssociation.getAssociatedIds() != null && !tenantAssociation.getAssociatedIds().equals("") && !tenantAssociation.getAssociatedIds().isEmpty()) {
							tenantPropertyIds = tenantPropertyIds + tenantAssociation.getAssociatedIds() + "," + tenantAssociation.getAssociationId();
						}else {
							tenantPropertyIds = tenantPropertyIds + tenantAssociation.getAssociationId();
						}
					}
				}
			} else {
				newTenant = true;
			}
		}
		PropertyAccountAssociation association = new PropertyAccountAssociation();
		association.setAccount(account);
		association.setProperty(property);
		association.setTenureType("owner");
		association.setDeleted(false);
		if (newOwner)
			association.setMoveInStatus("Completed");
		else
			association.setMoveInStatus("Pending");
		association.setStartDate(currentStartDate);
		this.updateAudit(association, username);
		association.setAssociatedIds(ownerPropertyIds);
		repository.saveAndFlush(association);
		if (dto.getTenant() == 0) {
			PropertyAccountAssociation tenantAssociation = new PropertyAccountAssociation();
			tenantAssociation.setAccount(account);
			tenantAssociation.setProperty(property);
			tenantAssociation.setTenureType("tenant");
			if (newTenant)
				tenantAssociation.setMoveInStatus("Completed");
			else
				tenantAssociation.setMoveInStatus("Pending");
			tenantAssociation.setDeleted(false);
			tenantAssociation.setStartDate(currentStartDate);
			this.updateAudit(tenantAssociation, username);
			tenantAssociation.setAssociatedIds(tenantPropertyIds);
			repository.saveAndFlush(tenantAssociation);
		}
		return "Success";
	}

	/*public String updatePropertyAccountAssociationForOwner(PropertyAccountAssociationLimitedDto dto, String username)
			throws ParseException {

		boolean newOwner = false, newTenant = false;
		String validationResult = this.validateInputForAccountAssociation(dto);
		if (!validationResult.equalsIgnoreCase("Success"))
			return validationResult;

		Account account = accountRepository.findOne(dto.getAccountId());
		if (account == null)
			return "Invalid Account";

		Property property = propertyRepository.findOne(dto.getPropertyId());
		if (property == null)
			return "Invalid Property";

		List<PropertyAccountAssociation> existingActiveAssociation = repository
				.findExistingPropertyOwnerAssociation(dto.getPropertyId(), "owner");
		java.util.Date dateTemp = new SimpleDateFormat("dd/MM/yyyy").parse(dto.getStartDate());
		Date currentStartDate = new Date(dateTemp.getTime());

		if (existingActiveAssociation != null && existingActiveAssociation.size() > 0) {
			for (PropertyAccountAssociation existingAssociation : existingActiveAssociation) {
				if (existingAssociation.getMoveOutStatus() == null) {
					historyService.updatePropertyAccountAssociationHistory(existingAssociation, username);
					existingAssociation.setMoveOutStatus("Pending");
					this.updateAudit(existingAssociation, username);
				}
			}
		} else {
			newOwner = true;
		}
		if (dto.getTenant() == 0) {
			List<PropertyAccountAssociation> existingActiveTenant = repository
					.findExistingPropertyOwnerAssociation(dto.getPropertyId(), "tenant");
			if (existingActiveTenant != null && existingActiveTenant.size() > 0) {
				for (PropertyAccountAssociation tenantAssociation : existingActiveTenant) {
					if (tenantAssociation.getMoveOutStatus() == null) {
						historyService.updatePropertyAccountAssociationHistory(tenantAssociation, username);
						tenantAssociation.setMoveOutStatus("Pending");
						this.updateAudit(tenantAssociation, username);
					}
				}
			} else {
				newTenant = true;
			}
		}
		PropertyAccountAssociation association = new PropertyAccountAssociation();
		association.setAccount(account);
		association.setProperty(property);
		association.setTenureType("owner");
		association.setDeleted(false);
		if (newOwner)
			association.setMoveInStatus("Completed");
		else
			association.setMoveInStatus("Pending");
		association.setStartDate(currentStartDate);
		this.updateAudit(association, username);
		repository.saveAndFlush(association);
		if (dto.getTenant() == 0) {
			PropertyAccountAssociation tenantAssociation = new PropertyAccountAssociation();
			tenantAssociation.setAccount(account);
			tenantAssociation.setProperty(property);
			tenantAssociation.setTenureType("tenant");
			if (newTenant)
				tenantAssociation.setMoveInStatus("Completed");
			else
				tenantAssociation.setMoveInStatus("Pending");
			tenantAssociation.setDeleted(false);
			tenantAssociation.setStartDate(currentStartDate);
			this.updateAudit(tenantAssociation, username);
			repository.saveAndFlush(tenantAssociation);
		}
		return "Success";
	}*/

	public MyDate getLastOwnerAccountAssociationDate(Long propertyId, boolean isProperty) throws ParseException {
		MyDate date = new MyDate();
		String dateString = null;
		if (isProperty)
			dateString = repository.getLastOwnerAccountAssociationDate(propertyId);
		else
			dateString = repository.getLastOwnerForAssociation(propertyId);
		if (dateString != null) {
			String dateFields[] = dateString.split("/");
			date.setYear(Integer.parseInt(dateFields[2]));
			date.setMonth(Integer.parseInt(dateFields[1]));
			date.setDay(Integer.parseInt(dateFields[0]));
		}
		return date;
	}

	public List<PropertyAccountAssociationLimitedDto> getAllAccountsForProperty(long propertyId, String tenureType) {
		List<PropertyAccountAssociationLimitedDto> resultList = new ArrayList<>();
		List<PropertyAccountAssociation> associations = repository.findAllOwnersForProperty(propertyId, tenureType);
		for (PropertyAccountAssociation association : associations) {
			PropertyAccountAssociationLimitedDto dto = new PropertyAccountAssociationLimitedDto();
			dto.setAssociationId(association.getAssociationId());
			if (association.getAccount() != null) {
				dto.setAccountId(association.getAccount().getAccountId());
				List<BillablePerson> billablePerson = association.getAccount().getBillablePerson();
				if (billablePerson != null && billablePerson.size() > 0) {
					BillablePerson person = billablePerson.get(0);
					String name = person.getFirstName() + " " + person.getLastName();
					dto.setAccountName(name);
				}
				dto.setStartDate(association.getStartDate().toString());
				dto.setEndDate(association.getEndDate() != null ? association.getEndDate().toString() : null);
				if (!association.getMoveInStatus().equalsIgnoreCase("Completed")) {
					dto.setDelete(1);
				} else {
					dto.setDelete(0);
				}
			}
			resultList.add(dto);
		}
		return resultList;
	}

	public void updateAssociationStatusToDeleted(long associationId, String username) throws Exception {
		PropertyAccountAssociation association = repository.findOne(associationId);
		if(association == null)
			throw new Exception("Invalid data: No such association");
		int count = repository.checkForExistingAssociations(association.getProperty().getPropertyId(), association.getTenureType(), associationId);
		if(count <= 0) {
			String associationIds = association.getAssociatedIds();
			String[] asIds = associationIds.split(",");
			for(int i=(asIds.length-1); i>=0; i--) {
				try {
					String associationID = asIds[i];
					PropertyAccountAssociation temp = repository.findOne(Long.parseLong(associationID));
					if(!temp.isDeleted())
					{
						if(temp.getMoveOutStatus() != null && !temp.getMoveOutStatus().equalsIgnoreCase("Completed")) {
							temp.setMoveOutStatus(null);
							temp.setEndDate(null);
						}
						break;
					}
				}catch(Exception ex) {
					throw new Exception("Invalid data reference: No such association");
				}
			}
		}
		historyService.updatePropertyAccountAssociationHistory(association, username);
		association.setDeleted(true);
		updateAudit(association, username);
	}

	public AccountBalanceDto getAccountBalanceForAccountId(long accountId) {
		AccountBalanceDto dto = new AccountBalanceDto();
		AccountBalance entity = accountBalanceRepository.findByAccountId(accountId);
		if (entity != null) {
			dto.setAccountId(accountId);
			dto.setBalance(entity.getBalance());
		}
		return dto;
	}

	@Override
	public void updateAudit(PropertyAccountAssociation entity, String username) {
		if (entity != null) {
			Calendar cal = Calendar.getInstance();
			if (entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			} else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}
	}

}