package com.monarch.mabdeck.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.BankDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Bank;
import com.monarch.mabdeck.mapper.BankMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.repository.BankRepository;

@Component
public class BankService extends CommonServiceImpl<BankDto, Bank> {
	
	private Logger logger = LoggerFactory.getLogger(BankService.class);
	
	@Resource
	private BankRepository repository;

	@Override
	public JpaRepository<Bank, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<BankDto, Bank> getMapper() {
		return BankMapper.INSTANCE;
	}
	
	@Override
	public void updateAudit(Bank entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
			}else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}

}
