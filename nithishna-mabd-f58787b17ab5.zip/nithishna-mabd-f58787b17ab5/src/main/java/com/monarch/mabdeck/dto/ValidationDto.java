package com.monarch.mabdeck.dto;

import java.util.List;

public class ValidationDto implements IDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long validId;
	private TempDifferenceValidationDto tempValidation;
	private List<NegativeConsumptionValidationDto> negativeValidation;
	
	private ZeroConsumptionValidationDto zeroConsumptionValidation;
	private ClientDto client;
	private NetworkDto network;	
	private String emailNotification;

	public long getValidId() {
		return validId;
	}

	public TempDifferenceValidationDto getTempValidation() {
		return tempValidation;
	}

	public List<NegativeConsumptionValidationDto> getNegativeValidation() {
		return negativeValidation;
	}

	public ZeroConsumptionValidationDto getZeroConsumptionValidation() {
		return zeroConsumptionValidation;
	}

	public String getEmailNotification() {
		return emailNotification;
	}

	public void setValidId(long validId) {
		this.validId = validId;
	}

	public void setTempValidation(TempDifferenceValidationDto tempValidation) {
		this.tempValidation = tempValidation;
	}

	public void setNegativeValidation(List<NegativeConsumptionValidationDto> negativeValidation) {
		this.negativeValidation = negativeValidation;
	}

	public void setZeroConsumptionValidation(ZeroConsumptionValidationDto zeroConsumptionValidation) {
		this.zeroConsumptionValidation = zeroConsumptionValidation;
	}

	public void setEmailNotification(String emailNotification) {
		this.emailNotification = emailNotification;
	}

	public ClientDto getClient() {
		return client;
	}

	public NetworkDto getNetwork() {
		return network;
	}

	public void setClient(ClientDto client) {
		this.client = client;
	}

	public void setNetwork(NetworkDto network) {
		this.network = network;
	}
}
