package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.BandDto;
import com.monarch.mabdeck.entity.Band;

@Mapper
public abstract class BandMapper implements IBaseMapper<BandDto, Band>{
	public static final BandMapper INSTANCE = Mappers.getMapper(BandMapper.class);
	
	@Mappings({
		@Mapping(target = "property", ignore = true),
		@Mapping(target = "network", ignore = true),
		@Mapping(target = "client", ignore = true),
		@Mapping(target = "adminCharge", ignore = true),
		@Mapping(target = "tariff", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract Band convertToEntity(BandDto dto);
	
	
	@Mappings({
		@Mapping(target = "property", ignore = true),
		@Mapping(target = "network", ignore = true),
		@Mapping(target = "client", ignore = true),
		@Mapping(target = "adminCharge", ignore = true),
		@Mapping(target = "tariff", ignore = true)
	})
	public abstract BandDto convertToDTO(Band entity);
	
}
