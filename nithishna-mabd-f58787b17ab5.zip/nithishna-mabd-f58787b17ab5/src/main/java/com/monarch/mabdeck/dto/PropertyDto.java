package com.monarch.mabdeck.dto;

import java.sql.Date;
import java.util.List;

public class PropertyDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long propertyId;
	private ClientDto client;
	private NetworkDto network;
	private BandDto band;
	private String reference;
	private String area;
	private AddressDto address;
	private String name;
	private List<SupplyPointDto> supply;
	private List<HubDto> hub;
	private int noOfMeters;
	
	private float perDayUsage;
	private Date lastBilledDate;
	
	public long getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(long propertyId) {
		this.propertyId = propertyId;
	}
	public ClientDto getClient() {
		return client;
	}
	public void setClient(ClientDto client) {
		this.client = client;
	}
	public NetworkDto getNetwork() {
		return network;
	}
	public void setNetwork(NetworkDto network) {
		this.network = network;
	}
	public BandDto getBand() {
		return band;
	}
	public void setBand(BandDto band) {
		this.band = band;
	}
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public AddressDto getAddress() {
		return address;
	}
	public void setAddress(AddressDto address) {
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<SupplyPointDto> getSupply() {
		return supply;
	}
	public void setSupply(List<SupplyPointDto> supply) {
		this.supply = supply;
	}
	public int getNoOfMeters() {
		return noOfMeters;
	}
	public void setNoOfMeters(int noOfMeters) {
		this.noOfMeters = noOfMeters;
	}
	public List<HubDto> getHub() {
		return hub;
	}
	public void setHub(List<HubDto> hub) {
		this.hub = hub;
	}
	public float getPerDayUsage() {
		return perDayUsage;
	}
	public Date getLastBilledDate() {
		return lastBilledDate;
	}
	public void setPerDayUsage(float perDayUsage) {
		this.perDayUsage = perDayUsage;
	}
	public void setLastBilledDate(Date lastBilledDate) {
		this.lastBilledDate = lastBilledDate;
	}
}
