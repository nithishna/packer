package com.monarch.mabdeck.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;

import org.apache.poi.util.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Account;
import com.monarch.mabdeck.repository.AccountRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.util.Constants;

@Component
public class PaymentService {

	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	NetworkRepository networkRepository;
	
	public byte[] downloadTemplate(Long networkId, Long transactionTypeId, Long paymentMethodId) throws IOException {
		File tempFile = new File("template.csv");
        PrintWriter pw = new PrintWriter(tempFile);
        StringBuilder sb = new StringBuilder();
        this.populateHeading(sb);
        List<Account> accounts = accountRepository.fetchAllAccountByNetworkId(networkId);
        String networkName = networkRepository.getNetworkNameById(networkId);
        for(Account account : accounts) {
        	this.populateRow(networkId, networkName, transactionTypeId, paymentMethodId,sb, account);
        }
        pw.write(sb.toString());
        pw.close();
        InputStream stream = new FileInputStream("template.csv");
		byte[] result = IOUtils.toByteArray(stream);
		stream.close();
		tempFile.delete();
		return result;        
	}	
		
	private void populateHeading(StringBuilder sb) {						
		sb.append("TransactionTypeId").append(",");
		sb.append("TransactionType").append(",");
		sb.append("PaymentMethodId").append(",");
		sb.append("PaymentMethod").append(",");
		sb.append("AccountId").append(",");
		sb.append("AccountReference").append(",");
		sb.append("NetAmount").append(",");
		sb.append("VatRate").append(",");
		sb.append("VatAmount").append(",");
		sb.append("GrossAmount").append(",");
		sb.append("ProcessedDateTime").append(",");
		sb.append("Description");
		sb.append("\n");
	}
	
	private void populateRow(Long networkId, String networkName, Long transactionTypeId, Long paymentMethodId, StringBuilder sb, Account account) {
		sb.append(transactionTypeId).append(",");
		sb.append(Constants.transactionMap.get(transactionTypeId)).append(",");
		sb.append(paymentMethodId).append(",");		
		sb.append(Constants.paymentMap.get(paymentMethodId)).append(",");
		sb.append(account.getAccountId()).append(",");
		sb.append(account.getAccountNumber()).append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append("");
		sb.append("\n");
	}
}
