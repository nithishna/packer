package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Schedule implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long scheduleId;
	private String recursionType;
	private int period;
	private long offset;
	private long recursionOffset;
	private long hour;
	private long minute;
	private String emailIds;
	
	@Embedded
	private Audit audit;
	public String getRecursionType() {
		return recursionType;
	}
	public int getPeriod() {
		return period;
	}
	public String getEmailIds() {
		return emailIds;
	}
	public void setRecursionType(String recursionType) {
		this.recursionType = recursionType;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public void setEmailIds(String emailIds) {
		this.emailIds = emailIds;
	}
	public long getOffset() {
		return offset;
	}
	public void setOffset(long offset) {
		this.offset = offset;
	}
	public long getScheduleId() {
		return scheduleId;
	}
	public void setScheduleId(long scheduleId) {
		this.scheduleId = scheduleId;
	}
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public long getRecursionOffset() {
		return recursionOffset;
	}
	public void setRecursionOffset(long recursionOffset) {
		this.recursionOffset = recursionOffset;
	}
	public long getHour() {
		return hour;
	}
	public long getMinute() {
		return minute;
	}
	public void setHour(long hour) {
		this.hour = hour;
	}
	public void setMinute(long minute) {
		this.minute = minute;
	}
}
