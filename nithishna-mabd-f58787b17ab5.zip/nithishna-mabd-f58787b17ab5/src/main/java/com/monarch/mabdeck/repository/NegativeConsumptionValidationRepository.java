package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.NegativeConsumptionValidation;

@Repository
public interface NegativeConsumptionValidationRepository extends JpaRepository<NegativeConsumptionValidation, Long> {

	List<NegativeConsumptionValidation> findByValidationId(long validationId);
}
