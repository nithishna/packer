package com.monarch.mabdeck.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class SupplyPoint implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long supplyId;
	private String supplyType;
	private String weightFactor;
	private String technicalFactor;
	private String location;
	@ManyToOne(targetEntity = Client.class, fetch = FetchType.EAGER)
	@JoinColumn(name="clientId",referencedColumnName="clientId", insertable = true, updatable = true)
	private Client client;
	
	@ManyToOne(targetEntity = Network.class, fetch = FetchType.EAGER)
	@JoinColumn(name="networkId",referencedColumnName="networkId", insertable = true, updatable = true)
	private Network network;
	
	@ManyToOne(targetEntity = Property.class, fetch = FetchType.EAGER)
	@JoinColumn(name="propertyId",referencedColumnName="propertyId", insertable = true, updatable = true)
	private Property property;
	
	@OneToMany(mappedBy = "supply")
	private List<Meter> meter;
	
	private Date startDate;
	private Date endDate;
	
	@Embedded
	private Audit audit;
	
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public Network getNetwork() {
		return network;
	}
	public void setNetwork(Network network) {
		this.network = network;
	}
	public Property getProperty() {
		return property;
	}
	public void setProperty(Property property) {
		this.property = property;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getSupplyType() {
		return supplyType;
	}
	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}
	public String getWeightFactor() {
		return weightFactor;
	}
	public void setWeightFactor(String weightFactor) {
		this.weightFactor = weightFactor;
	}
	public String getTechnicalFactor() {
		return technicalFactor;
	}
	public void setTechnicalFactor(String technicalFactor) {
		this.technicalFactor = technicalFactor;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Long getSupplyId() {
		return supplyId;
	}
	public void setSupplyId(Long supplyId) {
		this.supplyId = supplyId;
	}
	public List<Meter> getMeter() {
		return meter;
	}
	public void setMeter(List<Meter> meter) {
		this.meter = meter;
	}
}
