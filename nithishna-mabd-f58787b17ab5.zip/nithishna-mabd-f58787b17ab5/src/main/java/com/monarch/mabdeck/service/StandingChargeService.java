package com.monarch.mabdeck.service;

import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.StandingChargeDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.StandingCharge;
import com.monarch.mabdeck.entity.Tariff;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.StandingChargeMapper;
import com.monarch.mabdeck.repository.StandingChargeRepository;
import com.monarch.mabdeck.repository.TariffRepository;

@Component
public class StandingChargeService extends CommonServiceImpl<StandingChargeDto, StandingCharge>{
	
	private Logger logger = LoggerFactory.getLogger(StandingChargeService.class);
	
	@Resource
	private StandingChargeRepository repository;
	
	@Resource
	private TariffRepository tariffRepository;
	
	@Override
	public JpaRepository<StandingCharge, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<StandingChargeDto, StandingCharge> getMapper() {
		return StandingChargeMapper.INSTANCE;
	}
	
	@Override
	public void updateAudit(StandingCharge entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
			}else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
	
	public StandingChargeDto create(StandingChargeDto dto, String username) {
		StandingCharge entity = getMapper().convertToEntity(dto);
		updateAudit(entity, username);
		if(dto.getTariff() != null) {
			Tariff tariff = tariffRepository.findOne(dto.getTariff().getTariffId());
			entity.setTariff(tariff);
		}
		repository.saveAndFlush(entity);
		return dto;
	}
}