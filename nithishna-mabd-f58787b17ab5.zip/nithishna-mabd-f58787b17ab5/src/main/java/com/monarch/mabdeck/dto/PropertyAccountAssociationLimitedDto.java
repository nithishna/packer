package com.monarch.mabdeck.dto;

public class PropertyAccountAssociationLimitedDto implements IDto{

	/**
	 */
	private static final long serialVersionUID = 1L;

	private long associationId;
	private long propertyId;
	private long accountId;
	private String startDate;
	private String endDate;
	private String accountName;
	private long tenant;
	private long owner;
	private int delete;
	public long getPropertyId() {
		return propertyId;
	}
	public long getAccountId() {
		return accountId;
	}
	public String getStartDate() {
		return startDate;
	}
	public long getTenant() {
		return tenant;
	}
	public long getOwner() {
		return owner;
	}
	public void setPropertyId(long propertyId) {
		this.propertyId = propertyId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public void setTenant(long tenant) {
		this.tenant = tenant;
	}
	public void setOwner(long owner) {
		this.owner = owner;
	}
	public int getDelete() {
		return delete;
	}
	public void setDelete(int delete) {
		this.delete = delete;
	}
	public String getEndDate() {
		return endDate;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public long getAssociationId() {
		return associationId;
	}
	public void setAssociationId(long associationId) {
		this.associationId = associationId;
	}
}
