package com.monarch.mabdeck.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.SupplyPointDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.Property;
import com.monarch.mabdeck.entity.SupplyPoint;
import com.monarch.mabdeck.history.service.SupplyPointHistoryService;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.SupplyPointMapper;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.repository.PropertyRepository;
import com.monarch.mabdeck.repository.SupplyPointRepository;
import com.monarch.mabdeck.util.Constants;

@Component
public class SupplyPointService extends CommonServiceImpl<SupplyPointDto, SupplyPoint> {

	private Logger logger = LoggerFactory.getLogger(SupplyPointService.class);

	@Resource
	private SupplyPointRepository repository;

	@Resource
	private PropertyRepository propertyRepository;

	@Resource
	private ClientRepository clientRepository;

	@Resource
	private NetworkRepository networkRepository;
	
	@Autowired
	private SupplyPointHistoryService historyService;

	@Override
	public JpaRepository<SupplyPoint, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<SupplyPointDto, SupplyPoint> getMapper() {
		return SupplyPointMapper.INSTANCE;
	}
	
	@Override
	public void updateAudit(SupplyPoint entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			}else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}

	@Override
	public SupplyPointDto create(SupplyPointDto dto, String username) {
		SupplyPoint supplyPoint = this.getMapper().convertToEntity(dto);
		updateAudit(supplyPoint, username);
		if (dto.getClient() != null && dto.getClient().getClientId() > 0) {
			Client client = clientRepository.findOne(dto.getClient().getClientId());
			supplyPoint.setClient(client);
		} else {
			supplyPoint.setClient(null);
		}
		if (dto.getNetwork() != null && dto.getNetwork().getNetworkId() > 0) {
			Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
			supplyPoint.setNetwork(network);
		} else {
			supplyPoint.setNetwork(null);
		}
		if (dto.getProperty() != null && dto.getProperty().getPropertyId() > 0) {
			Property property = propertyRepository.findOne(dto.getProperty().getPropertyId());
			supplyPoint.setProperty(property);
		} else {
			supplyPoint.setProperty(null);
		}
		repository.saveAndFlush(supplyPoint);
		return dto;
	}

	public SupplyPointDto update(SupplyPointDto dto, String username) {
		if (dto != null && dto.getSupplyId() != null) {
			SupplyPoint supplyPoint = repository.findOne(dto.getSupplyId());
			updateAudit(supplyPoint, username);
			historyService.updateSupplyPointHistory(supplyPoint, username);
			SupplyPoint newEntity = this.getMapper().convertToEntity(dto);
			if (supplyPoint != null) {
				if (dto.getClient() != null && dto.getClient().getClientId() > 0) {
					Client client = clientRepository.findOne(dto.getClient().getClientId());
					supplyPoint.setClient(client);
				} else {
					supplyPoint.setClient(null);
				}
				if (dto.getNetwork() != null && dto.getNetwork().getNetworkId() > 0) {
					Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
					supplyPoint.setNetwork(network);
				} else {
					supplyPoint.setNetwork(null);
				}
				if (dto.getProperty() != null && dto.getProperty().getPropertyId() > 0) {
					Property property = propertyRepository.findOne(dto.getProperty().getPropertyId());
					supplyPoint.setProperty(property);
				} else {
					supplyPoint.setProperty(null);
				}
				supplyPoint.setStartDate(newEntity.getStartDate());
				supplyPoint.setEndDate(newEntity.getEndDate());
				supplyPoint.setLocation(newEntity.getLocation());
				supplyPoint.setSupplyType(newEntity.getSupplyType());
				supplyPoint.setTechnicalFactor(newEntity.getTechnicalFactor());
				supplyPoint.setWeightFactor(newEntity.getWeightFactor());
			}
		}
		return dto;
	}

	public List<SupplyPointDto> getSupplyPointTypes(Long clientId, Long networkId, Long propertyId) {
		List<SupplyPoint> entities = this.repository.getSupplyPoint(clientId, networkId, propertyId);
		List<SupplyPointDto> dtos = new ArrayList<>();
		for (SupplyPoint entity : entities) {
			SupplyPointDto dto = new SupplyPointDto();
			dto.setSupplyId(entity.getSupplyId());
			dto.setSupplyType(entity.getSupplyType());
			dtos.add(dto);
		}
		return dtos;
	}

	public List<SupplyPointDto> getSupplyPointTypesByNetworkAndClient(Long clientId, Long networkId) {
		List<SupplyPoint> entities = this.repository.getSupplyPointByClientAndNetwork(clientId, networkId);
		List<SupplyPointDto> dtos = new ArrayList<>();
		Set<String> supplyTypes = new HashSet<>();
		entities.forEach(p -> supplyTypes.add(p.getSupplyType()));
		for (String supplyType : supplyTypes) {
			SupplyPointDto dto = new SupplyPointDto();
			dto.setSupplyType(supplyType);
			for (Map.Entry<Long, String> entry : Constants.supplyTypeMap.entrySet()) {
				if (entry.getValue().equalsIgnoreCase(supplyType)) {
					dto.setSupplyId(entry.getKey());
					break;
				}
			}
			dtos.add(dto);
		}
		return dtos;
	}

	public byte[] downloadTemplate(Long clientId, Long networkId, Long bandId, Long supplyTypeId) throws IOException {
		File tempFile = new File("template.csv");
		PrintWriter pw = new PrintWriter(tempFile);
		StringBuilder sb = new StringBuilder();
		this.populateHeading(sb);
		this.populateRow(clientId, networkId, bandId, supplyTypeId, sb);
		pw.write(sb.toString());
		pw.close();
		InputStream stream = new FileInputStream("template.csv");
		byte[] result = IOUtils.toByteArray(stream);
		stream.close();
		logger.debug("File deletion status : " + (tempFile.delete() ? "Success" : "Failure"));
		return result;
	}

	private void populateHeading(StringBuilder sb) {
		sb.append("PropertyId").append(",");
		sb.append("PropertyAddress").append(",");
		sb.append("SupplyTypeId").append(",");
		sb.append("SupplyType").append(",");
		sb.append("Location").append(",");
		sb.append("WeightFactor").append(",");
		sb.append("TechnicalFactor").append(",");
		sb.append("StartDate").append(",");
		sb.append("EndDate").append("\n");
	}

	private void populateRow(Long clientId, Long networkId, Long bandId, Long supplyTypeId, StringBuilder sb) {
		List<Property> properties = propertyRepository.fetchAllPropertiesByClientAndNetworkAndBand(clientId, networkId,
				bandId);
		for (Property property : properties) {
			sb.append(property.getPropertyId()).append(",");
			if (property.getAddress() != null) {
				sb.append(
						property.getAddress().getAddressLine1() != null ? property.getAddress().getAddressLine1() + " "
								: "");
				sb.append(property.getAddress().getAddressLine2());
				sb.append(",");
			} else {
				sb.append("").append(",");
			}
			sb.append(supplyTypeId).append(",");
			sb.append(Constants.supplyTypeMap.get(supplyTypeId)).append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append(Constants.REQUIRED).append(",");
			sb.append("").append("\n");
		}
	}

	public byte[] uploadCSV(MultipartFile multipartFile) throws IOException {
		File file = null;
		byte[] result = null;
		try {
			file = convertMultiPartToFile(multipartFile);
			FileWriter csvWriter = new FileWriter("result.csv");
			Scanner scanner = new Scanner(file);
			boolean headingValidation = false;
			while (scanner.hasNextLine()) {
				if (!headingValidation) {
					headingValidation = validateHeading(scanner.nextLine());
					if (!headingValidation) {
						scanner.close();
						throw new IOException("Kindly check the heading order");
					}
					for(String value : Constants.supplyPointHeading) {
						csvWriter.append(value);
						csvWriter.append(",");
					}
					csvWriter.append("Message").append("\n");
				} else
					getRecordFromLine(scanner.nextLine(), csvWriter);
			}
			scanner.close();
			csvWriter.flush();
			csvWriter.close();
			InputStream stream = new FileInputStream("result.csv");
			result = IOUtils.toByteArray(stream);
			stream.close();			
			if (file != null)
				logger.debug(file.delete() ? "Temp File Deleted successfully" : "Temp File could not be deleted");
			File resultFile = new File("result.csv");
			resultFile.delete();
		} catch (Exception ex) {
			if(file!= null)
				logger.debug(file.delete()? "Temp File Deleted successfully":"Temp File could not be deleted");
			throw new IOException("Unable to parse the file. Kindly raise a support request and get this sorted");
		}
		return result;
	}
	
	public long getCount() {
		return repository.getCount();
	}

	private boolean validateHeading(String line) {
		List<String> heading = Constants.supplyPointHeading;
		Iterator<String> iterator = heading.iterator();
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			while (rowScanner.hasNext()) {
				if (!iterator.next().equalsIgnoreCase(rowScanner.next())) {
					return false;
				}
			}
		}
		return true;
	}

	private void getRecordFromLine(String line, FileWriter csvWriter) throws IOException {
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			SupplyPoint supplyPoint = new SupplyPoint();
			if (rowScanner.hasNext()) {
				long propertyId = rowScanner.nextLong();
				Property property = propertyRepository.findOne(propertyId);
				if (property == null)
					throw new IOException(
							"Property details are mandatory. Please enter the Property details and try again.");
				supplyPoint.setProperty(property);
				logger.debug("Property name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
				Client client = property.getClient();
				supplyPoint.setClient(client);
				Network network = property.getNetwork();
				supplyPoint.setNetwork(network);
			}
			logger.debug("Supply type Id: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			supplyPoint.setSupplyType((rowScanner.hasNext() ? rowScanner.next() : null));
			supplyPoint.setLocation((rowScanner.hasNext() ? rowScanner.next() : null));
			supplyPoint.setWeightFactor((rowScanner.hasNext() ? rowScanner.next() : null));
			supplyPoint.setTechnicalFactor((rowScanner.hasNext() ? rowScanner.next() : null));
			if (rowScanner.hasNext()) {
				Date date = null;
				try {
					date = new SimpleDateFormat("dd/MM/yyyy").parse(rowScanner.next());
				} catch (Exception ex) {
					throw new IOException(
							"Issue in the data!.....Kindly specify start date in dd/MM/YYYY format and try again");
				}
				if (date != null)
					supplyPoint.setStartDate(new java.sql.Date(date.getTime()));
				else
					throw new IOException("Start Date time cannot be empty....Kindly update the excel and try again");
			}
			if (rowScanner.hasNext()) {
				Date date = null;
				try {
					date = new SimpleDateFormat("dd/MM/yyyy").parse(rowScanner.next());
				} catch (Exception ex) {
					throw new IOException(
							"Issue in the data!.....Kindly specify End date in dd/MM/YYYY format and try again");
				}
				if (date != null)
					supplyPoint.setEndDate(new java.sql.Date(date.getTime()));
			}
			this.updateAudit(supplyPoint, "Application\\Bulk upload");
			repository.saveAndFlush(supplyPoint);
			this.writeLine(line, csvWriter);
			csvWriter.append("Success");
			csvWriter.append("\n");

		} catch (Exception ex) {
			this.writeLine(line, csvWriter);
			csvWriter.append("Error: " + ex.getMessage());
			csvWriter.append("\n");
		}
	}

	private void writeLine(String line, FileWriter csvWriter) throws IOException {
		String[] values = line.split(",");
		for(String value : values) {
			csvWriter.append(value);
			csvWriter.append(",");
		}
		int extension = Constants.supplyPointHeading.size() - values.length;
		if(extension > 0) {
			for(int i=0; i<extension; i++) {
				csvWriter.append("");
				csvWriter.append(",");
			}
		}
	}
	
	private File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}
}