package com.monarch.mabdeck.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Tariff implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long tariffId;
	private String tariffType;
	private String supplyType;
	private String tariffName;
	private String tariffCode;
	private float vatRate;
	private Date activeFromDate;
	private Date activeToDate;
	private int deleted;
	
	@OneToMany(mappedBy="tariff")
	private List<UnitCharge> unitCharge;
	
	@OneToMany(mappedBy="tariff")
	private List<StandingCharge> standingCharge;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "property_id")
	private PropertyAreaCharge propertyAreaCharge;
	
	@ManyToOne(targetEntity = Band.class, fetch = FetchType.LAZY)
	@JoinColumn(name="bandId",referencedColumnName="bandId", insertable = true, updatable = true)
	private Band band;
	
	@Embedded
	private Audit audit;
	
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	
	public Long getTariffId() {
		return tariffId;
	}
	public void setTariffId(Long tariffId) {
		this.tariffId = tariffId;
	}
	public String getTariffType() {
		return tariffType;
	}
	public void setTariffType(String tariffType) {
		this.tariffType = tariffType;
	}
	public String getSupplyType() {
		return supplyType;
	}
	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}
	public String getTariffName() {
		return tariffName;
	}
	public void setTariffName(String tariffName) {
		this.tariffName = tariffName;
	}
	public String getTariffCode() {
		return tariffCode;
	}
	public void setTariffCode(String tariffCode) {
		this.tariffCode = tariffCode;
	}
	public float getVatRate() {
		return vatRate;
	}
	public void setVatRate(float vatRate) {
		this.vatRate = vatRate;
	}
	public Date getActiveFromDate() {
		return activeFromDate;
	}
	public void setActiveFromDate(Date activeFromDate) {
		this.activeFromDate = activeFromDate;
	}
	public Date getActiveToDate() {
		return activeToDate;
	}
	public void setActiveToDate(Date activeToDate) {
		this.activeToDate = activeToDate;
	}
	public List<UnitCharge> getUnitCharge() {
		return unitCharge;
	}
	public void setUnitCharge(List<UnitCharge> unitCharge) {
		this.unitCharge = unitCharge;
	}
	public List<StandingCharge> getStandingCharge() {
		return standingCharge;
	}
	public void setStandingCharge(List<StandingCharge> standingCharge) {
		this.standingCharge = standingCharge;
	}
	public Band getBand() {
		return band;
	}
	public void setBand(Band band) {
		this.band = band;
	}
	public PropertyAreaCharge getPropertyAreaCharge() {
		return propertyAreaCharge;
	}
	public void setPropertyAreaCharge(PropertyAreaCharge propertyAreaCharge) {
		this.propertyAreaCharge = propertyAreaCharge;
	}
	public int getDeleted() {
		return deleted;
	}
	public void setDeleted(int deleted) {
		this.deleted = deleted;
	}
}
