package com.monarch.mabdeck.dto;

public class StatementDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long statementId;
	private String billablePerson;
	private String client;
	private String network;
	private String propertyAddress;
	private String fromDate;
	private String toDate;
	private String generationDate;
	private double netAmount;
	private double vat;
	private double grossAmount;
	private String fileName;
	private long queueId;
	private String message;
	private boolean approved;
	private boolean deleted;
	public long getStatementId() {
		return statementId;
	}
	public String getBillablePerson() {
		return billablePerson;
	}
	public String getClient() {
		return client;
	}
	public String getNetwork() {
		return network;
	}
	public String getFromDate() {
		return fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public String getGenerationDate() {
		return generationDate;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public double getVat() {
		return vat;
	}
	public double getGrossAmount() {
		return grossAmount;
	}
	public String getFileName() {
		return fileName;
	}
	public void setStatementId(long statementId) {
		this.statementId = statementId;
	}
	public void setBillablePerson(String billablePerson) {
		this.billablePerson = billablePerson;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public void setGenerationDate(String generationDate) {
		this.generationDate = generationDate;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public void setVat(double vat) {
		this.vat = vat;
	}
	public void setGrossAmount(double grossAmount) {
		this.grossAmount = grossAmount;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getPropertyAddress() {
		return propertyAddress;
	}
	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	public long getQueueId() {
		return queueId;
	}
	public String getMessage() {
		return message;
	}
	public boolean isApproved() {
		return approved;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setQueueId(long queueId) {
		this.queueId = queueId;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	
}
