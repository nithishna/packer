package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class PropertyAreaCharge implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long propertyChargeId;
	
	private String name;
	private float pricePerUnit;
	private String areaUnits;
	
	@OneToOne(mappedBy = "propertyAreaCharge", fetch = FetchType.LAZY, optional = false)
	private Tariff tariff;
	
	@Embedded
	private Audit audit;
	
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Long getPropertyChargeId() {
		return propertyChargeId;
	}
	public void setPropertyChargeId(Long propertyChargeId) {
		this.propertyChargeId = propertyChargeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(float pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public String getAreaUnits() {
		return areaUnits;
	}
	public void setAreaUnits(String areaUnits) {
		this.areaUnits = areaUnits;
	}
	public Tariff getTariff() {
		return tariff;
	}
	public void setTariff(Tariff tariff) {
		this.tariff = tariff;
	}
}
