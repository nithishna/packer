package com.monarch.mabdeck.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.PropertyAccountAssociationHistory;

@Repository
public interface PropertyAccountAssociationHistoryRepository extends JpaRepository<PropertyAccountAssociationHistory, Long> {

}
