package com.monarch.mabdeck.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.AdminChargeDto;
import com.monarch.mabdeck.dto.BandDto;
import com.monarch.mabdeck.dto.ClientDto;
import com.monarch.mabdeck.dto.NetworkDto;
import com.monarch.mabdeck.dto.PropertyAreaChargeDto;
import com.monarch.mabdeck.dto.TariffDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Band;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.Tariff;
import com.monarch.mabdeck.history.service.BandHistoryService;
import com.monarch.mabdeck.mapper.AdminChargeMapper;
import com.monarch.mabdeck.mapper.BandMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.TariffMapper;
import com.monarch.mabdeck.repository.BandRepository;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.util.Constants;

import javassist.NotFoundException;

@Component
public class BandService extends CommonServiceImpl<BandDto, Band>{
	
	private Logger logger = LoggerFactory.getLogger(BandService.class);
	
	@Resource
	private BandRepository repository;
	
	@Resource
	private BandHistoryService historyService;
	
	@Resource
	private ClientRepository clientRepository;
	
	@Resource
	private NetworkRepository networkRepository;

	@Override
	public JpaRepository<Band, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<BandDto, Band> getMapper() {
		return BandMapper.INSTANCE;
	}
	
	@Override
	public void updateAudit(Band entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
			}else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
	
	@Override
	public BandDto create(BandDto dto, String username) {
		Band entity = getMapper().convertToEntity(dto);
		updateAudit(entity, username);
		if(entity != null){
			Client client = null;
			Network network = null;
			if(dto.getClient() != null)
				client = clientRepository.findOne(dto.getClient().getClientId());
			if(dto.getNetwork() != null)
				network = networkRepository.findOne(dto.getNetwork().getNetworkId());
			entity.setNetwork(network);
			entity.setClient(client);
			entity = getJPARepository().saveAndFlush(entity);
		}
		return getMapper().convertToDTO(entity);
	}
	
	public long getCount() {
		return repository.getCount();
	}
	
	public List<BandDto> readAllV2(int index, int noOfItems) throws NotFoundException {
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1)*noOfItems + 1;
		endIndex = index * noOfItems;
	
		List<Band> bandList = repository.getAllBandsV2(startIndex, endIndex);
		List<BandDto> bandDtoList = new ArrayList<>();
		TariffService tariffService = new TariffService();
		for(Band band : bandList) {
			BandDto bandDto = new BandDto();
			bandDto = getMapper().convertToDTO(band);
			NetworkDto networkDto = new NetworkDto();
			if(band.getNetwork()!= null) {
				Network network = networkRepository.getOne(band.getNetwork().getNetworkId());
				networkDto.setNetwork(network.getNetwork());
				networkDto.setNetworkId(network.getNetworkId());
			}
			bandDto.setNetwork(networkDto);
			
			ClientDto clientDto = null;			
			if(band.getClient() != null) {
				Client client = band.getClient();
				clientDto = new ClientDto();
				clientDto.setClientId(client.getClientId());
				clientDto.setClientName(client.getClientName());
			}
			bandDto.setClient(clientDto);
			List<TariffDto> tariffDtos = new ArrayList<>();
			if(band.getTariff() != null && band.getTariff().size()>0){				
				List<Tariff> tariffEntities = band.getTariff();
				for(Tariff tariffEntity : tariffEntities) {
					TariffDto tariffDto = null;
					if(tariffEntity!= null && tariffEntity.getDeleted()!=1 && tariffEntity.getActiveToDate()==null) {
						tariffDto = TariffMapper.INSTANCE.convertToDTO(tariffEntity);
						tariffDto.setUnitCharge(tariffService.getUnitCharge(tariffEntity.getUnitCharge()));
						tariffDto.setStandingCharge(tariffService.getStandingCharge(tariffEntity.getStandingCharge()));
						tariffDto.setSupplyType(Constants.supplyTypeMap.entrySet().stream().filter(e -> e.getValue().equals(tariffEntity.getSupplyType())).map(Map.Entry::getKey).findFirst().orElse(null));
						PropertyAreaChargeDto propertyAreaChargeDto = tariffService.getPropertyAreaCharge(tariffEntity.getPropertyAreaCharge());
						if(propertyAreaChargeDto != null) {
							List<PropertyAreaChargeDto> propertyAreaChargeDtoList = new ArrayList<>();
							propertyAreaChargeDtoList.add(propertyAreaChargeDto);
							tariffDto.setPropertyAreaCharge(propertyAreaChargeDtoList);
						}
					}else {
						continue;
					}
					tariffDtos.add(tariffDto);
				}
			}
			bandDto.setTariff(tariffDtos);
			bandDto.setNoOfTariffs(tariffDtos.size());
			List<AdminChargeDto> adminChargeDtos = new ArrayList<>();
			if(band.getAdminCharge() != null && band.getAdminCharge().size()>0) {
				adminChargeDtos = AdminChargeMapper.INSTANCE.convertToDTOList(band.getAdminCharge());
			}
			bandDto.setAdminCharge(adminChargeDtos);
			bandDtoList.add(bandDto);
		}
		return bandDtoList;
	}
	
	public List<BandDto> readAll() throws NotFoundException {
		List<Band> bandList = repository.findAll();
		List<BandDto> bandDtoList = new ArrayList<>();
		TariffService tariffService = new TariffService();
		for(Band band : bandList) {
			BandDto bandDto = new BandDto();
			bandDto = getMapper().convertToDTO(band);
			NetworkDto networkDto = new NetworkDto();
			if(band.getNetwork()!= null) {
				Network network = networkRepository.getOne(band.getNetwork().getNetworkId());
				networkDto.setNetwork(network.getNetwork());
				networkDto.setNetworkId(network.getNetworkId());
			}
			bandDto.setNetwork(networkDto);
			
			ClientDto clientDto = null;			
			if(band.getClient() != null) {
				Client client = band.getClient();
				clientDto = new ClientDto();
				clientDto.setClientId(client.getClientId());
				clientDto.setClientName(client.getClientName());
			}
			bandDto.setClient(clientDto);
			List<TariffDto> tariffDtos = new ArrayList<>();
			if(band.getTariff() != null && band.getTariff().size()>0){				
				List<Tariff> tariffEntities = band.getTariff();
				for(Tariff tariffEntity : tariffEntities) {
					TariffDto tariffDto = null;
					if(tariffEntity!= null && tariffEntity.getDeleted()!=1 && tariffEntity.getActiveToDate()==null) {
						tariffDto = TariffMapper.INSTANCE.convertToDTO(tariffEntity);
						tariffDto.setUnitCharge(tariffService.getUnitCharge(tariffEntity.getUnitCharge()));
						tariffDto.setStandingCharge(tariffService.getStandingCharge(tariffEntity.getStandingCharge()));
						tariffDto.setSupplyType(Constants.supplyTypeMap.entrySet().stream().filter(e -> e.getValue().equals(tariffEntity.getSupplyType())).map(Map.Entry::getKey).findFirst().orElse(null));
						PropertyAreaChargeDto propertyAreaChargeDto = tariffService.getPropertyAreaCharge(tariffEntity.getPropertyAreaCharge());
						if(propertyAreaChargeDto != null) {
							List<PropertyAreaChargeDto> propertyAreaChargeDtoList = new ArrayList<>();
							propertyAreaChargeDtoList.add(propertyAreaChargeDto);
							tariffDto.setPropertyAreaCharge(propertyAreaChargeDtoList);
						}
					}else {
						continue;
					}
					tariffDtos.add(tariffDto);
				}
			}
			bandDto.setTariff(tariffDtos);
			bandDto.setNoOfTariffs(tariffDtos.size());
			List<AdminChargeDto> adminChargeDtos = new ArrayList<>();
			if(band.getAdminCharge() != null && band.getAdminCharge().size()>0) {
				adminChargeDtos = AdminChargeMapper.INSTANCE.convertToDTOList(band.getAdminCharge());
			}
			bandDto.setAdminCharge(adminChargeDtos);
			bandDtoList.add(bandDto);
		}
		return bandDtoList;
	}
	
	public BandDto read(Long id) throws NotFoundException {
		BandDto dto = null;
		TariffService tariffService = new TariffService();
		Band entity = repository.findOne(id);
		dto = BandMapper.INSTANCE.convertToDTO(entity);
		List<TariffDto> tariffDtos = new ArrayList<>();
		if(entity.getTariff() != null && entity.getTariff().size() > 0) {
			List<Tariff> tariffEntities = entity.getTariff();
			for(Tariff tariffEntity : tariffEntities) {
				TariffDto tariffDto = null;
				if(tariffEntity!= null) {
					tariffDto = TariffMapper.INSTANCE.convertToDTO(tariffEntity);
					tariffDto.setUnitCharge(tariffService.getUnitCharge(tariffEntity.getUnitCharge()));
					tariffDto.setStandingCharge(tariffService.getStandingCharge(tariffEntity.getStandingCharge()));
					PropertyAreaChargeDto propertyAreaChargeDto = tariffService.getPropertyAreaCharge(tariffEntity.getPropertyAreaCharge());
					if(propertyAreaChargeDto != null) {
						List<PropertyAreaChargeDto> propertyAreaChargeDtoList = new ArrayList<>();
						propertyAreaChargeDtoList.add(propertyAreaChargeDto);
						tariffDto.setPropertyAreaCharge(propertyAreaChargeDtoList);
					}
				}else {
					continue;
				}
				tariffDtos.add(tariffDto);
			}
		}
		if(entity.getNetwork() != null) {
			Network network = entity.getNetwork();
			NetworkDto networkDto = new NetworkDto();
			networkDto.setNetworkId(network.getNetworkId());
			networkDto.setNetwork(network.getNetwork());
			dto.setNetwork(networkDto);
		}
		dto.setTariff(tariffDtos);
		return dto;
	}
	
	public List<BandDto> getAllBandForClientAndNetwork(Long clientId, Long networkId){
		List<Band> bandList = repository.fetchAllBandForNetworkAndClient(clientId, networkId);
		List<BandDto> bandDtoList = new ArrayList<>();
		if(bandList!=null && bandList.size()>0) {
			for(Band band : bandList) {
				BandDto dto = new BandDto();
				dto.setBandId(band.getBandId());
				dto.setBandName(band.getBandName());
				bandDtoList.add(dto);
			}
		}
		return bandDtoList;
	}
	
	public BandDto update(BandDto dto, String username) {
		Band existingEntity = repository.findOne(dto.getBandId());
		updateAudit(existingEntity, username);
		historyService.updateBandHistory(existingEntity, username);
		existingEntity.setBandName(dto.getBandName());
		if(dto.getClient() != null && dto.getClient().getClientId() > 0) {
			Client client = clientRepository.findOne(dto.getClient().getClientId());
			existingEntity.setClient(client);
		}
		
		if(dto.getNetwork() != null && dto.getNetwork().getNetworkId() != null) {
			Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
			existingEntity.setNetwork(network);
		}
		existingEntity.setBandType(dto.getBandType());
		existingEntity.setStartDate(dto.getStartDate());
		existingEntity.setEndDate(dto.getEndDate());
		existingEntity.setNumberOfBedroom(dto.getNumberOfBedroom());
		existingEntity.setPropertyPart1(dto.getPropertyPart1());
		existingEntity.setPropertyPart2(dto.getPropertyPart2());
		existingEntity.setPropertyUnit(dto.getPropertyUnit());
		return dto;
	}
}
