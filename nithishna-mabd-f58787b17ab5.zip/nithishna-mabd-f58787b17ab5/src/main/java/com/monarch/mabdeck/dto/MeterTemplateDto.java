package com.monarch.mabdeck.dto;

public class MeterTemplateDto implements IDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long clientId;
    private Long networkId;
    private Long supplyTypeId;
    private Long unitId;
    private Long meterUseId;
    private Long readingFrequencyId;
	public Long getClientId() {
		return clientId;
	}
	public Long getNetworkId() {
		return networkId;
	}
	public Long getSupplyTypeId() {
		return supplyTypeId;
	}
	public Long getUnitId() {
		return unitId;
	}
	public Long getReadingFrequencyId() {
		return readingFrequencyId;
	}
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}
	public void setSupplyTypeId(Long supplyTypeId) {
		this.supplyTypeId = supplyTypeId;
	}
	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}
	public void setReadingFrequencyId(Long readingFrequencyId) {
		this.readingFrequencyId = readingFrequencyId;
	}
	public Long getMeterUseId() {
		return meterUseId;
	}
	public void setMeterUseId(Long meterUseId) {
		this.meterUseId = meterUseId;
	}  
}
