package com.monarch.mabdeck.dto;

import java.sql.Date;

public class AdminChargeDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long adminChargeId;
	private String chargeTo;
	private String description;
	private float dailyCharge;
	private float vatRate;
	private Date activeFromDate;
	private Date activeToDate;
	private BandDto band;
	public Long getAdminChargeId() {
		return adminChargeId;
	}
	public void setAdminChargeId(Long adminChargeId) {
		this.adminChargeId = adminChargeId;
	}
	public String getChargeTo() {
		return chargeTo;
	}
	public void setChargeTo(String chargeTo) {
		this.chargeTo = chargeTo;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public float getDailyCharge() {
		return dailyCharge;
	}
	public void setDailyCharge(float dailyCharge) {
		this.dailyCharge = dailyCharge;
	}
	public float getVatRate() {
		return vatRate;
	}
	public void setVatRate(float vatRate) {
		this.vatRate = vatRate;
	}
	public Date getActiveFromDate() {
		return activeFromDate;
	}
	public void setActiveFromDate(Date activeFromDate) {
		this.activeFromDate = activeFromDate;
	}
	public Date getActiveToDate() {
		return activeToDate;
	}
	public void setActiveToDate(Date activeToDate) {
		this.activeToDate = activeToDate;
	}
	public BandDto getBand() {
		return band;
	}
	public void setBand(BandDto band) {
		this.band = band;
	}

}
