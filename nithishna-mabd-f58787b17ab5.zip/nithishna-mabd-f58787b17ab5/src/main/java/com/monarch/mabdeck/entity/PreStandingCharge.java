package com.monarch.mabdeck.entity;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class PreStandingCharge implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long standingChargeId;
	
	private String standingChargeName;
	private float standingCharge;
	private float totalStandingCharge;
	private long noOfDays;
	@Embedded
	private Audit audit;
	
	@ManyToOne(cascade = CascadeType.ALL, targetEntity = PreStatementEnergy.class, fetch = FetchType.EAGER)
	@JoinColumn(name="preStatementEnergyId",referencedColumnName="preStatementEnergyId", insertable = true, updatable = true)
	private PreStatementEnergy preStatement;
	
	public Long getStandingChargeId() {
		return standingChargeId;
	}
	public String getStandingChargeName() {
		return standingChargeName;
	}
	public float getStandingCharge() {
		return standingCharge;
	}
	public float getTotalStandingCharge() {
		return totalStandingCharge;
	}
	public long getNoOfDays() {
		return noOfDays;
	}
	public Audit getAudit() {
		return audit;
	}
	public void setStandingChargeId(Long standingChargeId) {
		this.standingChargeId = standingChargeId;
	}
	public void setStandingChargeName(String standingChargeName) {
		this.standingChargeName = standingChargeName;
	}
	public void setStandingCharge(float standingCharge) {
		this.standingCharge = standingCharge;
	}
	public void setTotalStandingCharge(float totalStandingCharge) {
		this.totalStandingCharge = totalStandingCharge;
	}
	public void setNoOfDays(long noOfDays) {
		this.noOfDays = noOfDays;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public PreStatementEnergy getPreStatement() {
		return preStatement;
	}
	public void setPreStatement(PreStatementEnergy preStatement) {
		this.preStatement = preStatement;
	}
}
