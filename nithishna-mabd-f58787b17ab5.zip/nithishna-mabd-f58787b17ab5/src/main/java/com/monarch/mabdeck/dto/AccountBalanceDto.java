package com.monarch.mabdeck.dto;

public class AccountBalanceDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long accountId;
	private double balance;
	public long getAccountId() {
		return accountId;
	}
	public double getBalance() {
		return balance;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
}
