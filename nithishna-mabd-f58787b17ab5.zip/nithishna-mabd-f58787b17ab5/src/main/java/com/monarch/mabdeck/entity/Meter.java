package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class Meter implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long meterId;
	private String unit;
	private String meterType;
	private String manufacturer;
	private String model;
	private String location;
	private String serialNumber;
	private boolean childMeter;
	private String parentSerialNumber;
	private int pulseInputNumber;
	private String readingFrequency;
	private String readingImportFactor;
	private String initialReading;
	private String offset;
	private boolean active;
	@ManyToOne(targetEntity = Client.class, fetch = FetchType.EAGER)
	@JoinColumn(name="clientId",referencedColumnName="clientId", insertable = true, updatable = true)
	private Client client;
	
	@ManyToOne(targetEntity = Network.class, fetch = FetchType.EAGER)
	@JoinColumn(name="networkId",referencedColumnName="networkId", insertable = true, updatable = true)
	private Network network;
	
	@ManyToOne(targetEntity = Property.class, fetch = FetchType.EAGER)
	@JoinColumn(name="propertyId",referencedColumnName="propertyId", insertable = true, updatable = true)
	private Property property;
	
	@ManyToOne(targetEntity = SupplyPoint.class, fetch = FetchType.EAGER)
	@JoinColumn(name="supplyId",referencedColumnName="supplyId", insertable = true, updatable = true)
	private SupplyPoint supply;
	
	private Date startDate;
	private Date endDate;
	
	@Embedded
	private Audit audit;
	
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public Network getNetwork() {
		return network;
	}
	public void setNetwork(Network network) {
		this.network = network;
	}
	public Property getProperty() {
		return property;
	}
	public void setProperty(Property property) {
		this.property = property;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public SupplyPoint getSupply() {
		return supply;
	}
	public void setSupply(SupplyPoint supply) {
		this.supply = supply;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getMeterType() {
		return meterType;
	}
	public void setMeterType(String meterType) {
		this.meterType = meterType;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public boolean isChildMeter() {
		return childMeter;
	}
	public void setChildMeter(boolean childMeter) {
		this.childMeter = childMeter;
	}
	public String getReadingFrequency() {
		return readingFrequency;
	}
	public void setReadingFrequency(String readingFrequency) {
		this.readingFrequency = readingFrequency;
	}
	public String getReadingImportFactor() {
		return readingImportFactor;
	}
	public void setReadingImportFactor(String readingImportFactor) {
		this.readingImportFactor = readingImportFactor;
	}
	public String getInitialReading() {
		return initialReading;
	}
	public void setInitialReading(String initialReading) {
		this.initialReading = initialReading;
	}
	public String getOffset() {
		return offset;
	}
	public void setOffset(String offset) {
		this.offset = offset;
	}
	public Long getMeterId() {
		return meterId;
	}
	public void setMeterId(Long meterId) {
		this.meterId = meterId;
	}
	public String getParentSerialNumber() {
		return parentSerialNumber;
	}
	public void setParentSerialNumber(String parentSerialNumber) {
		this.parentSerialNumber = parentSerialNumber;
	}
	public int getPulseInputNumber() {
		return pulseInputNumber;
	}
	public void setPulseInputNumber(int pulseInputNumber) {
		this.pulseInputNumber = pulseInputNumber;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	
}
