package com.monarch.mabdeck.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.ClientDto;
import com.monarch.mabdeck.dto.DataLoggerDto;
import com.monarch.mabdeck.dto.NetworkDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.DataLogger;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.history.service.NetworkHistoryService;
import com.monarch.mabdeck.mapper.DataLoggerMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.NetworkMapper;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.NetworkRepository;

import javassist.NotFoundException;

@Component
public class NetworkService extends CommonServiceImpl<NetworkDto, Network> {

	private Logger logger = LoggerFactory.getLogger(NetworkService.class);

	@Resource
	private NetworkRepository repository;

	@Resource
	private ClientRepository clientRepository;
	
	@Autowired
	private NetworkHistoryService historyService;

	@Override
	public JpaRepository<Network, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<NetworkDto, Network> getMapper() {
		return NetworkMapper.INSTANCE;
	}
	
	@Override
	public void updateAudit(Network entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
			}else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}

	@Override
	public NetworkDto create(NetworkDto dto, String username) {
		Network entity = getMapper().convertToEntity(dto);
		updateAudit(entity, username);
		Client client = clientRepository.getOne(dto.getClient() != null ? dto.getClient().getClientId() : null);
		if (client != null)
			entity.setClient(client);
		getJPARepository().saveAndFlush(entity);
		return dto;
	}

	public Set<NetworkDto> getAllNetworkForDataLogger() {
		Set<NetworkDto> dtos = new HashSet<>();
		List<Network> entities = repository.getAllNetworksForDataLogger();
		for (Network entity : entities) {
			NetworkDto dto = new NetworkDto();
			Client client = entity.getClient();
			ClientDto clientDto = new ClientDto();
			clientDto.setClientId(client.getClientId());
			clientDto.setClientName(client.getClientName());
			dto.setClient(clientDto);
			dto.setNetworkId(entity.getNetworkId());
			dto.setNetwork(entity.getNetwork());
			this.populateDataLoggerDetails(dto, entity.getDataLogger());
			dtos.add(dto);
		}
		return dtos;
	}

	private void populateDataLoggerDetails(NetworkDto dto, List<DataLogger> dataLoggers) {
		List<DataLoggerDto> dataLoggerDtos = DataLoggerMapper.INSTANCE.convertToDTOList(dataLoggers);
		dto.setDataLogger(dataLoggerDtos);
	}

	public List<NetworkDto> readAllByStartIndexAndRange(int index, int size) throws NotFoundException{
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1)*size + 1;
		endIndex = index * size;	
		List<Network> entities = this.repository.getAllNetworksByRange(startIndex, endIndex);
		List<NetworkDto> dtos = new ArrayList<>();
		if (entities == null || entities.size() == 0) {
			throw new NotFoundException("There are no elements to display");
		}
		for (Network network : entities) {
			NetworkDto dto = this.convertToDto(network);
			Client clientEntity = network.getClient();
			ClientDto clientDto = new ClientDto();
			clientDto.setClientId(clientEntity.getClientId());
			clientDto.setClientName(clientEntity.getClientName());
			dto.setClient(clientDto);
			dto.setNumberOfProperties(network.getProperty().size());
			dtos.add(dto);
		}
		return dtos;
	}
	
	public long getCount() {
		return this.repository.getCount();
	}
	
	public List<NetworkDto> readAll() throws NotFoundException {
		List<Network> entities = getJPARepository().findAll();
		List<NetworkDto> dtos = new ArrayList<>();
		if (entities == null || entities.size() == 0) {
			throw new NotFoundException("There are no elements to display");
		}
		for (Network network : entities) {
			NetworkDto dto = this.convertToDto(network);
			Client clientEntity = network.getClient();
			ClientDto clientDto = new ClientDto();
			clientDto.setClientId(clientEntity.getClientId());
			clientDto.setClientName(clientEntity.getClientName());
			dto.setClient(clientDto);
			dto.setNumberOfProperties(network.getProperty().size());
			dtos.add(dto);
		}
		return dtos;
	}
	
	private NetworkDto convertToDto(Network network) {
		NetworkDto dto = new NetworkDto();
		dto.setAllowPrepayment(network.isAllowPrepayment());
		dto.setCardNumberGeneration(network.isCardNumberGeneration());
		dto.setEstimationMethod(network.getEstimationMethod());
		dto.setHubManufacturer(network.getHubManufacturer());
		dto.setIin(network.getIin());
		dto.setManualReview(network.isManualReview());
		dto.setNetwork(network.getNetwork());
		dto.setNetworkId(network.getNetworkId());
		dto.setNetworkType(network.getNetworkType());
		dto.setPaymentCardProvider(network.getPaymentCardProvider());
		dto.setPeerComparison(network.isPeerComparison());
		dto.setRecoveryPercentage(network.getRecoveryPercentage());
		return dto;
	}

	public NetworkDto update(NetworkDto dto, String username) {
		Client client = null;		
		Network entity = getMapper().convertToEntity(dto);
		updateAudit(entity, username);
		if(dto.getClient() != null && dto.getClient().getClientId() >0)
			client = clientRepository.findOne(dto.getClient().getClientId());
		Network existingEntity = repository.findOne(entity.getNetworkId());
		historyService.updateNetworkHistory(existingEntity, username);
		existingEntity.setClient(client);
		this.updateNetwork(entity, existingEntity);
		return dto;
	}

	private void updateNetwork(Network newEntity, Network existingEntity) {
		existingEntity.setNetwork(newEntity.getNetwork());
		existingEntity.setNetworkType(newEntity.getNetworkType());
		existingEntity.setManualReview(newEntity.isManualReview());
		existingEntity.setEstimationMethod(newEntity.getEstimationMethod());		
		existingEntity.setHubManufacturer(newEntity.getHubManufacturer());
		existingEntity.setAllowPrepayment(newEntity.isAllowPrepayment());		
		existingEntity.setPeerComparison(newEntity.isPeerComparison());
		existingEntity.setPaymentCardProvider(newEntity.getPaymentCardProvider());
		existingEntity.setIin(newEntity.getIin());
		existingEntity.setRecoveryPercentage(newEntity.getRecoveryPercentage());
		existingEntity.setCardNumberGeneration(newEntity.isCardNumberGeneration());
	}
	
	public List<NetworkDto> getAllNetworksForClientID(long clientID) throws Exception{
		if(clientID <=0)
			throw new Exception("Invalid client supplied");
		List<Network> networks = repository.getAllNetworksForClient(clientID);
		List<NetworkDto> networkDtos = new ArrayList<>();
		for(Network network : networks) {
			NetworkDto networkDto = new NetworkDto();
			networkDto.setNetworkId(network.getNetworkId());
			networkDto.setNetwork(network.getNetwork());
			networkDto.setNetworkType(network.getNetworkType());
			networkDtos.add(networkDto);
		}
		return networkDtos;
	}
	
	public List<NetworkDto> getAllNetworksByName(String name){
		List<Network> networks = repository.getAllNetworkByName(name);
		List<NetworkDto> dtos = new ArrayList<>();
		for(Network network: networks) {
			NetworkDto dto = new NetworkDto();
			dto.setNetwork(network.getNetwork());
			dto.setNetworkId(network.getNetworkId());
			dto.setNetworkType(network.getNetworkType());
			dtos.add(dto);
		}
		return dtos;
	}
}