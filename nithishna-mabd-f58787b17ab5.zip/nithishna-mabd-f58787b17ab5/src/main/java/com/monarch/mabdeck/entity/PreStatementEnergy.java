package com.monarch.mabdeck.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class PreStatementEnergy implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long preStatementEnergyId;

	private double unitPricePerUnit;
	private double unitsUsed;
	private double totalUnitsUsed;

	@OneToMany(mappedBy = "preStatement", cascade = CascadeType.ALL)
	private List<PreStandingCharge> standingChargeList = new ArrayList<>();
	
	private double totalCost;
	private double adminCharge;
	private double adminVat;
	private double unitChargeVat;
	private String energy;
	
	@OneToMany(mappedBy = "preStatementEnergy", cascade = CascadeType.ALL)
	private List<PreReadings> reading = new ArrayList<>();
	
	@ManyToOne(cascade = CascadeType.ALL, targetEntity = PreStatement.class, fetch = FetchType.EAGER)
	@JoinColumn(name="preStatementId",referencedColumnName="preStatementId", insertable = true, updatable = true)
	private PreStatement preStatement;

	public Long getPreStatementEnergyId() {
		return preStatementEnergyId;
	}


	public double getUnitPricePerUnit() {
		return unitPricePerUnit;
	}


	public double getUnitsUsed() {
		return unitsUsed;
	}


	public double getTotalUnitsUsed() {
		return totalUnitsUsed;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public List<PreReadings> getReading() {
		return reading;
	}


	public void setPreStatementEnergyId(Long preStatementEnergyId) {
		this.preStatementEnergyId = preStatementEnergyId;
	}


	public void setUnitPricePerUnit(double unitPricePerUnit) {
		this.unitPricePerUnit = unitPricePerUnit;
	}


	public void setUnitsUsed(double unitsUsed) {
		this.unitsUsed = unitsUsed;
	}


	public void setTotalUnitsUsed(double totalUnitsUsed) {
		this.totalUnitsUsed = totalUnitsUsed;
	}


	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}


	public void setReading(List<PreReadings> reading) {
		this.reading = reading;
	}


	public PreStatement getPreStatement() {
		return preStatement;
	}


	public void setPreStatement(PreStatement preStatement) {
		this.preStatement = preStatement;
	}


	public double getAdminCharge() {
		return adminCharge;
	}


	public double getAdminVat() {
		return adminVat;
	}


	public double getUnitChargeVat() {
		return unitChargeVat;
	}


	public String getEnergy() {
		return energy;
	}


	public void setAdminCharge(double adminCharge) {
		this.adminCharge = adminCharge;
	}


	public void setAdminVat(double adminVat) {
		this.adminVat = adminVat;
	}


	public void setUnitChargeVat(double unitChargeVat) {
		this.unitChargeVat = unitChargeVat;
	}


	public void setEnergy(String energy) {
		this.energy = energy;
	}


	public List<PreStandingCharge> getStandingChargeList() {
		return standingChargeList;
	}


	public void setStandingChargeList(List<PreStandingCharge> standingChargeList) {
		this.standingChargeList = standingChargeList;
	}
}