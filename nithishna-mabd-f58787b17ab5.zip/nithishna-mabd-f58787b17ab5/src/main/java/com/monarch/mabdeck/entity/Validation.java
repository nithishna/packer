package com.monarch.mabdeck.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Validation implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long validId;
	
	@ManyToOne(cascade = CascadeType.ALL, targetEntity = Client.class, fetch = FetchType.LAZY)
	@JoinColumn(name="clientId",referencedColumnName="clientId", insertable = true, updatable = true)
	private Client client;
	
	@ManyToOne(targetEntity = Network.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "networkId", referencedColumnName = "networkId", insertable = true, updatable = true)
	private Network network;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="temp_valid_id", insertable = true, updatable = true)
	private TempDifferenceValidation tempValidation;
	
	@OneToMany(mappedBy="validation", fetch=FetchType.EAGER)
	private List<NegativeConsumptionValidation> negativeValidation;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="zero_valid_id", insertable = true, updatable = true)
	private ZeroConsumptionValidation zeroConsumptionValidation;
	
	private String emailNotification;
	public TempDifferenceValidation getTempValidation() {
		return tempValidation;
	}
	public List<NegativeConsumptionValidation> getNegativeValidation() {
		return negativeValidation;
	}
	public ZeroConsumptionValidation getZeroConsumptionValidation() {
		return zeroConsumptionValidation;
	}
	public void setTempValidation(TempDifferenceValidation tempValidation) {
		this.tempValidation = tempValidation;
	}
	public void setNegativeValidation(List<NegativeConsumptionValidation> negativeValidation) {
		this.negativeValidation = negativeValidation;
	}
	public void setZeroConsumptionValidation(ZeroConsumptionValidation zeroConsumptionValidation) {
		this.zeroConsumptionValidation = zeroConsumptionValidation;
	}
	public String getEmailNotification() {
		return emailNotification;
	}
	public void setEmailNotification(String emailNotification) {
		this.emailNotification = emailNotification;
	}
	public long getValidId() {
		return validId;
	}
	public void setValidId(long validId) {
		this.validId = validId;
	}
	public Client getClient() {
		return client;
	}
	public Network getNetwork() {
		return network;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public void setNetwork(Network network) {
		this.network = network;
	}
}
