package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BillablePersonHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long billablePersonId;
	private String titles;
	private String firstName;
	private String lastName;
	private String preferredName;
	private String landlineNumber;
	private String mobileNumber;
	private String emailAddress;
	private boolean deleted;
	
	@Embedded
	private Audit audit;
	
	private Long accountId;

	public Long getId() {
		return id;
	}

	public Long getBillablePersonId() {
		return billablePersonId;
	}

	public String getTitles() {
		return titles;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getPreferredName() {
		return preferredName;
	}

	public String getLandlineNumber() {
		return landlineNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public Audit getAudit() {
		return audit;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setBillablePersonId(Long billablePersonId) {
		this.billablePersonId = billablePersonId;
	}

	public void setTitles(String titles) {
		this.titles = titles;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}

	public void setLandlineNumber(String landlineNumber) {
		this.landlineNumber = landlineNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

}
