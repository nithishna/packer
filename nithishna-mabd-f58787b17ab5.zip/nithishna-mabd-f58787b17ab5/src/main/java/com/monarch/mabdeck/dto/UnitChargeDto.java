package com.monarch.mabdeck.dto;

public class UnitChargeDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long unitChargeId;
	
	private String name;
	private float pricePerUnit;
	private String unit;
	private TariffDto tariff;
	public Long getUnitChargeId() {
		return unitChargeId;
	}
	public void setUnitChargeId(Long unitChargeId) {
		this.unitChargeId = unitChargeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(float pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public TariffDto getTariff() {
		return tariff;
	}
	public void setTariff(TariffDto tariff) {
		this.tariff = tariff;
	}

}
