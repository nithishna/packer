package com.monarch.mabdeck.controller;

import java.text.ParseException;
import java.util.Base64;
import java.util.List;

import javax.activity.InvalidActivityException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.AccountAssociatedUser;
import com.monarch.mabdeck.dto.AccountBalanceDto;
import com.monarch.mabdeck.dto.AccountLimitedDto;
import com.monarch.mabdeck.dto.MyDate;
import com.monarch.mabdeck.dto.PropertyAccountAssociationLimitedDto;
import com.monarch.mabdeck.dto.PropertyAccountDto;
import com.monarch.mabdeck.service.PropertyAccountAssociationService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;

@RestController
public class PropertyAccountAssociationController {

	@Autowired
	private PropertyAccountAssociationService service;
	private Logger logger = LoggerFactory.getLogger(PropertyAccountAssociationController.class);

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_ASSOCIATION, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<PropertyAccountDto> getAllPropertyAssociations(
			@RequestParam("account_id") Long accountId) {
		logger.info("PropertyAccountAssociationController: getAllPropertyAssociations - Start");
		return service.getAllPropertyAssociations(accountId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_MOVE_OUT, method = RequestMethod.PUT)
	public void updateMoveOutStatusForProperties(@RequestParam("association_id") Long associationId,
			@RequestParam("end_date") String date,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization)
			throws InvalidActivityException, ParseException {
		logger.info("PropertyAccountAssociationController: updateMoveOutStatusForProperties - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAccountAssociationController: updateMoveOutStatusForProperties - Service call, Username : "
				+ username);
		service.updateMoveOutStatusForProperties(associationId, date, username);
		logger.info("PropertyAccountAssociationController: updateMoveOutStatusForProperties - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_MOVE_IN, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public String updateMoveInStatusForProperties(@RequestBody PropertyAccountDto dto,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization)
			throws InvalidActivityException {
		logger.info("PropertyAccountAssociationController: updateMoveInStatusForProperties - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAccountAssociationController: updateMoveInStatusForProperties - Service call, Username : "
				+ username);
		return service.updateMoveInStatusForProperties(dto, username);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_STATUS, method = RequestMethod.GET)
	public @ResponseBody String getStatusForAccountAndProperty(@RequestParam("property_id") Long propertyId,
			@RequestParam("account_id") Long accountId, @RequestParam("value") int value) {
		logger.info("PropertyAccountAssociationController: getStatusForAccountAndProperty - Start");
		return service.getStatusForPropertyAndAccount(propertyId, accountId, value);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.OWNER_PROPERTY_STATUS, method = RequestMethod.GET)
	public @ResponseBody String getStatusForAssociationId(@RequestParam("association_id")Long associationId, @RequestParam("value") int value) {
		logger.info("PropertyAccountAssociationController: getStatusForAssociationId - Start");
		return service.getStatusForAssociationId(associationId, value);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.OWNER_AND_TENANT, method = RequestMethod.GET)
	public @ResponseBody AccountAssociatedUser getOwnerAndTenantAssociatedWithProperty(@RequestParam("property_id") Long propertyId) {
		logger.info("PropertyAccountAssociationController: getOwnerAndTenantAssociatedWithProperty - Start");
		return service.getOwnerAndTenantAssociatedWithProperty(propertyId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PENDING_TO_SANITY, method = RequestMethod.PUT)
	public @ResponseBody String changePendingToSanityCheck(@RequestParam("property_id") Long propertyId,
			@RequestParam("account_id") Long accountId, @RequestParam("tenureType") String tenure,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) {
		logger.info("PropertyAccountAssociationController: changePendingToSanityCheck - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAccountAssociationController: changePendingToSanityCheck - Service call, Username : "
				+ username);
		return service.changePendingToSanityCheck(accountId, propertyId, username, tenure);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.SANITY_TO_PREVIOUS_TENANT, method = RequestMethod.PUT)
	public @ResponseBody String changeSanityToPreviousTenant(@RequestParam("property_id") Long propertyId,
			@RequestParam("account_id") Long accountId, @RequestParam("tenureType") String tenure,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) {
		logger.info("PropertyAccountAssociationController: changeSanityToPreviousTenant - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAccountAssociationController: changeSanityToPreviousTenant - Service call, Username : "
				+ username);
		return service.changeSanityToPreviousTenant(accountId, propertyId, username, tenure);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PREVIOUS_TENANT_TO_PREVIOUS_METERREADING, method = RequestMethod.PUT)
	public @ResponseBody String changePreviousTenantToPreviousMeterReading(@RequestParam("property_id") Long propertyId,
			@RequestParam("account_id") Long accountId, @RequestParam("tenureType") String tenure,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) {
		logger.info("PropertyAccountAssociationController: changePreviousTenantToPreviousMeterReading - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info(
				"PropertyAccountAssociationController: changePreviousTenantToPreviousMeterReading - Service call, Username : "
						+ username);
		return service.changePreviousTenantToPreviousMeterReading(accountId, propertyId, username, tenure);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PREVIOUS_METERREADING_TO_CURRENT_METERREADING, method = RequestMethod.PUT)
	public @ResponseBody String changePreviousMeterReadingToCurrentMeterReading(
			@RequestParam("property_id") Long propertyId, @RequestParam("account_id") Long accountId, @RequestParam("tenureType") String tenure,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) {
		logger.info("PropertyAccountAssociationController: changePreviousMeterReadingToCurrentMeterReading - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info(
				"PropertyAccountAssociationController: changePreviousMeterReadingToCurrentMeterReading - Service call, Username : "
						+ username);
		return service.changePreviousMeterReadingToCurrentMeterReading(accountId, propertyId, username, tenure);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CURRENT_METERREADING_TO_COMPLETED, method = RequestMethod.PUT)
	public @ResponseBody String changeCurrentReadingToCompleted(@RequestParam("property_id") Long propertyId,
			@RequestParam("account_id") Long accountId, @RequestParam("tenureType") String tenure,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) {
		logger.info("PropertyAccountAssociationController: changeCurrentReadingToCompleted - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAccountAssociationController: changeCurrentReadingToCompleted - Service call, Username : "
				+ username);
		return service.changeCurrentReadingToCompleted(accountId, propertyId, username, tenure);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.TENANT_OUT_PENDING_TO_PREVIOUS_METER_READ, method = RequestMethod.PUT)
	public @ResponseBody String changePendingToPreviousMeterReading(@RequestParam("property_id") Long propertyId,
			@RequestParam("account_id") Long accountId, @RequestParam("tenureType") String tenure,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) {
		logger.info("PropertyAccountAssociationController: changePendingToPreviousMeterReading - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAccountAssociationController: changePendingToPreviousMeterReading - Service call, Username : "
				+ username);
		return service.changePendingToPreviousMeterReadingForTenantOut(accountId, propertyId, username, tenure);
	}
	
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.TENANT_OUT_PREVIOUS_METER_READ_TO_CURRENT_METERREADING, method = RequestMethod.PUT)
	public @ResponseBody String changePreviousMeterReadingToCurrentMeterReadingForTenantOut(@RequestParam("property_id") Long propertyId,
			@RequestParam("account_id") Long accountId, @RequestParam("tenureType") String tenure,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) {
		logger.info("PropertyAccountAssociationController: changePreviousMeterReadingToCurrentMeterReadingForTenantOut - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAccountAssociationController: changePreviousMeterReadingToCurrentMeterReadingForTenantOut - Service call, Username : "
				+ username);
		return service.changePreviousMeterReadingToCurrentMeterReadingForTenantOut(accountId, propertyId, username, tenure);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.TENANT_OUT_CURRENT_METERREADING_TO_COMPLETED, method = RequestMethod.PUT)
	public @ResponseBody String changeCurrentReadingToCompletedForTenantOut(@RequestParam("property_id") Long propertyId,
			@RequestParam("account_id") Long accountId, @RequestParam("tenureType") String tenure,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) {
		logger.info("PropertyAccountAssociationController: changeCurrentReadingToCompletedForTenantOut - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAccountAssociationController: changeCurrentReadingToCompletedForTenantOut - Service call, Username : "
				+ username);
		return service.changeCurrentReadingToCompletedForTenantOut(accountId, propertyId, username, tenure);
	}
	
	@CrossOrigin(origins="http://fileserver:4200")
	@RequestMapping(path = Constants.OWNER_FOR_PROPERTY, method= RequestMethod.GET)
	public @ResponseBody String getOwnerForProperty(@RequestParam("propertyId") Long propertyId) {
		logger.info("PropertyAccountAssociationController: getOwnerForProperty");
		return service.getOwnerForPropertyId(propertyId);
	}
	
	@CrossOrigin(origins="http://fileserver:4200")
	@RequestMapping(path = Constants.ACCOUNTS_FOR_PROPERTY, method= RequestMethod.GET)
	public @ResponseBody List<AccountLimitedDto> getAllAccountsForProperty(@RequestParam("propertyId") Long propertyId, @RequestParam("tenuretype") String tenureType){
		logger.info("PropertyAccountAssociationController: getAllAccountsForProperty");
		return service.getAllAccountsForProperty(propertyId, tenureType);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.OWNER_PROPERTY_ASSOCIATION, method = RequestMethod.POST)
	public @ResponseBody String updatePropertyAccountAssociationForOwner(@RequestBody PropertyAccountAssociationLimitedDto dto,
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) throws ParseException {
		logger.info("PropertyAccountAssociationController: updatePropertyAccountAssociationForOwner - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAccountAssociationController: updatePropertyAccountAssociationForOwner - Service call, Username : "
				+ username);
		return service.updatePropertyAccountAssociationForOwnerV2(dto, username);
	}
	
	@CrossOrigin(origins="http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_ACTIVE_DATE, method= RequestMethod.GET)
	public @ResponseBody MyDate getLastActiveDateForProperty(@RequestParam("propertyId") Long propertyId, @RequestParam("isProperty") boolean isProperty) throws ParseException{
		logger.info("PropertyAccountAssociationController: getLastActiveDateForProperty, PropertyId - "+propertyId+", IsProperty - "+isProperty);
		return service.getLastOwnerAccountAssociationDate(propertyId, isProperty);
	}
	
	@CrossOrigin(origins="http://fileserver:4200")
	@RequestMapping(path = Constants.ALL_OWNER_FOR_PROPERTY, method= RequestMethod.GET)
	public @ResponseBody List<PropertyAccountAssociationLimitedDto> getAllOwnersForProperty(@PathVariable("property_id") long propertyId){
		logger.info("PropertyAccountAssociationController: getAllOwnersForProperty");
		return service.getAllAccountsForProperty(propertyId, "owner");
	}
	
	@CrossOrigin(origins="http://fileserver:4200")
	@RequestMapping(path = Constants.ALL_TENANTS_FOR_PROPERTY, method= RequestMethod.GET)
	public @ResponseBody List<PropertyAccountAssociationLimitedDto> getAllTenantsForProperty(@PathVariable("property_id") long propertyId){
		logger.info("PropertyAccountAssociationController: getAlltenantsForProperty");
		return service.getAllAccountsForProperty(propertyId, "tenant");
	}
	
	@CrossOrigin(origins="http://fileserver:4200")
	@RequestMapping(path = Constants.ACCOUNT_BALANCE, method= RequestMethod.GET)
	public @ResponseBody AccountBalanceDto getAccountBalanceForAccountId(@RequestParam("account_id")long accountId) {
		logger.info("PropertyAccountAssociationController: getAccountBalanceForAccountId");
		return service.getAccountBalanceForAccountId(accountId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.DELETE_ASSOCIATION, method = RequestMethod.PUT)
	public void updateAssociationStatusToDeleted(@RequestParam("association_id")long associationId, @ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) throws Exception {
		logger.info("PropertyAccountAssociationController: updateAssociationStatusToDeleted");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAccountAssociationController: updateAssociationStatusToDeleted - Service call, Username : "
				+ username);
		service.updateAssociationStatusToDeleted(associationId, username);
	}
}
