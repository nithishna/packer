package com.monarch.mabdeck.dto;

public class MeterReadingSearchDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String accountId;
	private Long meterId;
	private Long supplyId;
	private Long propertyId;
	private String readingFromDate;
	private String readingToDate;
	public String getAccountId() {
		return accountId;
	}
	public Long getMeterId() {
		return meterId;
	}
	public Long getSupplyId() {
		return supplyId;
	}
	public Long getPropertyId() {
		return propertyId;
	}
	public String getReadingFromDate() {
		return readingFromDate;
	}
	public String getReadingToDate() {
		return readingToDate;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public void setMeterId(Long meterId) {
		this.meterId = meterId;
	}
	public void setSupplyId(Long supplyId) {
		this.supplyId = supplyId;
	}
	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}
	public void setReadingFromDate(String readingFromDate) {
		this.readingFromDate = readingFromDate;
	}
	public void setReadingToDate(String readingToDate) {
		this.readingToDate = readingToDate;
	}
}
