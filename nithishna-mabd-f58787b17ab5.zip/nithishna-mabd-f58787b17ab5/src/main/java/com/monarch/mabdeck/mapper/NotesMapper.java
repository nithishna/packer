package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.NotesDto;
import com.monarch.mabdeck.entity.Notes;

@Mapper
public abstract class NotesMapper implements IBaseMapper<NotesDto, Notes> {

	public static final NotesMapper INSTANCE = Mappers.getMapper(NotesMapper.class);
	
	@Mappings({
		@Mapping(target = "attachment", ignore = true),
		@Mapping(target = "account", ignore = true)
	})
	public abstract Notes convertToEntity(NotesDto dto);
	
	
	@Mappings({
		@Mapping(target = "attachment", ignore = true),
		@Mapping(target = "accountId", ignore = true)
	})
	public abstract NotesDto convertToDTO(Notes entity);
}
