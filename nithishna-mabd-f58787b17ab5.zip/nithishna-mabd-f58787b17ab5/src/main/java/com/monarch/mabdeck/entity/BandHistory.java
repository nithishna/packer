package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BandHistory implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long bandId;
	private String bandName;
	private String bandType;
	private Date startDate;
	private Date endDate;
	private int propertyPart1;
	private int propertyPart2;
	private String propertyUnit;
	private int numberOfBedroom;
	private Long clientId;
	private Long networkId;
	@Embedded
	private Audit audit;
	public long getBandId() {
		return bandId;
	}
	public String getBandName() {
		return bandName;
	}
	public String getBandType() {
		return bandType;
	}
	public Date getStartDate() {
		return startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public int getPropertyPart1() {
		return propertyPart1;
	}
	public int getPropertyPart2() {
		return propertyPart2;
	}
	public String getPropertyUnit() {
		return propertyUnit;
	}
	public int getNumberOfBedroom() {
		return numberOfBedroom;
	}
	public long getClientId() {
		return clientId;
	}
	public long getNetworkId() {
		return networkId;
	}
	public Audit getAudit() {
		return audit;
	}
	public void setBandId(long bandId) {
		this.bandId = bandId;
	}
	public void setBandName(String bandName) {
		this.bandName = bandName;
	}
	public void setBandType(String bandType) {
		this.bandType = bandType;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public void setPropertyPart1(int propertyPart1) {
		this.propertyPart1 = propertyPart1;
	}
	public void setPropertyPart2(int propertyPart2) {
		this.propertyPart2 = propertyPart2;
	}
	public void setPropertyUnit(String propertyUnit) {
		this.propertyUnit = propertyUnit;
	}
	public void setNumberOfBedroom(int numberOfBedroom) {
		this.numberOfBedroom = numberOfBedroom;
	}
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
}
