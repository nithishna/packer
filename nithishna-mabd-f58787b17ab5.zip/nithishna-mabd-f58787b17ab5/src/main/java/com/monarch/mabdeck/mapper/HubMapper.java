package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.HubDto;
import com.monarch.mabdeck.entity.Hub;

@Mapper(uses = {ClientMapper.class, NetworkMapper.class, PropertyMapper.class})
public abstract class HubMapper implements IBaseMapper<HubDto, Hub>{
	public static final HubMapper INSTANCE = Mappers.getMapper(HubMapper.class);
	
	@Mappings({
		@Mapping(target = "audit", ignore = true)
	})
	public abstract Hub convertToEntity(HubDto dto);
}
