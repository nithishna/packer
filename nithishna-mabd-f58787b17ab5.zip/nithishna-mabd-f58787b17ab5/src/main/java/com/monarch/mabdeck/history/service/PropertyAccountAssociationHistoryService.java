package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.PropertyAccountAssociation;
import com.monarch.mabdeck.entity.PropertyAccountAssociationHistory;
import com.monarch.mabdeck.repository.PropertyAccountAssociationHistoryRepository;

@Component
public class PropertyAccountAssociationHistoryService {

	@Resource
	private PropertyAccountAssociationHistoryRepository historyRepository;
	
	public void updatePropertyAccountAssociationHistory(PropertyAccountAssociation entity, String username) {
		if(entity != null) {
			PropertyAccountAssociationHistory history = new PropertyAccountAssociationHistory();
			history.setAccountId(entity.getAccount() != null? entity.getAccount().getAccountId() : null);
			history.setAssociationId(entity.getAssociationId());
			history.setAudit(entity.getAudit());
			history.setEndDate(entity.getEndDate());
			history.setStartDate(entity.getStartDate());
			history.setPropertyId(entity.getProperty() != null? entity.getProperty().getPropertyId() : null);
			history.setTenureType(entity.getTenureType());
			history.setMessage(entity.getMessage());
			history.setMoveOutMessage(entity.getMoveOutMessage());
			history.setCounter(entity.getCounter());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
