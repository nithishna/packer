package com.monarch.mabdeck.dto;

public class ScheduleDto implements IDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long scheduleId;
	private String recursionType;
	private int period;
	private long offset;
	private long recursionOffset;
	private long hour;
	private long minute;
	private String emailIds;
	public long getScheduleId() {
		return scheduleId;
	}
	public String getRecursionType() {
		return recursionType;
	}
	public int getPeriod() {
		return period;
	}
	public long getOffset() {
		return offset;
	}
	public String getEmailIds() {
		return emailIds;
	}
	public void setScheduleId(long scheduleId) {
		this.scheduleId = scheduleId;
	}
	public void setRecursionType(String recursionType) {
		this.recursionType = recursionType;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public void setOffset(long offset) {
		this.offset = offset;
	}
	public void setEmailIds(String emailIds) {
		this.emailIds = emailIds;
	}
	public long getRecursionOffset() {
		return recursionOffset;
	}
	public void setRecursionOffset(long recursionOffset) {
		this.recursionOffset = recursionOffset;
	}
	public long getHour() {
		return hour;
	}
	public long getMinute() {
		return minute;
	}
	public void setHour(long hour) {
		this.hour = hour;
	}
	public void setMinute(long minute) {
		this.minute = minute;
	}

}
