package com.monarch.mabdeck.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.annotation.Resource;

import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.DataLoggerDto;
import com.monarch.mabdeck.entity.Address;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.DataLogger;
import com.monarch.mabdeck.entity.Meter;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.history.service.DataLoggerHistoryService;
import com.monarch.mabdeck.mapper.DataLoggerMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.DataLoggerRepository;
import com.monarch.mabdeck.repository.MeterRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.repository.PropertyRepository;
import com.monarch.mabdeck.util.Constants;

@Component
public class DataLoggerService extends CommonServiceImpl<DataLoggerDto, DataLogger> {

	private Logger logger = LoggerFactory.getLogger(DataLoggerService.class);

	@Resource
	private DataLoggerRepository repository;

	@Resource
	private ClientRepository clientRepository;

	@Resource
	private NetworkRepository networkRepository;
	
	@Resource
	private MeterRepository meterRepository;
	
	@Resource
	private PropertyRepository propertyRepository;
	
	@Autowired
	private DataLoggerHistoryService historyService;

	@Override
	public JpaRepository<DataLogger, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<DataLoggerDto, DataLogger> getMapper() {
		return DataLoggerMapper.INSTANCE;
	}

	@Override
	public void updateAudit(DataLogger entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
			}else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
	public DataLoggerDto update(DataLoggerDto dto, String username) {
		if (dto != null) {
			DataLogger entity = repository.findOne(dto.getId());		
			updateAudit(entity, username);
			historyService.updateDataLoggerHistory(entity, username);
			if (dto.getClient() != null && dto.getClient().getClientId() > 0) {
				Client client = clientRepository.findOne(dto.getClient().getClientId());
				entity.setClient(client);
			}
			if(dto.getNetwork() != null && dto.getNetwork().getNetworkId() != null) {
				Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
				entity.setNetwork(network);
			}
			entity.setCommunicationType(dto.getCommunicationType());
			entity.setEndDate(dto.getEndDate());
			entity.setStartDate(dto.getStartDate());
			entity.setImei(dto.getImei());
			entity.setIpAddress(dto.getIpAddress());
			entity.setLocation(dto.getLocation());
			entity.setManufacturer(dto.getManufacturer());
			entity.setModel(dto.getModel());
			entity.setPhoneNumber(dto.getPhoneNumber());
			entity.setPortNumber(dto.getPortNumber());
			entity.setSerialNumber(dto.getSerialNumber());
			entity.setUsername(dto.getUsername());
			entity.setPassword(dto.getPassword());
		}
		return dto;
	}
	
	public byte[] downloadDataLoggerTemplate(Long clientId, Long networkId) throws IOException {
		File dataLoggerTemplate = new File("dataLoggerTemplate.csv");
		PrintWriter pw = new PrintWriter(dataLoggerTemplate);
		StringBuilder sb = new StringBuilder();
		this.populateHeading(sb);
		this.populateRows(clientId, networkId, sb);
		pw.write(sb.toString());
		pw.close();
		InputStream stream = new FileInputStream("dataLoggerTemplate.csv");
		byte[] result = IOUtils.toByteArray(stream);
		stream.close();
		logger.debug("File deletion status : " + (dataLoggerTemplate.delete() ? "Success" : "Failure"));
		return result;
	}
	
	public void populateHeading(StringBuilder sb) {
		sb.append("ClientId").append(",");	
		sb.append("Client").append(",");	
		sb.append("NetworkId").append(",");	
		sb.append("Network").append(",");	
		sb.append("PropertyAddress").append(",");	
		sb.append("MeterSerialNumber").append(",");	
		sb.append("DataLoggerSerialNumber").append("\n");
	}
	
	public void populateRows(Long clientId, Long networkId, StringBuilder sb) {
		List<Meter> meters = meterRepository.getMeterForClientAndNetwork(clientId, networkId);
		for(Meter meter: meters) {
			sb.append(meter.getClient() != null? meter.getClient().getClientId() : "").append(",");
			sb.append(meter.getClient() != null? meter.getClient().getClientName(): "").append(",");
			sb.append(meter.getNetwork()!= null? meter.getNetwork().getNetworkId(): "").append(",");
			sb.append(meter.getNetwork()!= null? meter.getNetwork().getNetwork() : "").append(",");
			sb.append(meter.getProperty()!= null? getAddress(meter.getProperty().getAddress()):"").append(",");
			sb.append(meter.getSerialNumber()).append(",");
			sb.append("*Required*").append("\n");
		}
	}

	private String getAddress(Address address) {
		if(address == null) 
			return "";
		return address.getAddressLine1();
	}
	
	public void uploadCSV(MultipartFile multipartFile) throws IOException {
		File file = null;
		try {
			file = convertMultiPartToFile(multipartFile);
			Scanner scanner = new Scanner(file);
			boolean headingValidation = false;
			while (scanner.hasNextLine()) {
				if (!headingValidation) {
					headingValidation = validateHeading(scanner.nextLine());
					if (!headingValidation) {
						scanner.close();
						throw new IOException("Kindly check the heading order");
					}
				} else
					getRecordFromLine(scanner.nextLine());
			}
			scanner.close();
			if(file!= null)
				logger.debug(file.delete()? "Temp File Deleted successfully":"Temp File could not be deleted");
		} catch (IOException ex) {
			if(file!= null)
				logger.debug(file.delete()? "Temp File Deleted successfully":"Temp File could not be deleted");
			throw ex;
		} catch (Exception ex) {
			if(file!= null)
				logger.debug(file.delete()? "Temp File Deleted successfully":"Temp File could not be deleted");
			throw new IOException("Unable to parse the file. Kindly raise a support request and get this sorted");
		}
	}

	private boolean validateHeading(String line) {
		List<String> heading = Constants.dataloggerHeading;
		Iterator<String> iterator = heading.iterator();
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			while (rowScanner.hasNext()) {
				if (!iterator.next().equalsIgnoreCase(rowScanner.next())) {
					return false;
				}
			}
		}
		return true;
	}

	private void getRecordFromLine(String line) throws IOException {
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			DataLogger dataLogger = new DataLogger();
			Client client = null;
			Network network = null;
			if (rowScanner.hasNext()) {
				long clientId = rowScanner.nextLong();
				client = clientRepository.findOne(clientId);
				if (client == null)
					throw new IOException(
							"Client details are mandatory. Please enter the Client details and try again");
				dataLogger.setClient(client);
				logger.debug("Client name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			if (rowScanner.hasNext()) {
				long networkId = rowScanner.nextLong();
				network = networkRepository.findOne(networkId);
				if (network == null)
					throw new IOException(
							"Network details are mandatory. Please enter the Network details and try again");
				dataLogger.setNetwork(network);
				logger.debug("Network name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}			
			logger.debug("Property addressline1 : "+ (rowScanner.hasNext() ? rowScanner.next() : null));
			logger.debug("Meter serial number: "+ (rowScanner.hasNext()? rowScanner.next(): null));
			if (rowScanner.hasNext()) {
				String serialNumber = rowScanner.next();
				if(serialNumber.isEmpty() || serialNumber == null)
					throw new IOException("Serial Number cannot be empty. Please enter the serial number and try again");
				dataLogger.setSerialNumber(serialNumber);
			}
			repository.saveAndFlush(dataLogger);
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw new IOException("Unable to parse the file. Kindly raise a support request and get this sorted");
		}
	}

	private File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}
}