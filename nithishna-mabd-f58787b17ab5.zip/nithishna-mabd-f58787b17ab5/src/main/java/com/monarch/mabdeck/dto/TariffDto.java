package com.monarch.mabdeck.dto;

import java.sql.Date;
import java.util.List;

public class TariffDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long tariffId;
	private String tariffType;
	private Long supplyType;
	private String tariffName;
	private String tariffCode;
	private int vatRate;
	private Date activeFromDate;
	private Date activeToDate;
	private List<UnitChargeDto> unitCharge;
	private List<StandingChargeDto> standingCharge;
	private List<PropertyAreaChargeDto> propertyAreaCharge;
	private BandDto band;
	private int deleted;
	public Long getTariffId() {
		return tariffId;
	}
	public void setTariffId(Long tariffId) {
		this.tariffId = tariffId;
	}
	public String getTariffType() {
		return tariffType;
	}
	public void setTariffType(String tariffType) {
		this.tariffType = tariffType;
	}
	public Long getSupplyType() {
		return supplyType;
	}
	public void setSupplyType(Long supplyType) {
		this.supplyType = supplyType;
	}
	public String getTariffName() {
		return tariffName;
	}
	public void setTariffName(String tariffName) {
		this.tariffName = tariffName;
	}
	public String getTariffCode() {
		return tariffCode;
	}
	public void setTariffCode(String tariffCode) {
		this.tariffCode = tariffCode;
	}
	public int getVatRate() {
		return vatRate;
	}
	public void setVatRate(int vatRate) {
		this.vatRate = vatRate;
	}
	public Date getActiveFromDate() {
		return activeFromDate;
	}
	public void setActiveFromDate(Date activeFromDate) {
		this.activeFromDate = activeFromDate;
	}
	public Date getActiveToDate() {
		return activeToDate;
	}
	public void setActiveToDate(Date activeToDate) {
		this.activeToDate = activeToDate;
	}
	public List<UnitChargeDto> getUnitCharge() {
		return unitCharge;
	}
	public void setUnitCharge(List<UnitChargeDto> unitCharge) {
		this.unitCharge = unitCharge;
	}
	public List<StandingChargeDto> getStandingCharge() {
		return standingCharge;
	}
	public void setStandingCharge(List<StandingChargeDto> standingCharge) {
		this.standingCharge = standingCharge;
	}
	public List<PropertyAreaChargeDto> getPropertyAreaCharge() {
		return propertyAreaCharge;
	}
	public void setPropertyAreaCharge(List<PropertyAreaChargeDto> propertyAreaCharge) {
		this.propertyAreaCharge = propertyAreaCharge;
	}
	public BandDto getBand() {
		return band;
	}
	public void setBand(BandDto band) {
		this.band = band;
	}
	public int getDeleted() {
		return deleted;
	}
	public void setDeleted(int deleted) {
		this.deleted = deleted;
	}
}
