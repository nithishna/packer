package com.monarch.mabdeck.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.FinancialsDto;
import com.monarch.mabdeck.entity.Account;
import com.monarch.mabdeck.entity.AccountBalance;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Financials;
import com.monarch.mabdeck.entity.PaymentMethod;
import com.monarch.mabdeck.entity.PaymentType;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.repository.AccountBalanceRepository;
import com.monarch.mabdeck.repository.AccountRepository;
import com.monarch.mabdeck.repository.FinancialsRepository;
import com.monarch.mabdeck.repository.PaymentMethodRepository;
import com.monarch.mabdeck.repository.PaymentTypeRepository;

import javassist.NotFoundException;

@Component
public class FinancialsService extends CommonServiceImpl<FinancialsDto, Financials> {

	private Logger logger = LoggerFactory.getLogger(FinancialsService.class);

	@Resource
	private FinancialsRepository repository;
	
	@Resource
	private PaymentMethodRepository paymentMethodRepository;
	
	@Resource
	private PaymentTypeRepository paymentTypeRepository;
	
	@Resource
	private AccountRepository accountRepository;
	
	@Resource
	private AccountBalanceRepository accountBalanceRepository;

	@Override
	public JpaRepository<Financials, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<FinancialsDto, Financials> getMapper() {
		return null;
	}

	@Override
	public void updateAudit(Financials entity, String username) {
		if (entity != null) {
			Calendar cal = Calendar.getInstance();
			if (entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			} else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}
	}
	
	public FinancialsDto create(FinancialsDto dto, String username) {
		boolean newBalance = false;
		if(dto != null) {
			Financials financials = new Financials();			
			financials.setDate(dto.getDate());
			PaymentMethod paymentMethod = paymentMethodRepository.findOne(dto.getPaymentMethodId());
			financials.setPaymentMethod(paymentMethod);
			PaymentType paymentType = paymentTypeRepository.findOne(dto.getPaymentTypeId());
			financials.setPaymentType(paymentType);
			financials.setReference(dto.getReference());
			AccountBalance accountBalance = accountBalanceRepository.findByAccountId(dto.getAccountId());
			Account account = accountRepository.findOne(dto.getAccountId());
			financials.setAccount(account);
			if(accountBalance == null) {
				accountBalance = new AccountBalance();
				newBalance = true;
			}
			if(dto.getPaymentMethodId() > 0) {
				if(dto.getPaymentMethodId()== 3 || dto.getPaymentMethodId() == 5 || dto.getPaymentMethodId()==8) {
					financials.setCredit(0);
					financials.setDebit(dto.getAmount());	
					accountBalance.setBalance((accountBalance.getBalance() - dto.getAmount()));
					financials.setBalance(accountBalance.getBalance());
				}else {
					financials.setCredit(dto.getAmount());
					financials.setDebit(0);	
					accountBalance.setBalance((accountBalance.getBalance() + dto.getAmount()));
					financials.setBalance(accountBalance.getBalance());
				}				
			}
			this.updateAudit(financials, username);			
			repository.saveAndFlush(financials);
			if(newBalance) {
				accountBalance.setAccount(account);
				accountBalanceRepository.saveAndFlush(accountBalance);
			}			
			dto.setId(financials.getId());
		}	
		return dto;
	}
	
	public List<FinancialsDto> readAll(long accountId) throws NotFoundException {
		List<Financials> financialsList = repository.findAllTransactionsForAccountAndOrderByIdDesc(accountId);
		List<FinancialsDto> dtos = new ArrayList<>();
		for(Financials financials : financialsList) {
			FinancialsDto dto = new FinancialsDto();			
			dto.setDate(financials.getDate());
			if(financials.getPaymentMethod() != null)
				dto.setPaymentMethod(financials.getPaymentMethod().getMethod());
			else
				dto.setPaymentMethod("");
			if(financials.getPaymentType() != null)
				dto.setPaymentType(financials.getPaymentType().getType());
			else
				dto.setPaymentType("");
			dto.setCredt(financials.getCredit());
			dto.setDebit(financials.getDebit());
			dto.setBalance(financials.getBalance());
			dto.setReference(financials.getReference());
			if(financials.getAccount() !=null)
				dto.setAccountId(financials.getAccount().getAccountId());
			dtos.add(dto);
		}
		return dtos;
	}
	
	public List<PaymentType> getAllPaymentTypes(){
		return paymentTypeRepository.findAll();
	}
	
	public List<PaymentMethod> getAllPaymentMethods(){
		return paymentMethodRepository.findAll();
	}
}
