package com.monarch.mabdeck.dto;

public class StandingChargeDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long standingChargeId;
	
	private String name;
	private float dailyNetCharge;
	private TariffDto tariff;
	
	public Long getStandingChargeId() {
		return standingChargeId;
	}
	public void setStandingChargeId(Long standingChargeId) {
		this.standingChargeId = standingChargeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getDailyNetCharge() {
		return dailyNetCharge;
	}
	public void setDailyNetCharge(float dailyNetCharge) {
		this.dailyNetCharge = dailyNetCharge;
	}
	public TariffDto getTariff() {
		return tariff;
	}
	public void setTariff(TariffDto tariff) {
		this.tariff = tariff;
	}
}
