package com.monarch.mabdeck.dto;

import java.sql.Date;

public class MeterReading implements IDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MeterReading(long mid, double mreading, Date rdate, long pid, Date ldate, Date usage) {
		this.mid = mid;
		this.mreading = mreading;
		this.rdate = rdate;
		this.pid = pid;
		this.ldate = ldate;
		this.usage = usage;
	}
	
	private long mid;
	private double mreading;
	private Date rdate;
	private long pid;
	private Date ldate;
	private Date usage;
	public long getMid() {
		return mid;
	}
	public double getMreading() {
		return mreading;
	}
	public Date getRdate() {
		return rdate;
	}
	public long getPid() {
		return pid;
	}
	public Date getLdate() {
		return ldate;
	}
	public Date getUsage() {
		return usage;
	}
	public void setMid(long mid) {
		this.mid = mid;
	}
	public void setMreading(double mreading) {
		this.mreading = mreading;
	}
	public void setRdate(Date rdate) {
		this.rdate = rdate;
	}
	public void setPid(long pid) {
		this.pid = pid;
	}
	public void setLdate(Date ldate) {
		this.ldate = ldate;
	}
	public void setUsage(Date usage) {
		this.usage = usage;
	}
}
