package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PropertyAccountAssociationHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long historyId;

	private Long associationId;
	private Long propertyId;
	private Long accountId;
	@Embedded
	private Audit audit;
	
	private Date startDate;;
	private Date endDate;
	
	private String tenureType;
	private int counter;
	private String message;
	private String moveOutMessage;
	public Long getHistoryId() {
		return historyId;
	}

	public Long getAssociationId() {
		return associationId;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public Long getAccountId() {
		return accountId;
	}

	public Audit getAudit() {
		return audit;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setHistoryId(Long historyId) {
		this.historyId = historyId;
	}

	public void setAssociationId(Long associationId) {
		this.associationId = associationId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMoveOutMessage() {
		return moveOutMessage;
	}

	public void setMoveOutMessage(String moveOutMessage) {
		this.moveOutMessage = moveOutMessage;
	}

	public String getTenureType() {
		return tenureType;
	}

	public void setTenureType(String tenureType) {
		this.tenureType = tenureType;
	}
}
