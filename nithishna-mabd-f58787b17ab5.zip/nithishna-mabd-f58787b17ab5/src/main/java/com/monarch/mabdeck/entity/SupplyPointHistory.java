package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SupplyPointHistory implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long supplyId;
	private String supplyType;
	private String weightFactor;
	private String technicalFactor;
	private String location;
	private Long clientId;
	private Long networkId;
	private Long propertyId;
	private Date startDate;
	private Date endDate;
	
	@Embedded
	private Audit audit;
	public Long getId() {
		return id;
	}

	public Long getSupplyId() {
		return supplyId;
	}

	public String getSupplyType() {
		return supplyType;
	}

	public String getWeightFactor() {
		return weightFactor;
	}

	public String getTechnicalFactor() {
		return technicalFactor;
	}

	public String getLocation() {
		return location;
	}

	public Long getClientId() {
		return clientId;
	}

	public Long getNetworkId() {
		return networkId;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public Audit getAudit() {
		return audit;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setSupplyId(Long supplyId) {
		this.supplyId = supplyId;
	}

	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}

	public void setWeightFactor(String weightFactor) {
		this.weightFactor = weightFactor;
	}

	public void setTechnicalFactor(String technicalFactor) {
		this.technicalFactor = technicalFactor;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}
}
