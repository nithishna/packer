package com.monarch.mabdeck.controller;

import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.UnitChargeDto;
import com.monarch.mabdeck.service.UnitChargeService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class UnitChargeController {

	private Logger logger = LoggerFactory.getLogger(UnitChargeController.class);

	@Autowired
	private UnitChargeService service;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.UNIT_CHARGE, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createUnitCharge(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody UnitChargeDto unitCharge) {
		logger.info("UnitChargeController: createUnitCharge - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("UnitChargeController: createUnitCharge - Service call, Username : " + username);
		service.create(unitCharge, username);
		logger.info("UnitChargeController: createUnitCharge - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.UNIT_CHARGE_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody UnitChargeDto getUnitChargeById(@PathVariable("unitcharge_id") Long unitChargeId)
			throws NotFoundException {
		logger.info("UnitChargeController: getUnitChargeById - Start");
		return service.read(unitChargeId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.UNIT_CHARGE, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<UnitChargeDto> getAllUnitCharges() throws NotFoundException {
		logger.info("UnitChargeController: getAllUnitCharges - Start");
		return service.readAll();
	}
}
