package com.monarch.mabdeck.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("ActionEmail")
public class ActionEmail extends Action {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String subject;
	private String body;
	private String emailIds;
	public String getSubject() {
		return subject;
	}
	public String getBody() {
		return body;
	}
	public String getEmailIds() {
		return emailIds;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public void setEmailIds(String emailIds) {
		this.emailIds = emailIds;
	}
	
}
