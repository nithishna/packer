package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Financials;

@Repository
public interface FinancialsRepository extends JpaRepository<Financials, Long>{

	@Query(value="select * from financials where account_id=?1 order by id desc", nativeQuery = true)
	List<Financials> findAllTransactionsForAccountAndOrderByIdDesc(long accountId);
	
	@Query(value="select * from financials where cast(date as date) >=?1 and cast(date as date) <= ?2", nativeQuery = true)
	List<Financials> getAllTransactionsBetweenTheDates(String fromDate, String toDate);
}
