package com.monarch.mabdeck.dto;

public class BankAccountDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	private String accountHolderName;
	private String bankName;
	private String sortCode;
	private long accountNumber;
	private BankDto bank;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getSortCode() {
		return sortCode;
	}
	public void setSortCode(String sortCode) {
		this.sortCode = sortCode;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public BankDto getBank() {
		return bank;
	}
	public void setBank(BankDto bank) {
		this.bank = bank;
	}
	
}
