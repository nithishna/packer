package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.NetworkHistory;
import com.monarch.mabdeck.repository.NetworkHistoryRepository;

@Component
public class NetworkHistoryService {

	@Resource
	private NetworkHistoryRepository historyRepository;
	
	public void updateNetworkHistory(Network network, String username) {
		if(network != null) {
			NetworkHistory history = new NetworkHistory();
			history.setAllowPrepayment(network.isAllowPrepayment());
			history.setAudit(network.getAudit());
			history.setCardNumberGeneration(network.isCardNumberGeneration());
			history.setClientId(network.getClient()!=null?network.getClient().getClientId(): null);
			history.setEstimationMethod(network.getEstimationMethod());
			history.setHubManufacturer(network.getHubManufacturer());
			history.setIin(network.getIin());
			history.setManualReview(network.isManualReview());
			history.setNetwork(network.getNetwork());
			history.setNetworkId(network.getNetworkId());
			history.setNetworkType(network.getNetworkType());
			history.setPaymentCardProvider(network.getPaymentCardProvider());
			history.setPeerComparison(network.isPeerComparison());
			history.setRecoveryPercentage(network.getRecoveryPercentage());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
