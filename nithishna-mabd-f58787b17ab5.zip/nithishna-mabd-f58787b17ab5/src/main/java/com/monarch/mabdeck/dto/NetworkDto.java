package com.monarch.mabdeck.dto;

import java.util.List;

public class NetworkDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long networkId;
	private ClientDto client;
	private String network;
	private String networkType;
	private boolean manualReview;
	private boolean peerComparison;
	private String hubManufacturer;
	private List<BandDto> band;
	private boolean allowPrepayment;
	private long iin;
	private boolean cardNumberGeneration;
	private float recoveryPercentage;
	private String estimationMethod;
	private String paymentCardProvider;
	private int numberOfProperties;
	private List<PropertyDto> property;
	private List<DataLoggerDto> dataLogger;
	public ClientDto getClient() {
		return client;
	}
	public void setClient(ClientDto client) {
		this.client = client;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public String getNetworkType() {
		return networkType;
	}
	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}
	public boolean isManualReview() {
		return manualReview;
	}
	public void setManualReview(boolean manualReview) {
		this.manualReview = manualReview;
	}
	public String getHubManufacturer() {
		return hubManufacturer;
	}
	public void setHubManufacturer(String hubManufacturer) {
		this.hubManufacturer = hubManufacturer;
	}
	public List<BandDto> getBand() {
		return band;
	}
	public void setBand(List<BandDto> band) {
		this.band = band;
	}
	public Long getNetworkId() {
		return networkId;
	}
	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}
	public boolean isAllowPrepayment() {
		return allowPrepayment;
	}
	public void setAllowPrepayment(boolean allowPrepayment) {
		this.allowPrepayment = allowPrepayment;
	}
	public long getIin() {
		return iin;
	}
	public void setIin(long iin) {
		this.iin = iin;
	}
	public boolean isCardNumberGeneration() {
		return cardNumberGeneration;
	}
	public void setCardNumberGeneration(boolean cardNumberGeneration) {
		this.cardNumberGeneration = cardNumberGeneration;
	}
	public float getRecoveryPercentage() {
		return recoveryPercentage;
	}
	public void setRecoveryPercentage(float recoveryPercentage) {
		this.recoveryPercentage = recoveryPercentage;
	}
	public String getEstimationMethod() {
		return estimationMethod;
	}
	public void setEstimationMethod(String estimationMethod) {
		this.estimationMethod = estimationMethod;
	}
	public String getPaymentCardProvider() {
		return paymentCardProvider;
	}
	public void setPaymentCardProvider(String paymentCardProvider) {
		this.paymentCardProvider = paymentCardProvider;
	}
	public List<PropertyDto> getProperty() {
		return property;
	}
	public void setProperty(List<PropertyDto> property) {
		this.property = property;
	}
	public List<DataLoggerDto> getDataLogger() {
		return dataLogger;
	}
	public void setDataLogger(List<DataLoggerDto> dataLogger) {
		this.dataLogger = dataLogger;
	}
	public int getNumberOfProperties() {
		return numberOfProperties;
	}
	public void setNumberOfProperties(int numberOfProperties) {
		this.numberOfProperties = numberOfProperties;
	}
	public boolean isPeerComparison() {
		return peerComparison;
	}
	public void setPeerComparison(boolean peerComparison) {
		this.peerComparison = peerComparison;
	}
}
