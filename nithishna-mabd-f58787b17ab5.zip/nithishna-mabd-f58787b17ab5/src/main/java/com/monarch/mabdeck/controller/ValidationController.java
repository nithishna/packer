package com.monarch.mabdeck.controller;

import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.NegativeConsumptionValidationDto;
import com.monarch.mabdeck.dto.NegativeConsumptionValidationError;
import com.monarch.mabdeck.dto.NegativeReadingValidationError;
import com.monarch.mabdeck.dto.TempDifferenceError;
import com.monarch.mabdeck.dto.TempDifferenceValidationDto;
import com.monarch.mabdeck.dto.ValidationDto;
import com.monarch.mabdeck.dto.ZeroConsumptionValidationDto;
import com.monarch.mabdeck.dto.ZeroReadingValidationError;
import com.monarch.mabdeck.service.ValidationService;
import com.monarch.mabdeck.util.Constants;

@RestController
public class ValidationController {

	@Autowired
	private ValidationService service;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NEGATIVE_VALIDATION, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, produces = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody NegativeConsumptionValidationDto createNegativeValidation(
			@RequestBody NegativeConsumptionValidationDto dto) throws InvalidFormatException {
		return this.service.createOrUpdateNegativeValidation(dto);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NEGATIVE_VALIDATION, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, produces = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody NegativeConsumptionValidationDto updateNegativeValidation(
			@RequestBody NegativeConsumptionValidationDto dto) throws InvalidFormatException {
		return this.service.createOrUpdateNegativeValidation(dto);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ZERO_VALIDATION, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, produces = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody ZeroConsumptionValidationDto createZeroConsumptionValidation(
			@RequestBody ZeroConsumptionValidationDto dto) throws InvalidFormatException {
		return this.service.createOrUpdateZeroConsumptionValidation(dto);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ZERO_VALIDATION, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, produces = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody ZeroConsumptionValidationDto updateZeroConsumptionValidation(
			@RequestBody ZeroConsumptionValidationDto dto) throws InvalidFormatException {
		return this.service.createOrUpdateZeroConsumptionValidation(dto);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.TEMP_VALIDATION, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, produces = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody TempDifferenceValidationDto createTempDifferenceValidation(
			@RequestBody TempDifferenceValidationDto dto) throws InvalidFormatException {
		return this.service.createOrUpdateTempDifferenceValidation(dto);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.TEMP_VALIDATION, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, produces = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody TempDifferenceValidationDto updateTempDifferenceValidation(
			@RequestBody TempDifferenceValidationDto dto) throws InvalidFormatException {
		return this.service.createOrUpdateTempDifferenceValidation(dto);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NOTIFICATION, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, produces = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody ValidationDto createNotification(@RequestBody ValidationDto dto)
			throws InvalidFormatException {
		return this.service.createNotification(dto);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.VALIDATION, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody ValidationDto getValidationByClientAndNetwork(@RequestParam("clientId") long clientId,
			@RequestParam("networkId") long networkId) {
		return this.service.getValidationByClientAndNetwork(clientId, networkId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.VALIDATION_BULK_APPROVE, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void approveBulk(@RequestBody List<Long> errors, @RequestParam("type")int type) throws InvalidFormatException {
		this.service.approveOrRejectBulk(errors, true, type);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.VALIDATION_APPROVE, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void approve(@RequestParam("id") long error, @RequestParam("type")int type) throws InvalidFormatException {
		this.service.approveOrReject(error, true, type);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.VALIDATION_BULK_REJECT, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void rejectBulk(@RequestBody List<Long> errors,@RequestParam("type") int type) throws InvalidFormatException {
		this.service.approveOrRejectBulk(errors, false, type);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.VALIDATION_REJECT, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void reject(@RequestParam("id") long error, @RequestParam("type") int type) throws InvalidFormatException {
		this.service.approveOrReject(error, false, type);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NEGATIVE_VALIDATION_LIST, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<NegativeConsumptionValidationError> getAllNegativeConsumptionHistory(@RequestParam("index")int index, @RequestParam("size")int pageSize) {
		return this.service.getAllNegativeConsumptionHistory(index, pageSize);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NEGATIVE_READING_LIST, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<NegativeReadingValidationError> getAllNegativeReading(@RequestParam("index")int index, @RequestParam("size")int pageSize) {
		return this.service.getAllNegativeReading(index, pageSize);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.TEMP_DIFF_VALIDATION_LIST, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<TempDifferenceError> getAllTemperatureDifferenceValidationErrors(@RequestParam("index")int index, @RequestParam("size")int pageSize) {
		return this.service.getAllTemperatureDifferenceValidationErrors(index, pageSize);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ZERO_VALIDATION_LIST, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<ZeroReadingValidationError> getAllZeroReadingValidationErrors(@RequestParam("index")int index, @RequestParam("size")int pageSize) {
		return this.service.getAllZeroReadingValidationErrors(index, pageSize);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NEGATIVE_VALIDATION_COUNT, method = RequestMethod.GET)
	public long getTotalCountOfNegativeConsumptionHistory() {
		return this.service.getTotalCountOfNegativeConsumptionHistory();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NEGATIVE_READING_COUNT, method = RequestMethod.GET)
	public long getTotalCountOfNegativeReading() {
		return this.service.getTotalCountOfNegativeReading();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.TEMP_DIFF_VALIDATION_COUNT, method = RequestMethod.GET)
	public long getTotalTemperatureDifferenceValidationErrors() {
		return this.service.getTotalTemperatureDifferenceValidationErrors();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ZERO_VALIDATION_COUNT, method = RequestMethod.GET)
	public long getTotalZeroConsumptionValidationErrors() {
		return this.service.getTotalZeroConsumptionValidationErrors();
	}
}
