package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.StandingCharge;
import com.monarch.mabdeck.entity.StandingChargeHistory;
import com.monarch.mabdeck.repository.StandingChargeHistoryRepository;

@Component
public class StandingChargeHistoryService {
	
	@Resource
	private StandingChargeHistoryRepository historyRepository;
	
	public void updateStandingChargeHistory(StandingCharge charge, String username) {
		if(charge != null) {
			StandingChargeHistory history = new StandingChargeHistory();
			history.setAudit(charge.getAudit());
			history.setDailyNetCharge(charge.getDailyNetCharge());
			history.setName(charge.getName());
			history.setStandingChargeId(charge.getStandingChargeId());
			history.setTariffId(charge.getTariff() != null? charge.getTariff().getTariffId() : null);
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
