package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.PreStatement;

@Repository
public interface PreStatementRepository extends JpaRepository<PreStatement, Long>{

	List<PreStatement> findByQueueId(Long queueId);
}