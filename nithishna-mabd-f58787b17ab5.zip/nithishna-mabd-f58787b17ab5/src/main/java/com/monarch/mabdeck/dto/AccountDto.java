package com.monarch.mabdeck.dto;

import java.util.List;

public class AccountDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long accountId;
	private ClientDto client;
	private NetworkDto network;
	private String accountNumber;
	private String paymentCardNumber;
	private AddressDto address;
	private List<BillablePersonDto> billablePerson;
	private List<NotesDto> notes;
	private boolean vulnerable;
	private boolean redFlag;
	private boolean onHold;
	private String mood;
	public ClientDto getClient() {
		return client;
	}
	public void setClient(ClientDto client) {
		this.client = client;
	}
	public NetworkDto getNetwork() {
		return network;
	}
	public void setNetwork(NetworkDto network) {
		this.network = network;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getPaymentCardNumber() {
		return paymentCardNumber;
	}
	public void setPaymentCardNumber(String paymentCardNumber) {
		this.paymentCardNumber = paymentCardNumber;
	}	
	public AddressDto getAddress() {
		return address;
	}
	public void setAddress(AddressDto address) {
		this.address = address;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public List<BillablePersonDto> getBillablePerson() {
		return billablePerson;
	}
	public void setBillablePerson(List<BillablePersonDto> billablePerson) {
		this.billablePerson = billablePerson;
	}
	public List<NotesDto> getNotes() {
		return notes;
	}
	public void setNotes(List<NotesDto> notes) {
		this.notes = notes;
	}
	public boolean isVulnerable() {
		return vulnerable;
	}
	public boolean isRedFlag() {
		return redFlag;
	}
	public boolean isOnHold() {
		return onHold;
	}
	public String getMood() {
		return mood;
	}
	public void setVulnerable(boolean vulnerable) {
		this.vulnerable = vulnerable;
	}
	public void setRedFlag(boolean redFlag) {
		this.redFlag = redFlag;
	}
	public void setOnHold(boolean onHold) {
		this.onHold = onHold;
	}
	public void setMood(String mood) {
		this.mood = mood;
	}
}
