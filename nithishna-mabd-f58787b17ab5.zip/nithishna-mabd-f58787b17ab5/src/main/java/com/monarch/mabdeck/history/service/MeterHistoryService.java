package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Meter;
import com.monarch.mabdeck.entity.MeterHistory;
import com.monarch.mabdeck.repository.MeterHistoryRepository;

@Component
public class MeterHistoryService {

	@Resource
	private MeterHistoryRepository historyRepository;
	
	public void updateMeterHistory(Meter meter, String username) {
		if(meter != null) {
			MeterHistory history = new MeterHistory();
			history.setAudit(meter.getAudit());
			history.setChildMeter(meter.isChildMeter());
			history.setClientId(meter.getClient() != null? meter.getClient().getClientId() : null);
			history.setEndDate(meter.getEndDate());
			history.setInitialReading(meter.getInitialReading());
			history.setLocation(meter.getLocation());
			history.setManufacturer(meter.getManufacturer());
			history.setMeterId(meter.getMeterId());
			history.setMeterType(meter.getMeterType());
			history.setModel(meter.getModel());
			history.setNetworkId(meter.getNetwork()!=null? meter.getNetwork().getNetworkId() : null);
			history.setOffset(meter.getOffset());
			history.setParentSerialNumber(meter.getParentSerialNumber());
			history.setPropertyId(meter.getProperty() != null? meter.getProperty().getPropertyId() : null);
			history.setPulseInputNumber(meter.getPulseInputNumber());
			history.setReadingFrequency(meter.getReadingFrequency());
			history.setReadingImportFactor(meter.getReadingImportFactor());
			history.setSerialNumber(meter.getSerialNumber());
			history.setStartDate(meter.getStartDate());
			history.setSupplyId(meter.getSupply()!=null?meter.getSupply().getSupplyId(): null);
			history.setUnit(meter.getUnit());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
