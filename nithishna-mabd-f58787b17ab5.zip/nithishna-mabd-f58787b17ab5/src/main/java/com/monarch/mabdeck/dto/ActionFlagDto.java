package com.monarch.mabdeck.dto;

public class ActionFlagDto extends ActionDto {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean flag;
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
}
