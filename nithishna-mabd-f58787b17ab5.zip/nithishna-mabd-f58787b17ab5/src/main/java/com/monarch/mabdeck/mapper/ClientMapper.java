package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.ClientDto;
import com.monarch.mabdeck.entity.Client;

@Mapper(uses = {AddressMapper.class, MainContactMapper.class, BankAccountMapper.class, CustomerServiceContactMapper.class})
public abstract class ClientMapper implements IBaseMapper<ClientDto, Client>{
	public static final ClientMapper INSTANCE = Mappers.getMapper(ClientMapper.class);
	
	@Mappings({
		@Mapping(target = "network", ignore = true),
		@Mapping(target = "band", ignore = true),
		@Mapping(target = "property", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract Client convertToEntity(ClientDto dto);
	

	@Mappings({
		@Mapping(target = "network", ignore = true),
		@Mapping(target = "band", ignore = true),
		@Mapping(target = "numberOfNetworks", ignore = true),
		@Mapping(target = "property", ignore = true)
	})
	public abstract ClientDto convertToDTO(Client entity);
	
}