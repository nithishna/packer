package com.monarch.mabdeck.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.ActionFlag;

@Repository
public interface ActionFlagRepository extends JpaRepository<ActionFlag, Long>{

}
