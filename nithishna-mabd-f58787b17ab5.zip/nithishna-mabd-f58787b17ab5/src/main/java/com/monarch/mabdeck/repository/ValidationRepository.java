package com.monarch.mabdeck.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Validation;

@Repository
public interface ValidationRepository extends JpaRepository<Validation, Long>{

	
	Validation findByClientClientIdAndNetworkNetworkId(long clientId, long networkId);
	
	
	Validation findByNetworkNetworkId(long networkId);
}
