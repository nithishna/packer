package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Network;

@Repository
public interface NetworkRepository extends JpaRepository<Network, Long>{

	@Query(value="select distinct n.* from network n, data_logger d where n.network_id = d.network_id and n.client_id = d.client_id ",nativeQuery = true)
	List<Network> getAllNetworksForDataLogger();
	
	@Query(value="select network from network where network_id = ?1", nativeQuery = true)
	String getNetworkNameById(Long networkId);
	
	@Query(value="select * from network where client_id=?1", nativeQuery = true)
	List<Network> getAllNetworksForClient(long clientID);
	
	@Query(value="select * from network where network like %:name%", nativeQuery = true)
	List<Network> getAllNetworkByName(@Param("name")String name);
	
	@Query(value="SELECT \r\n" + 
			"network_id, hub_manufacturer, manual_review, network, network_type, client_id, allow_prepayment, card_number_generation, \r\n" + 
			"iin, recovery_percentage, estimation_method, payment_card_provider, peer_comparison, created_date, created_user, updated_date, updated_user\r\n" + 
			"from\r\n" + 
			"(select n.*, RowNum = row_number() OVER ( order by n.network_id) \r\n" + 
			"FROM   network n)t\r\n" + 
			"where t.RowNum between ?1 and ?2", nativeQuery = true)
	List<Network> getAllNetworksByRange(int startIndex, int endindex);
	
	@Query(value="select count(*) from network", nativeQuery = true)
	long getCount();
	
	Network findByNetwork(String name);
}