package com.monarch.mabdeck.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ZeroConsumptionHistory implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private long meterId;
	private String validationType;
	private BigDecimal zeroReading;
	private Date readingDate;
	private long meterReadingId;
	private boolean deleted;
	public long getId() {
		return id;
	}
	public long getMeterId() {
		return meterId;
	}
	public String getValidationType() {
		return validationType;
	}
	public BigDecimal getZeroReading() {
		return zeroReading;
	}
	public Date getReadingDate() {
		return readingDate;
	}
	public long getMeterReadingId() {
		return meterReadingId;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setMeterId(long meterId) {
		this.meterId = meterId;
	}
	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}
	public void setZeroReading(BigDecimal zeroReading) {
		this.zeroReading = zeroReading;
	}
	public void setReadingDate(Date readingDate) {
		this.readingDate = readingDate;
	}
	public void setMeterReadingId(long meterReadingId) {
		this.meterReadingId = meterReadingId;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
}
