package com.monarch.mabdeck.service;

import static com.monarch.mabdeck.util.Constants.boldFont;
import static com.monarch.mabdeck.util.Constants.dataFont;
import static com.monarch.mabdeck.util.Constants.dataWhiteFont;
import static com.monarch.mabdeck.util.Constants.dataWhiteFontLarge;
import static com.monarch.mabdeck.util.Constants.headerFont;
import static com.monarch.mabdeck.util.Constants.smallBlueFont;
import static com.monarch.mabdeck.util.Constants.smallBoldFont;
import static com.monarch.mabdeck.util.Constants.smallFont;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.itextpdf.awt.PdfGraphics2D;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.Barcode128;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.Base64;
import com.monarch.mabdeck.dto.AddressDto;
import com.monarch.mabdeck.dto.PreStatementDto;
import com.monarch.mabdeck.dto.PreStatementDto.PreStandingChargeDto;
import com.monarch.mabdeck.dto.PreStatementDto.PreStatmentEnergyDto;
import com.monarch.mabdeck.dto.PreStatementDto.ReadingsDto;
import com.monarch.mabdeck.dto.PropertyLimited;
import com.monarch.mabdeck.dto.StatementDto;
import com.monarch.mabdeck.dto.StatementGenerationInput;
import com.monarch.mabdeck.dto.StatementQueueDto;
import com.monarch.mabdeck.entity.Account;
import com.monarch.mabdeck.entity.AccountBalance;
import com.monarch.mabdeck.entity.Address;
import com.monarch.mabdeck.entity.AdminCharge;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.BillablePerson;
import com.monarch.mabdeck.entity.Configuration;
import com.monarch.mabdeck.entity.Financials;
import com.monarch.mabdeck.entity.Meter;
import com.monarch.mabdeck.entity.MeterReading;
import com.monarch.mabdeck.entity.PreReadings;
import com.monarch.mabdeck.entity.PreStandingCharge;
import com.monarch.mabdeck.entity.PreStatement;
import com.monarch.mabdeck.entity.PreStatementEnergy;
import com.monarch.mabdeck.entity.Property;
import com.monarch.mabdeck.entity.PropertyAccountAssociation;
import com.monarch.mabdeck.entity.StandingCharge;
import com.monarch.mabdeck.entity.Statement;
import com.monarch.mabdeck.entity.StatementQueue;
import com.monarch.mabdeck.entity.Tariff;
import com.monarch.mabdeck.entity.UnitCharge;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.repository.AccountBalanceRepository;
import com.monarch.mabdeck.repository.AccountRepository;
import com.monarch.mabdeck.repository.AdminChargeRepository;
import com.monarch.mabdeck.repository.BillablePersonRepository;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.ConfigurationRepository;
import com.monarch.mabdeck.repository.FinancialsRepository;
import com.monarch.mabdeck.repository.MeterReadingRepository;
import com.monarch.mabdeck.repository.MeterRepository;
import com.monarch.mabdeck.repository.PaymentMethodRepository;
import com.monarch.mabdeck.repository.PreStatementRepository;
import com.monarch.mabdeck.repository.PropertyAccountAssociationRepository;
import com.monarch.mabdeck.repository.PropertyRepository;
import com.monarch.mabdeck.repository.StatementQueueRepository;
import com.monarch.mabdeck.repository.StatementRepository;
import com.monarch.mabdeck.repository.TariffRepository;

/**
 * @author NAppathurai This is the service which generates the statement.
 *
 */
@Component
public class StatementService extends CommonServiceImpl<StatementDto, Statement> {

	@Resource
	private StatementRepository repository;

	@Resource
	private AccountRepository accountRepository;

	@Resource
	private AccountBalanceRepository accountBalanceRepository;

	@Resource
	private ClientRepository clientRepository;

	@Resource
	private ConfigurationRepository configRepository;

	@Resource
	private PropertyRepository propertyRepository;

	@Resource
	private MeterReadingRepository meterReadingRepository;

	@Resource
	private PropertyAccountAssociationRepository propertyAccountAssociationRepository;

	@Resource
	private MeterRepository meterRepository;

	@Resource
	private TariffRepository tariffRepository;

	@Resource
	private AdminChargeRepository adminChargeRepository;

	@Resource
	private PreStatementRepository preStatementRepository;

	@Resource
	private StatementQueueRepository statementQueueRepository;

	@Resource
	private BillablePersonRepository billablePersonRepository;

	@Resource
	private FinancialsRepository financialRepository;

	@Resource
	private PaymentMethodRepository paymentRepository;

	@Override
	public JpaRepository<Statement, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<StatementDto, Statement> getMapper() {
		return null;
	}

	@Override
	public void updateAudit(Statement entity, String username) {
		if (entity != null) {
			Calendar cal = Calendar.getInstance();
			if (entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			} else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}
	}

	public byte[] downloadPdf(long statementId) throws IOException {
		Statement statement = repository.findOne(statementId);
		StringBuilder pathBuilder = new StringBuilder("C:\\Downloads\\pdf\\output\\");
		if (statement == null || statement.getFileName() == null)
			throw new IOException("No file present");
		pathBuilder.append(statement.getFileName());
		Path pdfPath = Paths.get(pathBuilder.toString());
		byte[] pdf = Files.readAllBytes(pdfPath);
		return pdf;
	}

	/* Unapproved statements */
	public List<StatementDto> getAllStatements() {
		List<Statement> statements = repository.getRecent20Statements();
		List<StatementDto> dtos = new ArrayList<>();
		if (statements == null || statements.isEmpty())
			return dtos;
		for (Statement statement : statements) {
			StatementDto dto = new StatementDto();
			convertEntityToDto(statement, dto);
			dtos.add(dto);
		}
		return dtos;
	}

	public List<StatementDto> getAllApprovedStatements() {
		List<Statement> statements = repository.getRecent20ApprovedStatements();
		List<StatementDto> dtos = new ArrayList<>();
		if (statements == null || statements.isEmpty())
			return dtos;
		for (Statement statement : statements) {
			StatementDto dto = new StatementDto();
			convertEntityToDto(statement, dto);
			dtos.add(dto);
		}
		return dtos;
	}

	private void convertEntityToDto(Statement statement, StatementDto dto) {
		if (statement.getAccount() != null) {
			BillablePerson person = billablePersonRepository
					.getBillablePersonForAccountId(statement.getAccount().getAccountId());
			StringBuilder builder = new StringBuilder();
			if (person.getFirstName() != null && !person.getFirstName().equals(""))
				builder.append(person.getFirstName()).append(",");
			builder.append(person.getLastName());
			dto.setBillablePerson(builder.toString());
		}
		if (statement.getProperty() != null) {
			Property property = propertyRepository.findOne(statement.getProperty().getPropertyId());
			if (property != null && property.getClient() != null)
				dto.setClient(property.getClient().getClientName());
			if (property != null && property.getNetwork() != null)
				dto.setNetwork(property.getNetwork().getNetwork());
			if (property.getAddress() != null) {
				Address ad = property.getAddress();
				StringBuilder builder = new StringBuilder();
				if (ad.getAddressLine1() != null && !ad.getAddressLine1().isEmpty()) {
					builder.append(ad.getAddressLine1());
				}
				if (ad.getAddressLine2() != null && !ad.getAddressLine2().isEmpty()) {
					builder.append(",").append(ad.getAddressLine2());
				}
				if (ad.getAddressLine3() != null && !ad.getAddressLine3().isEmpty()) {
					builder.append(",").append(ad.getAddressLine3());
				}
				if (ad.getPostCode() != null && !ad.getPostCode().isEmpty()) {
					builder.append(",").append(ad.getPostCode());
				}
				dto.setPropertyAddress(builder.toString());
			}
		}
		dto.setGrossAmount(statement.getGrossAmount());
		dto.setNetAmount(statement.getNetAmount());
		dto.setFileName(statement.getFileName());
		dto.setStatementId(statement.getStatementId());
		dto.setVat(statement.getVat());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		dto.setFromDate(formatter.format(statement.getFromDate()));
		dto.setToDate(formatter.format(statement.getToDate()));
		dto.setGenerationDate(formatter.format(statement.getGenerationDate()));
	}

	public List<PreStatementDto> fetchPreStatementsGeneratedForQueueByID(long queueId) {
		List<PreStatementDto> dtos = new ArrayList<>();
		List<PreStatement> entities = preStatementRepository.findByQueueId(queueId);
		String pattern = "MM-dd-yyyy";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		for (PreStatement entity : entities) {
			PreStatementDto dto = new PreStatementDto();
			dto.setPreStatementId(entity.getPreStatementId());
			dto.setQueueId(entity.getQueueId());
			if (entity.getAccountId() != null) {
				BillablePerson person = billablePersonRepository.getBillablePersonForAccountId(entity.getAccountId());
				StringBuilder builder = new StringBuilder();
				if (person.getFirstName() != null && !person.getFirstName().equals(""))
					builder.append(person.getFirstName()).append(",");
				builder.append(person.getLastName());
				dto.setBillablePerson(builder.toString());
			}
			if (entity.getPropertyAddress() != null) {
				AddressDto addressDto = new AddressDto();
				addressDto.setAddressLine1(entity.getPropertyAddress().getAddressLine1());
				addressDto.setAddressLine2(entity.getPropertyAddress().getAddressLine2());
				addressDto.setAddressLine3(entity.getPropertyAddress().getAddressLine3());
				addressDto.setPostCode(entity.getPropertyAddress().getPostCode());
				addressDto.setCountry(entity.getPropertyAddress().getCountry());
				dto.setPropertyAddress(addressDto);
			}
			if (entity.isInvalid()) {
				if (entity.getCreationDate() != null)
					dto.setGenerationDate(simpleDateFormat.format(entity.getCreationDate()));
				dto.setValid(true);
				dto.setValidityReason(entity.getValidityReason());
			} else {
				if (entity.getPropertyId() != null) {
					Property property = propertyRepository.findOne(entity.getPropertyId());
					if (property != null && property.getClient() != null)
						dto.setClientName(property.getClient().getClientName());
					if (property != null && property.getNetwork() != null)
						dto.setNetworkName(property.getNetwork().getNetwork());
				}
				dto.setFromDate(entity.getFromDate());
				dto.setToDate(entity.getToDate());
				dto.setAdminCharge(entity.getAdminCharge());
				dto.setTotalAdminCharge(entity.getTotalAdminCharge());
				dto.setTotalCharge(entity.getTotalCharge());
				dto.setNoOfDays(entity.getNoOfDays());

				if (entity.getCreationDate() != null)
					dto.setGenerationDate(simpleDateFormat.format(entity.getCreationDate()));
				if (entity.getPreStatementEnergy() != null && !entity.getPreStatementEnergy().isEmpty()) {
					List<PreStatmentEnergyDto> energyList = new ArrayList<>();
					dto.setEnergyList(energyList);
					updatePreStatementEnergyDetails(entity.getPreStatementEnergy(), energyList);
				}
			}
			dtos.add(dto);
		}
		return dtos;
	}

	private void updatePreStatementEnergyDetails(List<PreStatementEnergy> prestatementEnergy,
			List<PreStatmentEnergyDto> energyDtoList) {
		String pattern = "MM-dd-yyyy";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		for (PreStatementEnergy energy : prestatementEnergy) {
			PreStatmentEnergyDto dto = new PreStatmentEnergyDto();
			dto.setAdminCharge(energy.getAdminCharge());
			dto.setAdminVat(dto.getAdminVat());
			dto.setEnergy(energy.getEnergy());
			dto.setPreStatementEnergyId(energy.getPreStatementEnergyId());
			dto.setTotalCost(energy.getTotalUnitsUsed());
			dto.setTotalUnitsUsed(energy.getTotalUnitsUsed());
			dto.setUnitPricePerUnit(energy.getUnitPricePerUnit());
			dto.setUnitChargeVat(energy.getUnitChargeVat());
			dto.setUnitPricePerUnit(energy.getUnitPricePerUnit());
			dto.setUnitsUsed(energy.getUnitsUsed());
			dto.setTotalUnitsUsed(energy.getTotalUnitsUsed());
			List<PreReadings> readingsEntity = energy.getReading();
			if (readingsEntity != null) {
				List<ReadingsDto> readings = new ArrayList<>();
				for (PreReadings reading : readingsEntity) {
					ReadingsDto readingDto = new ReadingsDto();
					readingDto.setReadingDate(simpleDateFormat.format(reading.getReadingDateTime()));
					readingDto.setReadingId(reading.getReadingId());
					readingDto.setValue(reading.getValue());
					readings.add(readingDto);
				}
				dto.setReading(readings);
			}
			List<PreStandingCharge> standingCharges = energy.getStandingChargeList();
			if (standingCharges != null) {
				List<PreStandingChargeDto> standingChargeDtos = new ArrayList<>();
				for (PreStandingChargeDto standingCharge : standingChargeDtos) {
					PreStandingChargeDto standingChargeDto = new PreStandingChargeDto();
					standingChargeDto.setNoOfDays(standingCharge.getNoOfDays());
					standingChargeDto.setStandingCharge(standingCharge.getStandingCharge());
					standingChargeDto.setStandingChargeId(standingCharge.getStandingChargeId());
					standingChargeDto.setStandingChargeName(standingCharge.getStandingChargeName());
					standingChargeDto.setTotalStandingCharge(standingCharge.getTotalStandingCharge());
					standingChargeDtos.add(standingChargeDto);
				}
				dto.setStandingChargeList(standingChargeDtos);
			}
			energyDtoList.add(dto);
		}
	}

	public void deleteFromQueue(Long queueId, String username) {
		StatementQueue entity = statementQueueRepository.findOne(queueId);
		if (entity == null)
			return;
		entity.setDeleted(true);
		Audit audit = entity.getAudit();
		Calendar cal = Calendar.getInstance();
		if (audit == null) {
			audit = new Audit();
			audit.setCreatedUser(username);
			audit.setCreatedDate(new Date(cal.getTime().getTime()));
			entity.setAudit(audit);
		}
		audit.setUpdatedDate(new Date(cal.getTime().getTime()));
		audit.setUpdatedUser(username);
	}

	public void approveStatement(long statementId) {
		Statement statement = repository.findOne(statementId);
		statement.setApproved(true);
		Property property = statement.getProperty();
		if (isGreaterThan(statement.getToDate(), property.getLastBilledDate())) {
			property.setLastBilledDate(statement.getToDate());
		}
	}

	public void unapproveStatement(long statementId) {
		Statement statement = repository.findOne(statementId);
		statement.setApproved(false);
		statement.setDeleted((byte) 1);
	}

	public void updateStatus(Long queueId, String username) {

		List<PreStatement> preStatementList = preStatementRepository.findByQueueId(queueId);
		for (PreStatement preStatement : preStatementList) {
			preStatement.setDeleted((byte) 1);
			preStatement.setQueueId(new Long(0));
		}

		List<Statement> statements = repository.findByQueueId(queueId);
		for (Statement statement : statements) {
			if (statement.isApproved())
				continue;
			statement.setDeleted((byte) 1);
			statement.setQueueId(0l);
		}

		StatementQueue entity = statementQueueRepository.findOne(queueId);
		if (entity == null)
			return;
		entity.setStatus("Pending");
		entity.setMessage("");
		Audit audit = entity.getAudit();
		Calendar cal = Calendar.getInstance();
		if (audit == null) {
			audit = new Audit();
			audit.setCreatedUser(username);
			audit.setCreatedDate(new Date(cal.getTime().getTime()));
			entity.setAudit(audit);
		}
		audit.setUpdatedDate(new Date(cal.getTime().getTime()));
		audit.setUpdatedUser(username);
	}

	public List<StatementQueueDto> fetchStatementQueueDetails() {
		List<StatementQueue> entities = statementQueueRepository
				.findByStatusAndDeleted(Arrays.asList("Pending", "Completed", "Error"), false);
		List<StatementQueueDto> dtos = new ArrayList<>();
		for (StatementQueue entity : entities) {
			StatementQueueDto dto = new StatementQueueDto();
			if (entity.getAudit() != null) {
				String pattern = "MM-dd-yyyy";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
				if (entity.getAudit().getCreatedDate() != null)
					dto.setCreatedDate(simpleDateFormat.format(entity.getAudit().getCreatedDate()));
			}
			if (entity.getAudit() != null)
				dto.setCreatedUser(entity.getAudit().getCreatedUser());
			dto.setId(entity.getId());
			dto.setMessage(entity.getMessage());
			dto.setStatus(entity.getStatus());
			String property = entity.getPropertyIds();
			List<PropertyLimited> props = new ArrayList<>();
			if (property != null && !property.equals("")) {
				String[] properties = property.split(",");
				for (String prop : properties) {
					Long propertyId = Long.parseLong(prop);
					Property propEntity = propertyRepository.findOne(propertyId);
					PropertyLimited propDto = new PropertyLimited();
					propDto.setPid(propEntity.getPropertyId());
					if (propEntity.getAddress() != null) {
						propDto.setAddressLine1(propEntity.getAddress().getAddressLine1());
						propDto.setAddressLine2(propEntity.getAddress().getAddressLine2());
						propDto.setAddressLine3(propEntity.getAddress().getAddressLine3());
						propDto.setPostCode(propEntity.getAddress().getPostCode());
					}
					props.add(propDto);
				}
			}
			dto.setProperty(props);
			dtos.add(dto);
		}
		return dtos;
	}

	public String generatePreStatementQueue(StatementGenerationInput input, String username) {
		if (input == null)
			return "invalid input";
		StatementQueue queue = new StatementQueue();
		queue.setBillDate(input.getBillDate());
		queue.setStatus("Pending");
		if (input.getClientIDs() != null && !input.getClientIDs().isEmpty()) {
			queue.setClientIds(StringUtils.join(input.getClientIDs(), ','));
		}
		if (input.getNetworkIDs() != null && !input.getNetworkIDs().isEmpty()) {
			queue.setNetworkIds(StringUtils.join(input.getNetworkIDs(), ','));
		}
		if (input.getPropertyIDs() != null && !input.getPropertyIDs().isEmpty()) {
			queue.setPropertyIds(StringUtils.join(input.getPropertyIDs(), ','));
		}
		this.updateAudit(queue, username);
		statementQueueRepository.saveAndFlush(queue);
		return "Success";
	}

	private void updateAudit(StatementQueue queue, String username) {
		Audit audit = new Audit();
		Calendar cal = Calendar.getInstance();
		audit.setCreatedUser(username);
		Date date = new Date(cal.getTime().getTime());
		audit.setCreatedDate(date);
		queue.setAudit(audit);
	}

	public String generatePreStatement(StatementGenerationInput input, String username) throws Exception {
		if (input.getBillDate() == null)
			return "Invalid Bill date";

		List<Property> propertyList = new ArrayList<>();
		List<PreStatement> preStatementList = new ArrayList<>();

		if (input.getPropertyIDs() != null && !(input.getPropertyIDs().isEmpty())) {
			propertyList = propertyRepository.getRequestedPropertiesByPropertyIds(input.getPropertyIDs());
		} else if (input.getNetworkIDs() != null && !(input.getNetworkIDs().isEmpty())) {
			propertyList = propertyRepository.getRequestedPropertiesByNetworkIds(input.getNetworkIDs());
		} else if (input.getClientIDs() != null && !(input.getClientIDs().isEmpty())) {
			propertyList = propertyRepository.getRequestedPropertiesByClientIds(input.getClientIDs());
		} else {
			return "Invalid input";
		}

		for (Property property : propertyList) {
			if (property.getLastBilledDate() == null) {
				preStatementList.add(generatePreStatment(property, null, "No Last Billed date", username));
				continue;
			}
			String pattern = "yyyy-MM-dd";
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			String lastBilledDate = simpleDateFormat.format(property.getLastBilledDate());
			String billEndDate = simpleDateFormat.format(input.getBillDate());
			Date lastBilled = property.getLastBilledDate();
			Date statementEndDate = input.getBillDate();
			lastBilled = new java.sql.Date(lastBilled.getTime() + 24 * 60 * 60 * 1000);
			List<PropertyAccountAssociation> propertyAccountAssociation = propertyAccountAssociationRepository
					.getAllPropertyAccountAssociation(lastBilledDate, billEndDate, property.getPropertyId());

			/* If the bill is already generated for this property ignore */
			if (isGreaterThan(property.getLastBilledDate(), input.getBillDate())
					|| isEqualTo(property.getLastBilledDate(), input.getBillDate()))
				continue;

			/* Remove accounts which are meant to be deleted */
			for (int i = 0; i < propertyAccountAssociation.size();) {
				PropertyAccountAssociation account = propertyAccountAssociation.get(i);
				/*
				 * If an account is deleted and the status is completed then it is a valid
				 * account
				 */
				if (account.isDeleted() && (account.getMoveOutStatus() == null
						|| !account.getMoveOutStatus().equalsIgnoreCase("Completed"))) {
					propertyAccountAssociation.remove(i);
				} else
					i++;
			}

			if (propertyAccountAssociation == null || propertyAccountAssociation.isEmpty()) {

				if (generateStatementForOwners(lastBilled, input, property, preStatementList, username) == null)
					continue;

				/*
				 * Date tempBill = new Date(lastBilled.getTime() + 24 * 60 * 60 * 1000);
				 * List<PropertyAccountAssociation> accounts =
				 * propertyAccountAssociationRepository
				 * .getSegregatedOwnersForProperty(lastBilledDate, billEndDate,
				 * property.getPropertyId()); if (accounts == null || accounts.isEmpty()) {
				 * String errorMessage = "No owner for property id:" + property.getPropertyId()
				 * + ", StartDate:" + lastBilledDate + ",endDate:" + billEndDate;
				 * preStatementList.add(generatePreStatment(property, null, errorMessage));
				 * continue; } for (PropertyAccountAssociation account : accounts) {
				 * if(tempBill==null) break; if (isGreaterThan(account.getStartDate(),
				 * tempBill)) { String errorMessage = "No owner for property id:" +
				 * property.getPropertyId() + ", StartDate: " +
				 * simpleDateFormat.format(tempBill) + ", EndDate: " +
				 * simpleDateFormat.format(account.getStartDate());
				 * preStatementList.add(generatePreStatment(property, null, errorMessage));
				 * break; } else if (isLessThan(account.getStartDate(), tempBill) ||
				 * isEqualTo(account.getStartDate(), tempBill)) { PreStatement statement = new
				 * PreStatement(); if (account.getEndDate() == null ||
				 * isGreaterThan(account.getEndDate(), input.getBillDate()) ||
				 * isEqualTo(account.getEndDate(), input.getBillDate())) {
				 * generateStatement(statement, tempBill, input.getBillDate(), property,
				 * account.getAccount().getAccountId(), username);
				 * preStatementList.add(statement); tempBill = null; }else
				 * if(isLessThan(account.getEndDate(), input.getBillDate())) {
				 * generateStatement(statement, tempBill, account.getEndDate(), property,
				 * account.getAccount().getAccountId(), username);
				 * preStatementList.add(statement); tempBill = new
				 * java.sql.Date(account.getEndDate().getTime() + 24 * 60 * 60 * 1000); } } }
				 */

			} else {
				for (PropertyAccountAssociation account : propertyAccountAssociation) {
					PreStatement statement = new PreStatement();
					if (lastBilled == null)
						break;
					if (account.getStartDate() == null)
						continue;
					if (isGreaterThan(account.getStartDate(), lastBilled)) {
						String startDate = simpleDateFormat.format(account.getStartDate());
						List<PropertyAccountAssociation> owners = propertyAccountAssociationRepository
								.getAllOwnersForProperty(lastBilledDate, startDate, property.getPropertyId());
						if (owners == null || owners.isEmpty()) {
							/*
							 * Check if there is more than one owner associated with the property during the
							 * period.
							 */
							if (generateStatementForOwners(lastBilled, input, property, preStatementList,
									username) == null)
								break;
							/*
							 * String errorMessage = "No owner for property id:" + property.getPropertyId()
							 * + ", StartDate:" + lastBilledDate + ",endDate:" + startDate;
							 * preStatementList.add(generatePreStatment(property, null, errorMessage));
							 * noOwner = true;
							 */
						} else {
							PropertyAccountAssociation deletedOwner = null;
							PropertyAccountAssociation liveOwner = null;
							for (PropertyAccountAssociation owner : owners) {
								if (owner.isDeleted())
									deletedOwner = owner;
								else
									liveOwner = owner;
							}
							PropertyAccountAssociation owner = liveOwner == null ? deletedOwner : liveOwner;
							if (owner.getEndDate() == null || isGreaterThan(owner.getEndDate(), statementEndDate)
									|| isEqualTo(owner.getEndDate(), statementEndDate)) {
								// Generate preStatement for StartDate and BillEndDate
								generateStatement(statement, lastBilled, input.getBillDate(), property,
										account.getAccount().getAccountId(), username);
								preStatementList.add(statement);
								lastBilled = null;
							} else {
								preStatementList.add(generatePreStatment(property, null,
										"Invalid Owner account details found while processing, Association id= "
												+ account.getAssociationId(),
										username));
								lastBilled = null;
							}
						}
					} else if (isLessThan(account.getStartDate(), lastBilled)
							|| isEqualTo(account.getStartDate(), lastBilled)) {
						if (account.getEndDate() == null) {
							if (!account.isFinalStatement()) {
								// Generate Prestatement for LastBilled, BillEndDate
								generateStatement(statement, lastBilled, input.getBillDate(), property,
										account.getAccount().getAccountId(), username);
								preStatementList.add(statement);
								lastBilled = null;
							} else {
								preStatementList.add(generatePreStatment(property, null,
										"Final Statement generated without end date for Association id= "
												+ account.getAssociationId(),
										username));
								lastBilled = null;
							}
						} else if (isLessThan(account.getEndDate(), statementEndDate)) {
							if (!account.isFinalStatement()) {
								// Generate Prestatement for LastBilled, account.getEndDate()
								generateStatement(statement, lastBilled, account.getEndDate(), property,
										account.getAccount().getAccountId(), username);
								preStatementList.add(statement);
							} else {
								if (account.getAccount() != null)
									preStatementList.add(generatePreStatment(property, null,
											"Final Statement already generated for Accound id = "
													+ account.getAccount().getAccountId(),
											username));
								else
									preStatementList.add(generatePreStatment(property, null,
											"Final Statement already generated for Association id = "
													+ account.getAssociationId(),
											username));
							}
							lastBilled = new java.sql.Date(account.getEndDate().getTime() + 24 * 60 * 60 * 1000);
						} else if (isGreaterThan(account.getEndDate(), statementEndDate)
								|| isEqualTo(account.getEndDate(), statementEndDate)) {
							if (!account.isFinalStatement()) {
								// Generate Prestatement for LastBilled, statementEndDate
								generateStatement(statement, lastBilled, statementEndDate, property,
										account.getAccount().getAccountId(), username);
								preStatementList.add(statement);
							} else {
								if (account.getAccount() != null)
									preStatementList.add(generatePreStatment(property, null,
											"Final Statement already generated for Accound id = "
													+ account.getAccount().getAccountId(),
											username));
								else
									preStatementList.add(generatePreStatment(property, null,
											"Final Statement already generated for Association id = "
													+ account.getAssociationId(),
											username));
							}
							lastBilled = null;
						}
					} /*
						 * else { break; }
						 */
				}
			}
		}
		for (PreStatement preStat : preStatementList) {
			preStat.setQueueId(input.getQueueId());
			if (preStat.getPropertyId() != null && preStat.getPropertyId() > 0) {
				Property property = propertyRepository.findOne(preStat.getPropertyId());
				preStat.setLastBillDate(property.getLastBilledDate());
			}
			preStatementRepository.save(preStat);
			List<PreStatementEnergy> energyList = preStat.getPreStatementEnergy();
			if (energyList == null)
				continue;
			for (PreStatementEnergy energy : energyList) {
				energy.setPreStatement(preStat);
				List<PreReadings> readings = energy.getReading();
				List<PreStandingCharge> stat = energy.getStandingChargeList();
				if (readings != null) {
					for (PreReadings reading : readings) {
						reading.setPreStatementEnergy(energy);
					}
				}
				if (stat != null) {
					for (PreStandingCharge charge : stat) {
						charge.setPreStatement(energy);
					}
				}
			}
		}
		return "Statement generated successfully";
	}

	private String generateStatementForOwners(Date lastBilled, StatementGenerationInput input, Property property,
			List<PreStatement> preStatementList, String username) throws Exception {
		Calendar cal = Calendar.getInstance();
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String lastBilledDate = simpleDateFormat.format(lastBilled);
		// Date tempBill = lastBilled;
		// new Date(lastBilled.getTime() + 24 * 60 * 60 * 1000);
		String billEndDate = simpleDateFormat.format(input.getBillDate());
		List<PropertyAccountAssociation> accounts = propertyAccountAssociationRepository
				.getSegregatedOwnersForProperty(lastBilledDate, billEndDate, property.getPropertyId());
		if (accounts == null || accounts.isEmpty()) {
			String errorMessage = "No owner for property id:" + property.getPropertyId() + ", StartDate:"
					+ lastBilledDate + ",endDate:" + billEndDate;
			preStatementList.add(generatePreStatment(property, null, errorMessage, username));
			return null;
		}
		for (PropertyAccountAssociation account : accounts) {
			if (lastBilled == null)
				break;
			if (isGreaterThan(account.getStartDate(), lastBilled)) {
				String errorMessage = "No owner for property id:" + property.getPropertyId() + ", StartDate: "
						+ simpleDateFormat.format(lastBilled) + ", EndDate: "
						+ simpleDateFormat.format(account.getStartDate());
				preStatementList.add(generatePreStatment(property, null, errorMessage, username));
				/*
				 * If I don't break it here it will be difficult to recreate the same scenario
				 * when trying to regenerate the statement
				 */
				return null;
			} else if (isLessThan(account.getStartDate(), lastBilled)
					|| isEqualTo(account.getStartDate(), lastBilled)) {
				PreStatement statement = new PreStatement();
				statement.setCreatedUser("username");
				statement.setCreationDate(new Date(cal.getTime().getTime()));
				if (account.getEndDate() == null || isGreaterThan(account.getEndDate(), input.getBillDate())
						|| isEqualTo(account.getEndDate(), input.getBillDate())) {
					generateStatement(statement, lastBilled, input.getBillDate(), property,
							account.getAccount().getAccountId(), username);
					preStatementList.add(statement);
					lastBilled = null;
				} else if (isLessThan(account.getEndDate(), input.getBillDate())) {
					generateStatement(statement, lastBilled, account.getEndDate(), property,
							account.getAccount().getAccountId(), username);
					preStatementList.add(statement);
					lastBilled = new java.sql.Date(account.getEndDate().getTime() + 24 * 60 * 60 * 1000);
				}
			}
		}
		return "Success";
	}

	private void generateStatement(PreStatement statement, Date startDate, Date endDate, Property property,
			Long accountId, String username) throws Exception {
		Calendar cal = Calendar.getInstance();
		List<Meter> meterList = meterRepository.findMeterByPropertyId(property.getPropertyId());
		List<PreStatementEnergy> energy = new ArrayList<>();
		statement.setPreStatementEnergy(energy);
		long noOfDays = (endDate.getTime() - startDate.getTime()) / (24 * 60 * 60 * 1000);
		if (meterList == null || meterList.isEmpty()) {
			statement.setCreatedUser(username);
			statement.setCreationDate(new Date(cal.getTime().getTime()));
			statement.setInvalid(true);
			statement.setValidityReason("No meter associated with property");
			return;
		} else {
			for (Meter meter : meterList) {
				generatePreStatement(statement, startDate, endDate, property, accountId, meter, noOfDays, username);
			}
		}
	}

	private void generatePreStatement(PreStatement statement, Date startDateDD, Date endDateDD, Property property,
			Long accountId, Meter meter, long noOfDays, String username) throws Exception {
		String startDate;
		String endDate;
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		startDate = dateFormat.format(startDateDD);
		endDate = dateFormat.format(endDateDD);
		Calendar cal = Calendar.getInstance();
		if (property.getBand() == null) {
			statement.setCreatedUser(username);
			statement.setCreationDate(new Date(cal.getTime().getTime()));
			statement.setInvalid(true);
			statement.setValidityReason("There is no Band for the property");
			return;
		}

		Tariff tariff = tariffRepository.getTariffForRange(startDate, endDate, property.getBand().getBandId());
		if (tariff == null) {
			List<Tariff> tariffs = tariffRepository.getTariffsForRange(startDate, endDate,
					property.getBand().getBandId());
			if (tariffs == null || tariffs.isEmpty()) {
				statement.setCreatedUser(username);
				statement.setCreationDate(new Date(cal.getTime().getTime()));
				statement.setInvalid(true);
				statement.setValidityReason("No Tariff for StartDate:" + startDate + " EndDate:" + endDate);
				return;
			} else {
				// Iterate tariff and get the required data
				// Relative meter reading calculation.
				Date tariffStart = startDateDD;
				for (Tariff tar : tariffs) {
					if (tariffStart == null)
						break;
					if (tar.getActiveFromDate() == null)
						continue;
					if (isLessThan(tar.getActiveFromDate(), tariffStart)
							|| isEqualTo(tar.getActiveFromDate(), tariffStart)) {
						if (tar.getActiveToDate() == null) {
							// Generate bill for tariffStart to endDateDD (Look for meter readings)
							generateStatementFromActualReading(tariffStart, endDateDD, property, meter, statement,
									tariff, noOfDays, accountId, username);
							tariffStart = null;
						} else if (isLessThan(tar.getActiveToDate(), endDateDD)) {
							// Generate bill for tariffStart to tar.getActiveToDate()
							generateStatementFromActualReading(tariffStart, tar.getActiveToDate(), property, meter,
									statement, tariff, noOfDays, accountId, username);
							tariffStart = new java.sql.Date(tar.getActiveToDate().getTime() + 24 * 60 * 60 * 1000);
						} else if (isGreaterThan(tar.getActiveToDate(), endDateDD)
								|| isEqualTo(tar.getActiveToDate(), endDateDD)) {
							// Generate bill for tariffStart to endDateDD
							generateStatementFromActualReading(tariffStart, endDateDD, property, meter, statement,
									tariff, noOfDays, accountId, username);
							tariffStart = null;
						}
					} else if (isGreaterThan(tar.getActiveFromDate(), tariffStart)) {
						statement.setCreatedUser(username);
						statement.setCreationDate(new Date(cal.getTime().getTime()));
						statement.setInvalid(true);
						statement.setValidityReason(
								"No tariff for StartDate:" + tariffStart + " EndDate:" + tar.getActiveFromDate());
						return;
					}
				}
			}
		} else {
			generateStatementFromActualReading(startDateDD, endDateDD, property, meter, statement, tariff, noOfDays,
					accountId, username);
		}
		return;
	}

	private void generateStatementFromActualReading(Date startDateDD, Date endDateDD, Property property, Meter meter,
			PreStatement statement, Tariff tariff, long noOfDays, long accountId, String username) {
		String startDate;
		String endDate;
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		startDate = dateFormat.format(startDateDD);
		endDate = dateFormat.format(endDateDD);
		List<PreReadings> preReadingList = new ArrayList<>();
		List<MeterReading> readings = generateMeterReadingsIrrespectiveOfTariff(startDateDD, endDateDD, property,
				meter);
		Calendar cal = Calendar.getInstance();
		if (readings == null || readings.isEmpty()) {
			statement.setCreatedUser(username);
			statement.setCreationDate(new Date(cal.getTime().getTime()));
			statement.setInvalid(true);
			statement.setValidityReason("There is no meter reading for PropertyId: " + property.getPropertyId()
					+ ",MeterId: " + meter.getMeterId() + ",Date: (" + startDate + "," + endDate + ")");
			return;
		}
		for (MeterReading reading : readings) {
			PreReadings read = new PreReadings();
			read.setType("Actual");
			read.setValue(reading.getMeterReading());
			read.setReadingDateTime(reading.getReadingDateTime());
			preReadingList.add(read);
		}
		float unitsUsed = readings.get(readings.size() - 1).getMeterReading() - readings.get(0).getMeterReading();
		float pricePerUnit = 0;
		PreStatementEnergy energy = new PreStatementEnergy();
		if (meter != null && meter.getSupply() != null)
			energy.setEnergy(meter.getSupply().getSupplyType());
		energy.setReading(preReadingList);
		double totalCharge = statement.getTotalCharge();
		List<UnitCharge> unitChargeList = tariff.getUnitCharge();
		if (unitChargeList != null && unitChargeList.size() > 1) {
			statement.setCreatedUser(username);
			statement.setCreationDate(new Date(cal.getTime().getTime()));
			statement.setInvalid(true);
			statement.setValidityReason("There is more than one unit charge for the Tariff");
			return;
		} else if (unitChargeList == null || unitChargeList.size() == 0) {
			statement.setCreatedUser(username);
			statement.setCreationDate(new Date(cal.getTime().getTime()));
			statement.setInvalid(true);
			statement.setValidityReason("There is no unit charge for tariff");
			return;
		} else {
			pricePerUnit = unitChargeList.get(0).getPricePerUnit();
			energy.setUnitChargeVat(tariff.getVatRate());
			energy.setUnitsUsed(unitsUsed);
			energy.setUnitPricePerUnit(pricePerUnit);
			energy.setTotalUnitsUsed(unitsUsed * pricePerUnit);
			totalCharge = totalCharge + energy.getTotalUnitsUsed();
			statement.setTotalCharge(totalCharge);
			statement.getPreStatementEnergy().add(energy);
		}
		List<StandingCharge> standingChargeList = tariff.getStandingCharge();
		if (standingChargeList != null && !standingChargeList.isEmpty()) {
			List<PreStandingCharge> preStandingChargeList = new ArrayList<>();
			for (StandingCharge element : standingChargeList) {
				PreStandingCharge preStandingCharge = new PreStandingCharge();
				preStandingCharge.setNoOfDays(noOfDays);
				preStandingCharge.setStandingCharge(element.getDailyNetCharge());
				preStandingCharge.setStandingChargeName(element.getName());
				preStandingCharge.setTotalStandingCharge(noOfDays * element.getDailyNetCharge());
				totalCharge = totalCharge + preStandingCharge.getTotalStandingCharge();
				preStandingChargeList.add(preStandingCharge);
			}
			energy.setStandingChargeList(preStandingChargeList);
		} else {
			energy.setStandingChargeList(null);
		}
		List<AdminCharge> adminChargeList = adminChargeRepository.getAdminChargeForPeriod(startDate, endDate);
		if (adminChargeList != null && adminChargeList.size() > 1) {
			statement.setCreatedUser(username);
			statement.setCreationDate(new Date(cal.getTime().getTime()));
			statement.setInvalid(true);
			statement.setValidityReason(
					"There is more than one Admin charge for the period: StartDate-" + startDate + " ");
			return;
		} else if (adminChargeList != null && adminChargeList.size() == 1) {
			AdminCharge adminCharge = adminChargeList.get(0);
			statement.setAdminCharge(adminCharge.getDailyCharge());
			statement.setNoOfDays(noOfDays);
			statement.setTotalAdminCharge(noOfDays * adminCharge.getDailyCharge());
			totalCharge += statement.getTotalAdminCharge();
		}
		if (tariff.getVatRate() > 0) {
			double vatAmount = (tariff.getVatRate() / 100.0) * totalCharge;
			statement.setTotalChargeBeforeVat(totalCharge);
			totalCharge += vatAmount;
			statement.setVat(tariff.getVatRate());
			statement.setVatAmount(vatAmount);
			statement.setTotalCharge(totalCharge);
		}
		byte del = 0;
		statement.setNoOfDays(noOfDays);
		statement.setDeleted(del);
		statement.setAccountId(accountId);
		statement.setMeterId(meter.getMeterId());
		statement.setCreationDate(new Date(System.currentTimeMillis()));
		statement.setCreatedUser(username);
		statement.setFromDate(startDate);
		statement.setToDate(endDate);
		statement.setPropertyAddress(property.getAddress());
		statement.setPropertyId(property.getPropertyId());
	}

	private List<MeterReading> generateMeterReadingsIrrespectiveOfTariff(Date startDate, Date endDate,
			Property property, Meter meter) {
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		String startDateString = dateFormat.format(startDate);
		String endDateString = dateFormat.format(endDate);

		MeterReading startMeterReading = meterReadingRepository.getMeterReadingForPropertyByDate(startDateString,
				meter.getMeterId());
		List<MeterReading> readings = meterReadingRepository
				.getIntermediateMeterReadingForMeterId(dateFormat.format(startDate), endDateString, meter.getMeterId());

		if (startMeterReading == null) {
			// Get last meter reading and generate for date
			MeterReading reading = meterReadingRepository.getImmediateMeterReadingForMeterId(startDateString,
					meter.getMeterId());
			startMeterReading = new MeterReading();
			startMeterReading.setApproved(false);
			startMeterReading.setMethod("Estimated reading");
			startMeterReading.setReadingDateTime(startDate);
			startMeterReading.setAudit(getAudit());
			if (reading == null) {
				startMeterReading.setMeterReading(0);
			} else {
				float read = reading.getMeterReading();
				long noOfDays = (startDate.getTime() - reading.getReadingDateTime().getTime()) / (24 * 60 * 60 * 1000);
				float perDayUsage = property.getPerDayUsage();
				float generatedRead = read + (noOfDays * perDayUsage);
				startMeterReading.setMeterReading(generatedRead);
			}
			meterReadingRepository.saveAndFlush(startMeterReading);
			readings.add(0, startMeterReading);
		}

		MeterReading endMeterReading = meterReadingRepository.getMeterReadingForPropertyByDate(endDateString,
				meter.getMeterId());
		if (endMeterReading == null) {
			// Get last meter reading just before the end date and generate for that date
			MeterReading reading = meterReadingRepository.getImmediateMeterReadingForMeterId(endDateString,
					meter.getMeterId());
			endMeterReading = new MeterReading();
			endMeterReading.setApproved(false);
			endMeterReading.setMethod("Estimated reading");
			endMeterReading.setReadingDateTime(endDate);
			endMeterReading.setAudit(getAudit());
			if (reading == null) {
				long noOfDays = (endDate.getTime() - startDate.getTime()) / (24 * 60 * 60 * 1000);
				float generatedRead = startMeterReading.getMeterReading() + (noOfDays * property.getPerDayUsage());
				endMeterReading.setMeterReading(generatedRead);
			} else {
				long noOfDays = (endDate.getTime() - reading.getReadingDateTime().getTime()) / (24 * 60 * 60 * 1000);
				float generatedRead = reading.getMeterReading() + (noOfDays * property.getPerDayUsage());
				endMeterReading.setMeterReading(generatedRead);
			}
			meterReadingRepository.saveAndFlush(endMeterReading);
			readings.add(endMeterReading);
		}
		return readings;
	}

	private Audit getAudit() {
		Audit audit = new Audit();
		audit.setCreatedDate(new Date(System.currentTimeMillis()));
		audit.setCreatedUser("Auto generated");
		return audit;
	}

	private PreStatement generatePreStatment(Property property, Meter meter, String reason, String username) {
		Calendar cal = Calendar.getInstance();
		PreStatement statement = new PreStatement();
		statement.setCreatedUser(username);
		statement.setCreationDate(new Date(cal.getTime().getTime()));
		statement.setInvalid(true);
		statement.setValidityReason(reason);
		statement.setPropertyAddress(property.getAddress());
		if (meter != null) {
			statement.setMeterId(meter.getMeterId());
		}
		return statement;
	}

	/*
	 * public String generatePreStatement(StatementGenerationInput input) { if
	 * (input.getBillDate() == null) return "Invalid Date"; List<PreStatement>
	 * preStatementList = new ArrayList<>(); String clientIds = null, networkIds =
	 * null, propertyIds = null;
	 * 
	 * boolean clientCheck, networkCheck, propertyCheck;
	 * 
	 * List<com.monarch.mabdeck.dto.MeterReading> meterReadings = new ArrayList<>();
	 * Map<Long, Map<Long, List<com.monarch.mabdeck.dto.MeterReading>>>
	 * meterReadingsMap = new HashMap<>();
	 * 
	 * clientCheck = input.getClientIDs().isEmpty(); networkCheck =
	 * input.getNetworkIDs().isEmpty(); propertyCheck =
	 * input.getPropertyIDs().isEmpty();
	 * 
	 * if (!clientCheck) clientIds = StringUtils.join(input.getClientIDs(), ','); if
	 * (!networkCheck) networkIds = StringUtils.join(input.getNetworkIDs(), ','); if
	 * (!propertyCheck) propertyIds = StringUtils.join(input.getPropertyIDs(), ',');
	 * 
	 * if (!propertyCheck) { meterReadings =
	 * meterReadingRepository.getAllMeterReadingForStatementGenerationByProperty(
	 * propertyIds); } else if (!networkCheck) { meterReadings =
	 * meterReadingRepository.getAllMeterReadingForStatementGenerationByNetworkIds(
	 * networkIds); } else if (!clientCheck) { meterReadings =
	 * meterReadingRepository.getAllMeterReadingForStatementGenerationByClientIds(
	 * clientIds); } else { return "Invalid Input"; }
	 * 
	 * // segregating the meterReadings by property id for
	 * (com.monarch.mabdeck.dto.MeterReading reading : meterReadings) { if
	 * (meterReadingsMap.containsKey(reading.getPid())) { Map<Long,
	 * List<com.monarch.mabdeck.dto.MeterReading>> tempMap =
	 * meterReadingsMap.get(reading.getPid()); if (tempMap != null) { if
	 * (tempMap.containsKey(reading.getMid())) {
	 * tempMap.get(reading.getMid()).add(reading); } else {
	 * List<com.monarch.mabdeck.dto.MeterReading> r = new ArrayList<>();
	 * r.add(reading); tempMap.put(reading.getMid(), r); } } else { tempMap = new
	 * HashMap<>(); if (reading.getMid() == 0) tempMap.put(reading.getMid(), null);
	 * else { List<com.monarch.mabdeck.dto.MeterReading> read = new ArrayList<>();
	 * read.add(reading); tempMap.put(reading.getMid(), read); }
	 * meterReadingsMap.put(reading.getPid(), tempMap); } } else {
	 * List<com.monarch.mabdeck.dto.MeterReading> readings = new ArrayList<>();
	 * readings.add(reading); Map<Long, List<com.monarch.mabdeck.dto.MeterReading>>
	 * tempMap = new HashMap<>(); if(reading.getMid() == 0)
	 * tempMap.put(reading.getMid(), null); else {
	 * List<com.monarch.mabdeck.dto.MeterReading> readingList = new ArrayList<>();
	 * readingList.add(reading); tempMap.put(reading.getMid(), readingList); }
	 * meterReadingsMap.put(reading.getPid(), tempMap); } }
	 * 
	 * for (Map.Entry<Long, Map<Long, List<com.monarch.mabdeck.dto.MeterReading>>>
	 * entry : meterReadingsMap .entrySet()) { Map<Long,
	 * List<com.monarch.mabdeck.dto.MeterReading>> meterIDMap = entry.getValue();
	 * for(Map.Entry<Long, List<com.monarch.mabdeck.dto.MeterReading>> innerEntry :
	 * meterIDMap.entrySet()) { if(innerEntry.getKey()==0) continue; else {
	 * List<com.monarch.mabdeck.dto.MeterReading> metReadings =
	 * innerEntry.getValue(); generateReadings(metReadings, innerEntry.getKey(),
	 * entry.getKey());
	 * 
	 * } } }
	 * 
	 * }
	 */

	/*
	 * private void generateReadings(List<com.monarch.mabdeck.dto.MeterReading>
	 * meterReading, Long meterId, Long propertyId) {
	 * com.monarch.mabdeck.dto.MeterReading readingInit = null;
	 * com.monarch.mabdeck.dto.MeterReading readingFinal = null; if(meterReading ==
	 * null || meterReading.isEmpty()) return;
	 * 
	 * if(meterReading.size()==1) readingInit = meterReading.get(0); else {
	 * readingInit = meterReading.get(0); readingFinal =
	 * meterReading.get(meterReading.size()-1); Property property =
	 * propertyRepository.findOne(propertyId); if(property.getLastBilledDate() ==
	 * null) { PropertyAccountAssociation association =
	 * propertyAccountAssociationRepository.findRecentActiveUser(propertyId);
	 * if(association == null) {
	 * 
	 * } }else {
	 * 
	 * } } }
	 */
	String generateUniqueFileName() {
		String filename = "";
		long millis = System.currentTimeMillis();
		String datetime = new java.util.Date().toGMTString();
		datetime = datetime.replace(" ", "");
		datetime = datetime.replace(":", "");
		String rndchars = RandomStringUtils.randomAlphanumeric(16);
		filename = rndchars + "_" + datetime + "_" + millis;
		return filename;
	}

	public void generateCreditNote() throws InvalidFormatException, IOException {
		String fileName = "Credit_Note_" + generateUniqueFileName() + ".pdf";
		XWPFDocument doc = new XWPFDocument(OPCPackage.open("C:\\Users\\nappathurai\\Desktop\\Jas\\test.docx"));
		for (XWPFParagraph p : doc.getParagraphs()) {
			List<XWPFRun> runs = p.getRuns();
			if (runs != null) {
				for (XWPFRun r : runs) {
					String text = r.getText(0);
					if (text != null && text.contains("$test123$")) {
						text = text.replace("$test123$", "Its Nithish");
						r.setText(text, 0);
					}
				}
			}
		}
		for (XWPFTable tbl : doc.getTables()) {
			for (XWPFTableRow row : tbl.getRows()) {
				for (XWPFTableCell cell : row.getTableCells()) {
					for (XWPFParagraph p : cell.getParagraphs()) {
						for (XWPFRun r : p.getRuns()) {
							String text = r.getText(0);
							if (text != null && text.contains("$test123$")) {
								text = text.replace("$test123$", "Its Nithish again ha hha");
								r.setText(text, 0);
							}
						}
					}
				}
			}
		}
		doc.write(new FileOutputStream("output.docx"));
	}

	/**
	 * Method which initiates the statement generation
	 * 
	 * @throws DocumentException
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	public void generatePdf(long queueId, String username)
			throws DocumentException, MalformedURLException, IOException {
		List<PreStatement> entities = preStatementRepository.findByQueueId(queueId);
		if (entities == null || entities.isEmpty())
			return;
		for (PreStatement statement : entities) {
			if (statement.isInvalid() || statement.getDeleted() == 1)
				continue;
			if (statement.getAccountId() == null || statement.getAccountId() <= 0)
				continue;
			String fileName = generateUniqueFileName() + ".pdf";
			Statement actualStatement = generateStatement(statement, username, fileName, queueId);
			repository.save(actualStatement);
			try {
				StringBuilder builder = new StringBuilder("C:\\Downloads\\pdf\\output\\");
				builder.append(fileName);
				String newFile = builder.toString();// "C:\\Downloads\\pdf\\output\\NewPdfFile.pdf";
				Document document = new Document();
				document.setMargins(25, 25, 15, 25);
				PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(newFile));
				document.open();

				// Create the Statement object here and persist it to the database so that the
				// statement id can be send further
				/* Generate page 1 for the statement */
				this.generateSheet1(document, writer, statement, actualStatement.getStatementId());

				/* Generate new page */
				document.newPage();

				/* Generate other pages for the statement */
				this.generateOtherSheets(document, writer, statement);

				document.close();
			} catch (Exception ex) {
				actualStatement.setInvalid(true);
				actualStatement.setMessage(ex.getMessage());
			}
		}
	}

	private Statement generateStatement(PreStatement statement, String username, String fileName, long queueId) {
		Statement actualStatement = new Statement();
		actualStatement.setFileName(fileName);
		actualStatement.setApproved(false);
		actualStatement.setQueueId(queueId);
		updateAudit(actualStatement, username);
		actualStatement.setDeleted((byte) 0);
		actualStatement.setFromDate(Date.valueOf(statement.getFromDate()));
		actualStatement.setGenerationDate(statement.getCreationDate());
		actualStatement.setGrossAmount(statement.getTotalCharge());
		actualStatement.setNetAmount(statement.getTotalChargeBeforeVat());
		actualStatement.setVat(statement.getVat());
		actualStatement.setToDate(Date.valueOf(statement.getToDate()));
		if (statement.getAccountId() != null) {
			Account account = accountRepository.findOne(statement.getAccountId());
			actualStatement.setAccount(account);
		}
		if (statement.getPropertyId() != null) {
			Property property = propertyRepository.findOne(statement.getPropertyId());
			actualStatement.setProperty(property);
		}
		return actualStatement;
	}

	/**
	 * Generate the sheet 1
	 * 
	 * @param document
	 * @param writer
	 * @throws DocumentException
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	private void generateSheet1(Document document, PdfWriter writer, PreStatement statement, long statementNumber)
			throws DocumentException, MalformedURLException, IOException {
		this.renderTopRow(document, writer, statement, statementNumber);
		this.renderHeadingAndPayment(document, statement);
		document.add(new Paragraph("\n"));
		this.renderBoxSection(document, statement);
		this.renderBottomTable(document, statement);
	}

	/**
	 * Generate top row for page1 with the barcode and company logo followed by the
	 * billable person and property details
	 * 
	 * @param document
	 * @param writer
	 * @throws MalformedURLException
	 * @throws IOException
	 * @throws DocumentException
	 */
	private void renderTopRow(Document document, PdfWriter writer, PreStatement statement, long statementNumber)
			throws MalformedURLException, IOException, DocumentException {
		PdfPTable imageTab = new PdfPTable(2);
		imageTab.setWidthPercentage(100);
		PdfPCell temp = new PdfPCell(new Phrase(""));
		temp.setBorderColor(BaseColor.WHITE);
		imageTab.addCell(temp);
		// StringBuilder build = new StringBuilder();

		// build.append("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA+gAAAIPCAYAAADglfRqAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA/lpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ1dWlkOjY1RTYzOTA2ODZDRjExREJBNkUyRDg4N0NFQUNCNDA3IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjIxNzcwQzdBOTJEQzExRTdBNEFDRjM3MTc4N0U3NzcwIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjIxNzcwQzc5OTJEQzExRTdBNEFDRjM3MTc4N0U3NzcwIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIElsbHVzdHJhdG9yIENDIDIwMTcgKE1hY2ludG9zaCkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0idXVpZDpjMGIyMDZhOC01MjkwLWM1NDEtODliMS0xMGQyNzEyMjg5Y2MiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MjkxMDNmZWQtYmRiZS00MzRjLWJiODktOWI3YTg5OTcwN2IyIi8+IDxkYzp0aXRsZT4gPHJkZjpBbHQ+IDxyZGY6bGkgeG1sOmxhbmc9IngtZGVmYXVsdCI+VW50aXRsZWQtMTwvcmRmOmxpPiA8L3JkZjpBbHQ+IDwvZGM6dGl0bGU+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+XwW6OgAA06dJREFUeNrsnQd8ldX5x5/sPSELkgCBsPcGEdwTR7WOuq2jaod7tH9bbWuXWrVVq3VVrdaqrXvUjTIFkb3DCIRNgJC9/+f33BtEZNwk9z33vTe/7/9z/qgF7s15z3vO8zvPCptccKcQEqKkmZFhRor3n/cdyWYken9t+ec4M2L3Gfj3cO+I5nQSQgghhLSLOjOavKPajJp9Bv69wow93tHyz7v2G2VmbPf+MyEhRySngAQpEMyZXgGeZ0YP769dvQP/PdUrzuM4XYQQQgghIUG1V6Tv9gr1jd6xwYy13l/x37d5LwQIoUAnxI/A293djN5mFJrR04xuXhHeRTyeb0IIIYQQ0jGI845sM/oe5PfA+77JK9yLzVhtxiozVpqxTuh9JxTohPi0FnuZ0c8rxPuY0d/7axqnhxBCCCGE+AgcOL29Y38gzpebscyMFV7hvtz7awOnjlCgk45Kd68AH2rGGDMGiidEPYpTQwghhBBCHAKOn3He0UK9eELjF5sx24x5ZiwVj7edEAp0EnKg4BpCkMZ7xfgQrzinGCeEEEIIIYEGNmmBd5y+j2iHSF/gFe0zxON1r+F0EScJYxV34gAx4vGMQ5CP9v6az2khhBBCCCFBzHqvUG8R7PPNqOW0EH9CDzrxFyjedoQZJ5sxwYxcTgkhhBBCCAkh8r3jfO+/l5gxzYz3zZgunmJ0hLQLetBJW4nzCvJTzTjKjAHCkHVCCCGEENIxQUj8EjOmmPGeV7hXc1oIBTpxkhwzjjfjWO+vOZwSQgghhBBCvsNmMz4y4xPvr5s5JYQCnfgDhKqfYMb3xeMpj+OUEEIIIYQQ4jPwpE8x479mfCCe0HhCDghz0MmByBZPBcvzxJNPHs0pIYQQQgghpE3AwXWyd9SJJ/z9FTPeEnrWyX7Qg05aSDFjsng85fCYx3NKCCGEEEIIcYwqMz4Uj2f9HTN2c0oIBXrHJkI8hd4uNeNMM9I5JYQQQgghhFhnpxlvmvGceDzsjZwSCnTScehqxuVmXGRGH04HIYQQQgghrmGlGf804x9mbOR0UKCT0OU0M64UT2u0CE4HIYQQQgghrgVe9HfNeMqMtzkdFOgkNOhixiVm/NCMQk4HIYQQQgghQUeRGU+b8bwZmzgdoUs4pyBkGex9gdeZ8QeKc0IIIYQQQoKWXl6bfp3Xxh/MKaFAJ8HBWWZ8bsYCMy42I4pTQgghhBBCSEgQ5bXxF3ht/rM4JRToxH3EmnGVGUvF06ZhIqeEEEIIIYSQkGai1/Zf6tUCcZwSCnQSWJLNuNWMtWY8YUY/TgkhhBBCCCEdin5eLbDGqw2SOSUU6MQuqWbcY0axGfeakc0pIYQQQgghpEOT7dUGxV6tkMopCT4ieqcxGjqIyDLjF2a8aMYJ4gltJ4QQQgghhJAWoBEg8q4Rjzd9iRmVnJbggB704CDBjN+IJ2wFAp23YYQQQgghhJBDkerVDtAQv/VqCkKBTtpBjBl3mLHBjF+aEc8pIYQQQgghhLQCaIg7vZri516NQSjQSSuINONH8k0P8zROCSGEEEIIIaQdQFP83qsxrvFqDkKBTg7DKWYsNONxYfE3QgghhBBCiH+BxnjMqzlO5XRQoJMDM8qML8x4V9gujRBCCCGEEOIs0BzvmDHVjNGcDgp04iHDjH+YMduMIzkdhBBCCCGEEItMMONLM541I5PTQYHekbnBjCIzLuNUEEIIIYQQQgLIpV5tciOnggK9owFP+QozHhRPb0JCCCGEEEIICTRJZjxgxkphdC8FegcAISPPiSfXvDengxBCCCGEEOJCCr2a5XkzsjgdFOihyBVmrDLjEk4FIYQQQgghJAi4WDze9Cs5FRTooUKBGVPMeEoYzk4IIYQQQggJLqBhnvRqmp6cDgr0YOY2M5abMYlTQQghhBBCCAlioGmWeTUOoUAPKgaIp23an8yI4nQQQgghhBBCQoAor8aZ49U8hALd9dxqxkIzRnEqCCGEEEIIISHISK/muZVTQYHuVpCPMcOMezmvhBBCCCGEkA6gJaF9Zgpz0ynQXcYPzVhkxjhOBSGEEEIIIaQDMdarha7gVFCgB5pUM14242kz4jgdhBBCCCGEkA4ItBC6Vr3i1UiEAt06E8VTxfBcTgUhhBBCCCGEyDlejcQuVhToVvk/Mz43I5tTQQghhBBCCCF7gUaaYsadnAoKdKfpbMa7ZtzDqSCEEEIIIYSQg/Jbr3bqzKmgQHcChLSvNOMUTgUhhBBCCCGEHJZTvBqKIe8U6H7lJvGEtKdxKgghhBBCCCHEZ6Chpng1FaFAbzcvmPFnTgMhhBBCCCGEtBloqhc5DRTobSXfjIVmXMipIIQQQgghhJB2c4F4eqZ341RQoLeGY82Ya8YgTgUhhBBCCCGE+I2BZnxlxnGcCgp0X7jKjI+F1QYJIYQQQgghxAmgtT7yai9CgX5Q7jfjCU4DIYQQQgghhDgOtBfrfVGgf4dIM14342ZOBSGEEEIIIYRY4yavFovkVFCgg05mzDTjTE4FIYQQQgghhFgHWmyWMM24wwv0AeIpBjeS7wQhhBBCCCGEBIwRXm02gAK9YzLRjKnCEv+EEEIIIYQQ4gbQ6nqaV6tRoHcgTjfjMzPS+A4QQgghhBBCiGtI9Wq10ynQOwZXmPGmMLyfEEIIIYQQQtyqU9/0ajcK9BDmVjOe4nonhBBCCCGEENfzlFfDdRgieqd1mPD+n5vxR65xQgghhBBCCAkajjejTjy56RToIcJvvIMQQgghhBBCSHBxLLSreHLTKdCDnAfMuJ1rmhBCCCGEEEKClklmpJjxAQV68HK/GTdxLRNCCCGEEEJI0DPOjCQzPqRADz7uM+MWrmFCCCGEEEIICRnGm5FoxkcU6MHD/RTnhBBCCCGEEBKyIj0kPemhKNBRDO4OrllCCCGEEEIICWmRHnKF40JNoKNH3j1cq4QQQgghhBAS8qBwXLUZ0ynQ3cePzXiQa5QQQgghhBBCOgzok15qxuxQ+GHCQ+ShXGLGI1ybhBBCCCGEENLheNiMSynQ3cFJZjzHNUkIIYQQQgghHZZnzTiZAj2woDDAG1yLhBBCCCGEENLhed2rESnQA0BvM141I4brkBBCCCGEEEI6PNCG/zGjDwW6XVLNeNuMLlyDhBBCCCGEEEK85Hi1YioFuh3CzPi3eDzohBBCCCGEEELIvhR6NWPQ6d1gFOjPmnEi1xwhhBBCCCGEkIMAzfiPYPvSwdYH/Vdm3MC1RgghhBBCCCHkMAwxo9mMzynQ/c+5ZjzKNUYIIYQQQgghxEeONmO5GUuC4csGS4j7GPHkEBBCCCGEEEIIIa3h315NSYHuBzLFk3cexnVFCCGEEEIIIaQNQFNmUaC3n+fN6Mv1RAghhBBCCCGkjfT1aksK9HbwJ2HFdkIIIYQQQggh7ecEr8akQG8D55lxG9cQIYQQQgghhBA/AY15PgV660A5/Me4dgghhBBCCCGE+Jm/eTUnBbqPPGdGGtcNIYQQQgghhBA/k+bVnK4rRO5Ggf6QuPQ2gxBCCCGEEEJISADN+SAF+qFB3vn1XCuEEEIIIYQQQhwG2tNV+ehuEuj9xJMLQAghhBBCCCGE2OBRrxalQN+Px81I5/oghBBCCCGEEGKJdK8WpUDfh/8zYyLXBiGEEEIIIYQQy0z0atKAEza54M5Af4dRZszmmiCEkAPT3NQsjY1N0mR+xT/rr82e4fkN3g09PEwiIsMlOjpSwiLC9v53QgghhBDiE6PNmBPILxAZ4AmIFfY7J4SQb4nv+toGqautN6NBR6QR3bEJMRITGyXRsZHm3yMkMipCxXhYGIR5uIp1/LmqilrZWrJLooxIT8tINL8n4hshTwghhBBCDgW06QQzajqqQP+1GSO4DgghHY0wo6zr6xukck+N1FbXS1RMpMTGRUlsfLTk5GdIVl6adM5JkfSMJEk1QjspNV6SUuIkITlWYszvw4iOidK/B0K9qalJqitrZfeOSilesVVmfbxMZn6wVP/35LR4Ff6EEEIIIeSQjPBq1NsDZiMGMMT9KDM+4xoghHQsYS4Ch/b2jbslLjFGeg7oInm9MqTXoC5S0D9H8ntlSnpWssQlRLf7s2YYgX7P1S9KVUWNpKQnUKQTQgghhPjG0WZM6UgCHaHtC8zozWdPCOlINDY0qUi/4IZjZeLkQZKdn6bh6E4x9/NV8osLn9HPdPJzCCGEEEJCiJVmDJEAhLoHqor7bynOCSEdUqA3Nmk4+3HfH6aec6dF84hJhXL8OcNl1/YKTj4hhBBCiG/09mpW6wRCoCPp/hY+c0JIRyRMPCHuNhl+ZC/NXW+ob+QDIIQQQgjxjVu82jXkBfrv+awJIcQe+YWZkpgSJw0NFOiEEEIIIW7WrrYF+k1mHMnnTAgh9kBLtvBw9kUnhBBCCGklR3o1bEgK9G7iKVlPCCHEItpjneKcEEIIIaQtQMN2D0WB/hszEvl8CSGEEEIIIYQECYli0dFsS6CfbMYlfLaEEEIIIYQQQoKMS7yaNiQEOooW38VnSgghhBBCCCEkSLnLq22DXqDfaMYYPk9CCCGEEEIIIUHKGK+2DWqBnmnG7XyWhBBCCCGEEEKCnNu9GjdoBfodTv8AhBBCCCGEEEKIBTK9GjcoBfoIM37GZ0gIIYQQQgghJET4mVfrBp1Ah/s/gs+PEEIIIYQQQkiIAI3rmBfdKYF+vBnn8NkRQgghhBBCCAkxvu/VvEEj0H/OZ0YIIYQQQgghJERxRPM6IdDPNONoPi9CCCGEEEIIISHK0V7t63qBzrZqhBBCCCGEEEJCHb9rX38LdMTij+VzIoQQQgghhBAS4oz1amDXCvSb+IwIIYQQQgghhHQQ/KqB/SnQLzBjHJ8PIYQQQgghhJAOwjivFnadQP8xnw0hhBBCCCGEkA6G37SwvwT66WaM53MhhBBCCCGEENLBGO/VxK4R6NfzmRBCCCGEEEII6aD4RRP7Q6Af4x2EEEIIIYQQQkhHxC+62B8C/Vo+C0IIIYQQQgghHZx2a+P2CvQRZnyPz4EQQgghhBBCSAfne16NHDCBfrkZEXwOhBBCCCGEEEI6OBFejRwQgZ4jfuz3RgghhBBCCCGEBDkXeLWydYF+iRlpnH9CCCGEEEIIIURJ82plqwIdf+4yzj0hhBBCCCGEEPItLmur1m6rQJ9sRl/OOyGEEEIIIYQQ8i36ejWzNYF+OeecEEIIIYQQQgjxn2Zui0AfaMbJnG9CCCGEEEIIIeSAnOzVzo4L9PPNiOF8E0IIIYQQQgghByTGq50dFejxZpzNuSaEEEIIIYQQQg7J2V4N7TORrfyAScLicISQttJsRphIU2OT1Nc3SmNDk/5zoxnN5n9r9vw/CQszv8mM8PAwiYgIl4jIcImMijC/RuA/E2JlfTY1eNZmU2OzNHnXZrN3fYaZtRnWskYjw3VtYo3i31v+HhKAfaSpWfcS/CZ9TnhGERjhupfgGWGQ0FkLzYf4n8MkNN9FrPHGhkapr2uQBu/617Vvxt69KSLsmzUfHenZm0gA9qlms081+GzvhJvzJErtnXDP/0ZCgb5eDf2+UwL9Us7xQQ4B8w41mpewrqZeN0x9EZs8Lx5euOi4SImNi/YcFM2cLxLq70OYGg+15n2oqa5XoaPGQZjnBYiJjZLk9ASJT4qVuIRoiY2P9hgS5kCCId0AcdTkeZ+qq+qkuqJW9uyqkrKdFcYA8Z59TU3690XHROqfj4qO8BrmhByeBqxPszaxxrDWwr1GLYymmLgoSTHrMy4hRgf+XcW3d41ifeLPY5+vr22QyvJaqSir1lFn/r3FgoaoDw8P1z+vf4f5s1yjbdhHzHOqwXMyhm142D77iDlTU3QfMc8pPsbsA1F6UQLDFs9TL1nMn6mraZDqyloz6sw+Uim7d1TsFfEt5zT2Efx92EeI6NrGGldB4bVnPJcfzXvFBR4D3omoaNg3nrlvdmiB61ow36XGnAdYD01N36yFvRrmW2Km+Rvxvs93hvDBc8YZpDGkzcHxDlSZMxDrWMLEe/EkkpQaJxldUiUxJU7XPp4D1r4+O7P2sbdVmb1pz+5qKSutUNsU6H5nnltcvOfspV3qH/u/ttqzNrFOWy5xsfCiYz3nSXxijA6cBREQ4N5LQ7V3zO+rwz4He8fsU2U7K2XPzip9Vh57p1mfU4u9w0vGoORSpwR6rhkncX6//UJiw8MLWbmnRl/GzC4pkpWbpgYDNku8qDAMtm7YLZvWlhpREm821XjdDd1qqIV5b/xwK+vE5V3LxhWst7nfXL74aT68t6ZBb9A1esQK3oeKPdXGEIqUrLw06d4nW7Lz0yWvV4Z0Leis70da5wRJMEYFDISYeI+xdKD1UF/XqIceDq3K8hoVQNtKzLtUXCola3bI+pXbZMfmMv33cvO/JSR6BD8OMRiLhOwV5DBYzfqsqazTPTnOGEo5Zl1mmD0b6zO3Z4Z06d5J/z21c6IkJMfqpSoM3+iYKDV89wXGfoshDOMZo8b8vbt3VMqmdaWyef1O/RVj+8bdsmXDLr2wSjR/L9Z8dHQE1+hB9lecqzV6rlbr3GflpkqPftmSY55PrtlDcgsyJNP8NzwnzGfLJUr0gfYRc87W6TmNfQSCpUbKdlXJ9k279dmUrN6ue8n2jWWytWSXGVW6L3n2Ec/FTCh7YBu9Ahxzjv22vrZebRv8/BB+CcmefTrK7KnYVzEf6ngw7wPEO9b0ru0Vsrl4p4rmTlnJavu0W6hD2zTJXhurfHeVRJr3JbtbuhT0z5Ec8yve16yuqZKCdWC+a0xspF6I4XvU1Tbqs8a5sGtbub5/W8w7iee+1fzzxnU79HviPcf54ybBg6lrqG/Qc6/ciGtcGuUXZurP23NAF/35u/ToJJ2zU/T7t4i+/b2tLftdZYWZB7Pmt5l9aEPRdlm9ZJMUm7OzZe3jcgXzh/cnIiKMl4ittHdgm8CGy8732Duwe/LV3jH7lFmfaZme9akXIuZMicY6PYDN12LvtNhQsHe2byrz7lPG3inapmcJ3jWs63hcICdG6zqmYA8KTvJq6RJ/C/QTzUihMhf1Bu7aUaEitlN2svQa2EWGjCuQ3kNy9YWEgQch3iK6IN63mIN//tQiee3JabJ2+RazsSa7+vahocGz8YT7WTi2GLU41BuNYYvDJdEYAGFBItZx/uHQg2Hir++MecamjFtReJWD7YCEEVFWWqmHDm7zB47pIYNGd5deg7oaoyJDhU9bDw8YJlHRcXq4dc7xbD8DRn3790Cgr1u+VYqM0bH4y7WyYn6JGtq4hfZ4QaN5LHRQsN+U76qWKiOc4W3C5RD26X7D86SHMXLze2WqUdWWMEL8mZZwaby76ZlJBxWcMIJhDK9ZulkWmTW6evEmXbdYo0lp8Wpgd3Swj+ByA0IDRu3gcdnmXe8mhYO7qjiBKN//ksTXMzvaKy6TUuWgZgwM4Q3GAF69ZLMsm1ssKxeUyCZjCO/YuscYwtH6nII93BQXyzhrKspqVJyrAE+KlaSseMk2oiKnWycVF52ykiQtI0mSzc/sEemey6oYvayK1EltmQo8N92DV2yVL95eJB+9Olf/G84ynJNtpXxnlRGWtZKekSh9hubKsCN7Sd9heSpOcUnTVtsEor141TZZY57z0rnrZcGM1Sp+qoyITe2UqO9ycwAPYIgyCL7ktATzc+fJiEm9pf/IfOk3Il8vP1pDy7qHPYrLSOx9+15YQqQvNWt97uerZOGMNZ5LC7Of4eILF10U6oeyd6LUjh9obJ2BLfZO70zJM/tUZHT77Z1OB9EIpWY/WrN0i6xdttnYO+tk2dfrVbRjzaR08kR9EdeS4tXST/t0dE0uuNPXv/gjM47rkJrcexDhJhNeEtzYQ4SMOa6vjD+xv3Tvm+3z37W7tELuOP9p3Qwh5FvCV9wENp/Rx/aRC64/VsOimv02j9+EPeMz4GFatWCjLJ+3XkO3sLngMHHjnLSATfCiG46VQeN66Hpo73zAEEDo9uZ1pbrRLpq1Vuci1RgluOBpduEJie8NDyQMCfxzbs/OMuSInjJ8Qi8ZPqlQRVAg2W3W1tdfrJI5n67QX9cbYwzfEwY2jP/mAK8v3LrDg/rEpzdYmysIwxvPfFyNUw1pDOG9Gq8MvG3wwMIz1scYpUMn9FQDf8j4nq4Qw6Vb9siCmWuMYbzSrNEiXaMQM0j5gGBq7gCW8bf2ESMG8npm6DMair1kYqGK9ECCsx77MfaQedOK9OIPl6mIqEAUXMv+HRRzjXD/Wo9HFp7XHn1zjJjIUG9ft95ZGtkEu8YfQOz97poXjZAo1zPd1/225TvCNsA/42LmiJMHyhEn9Ze+w/Mdi7jDM51rnvG0dxfJjA+WqrcSewQuJzyXfM4+G/xctebM37OzUm2tngNyZPxJA2Ti5EEqzBERYGtPmvLWQvn0tXmywNin8BCnGaEOsdnc1HGVOtYiohCwT+GyD1EMQ42tM8zsUyOOKpTsvPSA2zvzzf4029g7c6eslA2rt+uaxfrF+dfMWxa38bEZx/tToPcyY54ZiR1LmIdpqBReTIiovJ6ZctSZQ+TUi0Z/6yaytcC7d+WkBzQ3CKHwbgIbcem2crnyzpPlip/byWjALeC/H5kiH70yV28OE1NiXSnSW8JZH//4er3Fd4Ilc4rlmT/8Tz5/e6Fk5KT4J1TQX++CObDh0SjbUaG3uyOP7iPHnjVURh/bd68x4zbw7sLo+uDfX6lgh5ckPTNZhToFemjt1QiFRRgnvOUIA51wykA56owhMmhsD1en0+CZzJ++Wj7+7zyZ9eEy2by+VCM/EFrs1ku69jwnGP4aZm4MS0TFjD7G7CNnD9P9BFEObgR7H/bmT1+fL9PeW6wREHFeEeeWPfpw+yAimX7+6PmaKuC0l23e1CK56XuPa1i85nr78O7uNHYH/nnCKQPk9MvGG5Ha33rYLmoTvP3cLHnr2ZlStHijnhUJxkZz4vF6ovEazc+9R9fQqKN7y+mXj5cJJw9Q72zAbEDzw875dKW8+NAnMtOcnfguaRmJQXUh5S/bH5d0WBO4qBh9XF89T3B5kpTizn0KDqTp7y/RKBacJbiQg7NHz3zqdNdsx2YMM6PIXwL9FjPu62jiHF4YHGyFg3Nl8iVj5JQLR2vojz/4+93vyHP3fSTpWUmuCpuDCEVRrtv+cq6cfMEoq5/94ctz5Q8/fklD19zoRUKhsqz8NHnk/Z/qhu0kj9/1jjx774ca0oZKrIF+F1CwBD9/j/7Zctz3R8jx5wyX7n2yguqdXjZ3vRpeH//nay2+gncvEMY1Bbp/jVzky8L7g9QQhIOe+IORMnHyYNeKvUOB3MJPjFD/30tzZNXCjRpSjLDbUDCMdR8prdDzpWf/LnLCeSPkmLOGSbfemUH1c8AumPruYnn/X7Nl3rTV0lDXqBeWbk5NQljsqKP6yF/euc7aZ/7hupfk7ednHTIsG+8vPO1Y35NOHyzn/+QojXJxg9D5z+NT5eVHpujc4bI83E+XZS3iDxcSuICbcOpAOe/HR2nkiNuY8uYCdRgs+apY5wA1GTqCSEd0JGz/ngNz5Ogzh6otjEiTYGL51xvk7edm6sXvTrOGsUd1lOcXBNxqxv3+Eugfio8u+WAHnhZU5IUggeHw/R9NVHGe6OcbsxXzN8j1pz2mB5Sbijt4qnyGye//9UMZfmQv658P8XTP1S9KbEKM2UzcVZUbHh+EYP7lbTtGzq8ufU4+eW3eQXNbnbWmNcvQc0m1p0ZzAE+/dJycfOHooBQ++7J22RZ56eHP9EII+ZjpWclWPZUU6P4RezByd22r0AusUcf00b163An9gqaexaGA5+bDl7/SmiXL5m6QRPPO4b0LtlDTMG+PK1ROx7naf0Q3Of2ysXLi+SP9fqYGgpkfLpXXn5yuUTpYj8jbdmPUA8QgBOCj//uptc+c+u4iueXsJw6YqgA7y+OdrJTB43rIFf93kow/cYDrni8K+z5655vGLpknCSmx6jltT3Qf9i14ZOtq6/Xnvejm4wJiZ7UGeGGf+O178sqjn2sNiNROCa5OQ2zzszFrUiOwKjwRWKeZfQpOOUQzBTNIn3rxoU/l41e/1ghCj9MnnEI9sCBl/ITD/aaI3mkTD/d7cK33kIR4V9eW0Lst63dp+OuFNxwjv3ryIhkxqdCRcKOEpDiZ8f5iraoZyHCm/UEIN37+8396lLfavF0QOr5j8x75aspKDfF0E7i0gZGDm34boODg528t1Gdis8o73gXkXCEVAwLyR3dNljseOd8YUgWHDVcMBhCud+Spg2SsEXOoaIvcUuxuaL1jIwwM4bK4lDvt0rFaINEGqLKMMH9cwAVztdeWYCOkHMFrPmxCL7n1oXPlyv87WbsEhErPWER2IO/2tEvH6XpdPm+DbES15SBqr4NnUVVRp10XuvToLNfcPVluf/hcLagUHQL7CEDe/PHnjpBBY3pooSZcvKM1GQqquemiCMUI0ang1IvGWPtMFMeFKNC+zt65aHk9t5o1gV7PV//qFPnVExdpEUA3grolSL9A8dNpxl7DetYaFq18tJpnXl2v1eNR4O6OR34g1/x6slaidzvYb1Bvqe+wfPny4+VqFySlxEuogH0KzwYV/pFyc/UvT5HbHzlPzxZtjRzkoA7EkacOlNHH9JYtG3bLotnr9GcOhZ8tiCkw4wWYZofcN3z4i87oCOIcN5oIA8Fm/MzUm+Xa35zmqEBFZen+o7qph9JNNmVjfZPeGCanBm4D/v61E9WYQAEht9By2ZiRY6+RQe/BXaWfMdJRq8DWewCBiksjVKq/6s5T5PlZt8t5P57krdwbWqAiMDxKdz19kfZQ3lK8U59zWEjvdsG9TzeY/QntktIzkuQ3z14qf//kBhl3Yv+Q/ZlhHCP89Z/mPbzg+mPUw7NruydX162nckuuKvaRxsZG+dHdp8qz02+V719zZMi2AkIEx8Pv/UT+9MpV0qVbJ7NGd2ox1FCI5mgrnhaF0er42Pv+NjRpGgcqkv/94xvksttOCIo5OvOK8fLkZzdpxwcI1DBfXz5vz/IdW/ZoBMnlPz9Rnpt5mxxz1tCge56oCfDkZzdqZXkU+NUpCOLl3XLOb9u0Wy+uEcXx4pyfy/k/Ozok67T0G9FNHnrrWrnn+cs0egmXRbR3Arf8vNpa2ivQQ773OcQIQj7uePQH8qeXr7SWa4IwGhgsyPt2z1zUazuOQIYfIrd5+MReUl1R55p5QfgiRBwqeNp8hfN6dpaaaufnwZPaUaNGNTzLT025SS+p3Fr8zZ/AS/nklBtl/MkDzM+/Syvqhofz1HITeB6IYNlpxOnZV0+Qp7+4SSZfMrbD/PyofXLLg+fIX9/9sXYN2VxcqpepbhM3eE7o34uWZTDon/niFrn6V6cGfVqMrxzzvaHyj2m3yOV3nKReOUR5dFgDOOzb6wIX7ju3mvf3R0d6hV5uUP04uNB9+N2faOs/XMAcTpxqVKZ5RyHoYVP+9Z0fy09+d4a2rAtWYP889uHPNLIU73iwLm3PeqzTfRRFKv/2wc/kx/ecoe3oQp1TLx6j6XVHTh4kW9aXetop094JBIfV1ocT6AhvnxDqs4TWXxBf406w64npPyJfMnJS9abdTZcV8F4HmjHH9VNh6hbjBmHJsQnRGqppk0iHi5i1hARDmOMW+cb7z5IH37hWW9x0JLqa5/rQm9fKD41hjRxBhFDz0HKBjQ9vbFOzemyQ/4kLVKRbpLeyH3CoMPKo3vLYR9fL9648QkMyK8uqXbFOW/YRhC7jeSHt4IHXr9GK4R0NtMq77renyV/fvU669cmSkjWlmqbU0faTlmMLPzf2U7SDuv5P39NK8kjhCEYQkg6RjloK2zbsPugFWcuFN4Q80gpw4Q2nQygA5839/7laBo/todEQwRQlEub1+nvsnUa54d6z9eIEER0dCVy03P/fq+Wau0/T97JsJ+2dADDBq7HbLNCRsBTyV9/Ih0Nrm4//M9fq5/Yc2EV7kqLvtVuora3XMK5AA8MOVbbdMjdNjc0a9tS1Ryern4veqJGRzoSFekIOG7XvK/LLEIZ6/k+P7tAhT8gL/N0Ll2tYJgor8dAKrOhDQb2NZn0ecdIAeXrqzTLptMEdfl7Qr/oXj10gdz9ziYYM79xeEdB16kk9aFRjfcDobvIPbzh7R2fw2AJ5bsZt8oOfHa2e4z27O5YRHOZdGxDnWB9/+vcVOhfBDjzguHzqNaiL7NhU9p1nin9HzQ94aH/5xEXyq6cucl07XX+I9N8+f5n0GthVay8EutOM7/ZOk5Ss3qFtkp/45Aa56KZjO/QehXbKf/z3lcbGDNc0DNo7Vonzauw2C/TTOsIsYVFCgC2ZXWx9w0DYlKdyuhtEaJPExkZbzbM+GNhAu/fJ1gribgBCFtVL0fLIFohmKFm7w5Ge3RriVVWrYWrnXjdJc7Gd6u0ebBz3/eF6q46wYrQA4qEVmD0ZIbGl2/bIFb84Se5/7UfWKt4HC6dfPs4IhR9pEbntm8sC4slqeU7bN+3WwqJ/+9/Pgq79opNERUfIrQ+dI79+7lI97zvSfqJVsXdXaZG4P7x0hbbUCxXgPPjV0xdLenayeiBbnil+3WHeRZwdf33nOo10CVWwH9/1zMVaq6mirMbVF/tYi4jIRMrJ2VdNkMc/vkF6B1mKhVMcfeYQeeCNa/QcoUi3zmltFehIlBnfUWYJlQ4Xz14nG40gsgnChBBq44ZkHnyP1M4JkpUXeEMYm0SPvtmafuAGIJYR7WDzJhw5t/Bu+7tyOuotIKSpYne13Pzns+X2h88LuRv+9oJq/fe+epUeWtsO4CUhzr77WJ9o73PrX87VvE2bXQyCCfR9/8tb10l2XrpWS7dZxV6fkxEnuES97a/naY68E5eJocBJ54+UR9//qWTmpmpOsoqGEN9S0Eca5+adT1woE04ZGHI/X58huXLjvd/TCyotCGgeaMmaHZLfO1Meef8nmo4S6sDB9ON7TteK/fBOu3FNh3vbp2Hgu2I9okgz2UeHjCuQh8w50ikriSLdLuO9WrvVAh2xHx0mMSM6NtIszDJZMseuF717v2zJ6JIiddWBz0OHJx8XFW7IQVeRNKGnRMVEuqL3L56P1QJxBrRVwsEX7kdxgo231Kxz9DO995WrNKSdHBhU0P/zaz/S3GeGu9szphAeimgehFCec81ETsphQDrQ3z74qXqu4cm24UlXT6Ex5CKiIjSX8Zxr+ZwOu5+MyJfHP7peBo7uIRvXlkoTasOG8JaCU/uOR86TE84dEbI/47FnD5dLbjlePbNI8YDQeeyjG1zbNs4JzvjheDnx/JEa6u62BY19CilAKMSM1DU8K3Jgeg3sIn9+/RpJz/SK9AjaOxbI92rtVgv0cR1qmrwacNaHy6x+LCq5I7TYDaHc8KCndU6UzK6prngk/Ud2k4Sk2L1tWgI6N/UN1gV68cqtng4DfjK4VZxvLd9b5AVVPMmhQaoFwjPRIx3vaBh7kjhqTCFfFZdyaFd11BlDOCk+gkvVP71ypfaCL3XYA+LZR/ZoGC9ycVEfgPgGztYH37xG+xJvgye9OXRFOvrdn3556Adhom82OivgAubR93+iqXAdDaQh5fbMkPKyatd40fWyd0eF1uzAPhVKKRZOUTioq9zzz8slLj5aykqrOnSbSIuMa4tAH9/RZgmVRZfP26B5UzaBB6SpqVmaA+woRrXwrLx01zwPVExFuFig+6GjwE1CUpz1i4t1y7dKbVWd2STb70FvEedoI4Jq5cOO7CXEN9BS5qY/ny3VFd+EMhIHxLl330V/83En9OOktBK0csLcxSXEfCsv1v/ivNwYvXHy5/9eLUPGF3DiWwlydvVi4+QBsgW9iJtCM9wda6UjRB2hyPAvn7hQfv2PS7SCf0cEEQOIokFR2+Zmd6w9eIHhjLjv1atl5NG9hfgG9vTbHj5PaqvrtAUb7R3HGd9agd5FOpoHXTzVcdcs3Szzp6+x+rnId42OiZTAK3RxVYEf5F6junj57uqAehlQSRq5OV0tt1hD/jmWRHv3R4TIw+OFXsT3vXqV9B2eL6R1nHLhaLnwxmO1T3pTUxMnxI+EeVsS1VTWy/89foEKF9I28G7/3+M/0HQl5PD707jae8mXFq9FhbiPtB1NMTLCAZ70Tet2uELUkLaD0PaO2FJwX866aoJGPaJNaaDFOdKkYuOi5I8vXSkDx3TnAm0lSEu5/I4TNe3XDSmmIc44r+b2WaDjD3S4q8CIyAj1li6aZVegY1OD0YMiG4Gk0QgPt+VO9RqQowU9GusDNzd1xthFOKfNEHdcSiCnrb3FTFoKOeGy4/cv/lAGjOJh1VauuXuyMagHaeV75qP7D1yAYY3ecO/3tII+aR9HnzlULrvtBGMoV2pklr+MXhTuw0UyagPgzCLtAxXe737mYhk+sVD7MnNPIcEM2tCeddURfttz2gIuJFFRPjIqQtuHDR7Xgw+mjVz9q1Pl6DOGyLZNu+lFd/jVkYM4xA8m0I/riLOEEG+ExMybWqS5v7bIzkvT29eq8sDloWNTjTHGl1sKxLUwYHR3SctMCmgrOhQY6ZSdrAeQLeA9R0eB9gh0bKroxVpXUy8//9sPGNbeTuD1uvG+szXHEB5fnln+AW2JzvvJUTqI/4yrsSf280vRuP33EaR8EP+QnJYgf3zpCsnvlcmWjiToOfH8UVpsDGmits9HbaVWVaft1G7767ky6pg+fCDt5JpfnyadspK9tQW4NznIca0R6B22ehQ8jeuLtsuKeRusfSZCkPsMy5OKPdUB+7lhfGXmpmlFeTcBj35OfrrVC5MDgfxOm2wuLtVDDjfBbTWq0aIO1cevu+d0eib9BC7SLr31BPUmMiy1/QYVPIcwpNCii/iXa+8+TYtsVrWjAClsMhTpRIrMj+4+VY4/h/uIv+mckyK/euoivYxFkUSKdBKsxCfGyLFnD1Mvtm1PekNdo2zfXCZX/t/JctIPRvFh+AFctlxyy3He2gI0eBxkkK8CHW62kR11lqJiImSXETVzP19p90UY0EUL7zQEqO83bh7hPXdLBfcWIFAHjumh3y9QeejIwSnobze/bPXiTRIZGdFmEYjNdGvJbm2BctGNx3L78yPn/+xoGTmpUC8/eKvcdnGOQz8rN43i3CH6Ds/TqASIvrZ60bH/4BLl9MvG6cUUccg6G9tDbrzvLI1UqK1p4ISQoGXSaYM1HbDWYuvglsveMy4fp7nTxH/gDBl1dB+1d4TmjlNAc/f8jv45wG9EucOYjmw4RkZHyKIv11n9XBSyQBh1uTGmIhMjrP/cqE6NUHs3gn7UenERgAs8GKiIcMjrZTc3f9WiTW3uQwkPzLZNZWr0Xf/HM139vpUZkYaNH/3ecaDjYiHCzDdabSHdBMX5UPXYTWB+f2BE+vwZazT1oq1RDh0ZeDsqy2vl5gfO0TaTxBmwTj99bZ4ar3ifWrvO4ZHqOyxPfvbH73EyHeaUi8bI8nkl8sKDH0tuQWdG6JCgpFufLBlk7NnP3lygUSFOr2PY7Du3lus+detfznX13OCydOfWPdqyFTY3nD9q70TD3ok1GiBFi/m6ShOFhcmFNx4jv7zkWWlqaFJ7mPgdaG7kZKw+nEAf16GnyWwmKekJsvSrYtlQtM2aMOvSrZN06dFJFpmXN87y/Qg2CWwQtvt8+wrCiuFpgxfdZh44qKutl845yVZD//Fzblq7o00bITZT5EdHRobLrQ+dI8np7unJigKMa5dvkcVfrpPlX6+XDau3a3EwreBtfuZ6I9qwFnExAdGLXpzxybGS1jlJeg7M0b66wyb00pDQQDPxtMFabXzau4s16oThX60TfluM8Dvx3BFy2qVjXfkd62oatLr2xnWlsqV4p/bTRZs91KPABS5SoVA4Es8e7SC7GkGV4MIWSyg+irzQJ37zriSYd8nXiA/8tirz8+L33/zA9yUtI9GVzwn1C1BMc1NxqfZ/hwGsF30wfKPC9ZmkZyZpdBjONww3X6hdd89pMn96kaxevFk6mXOno1dQxjMt3VYuZeb9Q8pXtTknPPVyoiSlU4I6NWA7xSeFpk8JLWZRlBSV0dE6saq81nMpbM53tHRDfR7YJtiHIlwknCacOkjef2mO8+Lc7E81lXVavPKG+85y1R7c1Ngka5ZukSVfrfPqiR2yZ2eFivO99o6ZIJyHiJaMTYjW749n2qNvtnYGQMszN0S1ojju6GP7yudvLVRbnPaOI0B7v3c4gX5UR58lHOCeMPdV1gQ6bgEHjy2Q2Z+s0CJUNtc/DjzcdLrVk4U8GLR/WzB9jXWBjo2054AuVovnodUfenhCBLT6ssUsHBipP/ndGa6ptFy8cqt8+PJcfZ9WLNigB2o4ersbERBl3rUIDGNc4L2DfGjWw838HLurZef2Cu0H//XUVfLKo59rwRL0NEWO2djjA9srG21lZry/RA/iMOaN+mxQIT8Rh/x1vzvddcbwlx8vN3vwclm5YKMxqLZ7ih0d5NnivzaZ9w0XSTlG+GGfgEE10RgznV1Uy+PkC0bKW8/O0AuGaJ/3lDAVBVf98lRtA+oWcMm3cOYa+dKck6gTg0t0RAcgTx6G7sHOTeyLuKzIL8wy50mOjJjUW8Yc17fVUQVOExsXLTfce5bces6TUmvOnpi46A5lDKOo4VdTVhpBs17Wr9omm9fvlNLNe7Tw1/53S7BbkPOMS5eC/l30eR51+mCJSwxesY5aO4tnrzO2zmopWrxJL+qxvsvMmY7LGs8FW7O+n1gX+HeciXmFGdJnSK4cfeYQTQkMNLA9cgsypKqixtiWzj0PnL1aZ+e3p8nIo9zR67x4xVb55LV5asuvWliiF50t9g5snMgD2Tvm2aJzD9rDrTN//usvVsmrj30hGTnJMnRCL23zCnsnkHbGGZePl1kfLlOnFRx6xO9M+o4W3e/fk81gXwLxFMaBoDjziiPsbWoj8j1G396N2JZAb1Ix6LYWa/vSc0COCnTv2WRRoHtC/23eTmODhmcoo5U3p1gz+HOjjuojl9xyfMCf2ZI5xfKfx7+QmWZTR1hXTFyUGslJxihui82JVwLP470XZ8unr8+X4Uf2kivvPFkGjg7MljX+xP5aGX++MabgpSO+7TUVZdWaJwjPlxvYumGXvPP8LPnsjfkqyqsq6yTeGJXxyTHqofPFSNy0ttQYYxvlo1fnyvP3fSTjzNpA/QeEXQaaHDPPg4zRDqOxkw8CHfvIzu3l6sH54c/dkc8JT+oH//5K3/t1y7eoMQsPOeq2wJPqy3kJcb983nr1UL/z/JcasXbESQPk1IvHuOpyGm3XcPn37J8+MGdPesjnfeISfOo7i+QLMxbOWmtESrn+N3hFIe5i46MO6iGHnYZ3FqkBH71i3r37P5Jzr50kky8dE1QiAmflF28vlFkfL5ONa0qlck/13gsInJtpnRIPvA6aMX+1Mn9akcz+eLm8/tR07bJw0U3H6WVhoOjWO1N6Deqigs4pga6pfGZfGHlUoVzogjo7KxaUyMsPT5EvzTPcsXmP1rNCNC4il9pm74TpxRScG5+9sUCf62W3n6BRhIEAEYP4DrM/XaGph3Si+50CrwbfczCBPtiMrpwnT0/HZXPXaw5ehqWQWoRywxMDAzbe4i0w8kEzuqVqKLdbGXpEL3nj6RlWjRXcUCOUzHboPzwHDQ1NEhER1qpNEJs5PGSXB9ioRrugJ3/7rooeFDyCeIXHtOXZtb3wnaixgr8LhtmMD5aqxxNVW68wIxAcdcYQFegt3gxyaIMDHoL+o7rJOddODPj3gWD7118+lVf+9rmUrN2hRnBCSlyr00KQigIjDANGNVI28HfiImnyJWO05VlKgFNNkB7yzj9n+fR74SHBSsYlSqDDwbGnweh9/enpsm7lVklOjdcwUFxetvZ1w8+C54CBSxWEDj9774fy2pPT5MTzR+qlplvSvC42Amum2d8QfZSWkRSSXnTUHXnbnBFvPztTVhpxExEZYd49zwWur+8LLs4RBYGBdw/tSX999T/lszfnyx2PnO/atL0WIHZeNXvFnM9Wyp5dlXrZhCgKXAz6dJ6Y34IzvyUyBnsaLjqmvb9ExdzVvzwlYOcSLicRjYSl68RXQCoL/t6r7zq1TdGG/gIe/Gd+/z954x8zpKayVvPIdX8K91ygtKfQL36uzNxUtXe+NHMJewfP9ao7T9G2r7ZBFw9cplGcO0JXrwaftte22P8c5xx5SEiO08Nx6Zxia5+Z2zNDevTN0lBEmyCvq7v5XLcV49qX3kNz1XDGAWQLbIq4ucdNsE1WL9lk1l9MqzZBhD7By3TaZWMDGur18X++lsvG3ysvP/q55sihRR48If6+WIFhhr8bhtkjd74pt57zhObm2QYtZeCJs1mxNlhB279aI7jO+/EkvWgJJAiTvtSs04dufU3zOvPN3oviPO2NlIFXB5e7XXt0VuMKFwCXjPmTTDcGcyDJykvzdAk5zP6J7w/vD9oyTjglsOYALuAuGXOv/OX217VWRV5BhqZ/aWhoO/cTXKrgEhzPCX8fwkkvP+J+efGhT13xrkCoXnLr8Rox1Bigzi5O8t4Ls+XyCffJ/Te8oh5w5Nli4J1paxEqrF0I+67dO+vlxlVHP6DC340smrVWbjzjMbl+8qMy9d1FRmBHakg43lHP+m7bAsef9bzrsfLIXW/InRc/G7AWtcOPLDT7aYQ4Ud0X84PaBN+78gj9nECBZ4dz5KWHP9Ooqy5mP4G9szcTwY/2Dt6PpLQ4+duv35Lbzn1SC0rbZtwJ/aVgQI5GMBFH+Nahu/9O2Jvz07LZew5x5EPZpHBwrootmzdUyL3M65Xh6ueRZwxo5A4iusAWzY3Namz36Gcv/BF5n8Urt+ktemuoMBsmvAU/+OnRAXk+8F488os3jUHwDyk3zyjfrCcYW056flpqJ8DI/vS/8+XW7z+pbYpsguiAERN7awEfOtAPDXrHI3z3+HNGBPR7QIz9bPLfZO3SLXop2hKC6M+lqt6PuCjzHmRq1MDt5z0lLzzwcQAFX4Lm5uLS8VDA+4/wxUC3Znz0zrfM+/yEekTxjFpyxf29neA5YY9H1fTGxkZ54Ob/mLXxqGxcsyPg78sJ546QI04ZoAUKQyXMfX3RNn2ud13+nLYB7WLEdErnBLW1/HFWtBTdwlmIyt4//8HTWozUNXugOSceuPm/8uOTH5ZZHy2T9KxkI7zS/HpWNnvPxfzuWfL+v2bLn376ckB+Vlxcp3b2v1OlpRBurjn3L7ohcPsUCm/ecvYT+kyxf2C/d7Kooz5Xs1fl98jSYm2/uPAZqw4rgAJ2OMNRgZ44Qu9DCfThnB/Zawggd2bhrDVWvWPDJvT0hq7YUegQObh1zenWyfXPpOfArnqZYIt6s/mhAEvnbHuh/2uXbVGR3prQUi28tada8xYDEdKH9wMG1xN/eFdSOyVqGGqTperDnvC5MMnpni6fvT1fDWzbDD2iQG/NG+qbuHEedI16POgI+Q5EaF4LuET640/+rd8BhdycDh3Ge4Bq7zCY7zdrE0ZdIIBoUa/cIX5cT2/6KjnpgtFmr+0SkO9ZZQzvG898XJ763fsa6owLMBvh3XrZlxijFfnhuf/RsQ/J118UBfy9Ofe6SZpLjfZGwc5nr8+Xq496cG8l6JT0eM+zbXbmeWZ0SdV6Lg/d9porfn44e64+9kG9qIO3FdXXPYUN/T8B+CvhdUVx27eenSn/fWKq9Z8XtXvyeyMitM7vzxaiGB1AcgKUwnD3D5+Xx+9+R/d2DKv2TrjoPjXt/cXy26tftP6zjz9pgNmTIljJ3RmGH0ygo0z1AM7PN8TGRUnJ6h1aVMYWKFaTnpmsLRisiNDaBv08FPVwO72H5KonpcFSyB+qjXfvk2210i8quCI3z9cwPxjdqDSNKvdn/+jIgDwXeM2RS5jXLUNz4QKxcaNKape8TvLaE9PkzX/MsPrZIyYWarg9ChuRA4tzRBjg/T3hvJEB+x4P3vJf+fsf3tU2feo1t2ZUecRfphEMj971lvzjjx9Y/9m3rN+pRi0MqwM/JNHUqkwjnNA7PRCgc8r1p/1NPn1znnTt0cn+XuK97MMlJ9brT099RAvrBRIUokR1ctT1COYaF0/d857cfNbfNZ0OotFGlGCz+T98FnJm33h6ekB//mf/9KFcd+Jf1Z5ES0aEtDv+82sNnQiJT4iWZ/7wgVaDt3omGxumixGS/naqoIAe6jWdfrn9jtCIQLrj/Kfl9X9M1zNfIx9st0L0FkrOye8kbzw7XSPCbNJveL6G2wcqdSLEGeDV4t8R6Hn7/g9EJCom0hg1FVpZ1BY4UHoP7qqiywZ4ydDjtlvvLNc/j8Fje0hq5yQtamcDDf0vtBv6v27FFs2lDvexnQaKHSGH9vTLx2uFdNvcdfnzWmEU4WbwSgbqVhWfC08TcjdhDCGs2BYoCAODIRA58MEAvAt1NfWarx+oYj5//8278uJDn0huXueAGFX4PIRSZ2anqncY1cht8tWUVWrZhR8sesFMB7znCKuG58s2iMJBvuz86WukW89MFaMB20vMs0KYP6JifnnJs1o9PpCcftk4rWQerAYxQqwfu+sdjVjxtJC19FybIRLD9H1/45kZ1sOBW2wIeFsf/vkbGl3WEo1nbQrMB6WYz91SvFPefGaG9Z8fF34t38MfeBwS1dp2rHOO/VaW9/7sFfnfy3Mkt3uG39Iy2rq2EWWZlp6odU5KLKbkIPKj/4hu2s6X+J10rxb/jkAfKN8Nee/wxCXGysIZa6yFsIBCI9Drauwcxgg71XCzTgmufxZZuanqWbFhqED4RsdFae67LVCxuHjFNok3a641BkB+70w5MQCeSQiNN5+doVVGbddNOJgxkpQWLyWrt8tLf7Vb7GnAqO6ed5Z56N8B84KLx2POGhaQz3//X3Pk2T9+oOkquMQJpPBD2hS82PDmoyWiDdAuFF5EVAM/WDgxnlG6EaUnnBeY+gC/ufKf2mIqp1uaKyoE47zHhWd0TJT87pp/ycwPlwbsu6BY36CxPfTSPti86Jg7dDSAjYG6Kk0B8DYiBBkdeWw/Q7xTyFF++7lZkt0tXS/orP/83nMxMTVOvnhnoaaQ2ASXfYgeamr0z8+NGkQI7z7pB6Osz+Nz932kbWO75HfSDjuBRu2d1HgtZv2W5ahBFIqDo4xR7n4nXPYpFLevIB/CufkuyINbuXCj9l61RZ+heVqN1EaYe2NDk14IBANowzJoTHfNt3baUEF7MNx2d++bbe3n27Bqu3rQD9bzdX8ginfvqJSJpw3SW02bTHtvsTx1z/uSkZ2iYXTiko0aIgjV4+GhRC6/LQqHdJUmh/Ipgxm8p7tLK7SwDArp2Gbj2h3y5xtf1QI+McZADnTenHq0zN6O7/XXn7/h+OfhAu+hW/8rVRU1B+0Lre3vzLsy6pg+AenbjpD/d/71pV7iuOn1gZhCnjT49RX/lDXLtgTsu5x60RjtgBAIgddWVswvkfde+FLrCMDbF6h3D+sbZ+WUNxda/dwNRdtk0Zdr1dPraZkauGeHjgW4/EdbN5vALsHFxOGKU/oKisNNPG2winSboL0Z0jRwielZy245X0UvXj/57zwtimhNoPfPUadeQz2jBh1gyIEEenfOywGuM8zGipzgWR8tt/aZA0Z1043A6ZBZvNwohFboQBsx5LY78f37DMvX4if+2vAP/v3r1ePWrY+93HwUiEO4uq+tnpAjj6qax51tt7ZjVUWtPPart9UTiNtxtxULwa0yKnTjULVFVtc0vdCpY3XTb4EIHaRrHHFSYMqbPHjra1K2s1JFcbNLxA1EFjyK/3tpjqPt1yC6bzjjMb1gPlQvbYT+Ij0FPW5tM29akTx334eSkZni2fdcpj/xrJAChovQe656wWqR0n1BYSZ0eLGV+uYPsKaS0xL0uQbyjGjpJ71yfomeXbZAZFmPvp7Up0AfkRCVELfLv15v9XNhQ6GWU5Mf7DU4k7CPT754jNWfAV57XKYiCgARUG6yd/BVcPmyZcMumfreYmufi5pHsLNYGNcRuh1IoOdxXg4kYsPUyFwwY7W9TQ2eW/MCOG3s4+VKSPL0gnXC8Fq9eLPf/95eA7toEZ8ahw0lXADgc1rb7qw9oGNAWLjvkQE4OIYf2Uv6jci3+k7A47ViQYnH6HehRweCMComQuZ8Zs9bkJ2fpoVTamt4o/ytNbqnRqNQRh5lv4Mnei1PeWOBVnN2m+cR9U0gXF5+ZIoze8nMNfKTkx6W+dNW67o8lFGJfaTP0FwZfWxf6/Pw5G/f0/zzeG11507vsKcieIrMn75anvh1YKrwI9x+9DF9guoCUKPcwtxx54J6Aju2lOkluC3Q0xwpV4HIfT8Q8GSvW7HN7rrtlOCXtCIsJVw4ItXDtr3zwoOfyLKviiU92532ju5Rxl61ae+0dGFobGgU4nfy9xfonfb9j+TbJJiNdql5QUss9tPERoQbTydDueEN6FqQIbkO9ECf+u5iDeP0N+jXjr641Q5XzMZtLapO22TVwo0+99JuKaI06fTBVr/jmqWbtWpoWudErZLrRjAvyONf/vUGa33RUekfuY51tfSg7wu8R/2G5VuvcYGK+iieg/ZmkdER7luj6plNkq+nFvm1YFz5riptJXftCX/V3EQYUofaU/C/oabH2OP7WS/g9/Kjn2vrqU7ZKa41fPedJxQ5e/XvU2XWh8sC8h2OP3eEevCCKczdLUCgo3DohiJ7Nhwu2xOSYtWWcAPoob1p3Q6rxb3w8yO1qL056I3mz+NcH3tCP7s22aKNWlwPkYpurv6AjhdrjW2GAno2QMoYUjcaGuhBd0igd9pXoHfxDnKgjc0YeWhTs8wY/LboNairbqhO3r5CvKDoGsKG/A1yqSE4naDv0DzHc9BhBNnMzYfw3VRc6rPHvrqqVrqYZ4e8UZu89NfPtM0JwqrcnG+NkD7cuK83IsUWEKFNjTywvrFQPUJ0/En9rX802u0VLd6olyZuFX8RUeF6gfGpH1p5IfT5xYc+lR9O/LM8e++HahgjvBRG7aGcV40athktR1m+6IPX/rUnpqpXLzwIStNiDrE3Q2whJD8QwHPYe2iuXsKQ1oGK2zU1deZMKLf6uTgn3SLQI6MjZde2Ck3ZtHkOYy9qamrfHKD+QtfunWTi5EFW5wziHO3p4jWVz73rG99vc/FOq7WyEFVED7oj7NXjLUdjDufk0CBMZ/Yn9nJa4b2Fd9upnDcYbsivd6K9GsLDN6/bKUvnFjvy3YdO6OmoQNfe8FlJRgDbK2pVtHiTbF2/S2+bfQE9jYce0VPDV22BCxfkzKJti9u9OMh/xLuzcV2pPYGeFq/92FnZ1Pse1TSoSISosPq5RvR++MpcrcDtbtXnKfCDKuvrV7Ut9LRo0SYNE79i4gPyl9tfk9Ite/TSFR4OX95ReNNw1tiOFkL+PS4l0XoqWN4XnJmoM7Fgxhp5/Sn7fbWREjHMnH2IHuMe0waxGBGhrQRtgvew0SWXtkj9QoSXzToGOIfbW70eph5q8/Qf2U0jgmyxydgOn7+1UM8w16/tqAittbLD7P/W7J10OiQcJGdfgV7I+Tg0CCFZMqdYb/5t0Nmbh15T7UzIrPbljYuWvsP9X3qgdPMe3SzQm7HagaIsyGlFZdh6h9qtVZrvnN8zU7r1tlcgDgIdB7kvBeLw+xCOOmhMgdV34LM35svm9TvV4+Z2YIygiF7pljJrn4l8w3Btv0LrGZSbvbLnwC6OXAIeipkfLNXLwWBoHYnQW3QbmNaKAj94B996dqbccvbf5ZrjH5LH7npb82txWZeYEuuzMQyRh5zmweMK1MNoCxh1/3vpKyNeol2bJnMosYC5eu2paVIbgHzwERMLtZc4qye37YKjpqrO8vvtrktCvPO20r5a5jwmtn056PijeG5jjrNbIwPt8eA9xyVLMIB9yVbrTpCQHOu39nnkOxTuK9C7cT4ODW4BNxrBCW+HLXBjGBHujKe4qckT2lg4yP9h3PAGITR/u9ncljlQNRTtmhB+vsehm2AYrXmFGT5XU28vmKsls9dpHrMvBxna73XOTpGxx9s7sFDs64t3FqlxGAy9vsPCw6WurkHKd9dY3SM0soNnlhpVWNc9B9gPzoL3HO9uMPSM1vfdfM+5n6886O+BV3zWR8vkmT/8T27+3uNy5cQ/y++vfUlmfLBU81xzCzI0jNRTl8L3z0Z4ItqIwitrE9QnwQVKUmpc0L0rzd6+2kvnFGtrI9v0H9VdC1LWsRhlGw4FaXeodWuJjAp31ZmA/cbp7kD7g4KYze2YdlwoIJ2v/wh7MgU2FvZXXKAGCzjzbNYXiHVB29IQRhd7JAW6j5tMdIRsL6uWJV8VWyvMNWR8gfb+xkvgb2MTlXNhPKPQg98FetE23VRrampl3fKt2gPZ3+BiYeq7i8Rr3/r14gLe6R797PU/R4sMFCD0tUhTbVWdDBzVTTIthnvNn1akF1Ruzz3fa4vBGGu0a4wgzCwYRKEN4CWNT4rRWho2gXcZBT3d1g7nUKCTxtplW7UtILz+KK4Jzw1CLFHUCheeyDtGASAIcoQW7luZva0/Jy5Q0DHEdlVk/JwoTOeP6s6BANE5ME4Rpn/KhaOtfjb2377D8jW1AR4s0mqNblmgR2iNBUSKhLnlZtvyK+dxdLT9QxGF2XdYnhRYvOydP71IVqFTTWZS8KztMLFr70RGMNWGAt09IIR13herNNwmNt75MF9ULM/KT5Nd28r9+3lhniI9BQO6eASXvwWnMZIRfh4XFyPL5zlTWK/v8Hz1/sALhEPQb2eXEejRsZFWb2sXzVyjKQGoPO7LJoxnhyr/4eH2DvyZHy7THrLw8gcPzWL3BKE43yvQm5p0zyq0LNDnTS2SDat3WK3N0H7RFatFkH5z5T9VNGMvQLs+eG/QQxih4NjjOuck770A8oewxfuMsFHkwdsCtTMQLeDJPQ9O6w7fG/vgollrZc6nK6wX6hw4prv85+9TuckEAcjBFrdd2obZf1/a9aFhYr1GxuxPVki92YtxuRBM+5TV70pzx3GBjqstqJt0zocvhlSMrFu5VYvb2ADe7T5mY/J32ApEKDzFBQ55ieFpjU2IlrhECPT1UlXu/zDjAaO6qbfJ31Xu8ffBYM23mH++fH6JVlbVw/yw388In4QY6TnAXtMFzMnyr9drHYZg0uYo2IbKtbbA7TVDvr5ZM+nmPcrKS7P6ucvmrtf9LSIiPIiWarPmDyKsEssHRYmQxoNLhuT0BM2B9Ht0BgovVdRYN3wXzloj2zbt1kvQYAZ5tbhImRmAlmv5vTK1BktdLcPc3S+YhClP7QR1XUZMslcmC7bx/OmrNQU0uMS5p5i1tTPenFcMGHQMaHK1YrIo0H3fKFBN0uahjCJLCGv0Z6sgrVJuDngnQoZgtCAkE5sbNosdm/dIcRsrFB/68iJZevTL0VB9fwKvUkH/HGuVO3EYFC3cqCG5vlBTXSfZuan6HW2BXqBrl23RiIVgAR5ciIDk9Hh7Ar22QdrrLAgV8F52NSIzOc3e/COyCRdJiHQKqosS71eNUW95lJWCbY31Tbrn5PbMsPqjzp+2Wqor6vTyLNiFF6IAEA1gq3BsC9j7s/PSrBc8I8Q2uOhNSo3XaFJbwAG3pXin+7uA7L+nNzRaLYyKGj9M6XNUoGfhlERD9GTOx+HBYoSgWjx7nbXPHDi6uySbDarBj/0G67wCvfdg/3tPUNBo26Yy3dwiIz1FKxAK6MSzgBcdlaL9uUnA22+zsFXxyq1StGSTz6HjKA6U0TXV6oGFOgIwQv2ZSuD4YdXYrCHWGQ7UWDgYFXuqvUWIeGhhj8nOs3vvu61kt/aCDabCPgG7QKmpVw+9zVobLcYvLrpDwa7DJfSG1dtl5cISq58LIzynW7r1Yl+E2AatUrsVZkp2vr2zBJe8O7buCbooH2iTzC72Ursqja0cFk5bxyGgyTu1CPQozoePs5YWL8vmFlsLc0dxDBTyQfijv8CtJDwnTty2rV6yWaugt7SjQW4l/psTwJMQZ0SYv8LcGxs8ha1stoVaMW+Dil9fwtsBPIN5vTKtrnl40COjI4LKK4nbZOT2du9r71nu2lGhxdF4qWwEYG299fB2XHShR7Sn1R05FIj2SOucpBXgbYECfsUrt0lCclxIzCGMU3ixv/xoufXPzjeihd4rEuogYhXOCJuXrmgPjPfaV5vMDcDmRtQnOjzYonxnVVClkgUZUS0CvTPnwndQabt0a7nmOtoAnlW0FKup9E8/cZzp8J7A++yIkWzEHLxnLTdrMMZWG8PZiXA8VB9G+41qP80N5qVTdopeitjiqykrWy18bYpOsGHVtqAzBmuq6yXfHOw2LzMqEc0RzgMLN/lRUZGSYjG9ACC1pqYy+MOnbdDY2KRpQuhOYoutG3Z5+grHhkaEQ0tbu1WLNln/bOxrWiSU+c0kRPG0oBTJ7Gr3ohdFjrUocxC9W2iDC7uwz1B7tuvO7eVW0rE6MJ1xUjL/vJWbBm7zZn6wVE69eIyVzxwwspu8/dwsvzyoJm8ue5+hzhQHQlsgeC9bBB080sUrtmrhOOTT+5Os3DQtmIOwVn+AkEH9Oy0ViIMXa/XiTa26hVQPusW8UeTkr1xQImUVlUHjGUbP1a2Vu+SaU061dsOLnOvdOyokOjp40gAcE3/m/UdfbtstaiD+cDkYzrA7n4AX1ib7nw2hAArHbijapmvPZueAvSlOXOokVM+RxiY9R7r2tOdDREs3ON+qqmpk1/bgeLlg05dVVsqoo+11k4DtigvXYEp7DELSIdBTOA+tAwJ9hREtpVv3WCkmhlDu1E4JKiDbW6URnuyu3Ts7EsaNSuTo4btvSzgIpDJsevM2+F2g6+XFqG4y6yP/FO3D/PYdnmfNgFz05VpZu3yrz/1sW3q0Z+babSF1y4PnqPAJls0YeeDogT58or3Krzu2lGlkTVQMs4VaUkVQRMsmaEcZxQsSn8BFX3Y3u3fzG9dsDzmPC1KscOYhLNamQEenEXTzwLsWTKG4hPh8jpszHJ2AunbvZO0zsT/95PdnaEppsIRvYy9HEenRx/a19pllu6qkDCHu3HucJAVqL43z0MpD2RyMOJTnfVEkx50z3PHPQyh31x6d9aY+Kr19Ah05PQNGddcKy/4GIaaYl+9UJG8WWThjtUx2IOIA/cD9oqfDcCvYqHNji6LFm2TPzkpJTuvsU7tuzRvNSNTLGlvAQ3Tk5EF86Q/DlvWe8F2bz8a9FyTNEhMTpWvHnjHXJOW7q7RWAvHBqDPPqHO23dqwWzbsCrl5RL0DGPMlRdtl+JG97Flu6fGSbs6CndvKjZEczQVNQlCgN+kZ0tlioVd00TjyVNo7hwNpj5V7qrUQNHGMNMwuPeitJDIqXIsyLJ6zzsrnIQ+9W58s7YHdLqPM2wLKqcq9m9aVSllp5XeMZOSjw1PsRJExRAKgwifaj7WHFvHbzWLY54IZa/QA8nVa6uvRRiNR244Qd4EUDoS580bZI/6iYiPV+2ELpGIggicykgL98OeAp++6rVaSLezYsicE51IkKipCq7nbBK0EUzsn+rV4LCGuEujmHEGnhOR0Xnq7jbXLNntsfYa4O0kKrMlUzkPrD+UUs2l8/UWRtlaywdDxBdLUboHrKd40xPxdToB2M/rC7vc1scmWoB3NAv+3o0Gl6F6Dukr5rvY9Bxj3EPuFQ7paeZ7IV15l5ism3nfvR0Ndg1beT0yJ40voMpZ8VaxtWZpZtMnTgz46UsN/bYECjygMyAruhwdh0YnJsT6n1vgDXICihWUoVv3FmkPkmE2Q6oSLWn91MCHEbWBtaypHHNPG3Ma6lds89V5YJM5JUulBbyPRZtPYVFxqROdGK583YHR3iTWHckuRt7ZteE2SnB7vWKXHFfNKDnijhpz0rSW7Ze2yLY58LnL04aVvj4cenghEFtgyIOdPXy3btV+87ykLMKxRNIW4z5DAZUt760OECngNcXDbvF1HRBNaOrKCu2/7CKIbvpOK5CDlZdUaYRKKBh06N5Ruth8dgItvFNIiJBRBiDvaGtNL6y5w1q6cX0JHkfOoB53xI20AQg5tlWZ/YqcHKqqVo7o4QjnbCnJGeg7IkS4OFN1ALtzm9aUH3kzDPGkBK+aXODI3Q8YVGOEa02ZjBSG58H4OHNPd2vpZ+lWxlO+ubtXho4Z1PPMN3QaqviK9A14t4lHo8CraDPdHQSEMtob2YR8x+yTEeazFvQTFSetDtMJ+hFnrFeU1up9bFeiJMdLUQIFOQnefiqdDwnWgIOa6FVus1pjpoCTAguI1SBtApW94a5bMXmfl8xJT47QKemU7QupRIM4p7zn6n+/cUi7RB6pi3ewpNgZRikrp/qbPsFzNx2truJ8n1ylGBo8tsPIsIbQXm3WDStet+p5G+MQmUKC7jYWz1nr6OzMUr+V11/0xjO3OXEmTCvRoqwId4ZCooRGKawJRAYjeKNtZafVzY+PoQSehvE81q+OFuIsZHyyVit3VDG93njgK9HaAfOBlX693JLf6QPQe3FW9dG0Jc4d4TTIiv3CQMznW61ZsVS961EFCthH+i37l8DT6G+QpFQ7O1QuItlBdWSvd+2RJjqW2Q5grVHBvTYiQhg0b4zaWHnR3iVHzYL78eJkn9YB6VAmTb1q/WBNJ5t2A154lAHxYs+a5RERGWI1wwMUsLiZDMcIBF/V1NZ4ce5ugGGsYQ0ZICJ+tMXG0d9zG3CkrVYNw67Ej0FkSuq0HZFSEVJTVaDVuGwxGKHdynDF0Wu8pRnhhelaSY2HcyC+PiAo/6EsLgQ4Pw5I5xY58ft9heW0L/zffF6GJiCywJX7nTV2llwkRrcqXbVbvE6uEu4tFX66T5V9v8FTWpzr0vlNh6v1otBh+G2H24sioSKuXAkFr+IonRctmvj6eS3NLG5GQE+hhegGBIoVW7Q9zFoSFCwtTkpAV6LR33AUiP+fPWK21rIjjxFOg+2EDsZWHjirjmbmp2q+7tSDEMK9nhlY99zcQm4giSEw+uEcY81RRVi2rF29yZG6QW4+CIq1tOwMRgfzzngNzrK0bFIhrwCVLK23VcCN8UIWfuIdP/vO1XjzRkPiWPtdK7jYFOiKLkGLQxJBfn8RyeKTdyz719IaF7nrHWscluE0Qrea5ZKFCJ6FoXwsLxLnN3vnvPO2YFM16O9YEOi3LdhqGqxZttNJmBW1x+o/IV6HbmvASGEeV5TUybGKhIyFxW0t2aUX7w+XgIud61SJnBPrA0d0lB/3Qq1rnRUdoYuecFBl6RE8r6wW5yvC4xrU2l7zZ8xwpBN0DWgd+9Mpc9qU/wH7TWN8odbX2PIqIfolPiGFOru9PyeqnIcIBXvvmUHT3ImKkqcl6yzPPXFKck9BV6BHMc3aVvfPZ6/O1xTQj1awQToHeTlBJdePaUlk0a62Vz0MoN7yvrclDx++HeMafdYKlc4ulprLusBV6E5LiZM3SzbJxjf8vM1AkLq8ws9VGEkREbkGG5PXKtPL8UPF7fdG21rdLC/MUiauvb+BL5xJef2q6bN+yp9XF/kL/VAmXWs3JrbX2mdjfUEiTfaF92ErMPt1kzgSbEQ7R0RESGRkRmgLdoyWs/2wNdS12AJNBSQjuU2Fh3M9dxDv//FJrSMWxertVgc4qDO0AN3w4HudPt5OHjkru8PjC8+srKF6Tb8SrUwIdHmEUWjtcTiPClfbsrJSiJc540YeM66Eh7r4GCeAAqK6sk8Hmz9lq//P1F6v2iphWG4FNdvN6yaHW/Hp567mZvE0+0KkSEaa9Uisr7BbNQl5cXS0vsA6/73lCsm2mA6DYE0KyQ/Vd8RQptOvrgHhpZrEmErIblbSp3hLxP2uXb5F3np+lhbHD6dK1RTSnup3g1hy5zwtmrLbSB7Xf8HztY46+sr5SW12vOdrwMjv18qIq8OEu8vE/IwR1/tQiR74HwtxROMfX6AKEJYZ5/5wNao1oQYGN+MTYVntbwsz/4c/UU4C4gifveV/KSivpPT+gWAnXtV65x65A75SVrJduLJp1OIEeJg0NTVaN38SUWI1yCMUUBK2Kb8R5dLTd+iAq0LnWSQjvU/X0oLuCR3/xpuzYXKbtiLnnWLSlOAXtB56BbSW7ZcFM573o8EL3GtilVYYO8paHjHcmx7p4xVat4O5Ty7Awz4XG6qWbHfkuCHHHqPaxmjtCcBFZ0HtIrpV1gjSITWtLtW5B608rT792ePxJYHn69+/L9P8tkcyuqfSeH2S/gTjftb3C6ufmFnTWXHRcvJFDHPpGTCLiqbrK3l4Cww4jFIv4abFYcy6j2KhNaqrqWZOEhPQ+1abOPMSvvPDAx/LFO4ukU3ZKyKYoUaCHMMitK99dJfOnFVn5vCFHFGhbF18KvsEggmE07Mhezgj0Vdv0Zs1X4wTfZUPRdkfy0OFB69EvRwvi+QKMVKQMQGhZEehfrtVe8W015CIiwjTXnwSOd1/4Up763fuSkhZvtU1VsAn06qpa2b2j3Orn5vfOlNi4KF6aHHYfCdcIrJoqu3tJWufEkPS+YL1FGYFuu2dzlTm/WESLhKw4CQ+TKstRWOTbvP/ibHnsrnc0+pZ7DQV6cGJ0cmxCtCycscZKUYvCQblaOdqXzyovq1aPe4++2Y58l4Uz13hy73w0vFC9vMSI8zXLnPGi9x7cVaMMDmukN7dEFhRYWybzp632FNhoY84g0ghglJHA8PIjU+Q3V7ygKQrw1PI2+VAiMEIvo2yCPS7R7Ius03C4fSRco4eqK+wK9Oz8tJCcz0Zz1iB8Pyk1zurnIlIsnB50ErJnSLhUGIHOczYwvPK3L+R3176kexvsdj6HwAj0ek5D+4FgLlq8SVuuOQ3yyQv652i7NV8O8QGjujvWT3LFvA2tulnTYmzmRV85v8SR74NIAQ2lPIxARxgsft/Io3pbWR9rl23WXvFqxLVxn9Mie7sqW93rnbSPzcU75ZeXPCsP3faaFiJLTI5tVReFjgiiRJD2Y5O0jCQV6dW8xDqMQI/QKKPKPdVWP7drj84haeQhSg0XdigYaQtEP+zZVaWee0JCcp+K8lzyooYSsQcqtd91+fPywM2vqjBPSomjvRMY6hFrS2vfHzcdRnji0Pzqs5VayM1JINQg0hceJucdHvaE5DjpP7KbI98DfRHhDW9NyDbsMwjjxXPWOfKduvXO0lD30q17jCF68JBDGKi9BnWVfPP7bTDrw2WaBtGeQn0wxlCYrNwYZulZSXzpHDa6l35VLJ+8Nl/e/9cc2b29XDrlpOhlFA+rw4M6C9gbaqrrJNZi6G+/4XnmmX1txHoii9kcBGRGYX1jj7QJWlmGYvoB5jIpLV49TbZAQdqyHRWOXbwTEnCBbs5a2Ey4cMUFGHEO1LRaMb9EPv7P1/Lhy1/J9o1l0jknWS9zae8E7rFAWTEe0G+Wj8jcz1fJxTcf57whOiJfhQOMg4O1d0HLIeRXO5V/vmROsWwuLlVB3CqhGR2heejbN5dJhhE9/gSGeV9jpP/vpa807eBg3mqE/g8a00NzVm3w9dQiDb0Na0dPHBQj3Lm1XHYbw8yWQIe3HpEa+rVDpJ8Pfgp48nAoNTU2az0HGAE7tuyRktU7ZPXijbJq4UY9sJBSgNzZjNxUXUsM8/KNaLNWt5bs0sskmwK999BcSUyO03VL8XKIdyA8zOy/dgV6Vl6qnhXoRIG9LGQEujFgs3Pthu+X7ayUXeYcCKV5JGRf4PRCNxCcy4iOsqKIjI2GKMWwEKovs6+9gwtS6ALYO6VmXlELqiXyd/m8DdqSGXOdmeepy0R7J7BHC3b3Ks6Df4hPjDELvUTWLN2sIehOMnhsgSQkx+pLd0CBbt5KVMCceGq+ilYnwIsNQxg5ja15j6NiolRoLjUCf9Lpg/3+vfoMzZO3n53luXo6gKZEZEFSSrwR6N2trIvilVtl6Vfrfat0fwgivSFfGAUDcqx8d/Sz/sUFT2uYd6LlHEtnDyyzDhoa9UBG5AveFbSdUsFu1gdu75GOkKqFrZrbnJbQYY0rVAo3c4oikhldUq197oiJhRpFs2H1dm1/SQ7yDoSFyZYNO61+Jp4LCvmhm0VqTGLIzCUuybsWdLb6mTgDsG/Rs0hC+wypk83rdkrhoK5WPhMRX3df/k8pWbPdUy8oxOwd2DcQ5/vaO7CHMdcIZU/tRHvHRVRBoFdzHvwDQrc3ri3V0FinBXpOt3TJLciQVQtLJOpA/Veb0f+8ToZPKnRGuNU2yJI56zT3vrWXbPCgb9+0W1Yv2eSIQEdRvLTMRKmra1BP3ndFZ4Nk5ToXWbA/uIiAN7FL93S/hN2WrN0uI4+2kzuPSyB85fVF2yQ9M0TC6ps9pxZECkZ4RJgaui0BAvtGOfAGue3GFaJUVny9QUZO6m3tc+OTYrXwY9HijRKWnsDndwijbf3KbdY/t3vfbJk7ZVUIXXR4LnzRrtMmG4q2fWsvIyTUgOMH3myIZVskmPMj0tinKGLc2shQ2jvEz1RToPv5sI6JjdQ89MmXjHX0s/CCIdd97ucr1dO3/3uFftnZeenSf4Qz+edb1u+U9au2tTnvDjmqCCN2AoT/Z3ZN02IX+wt0PCOELfcdnm8tbAo9s/Hz+mvvK15h17AeMraHLJi+Wi+gCPFJoIeHSV11vaxdvsX6Zx979jB57alpWggyLIzq5YDPJyJcQxwRIRMday93GgVL3/3nl4dMzQomEEGG/POcbp2sfm7xym2e3FAubxLKZ0hNg2zZsMvq5yJF8tPX59PeIQEX6OEU6P4DAgw3cEvnFmsIt9MUDuqiYc8HaitUVVEjvYd01T7fTjBvapGU76qWyDa2eUG4NAT69k1lfv9uCCVHEb2G+oYDPiNEFow6uo+VNQHP+bK56yUm3n9G8NpldkVP/9HdNRSKWoe0BqT8rDMCHWGDNhk+sVAGjyuQXdsr+BAOAgp77tperqkAdp9NL00bsdGO1AYIFc3vlSE9+mVZ/VwUaKW3i4Q6cESVWN6jEP0Kp1eo7FEkuAV6JefBf6Boy7aNZTL3C+fD+PqqpzhVC2kcSIgOO7LQsc+G6Kyuqm2zFwRh+cijQ362E8BAR3uO/T1oyL+Bt6P/yHwr62H2pys07SHOT7mCSA/YumGn1R7TPQd0kczcVKmpYrsT4jtIj1izdIsR6Vutf/axZw3TgjgUMQcT6FHmnNpt/bIvJx9RXfmyZ3dVSEQ34LIXYfs2vW3Y+1ETJJoF4kiIE58Uo6k4cHTYAvWd1K5mezcSWCqgrso4D/4DHm1UvUYhHOeFU46KTYQB7QtC39C/cNyJ/Rz5XIjc5fM3SHxibJv/DthmyGNfMGO1I98ReegxcdFaCGNfqsprpe/QPMdrBLQwf9pqLeSHdhX+ADfKCPlCjq0tcgs6azoF+u4S4itY8/Aw2tgL92fyxWOke79sbUfFMPcDnFOR4RrZYNuDDsYc30/PLKQgBDO4/MFF88DRPax+LorQIsWMBeJIqINLKNQrwoWULTK6pEjhwK66P/LoIAFkDwT6bs6Df0F4DIRn5Z4aRz8Hhic8wfX7heKgVzYEVe/BuY58LrwuGInJse367gghWrnAGaFZOKSr9DAG+oGewahj7YS379hcZgR6kbcns388eTAId5dWyJoldj1fo47p463WT48k8V3AYM18NWWF9c/+f/bOA06q6uz/z/TtvbPLwlKWDlZU7MZubIlGk+ib9k8xGtN73sTkjSYm0WgsMcZo7Ni7iEgRRZDe2WWBXRa29zp9/uf33BkYysLu7Nwpu883nxsQlrl3zj333PN7KorFXf21M1igI99ZOPzeIB0rkSrW74v4uc+4eBqNK8+n3m57XI8hUsvQKWBuhN4nAVD7pUO9449aHFYQRhDYJ8LBsV7toyLJ2VfOYg+67HaEKNIhHnQdQB46XqK7ttTpfi708uZcGcPBTTH6OqOSsV5sXLGbiwsZTMMzL8LLj3HSI1cUvZAh0O1BYUrYUCH3/dTzI7Oh+vSDCu71Hu6NVFJyAncKiCSotp9fnClhX8KQQHFEGOHq9rRG/Nwo1DlnXhn3i0bfb+HI9RfvKBSLiyQIHz3twqlsPI3X+wLhwIbwk0upJMIV3Lesqg5bypQgxDoej49TKiPJyedO5s4MPZ12uQFCtGAPeruMQ5hf3mrTgbzwFe9t0/1cEKE5BWkHwtzdLs2qf+r5U3Q757rlVVru+TDNiygiBYGOkD09KJ9TzDnb7PU1HIwsiFR4O/LPIWiNYd6EJqZYqWJDLX+fiG6qL5pKrY3dEjIcjjVilHxPziFUz/gGnVJZjre+3PzjC8nlcLPRUjgUpGO1NXfT1tU1ET/3lV85nRISrWzojU/R4OU2nqdfODWi5+3rtvPan5AsAl0YHSQkWmj31vqI5qEjzH3epdOpt7NfwtyFaNEuHnTdNuAG2vTJbt3PA7GJo6dDK8Zv73OwaNerCBryn9G/PBwFapCjCgG7c7M+Ye4nnDmR28AhJx8FozweT8R6n2OcNnxcRanpiWH/bKvNol5WHbR6SWRDhy+98RTKzEnm4oDCMNYGo4HTUo7WfUEvDmQmRHizYTQaea34+N2tURnrc6+azZ70JvW8iBf9MIGu1t/ujj7d6oAci/ITSui8a+ZwwbN43ABDKCNM/5wrZ0f0vBvVngJCRQrECaMFFButrmikrZ9G1pB4zTfmUWZeKjng/JJXhxAlgd4m46DDopKeQFVb6iISmoNicV7/DhyFvBA+qFdv262fVtP+3S3snRq+aPBxoRu9ikgVT8ilonHZbARwOTyUlZfG+Y8R2UipTS/6sMODGG6Q14sNYiQMQMHMPG08b6o7mnvCHhUw2kBedCQFutFk0IRQhJPq8IyjT/Tmlbu55Vo0uO3Oq2jyrDHcVkxEehAGregkUpYQZRBprr/lbMrMTdXSZuLotmAOwbBxzmdnUU5hWkTPjfamXW19ZLGIQBdGB9hrYM8TaYcEutecDyNiYxdJMroQBdog0FtkHMIPwnJQJCwSAn3W6RM419Pe56SM7BSaM08/L/HWNTUsLMJVlRxhlti461FQD6H+k2cX82YKlefRE36iTn3hD2fZG5vUJspEetVUQy79mqU7qbMtsl0SETKclpVMPcgfFa0zLNzuyPVZhbc0WuIU3j5EfCx5bWNUzg8vyO13X0tety+u8571IC0jiXZu2kcVGyNfLG76KePooutPpOa6+AriwxyCYQFh+pEEXU9QLCsRxnGZwsIogQtapiXQho93RXy/c913zqa84kzuzCSpfUKEaYVAR/UeSdDTYVGB93Tlou0R2OiM5crx8J5DkJ54tj4C3d7rpA3Lqyg1MzFs1bxtCWbeoO1Yr48hIyDIOzt76YxLpoXct30o7NvdwpEGNh0L+aAQYXVFQ8Srm6Jwypd/cAF1tPSQFHQPEYPmWXa7IifQURDMZIxOFX54QJBqsuzNTSwyogGiim6762pqberSClzKZku7NyYD35Mlr26Iyvlv+tGFVDa9kKNy4sFwohWH66GrvnYGlZbnR/Tc21bX0M5N+/ldLwijCUT6oJbJR29vieh5kT76xe+dR+3qmY/3tpBCXIHNYVtAoHfJeOiwqCRaqWpzHecj60l+SRZ7h7scvbwR1YvKzftpf3Ur2WzhC5+32Mych1i1RZ9CcdNOLuV+7ZnZqXTiWZMict/XLKmk/Xtaw5IGcCygtZZGwSv51Z9fzKkC6E8qQicUfW7gmgiIeIkUaDuGTY7XE3mBjnmanpXM4mLp6xujNu433HYufe3nl3DVckQvyNzV7g3W4E8/2MFpM5EGxSdv+f1n2UgQKHQa0+K8rZcmzhhDX/npRRE///svruV0AJm3wmgDIe4waK9atCPi5/7SDy6gc66YRU37OyS1T4gUCCtjD3ojSSV3XUAeOB7qNTrnzmDRKJtayBv/sy6fodt51i6t5MrhZqspbJ8Jr4nJZKQqnQrFIaIA/drREx5V3SPByve386YXBbL0JDnFxi8svargH4vv330tZRekc16vvLSGrNC5CnS3v7BjJIA4R75sJMPqjxSDPnrnmU+jOvTfu+tquvabZ1HD3jau7C7h7sSFLCs37adVH1RE5fznX3sCh5I2q3dl4PmIPXGuhZgjVeprv7yEUtIj68Vub+qm1YsrOBJFEOKJsARtqc/IykulNUsruGBcpPnp/V+gwrFZ7EyS/Y4QAVAbrh4KAmbrVhmP8GO2GNlLtuXTat3PlV2QSmecPZ096XqB74HFKaybWrXwImR+x7paDtHXQ5iMn1ZIp104JSL3HGFYW1btofTMJN3DieEVRXTG0tc3RXxuY5798uEbWeR0dfSJ0BmaPmeB3hXBfDo8t2PG50S1rRW86Kve3x4VL0gwv3jwBvrS9y+g/bUtnLYz2j2SqCeCMVg4f03UruHH915Hp108leprWtnQHIsio35fK13z9Xl00fUnRfz8y9/eQru21VNqRpIsoEKc7YNNYdkLwTEEgfz2U6si/h3GjM+mX/7zi1q7XvXeFpEuRECgewIuvr0yHvq81DNykrnaNnJ29eTkcydzWwjdhGdlExe8S89ODntFS24btr+dq8PrwRU3zY1YezWE8OIlEs4og4Hnl48y1P1Y/Op6ruwbaeZdMp1+95+bydnvluJbQ1LoBg41j6QHHcCo4rBHr2K2xd8a6oWHlkX9Fvzons/T9++8ljdbKAA0mjdcgXVk7Yc7aZNOHTUGw/8++mWacsJYaqxtj6m1BHMDRQ5PObucI4eicX8WPL+aEpNtEt4uxB2I+giLs8IHh4uNlry2gfdYkWbuBVPo1498iduu4d0t+x1BR2r53eP/jxoZD31AHnpddRtVbtyv63kQyn3xDSfr9vnov8rh7ZbwC08sdIg00Kvd2gWfO4Fmzh0fkfv96QcV/H0itZGCFx25ve9Fyft1yY2n0C8euoEc/U42QolleVD6nPPpuH1LBCmfU8KtBh190fGiI+8+IyeFQ3WjVZQsmK/94hL63eM3k8Vq4kgUbCJHq/6B8aSzpZfeU0IwWuQXZ9Kf53+DSibmaiIdNyPK9yMgzkvL8+j/nvqqVkE9wqAjyJZV1VwczieVOYV4E+gJFl77wwGiLdH1Z+H8tVH5Lhd/4WS64z83ceSg7HcEHakJFujVMh46bcbVA4yw0o/f1bf6JDYzeojnACsXbtNtc4BFDsVvKjbW6vL5GBc9xyYAIgw2r9rD3qhIgfx9WKjfeOKTiBYdC+aKm0+ju577BofKBgoixqOnB5es9Sf36CrUMDYQ6E2BnNsIMf2UUpp60lhuOxit22Oxmjm8//kHlsaE2Lj0xlPo4UW308y542jfnhbq7XbE1dzFtWIcEQVQv7eN+nocvCaEQkZuCi16aT3VVDZG7fuMKcuhf7zzXZo4s4j2q/vh8/iicz8M2oGOHEXjsujPz3+DCsZmRmVMXn98BQsCPDuCEI41I5Ig6pLrfRjC81gmpybSW0+tpO7O/qiM30VKpP/lpW9SYpKNiybDsx/v+x1p2xhzVAcL9CoZD/1AK5ttSrzFq/Ubomv7+lpdC9Sgb/ye7Q0s1OOVxa9uYE9yuHrED4ZAeCp6Gb/y6EdR++4oTvifD3/IkQp16qXliLdWVupSIc4QOocQNq/OwgBVaVujEKZ32ZdOJa/XR74odYzBfEWxH/S0nf/Aspi49Siw+e9lP6If3v05NuQhDxoGlFifvniddLT2UMPediqZmEc/+fv1NGFaIbW3hNayDJ4uFH2c/8DSqH6vwtJs+sfbt9L518yhfdUtvKZGci3BubxuL9XtaeVe7Q+99z1utxQN4D1fu3QnZeWnifdcCAsQZZEEtU/4nROOKHfULMpIpB1qP/rG459EbQzRLelfS75PJ541kQ2JcI7Em0jn/U5zD9nVnhvrnaTPxBQ7ggV6vYyHfqCwC6qUb45ift9wQNGz2p3NlJyWoNs5ktMSuTrnrm3xORWxQCN0F/n0kd5I+XxaMbxXHv04KrlZAcYroXP/29+lr//yEh6Pxn3t5MHCH6NhYAHvY0drL4fUol7ET++/nlsoITfZo+NGBmII7b46I1goLiDQUa8CNR+iGZ6HFoTP/WMJj3uscPNPLqR/LrqdLvvyXPZEN+3r4MrdsRTGiDlrV4K1ua6TxfTEGUVKmF/HIvIL3z2HbvzeeWzkdIXQbx7PAgr5vTd/LW+AowmMOH+a/w265Y7PUl+vk1oaOg98fz3BvcYz2VzfRZ+9+TR6eOH3qGBsVtTG4YWHlvI6JKG0wvAXD+0Zh/ExksC4lVOYHrYIP6PJyJ0n3nh8he61nY5F6eR8Xnf/3/9ezs/ogf2OIcb3O2rMEL2XlpnE7w6kevWrNdbjkT7vMURjsECvU0eDjIk+IDQNFcojUc1dD1YvqeANgp5tw+C5QuGN3XEq0FGZunLjPkpJT4jK+dMyk3nsnrt/SVTHAcLrlj9cSf9a/AM6/aJp1NrYdUDoxMpLCtZ8FmBKpEIgjp+ST7f/6Rp6fPlP6JpvnEk3/egzNPO08SyA9HrX2hKtVF/TRvXVkW+g8f2/XEs5BekcGTNc4wnGB4IQRQKHQqraHOzb1Uz/+sM7MfUcj59SQHc8fjM98M6t9JnrTuQq7whzRgi5Jwq90wNhiGjv1d7cw9diVH943tWz6c5nvsbP2RduPffAunPeNXNo3qXTeRMWyrXi+UV3gaf++n7U7wVC9b+pNr//eOu7NO2kUvXdmzk6AOMRzvsQ+CiM8d6qJkpOTaDfPnYT1yfQ0yh9PJC2tPL9HZSZmyKbKCEswJjvdEb2XYz2tlNOHMs1jMJhrIfIhNMLzpyn7/0gquOJfet37riCHlxwG515+Qxqru9k8evkCMJY2O9Q0H6ng/c7Yyfn0a1/vIoe/+jHdO3/O5O+/IMLaPYZZewwkMJ3MSPOWQiZJmeejV9RAvp6dYyRsdEHWNYQNnvpF0+Jq+uGN+GxPy6ISA6c0+6mtKwkOvuKmXF3f5/9+we0dXUNpWdFZzOFhdhsMVPF+lquWI+CS9EkpyCNC8jNPHU854rtrWyktqYeMpuN6jBprZQi9C7ACx0vKbw08RLq67FTbmE6zbtsBhsTvv27z/KYBadwJKcn0tLXNrKQ1uNFyyHu6mV+2kXTaPzUgojem+z8NJp1xgRasWArpyNAlBkHmbeMDR6Pp1rL+rrt1FzXRSlKxGTlpyoRayerzTy4UEb1M6hKjQ4XiLyIVgjxQOD5QX/uc66cxYKNQ8nV5gYiGSksGC8Dhd+ji7FFQSWPV4nyHniOu9jzlJmTwjUEvnj7+Txnr/3mmTSuPP+o9w2b18WvrOf5PNTrC0Tj7NhQy8YK3JtoAw/2pV86lcaU5XKnj9qqZupXY4IoFK4jF+I9CMxlGJcQkZCuxvi675zDnSlmn14W1e+Mjf6fb53PqUJ4ToYLPGQYx8u/PDdi3wHPyjvPfMrjjPUu2vSq9Qq1JrDmRoo1Sys5nScpNQYq8KsbAXGOauQTZ0Z2q59TmEYLntMK2SLKMBxY1X5044rddPpFU9lDH9X9jjo/Cshh3cD+Yu/OZo7CgYAPtLGM3G3W3iFYOxBR2aPWt2y1HztT7Xe+pfY6EOcIzcc6HyAtK5nef2Et7/GNpug/q6Oc7eq4jw1AQX+IVmunytjoAzZLe3Y0cBg3NlbxAqqS8yY+Vf/qtXiJ795azyFYkSjqFjZz1752blGECtXRyhPEaSG0mus66Ik/L6S/vfKtmBib09TLEwdepKjcveqDHVqOer+L73eKEsJWW/gNPwjxxSY+cB68jCDKz7piJp1w5kQ69fxyyi8Z2Ihxzmdn0oy54zm9A8Wzwt1aEJ+HOV6phBBybSMNNqqPLv0hPfSbN+iThdv5RR4YJzagGA0HxaLby88koiCwz8BaBnEEUT173gTuklA8PoduueR+FlCD7dWMzQDO98gdb9MstbHJLUqPuWcb3/G2u66mr/z8Yk5hWas23CgEic4cyI3GmKAKPAw5mMdDWbcwtm63R81VjK2LPwv3QBtfKxtupp44lgv7zVD3CyGVg+GMi6fx3EVKVSjeV9wXfI/H715IZ1wy/ZCNXLTAGF/11dPpws+fQEte20gfvLyetqyupt42O0c2QMTy3D3G+GPuYi4j57K/x8HzG/8GVeO/9IML6JIbTqbiCbkxMe8QwbB7ex0VlGRJ7rkQHqLU3hOccl453X73NfTgr17nCJ2UjEQW2Bx2fdhGJiBqjzfvE5OtHJn6yO/foXte/VZMhJbP/cwUPhAtu+ildfSpemfU+XPU8Z1gzLYmhL+WExxoiPay+2sg4R2C/Q68+nPOmMB7sGM5bfDOOPGcSbTho10SsRN9qgO/Cd4ZS6s1XQW6lcNL1ikhF08Cff1HVWx5hmdbb7BwwUtVtaWOppxQEjdjtPT1TVSvNuyZealRvQ680LIL0mn525vp+X8soRtuOy9mxgghVDj6uh20bvlOfnGhsF31jkY2cCCFImBp5nQKk5GLK+K/tePgdwz24nq9XhY6OOAlRx4V/i4zN5UmTC9UG9xMmjSrWInyCTRhxhguMDO4vYyBC9+tX16lVZLWIfQLG5Gta/ZG7Z4Ujcvm1lGI/Pjg5XXcChIpCT1d/eR2evh+QKzB8IOQ9IzsFCoszeJxLVfP5/jyAjJbDwqia79xJv3thy/525UZBjVfkfO8Z3s93X37fPrLi9+M2WccOY8wpOCA4WeXWqPQ+qpqy36qq2njaAiMHQwd+F5IBzIYiIImbsAuw7/H3MXYwZiROyadc67RAq+4LEfN1zHcs75IjXWomzlsuOC5w3Mx1LmrFZ5MoW1qXjz6h3fYQBEroK3k5TfN5QPviVXvb6fNajNcu7OJ3x2IONDSsQyHjD2Gn4W8msvYqBaeUkrls4vplPPL2chkS7DEzHdEZAsKYGXnp/NXEH0uhEmf8zPQ1hydOjU3qv3IhOlF9PIjy7lVGjy7MJgFL0+Y6zAGczqlkY5pGMf7Hp5hFFJEah+ii2KFGaeO4wNRZliHkQKJdrjokIF1CutTwBAerv3OuKkFVDg2i/c7s+eVcVvVlCGk6ODdtmZJxYFcdSG2BPomGRf9MJm0SQ/vC/I+4gGEqK1jz3Bk2oahkjvEWuWGfXEl0LGhOniPo3stWOzhlcbG+tTPTOEK1bEEIjEQaoUDLxh4XPHSqqls4hzTxtoOtrAjHxTebw+3AfG3PmMRb+SXN3sa1aYaAgYCEi9qiPG8MRlUoIQNKscWlWYPq/MAwptfeHAZG6j08CIi1A/CAiG78OJFC4RO4wDIXYZXgjdJatMArzBCvGHYOF7oG1IakDeLPN6UtMEZQjAHIJjQ3us/dy3ggjWxTqKaC4ENGG+i1HfAprelHkX/etQY9nLOOrwmSNvBHIahw2Iz8aYMzwBaD2GMkOOMlIOsMBv3ECnywkPLOK0jFJGPdxXqFDzz98XsWZl3yfSYuw8okIcDwKiEtQT3ACK9p7OP1w+sx1gDMIfhGUKUBuZbtENiBwLezft+/iq51ZzR0kVkoyyES6AbyOX0UPO+jqhdAyLXcCB1sr2pm9/tATWKX/BcPvbHd3ntGswzijoVWXkp9N+7F3J4+XT/mhw7+50EjkLCgdoZMObyfmdHI7f1hNMOufn9fdp+x+3ysgj3oIuIf5+DmiMmi3+/o9YEGBmxNufzfiedu17A2I5jOPuUuZ+Zqj4vkyPDrDFksByFbD6aQMcfooyfJCDoAN6z8ErA64I8WAiKWAfhvWg1g/yUiLxATNpCHU+V3NH7HOOEzV8s7KW4gIoS6I37O+ju216ge177NgvYWATGBAhTHGdeduh3gEjsVgc2FIHwaliYIXTw0sKvsA7DA6lXfiNEPqzQK97bqotAT0jSIkZgYY+mQA8GaRo4QgFiE0aNB3/9xqAFOs8DtclCjiIE+rgpBVEJ+R/WuqXmMUQ2jlihZEIuh+cjZDHUzRbmZ2+Pie5XgnHi9KJjpoREG8w3PKvl8TV1juD+X7xKuzbXUZFae0ScC+EG78podnoJgMip9AH2lWdfMYvefW71oIyLeEYggrGn/tuPXuKq6rGQkjPQew4RUjiCDZ74DjDMYc/jcmgindOd1M8jygq/WpQwx74O71i90j/HjM+mWWeU0aIX18VkutlokYrq2HpgzgT9BWIt22V89AMPGXKEt3waH+3WPnxrM+e2RCy1R01NeH93rNvLVrx44P0X13I/yUj2Pj8e8ErmFqRz9f2HlFiKN2Dpx8sb+aDIw0XILzy8yMeFxwzFq/CSg5DUu/jQnLMmcCiePoXiTGwt36gE+kjhxLMnsVCFN2DQjz02Wck2Ho+//uDFqLf4GikbcXj44VkOtRgj1pGs3BTas62B7v3JyzKoOvPSI8vptX9/TLljMkScC7oALywKEEIMxirTThnLkXCD7fyCCCa8c2Dovu9nr8blfgctz7CnQVHOwH5nyokl2n5nqrbfQdSV3rWZkPaDdwfWfiEqQIPXHE2go9/Pdhkf/YDH0N7n4tYpsQ7yKZF/i9z5iL5AEi3cfqmhtiPmxwgvuRXvbeNrjrUNFbx6ecUZNP+hZfTSwx/Kwxci4ybns6cenvxww7m+OSm0dvlOriI9EpgzbwKNm5I/5J632BBkqA0Iwv1+fsO/uSWMMDwQlYF3DmooDAesIwtfWMeREYI+IEf1gV++ztFqFptZBkTQBXiXuROC2mPFKij4iIKYQ3nn+khLlZr/4DJ69r7FcqNDBMVIkc6GlEIhKmz2a/EjBDpYK+OjL9YEM4dFD8XDFA0gzpErA492RI0YJiP19jhoaxz0jP9k4TYuFpUa4TEarPizWMzsib7/F68dyJMXhi5y2Jpv1+d5RU4ZcgJR4X6kgJ637hBe8IGiP+gP/7PrH2UjoTAcYZ3JrcOGY1yC3REiH7mOT/71fXr9PytkYMMMalDc+Z1nOZoGxkCfeK8EnUA3hO6OPq59EsugEKlrKP3afVqEKmp5/PN3b9GHb0lJrVAYOzGP63V4PLIGRYlDNoKHC/QKGR99Qc4sKv9uX7c3pq9z+dtbOJzGaIxs6wrk26AFDvrwxjoobBXLfSMh0pPRHk/dwju+/hRtWyONGoYKXvioYI48eD0ItJlZ8vrGkSPQTyjhKvChhFb7uGhcBleW/83NT8R0KGasg7BJpA54PJ5hriNahw2IR6QgoEuEEB5Q1A4RIyiOijomEloq6Lsn0IzCqE0Ry8AbPtR3Lt4dKMCJEO0/fPMZ2vTJbrnhQwTjh6g+j0s86FGi4lgCXdxsERCgqOy7dlllzF5jw942XtxQfCMaodsQvfBMxzIQu5tW7GLxFsv5gtjwoQUHipD8/IbHaNfWenkIhwAqpqK7gJ4WZWzMN3xURR+/OzKWX7R6wTM8nNBqFCRDK74fXP0w9XbZZSKGgOHA/4VhY6/WEURTIXUGxj509xCGBypZ//KLj1HFhn1cPdkrXishApjV2oz9S39v7Nb5Sc9JZqE91L0V1qm0jCRu5/qT6x6lnZv3yw0f4t5b86B7ZTCiw/ZjCXS4cepkjPQDCw5yltctq4rZa4RQqKtujVo1TGwEd2+vpz07GmJ2jJa+sYmroVrjIF8Q7T1QlRMhwz/+3CO0e5uI9MGCFz3yqU06Rklwz1clpF7+1/IRMWZaJfjkoYUoHrJGHhT6mz/ZQ9++8D7aX90qk3GI1O9t41aZ2HSFZR1hY18KF2/66fX/pnXLRaSHvK702OmnSkBsXLGbCsdlSVE4IWKgq0t1RSOtXhy7tZASEq1c0C4UoxXWqZyCNA7lxzMGA5gwOBx2F0et6V18Vzgq0N7rjyXQUamoWsZJ58VHCV+Iz4oYDeNe+f52FiQmkyEq50e/4PamHtpb2RiT49PV1kcfvb2Z0xXIEB9zLvDSQt/N2z/7EFVIpexBgVQU9GhPTNHPWMXF4rJTuE7AktfiP9QdYXI4uMftMClQIn3npn10+xUPUeVG2WgNBXTD6Ou2h7XyLzbMEOkOu1Ntfv/NRTKFoQFD6fcuf4irTueXZGiNdQQhUvsrq4n6ex20clHsCnSIc+SUoy5DqPud3MJ0Lr76k88/QltXi6wZDLu31vMe0SqFKqPBLr8GH1CgAyn5rPfik2ilhto22rwy9tqtVW2po02f7GEvWNSM+ihMZDLQxk9isx3dh29vouodjZScnhBXmyt+aRWlU0uD2iAqwbNmSaU8jMfh/RfXcYi11WbR9TzYjKDNGApxDba9zGgAxgsUO6uvaWVPuuQ/Dw54QRDlg9Y8YV9HlEjPyktjb8vPvvBvWvDcahnwQVJb1US3XvoArf+oiotPiuNciPyaSpz29smCrZzOGJN7FY+Xw9UNw+hvykVH81OptbGbbr3sAfpYCuUel/fmr6H2lvBFXQlD4qPD/+BoAv1jGSd9QUQrRPq65bEX5v7BS+uoqyP6IS4oTlcZo6FJ77+w7oAhId7ASytPifT+Pgf98Np/0ltPrpQHcgAQSbLoxbWUpV7yeoegYjOCgnToXvCvO96O63FD6kdbU0/Y2kX5/NEf8Mj/+HP/ov/86T2ZnMfhhQeXUdXm/ZSUkqDbBho90uGN+93XnqL/3LVABv04rFlaSd+58H6qqWikMeNzZECEqIE0y7qaNnrjiU9i8vpQnwF1c2C0Hu5+J/Du+OWNj9Erj34kN38AENHz7rOrud2pEBVWDEago4qcS8ZKx824j7jXIEIQUb01VkA7HoQ9mWMg/wRVg/fvaeGe6LEE2s+hQFJaVlLczj/OJc1JIavVTL//f0/TP37xmvS9PAx4IB/81ev8TOjtPQ8AZ0GmEukvPrwsrkOHEYWD/L+whlb7+6Tj+Odv32ShLr3SB16jnn9gKaVlJrMxWM91BPVC4KVHj/Tffe1Jqbo/AC89spx+cNXDbPxGFJPknAvRBs/uG0+spIba9pi7tsqN+zmK0hCGFMID+x21p7z7tvn0tx+9pFtXlngFtUruUePi6HOy8UaIOJiQOwcj0PFD0g9dZyxq84rQm7XLYqfQzpqlFVzdE72zo01ikpX7Ie+IMS/6gufXcNEwLPbxDF5aSWkJHKr6xJ8X0q2XPUj7d7fIg6lAfh76cKO4DPJtI7WZxmlQMR735q5bnqN9cXo/Fr+yQRejBsYFkUcIDV76xkb6yhl/oaUjqD1dONi/p5V+q4Syvd9JiclW3UOoEd2AfFHUCnjryVX0zfPupe1rpZ1jgJ7OfvrN//yXn2fMXQgFaaUmxIRAV+//hr2t9J87Yyv6BRXEV6u9aGKyLazvDnweDOBP3bOIvnvJP2hvZZNMAgXeFVob3r2UlZ8m61N0QChrxWAEOpBEP51B72wIvVgKc184fy1bLGOhrzdC7J0OV0xVHIc3H2HP8Bj5RsAihu+AYiCoIoyogK/M+8uoD3lHAacfXvMIffpBBbf6ivTLiq39ahOByJrffvVJDvWLJ95/YS198t42SstM1MmIoeUlFpVmU2+3nXOgMU6oqzDaqalspB9e/TAX+clWcyhScxf3BAVFsY7UVjXTN8//O6chhFrFf6SwYsE2+p/T76YFz37KfZ1ROFE2v1HGYJAxCHrX5BRm0OuPr6BFL62Lmeta9vpG2ra6hqvNh3udQm51SVkuh3N/49x76LXHVozqOYBItx9f+wgXqC0szSKpWBk1jlogYSAl9oGMl/5gAcJChKrgsSA+ERqZnJYYE+F3uISUNC0NIFY2NSi6FM32c3oKngIlRpGn9X/ffpb7pWOjPdrAXLvtsgf5ORhTFr0cURhOCkqyOB/9l1/8D1fijgfgvX3szgUcIme2mHWft4j0yS5I4yJlXzvzr/TSPz8ctQX21n1YxZXuEXVREAXDEr8y1JFTmMaeKqQh3HbZA7R5VfWouxcw8t39vfn0k+v+RU11nVQ0Llvr6Rzt95hoU9Efh2FNMHOkDVJUYsEZgnXrpX8u5/VEj0Jlgb0t73c8Xvrjd57l53TP9oZRd+/RRerbn7mP1izdyc4IrA+SeRM1Fg9FoMOs5JAx0xfkAHG7tRhoH7T87S28ucNiHSvYkixcLb21oTPq19Lf46CF89dQcoqNC9iNNAL5pNn5abT41fX01Xl/oSf+/F7ciMPhfnfk7MLzBy9kXnFG1I1UPvU/hHJ/+sEOuuXif3C7mFgGaQG/ufkJHj/kiUdi/DTPrZG9kwglvvOW5zl08eN3R0+1XhjVUPn/1kv/wcX5UBApmgZNnBsGTNwTdAP51vn30l++/yKL1pEO8lpfe+xj9pq/8NCHlJaZFDMh7TDChqPtYTyDMZAOGYetoWpupmUlc9QNIpGwjkaTf//xXVqzrFL31DI8k8mpCfyOXfbGJvXuv5ce++MC9R5zjor7/uLDH9J3LrqfjTIYA/+mQ4jSq4O0EPcjME3OPPtof4636UXqKJWx0/OFQRymmZmTTHM/MzVq14FF+d4fv8RtcxISY8s73KeE8bSTS2lceX5Ur+OZvy+mBc+tYQE7kq2M2MSkpieR0+mmD9/YTMvf2cx50RNnjhmRhgmE9iP/Ct7X5LSEmEtfQDHJ3dsbuD/6hGmFUfXsD0T1jgb6/pUPc894CLNoGDeQB42cSkR+vPP0p7Tl02pusROL4xUuNq7YTf/7lf+yKEQ0AQRhLIVQ43lCuhTaOaJdob3PQZNmjBmRRYgWvbye/vjtZ+lFtY5glcwuTFPrpTFmrs/tcvO7/fxr50QsAgyFp9555lN+X5pioPCs2+lh4XfhdScOq33XUEDlfoRTI73BEKvh9T7tWYUzZPXiCjrriplhDy8fDFi37/3Jy9wCzmyJzHzh/U5GErkcblr25iZa+vomri9Upt61sTBnw82mT7R3BgQ61oFI1tgRBgSd0/4+FIEOJqnjLBk7fUGeHvrKXnHTXDJESQDd+5NXOG80Qz2ssWRFw3h0tPRQ8YRcOvncyVG7Dry0/vbDlzi6wGw2jYp5iRZZsKy3NXZx0a+V7+/g+1EyMW9E9MjcvnYvPfy/b9JDv3mT871hRUZhs1h8WUF4dbT2sshBJMfM08aHtUL6cHjziU/o/771LNXVtFL+mMyojh82W2grhs3lri119IESTdgcw8AEoT5SNlw7N+3nufvAr16npn0dPHfxTMbc3FWXg/UyPSuJDa2IbECkFgzCxWW57MGKZ5x2N33wynq658cv07P3fsDvqtyiDM3IHWO3AnMfc2X2GRNo7KS8USnQ8f7q6ein0y+aRhk5KSLQD3tWIVQRAbVS7QWnnjT2oGc1Eu+R/35Cf7n9BRaNWL8jupT5w+lhnG9v7uZURuyH4UErmZjLdXrincqN+/id8aDa7yBNE/fWlmCWkPbY4GkaIMT9WAIdpbxvlLHT/6XR3tRDs+dN4Eq4kebh375Jz963mD3DaGsRU2OjFkiEzkKgXHjdSVG5hqWvbaQ/fPNpji5IUy+wUbWg+TTPJKzrdXtaaMlrG+ijd7Zw1EeeEmPw7sYTCPHcqDZLmPN4WcHLiugVeF5j+jagurvauBjU/z5+ZytvHjD2E6YXRe2a4L39823z6al7PuDnNJYs8ZpQt7GRadeWejZsIFWgWwlDrLHJafEnDNF3fNPKPfSvO96mh379Bm38ZA+nEiAtJeaXEf8GOEXNWRiaPnp7My15dQM17e9koZRTmB5X9wLt/d5+ahXd+9NXuN88hG9WfmpYq06HXaCbTGwkaanvpPOumRMRI2usCXQYi1BMsqfLTudcOUsE+lHAM4r5jGhBCNPpp5Tq6jhCtBravP7zt29xlwOsZ1GLAvJp/eGTkhOoobaNDbwfL9hKXW29VFiaHRdr7eFs+KiK/vX7d+h+NcbY76RlJ3GEpBBT/BU2lKPuZa4o+/VA/wh3EWXfi2X89KV2dzP97L4v0I3fOy8i50Me1uolFfTMvYtp9eIdlF2QzsVCYrEyuaPfxQvjQ+/dFjEDBqIa0HICYc/wHlvU2CCEFJvkUWtI4hxGD/WqzQ2EDnr5nnxeOV34+RPppHMnx7TIbdjbxu24lry6UQmb3SwkIW6wIYin8C7cA1xvpxI56AAxY+44uvrr8+jcq2azEUtv+rodtGLhNnr7yZW8fqBHPHKeTWrjG6vjiDFDbnBvVz9vzOHhPPncSRzGecbF09hrFMugR/HiV9bTh29sok2r9vB3ychOYYNNPIYmQqP41DLa1+vgeQwv+pwzJ/AcnnfJdK7/EIvAUIxiSlhHVr2/nSNG8F7CYY7h+X/4s9DS0EmzTi+jH93zeZo0c4yu50PINGoj4H0aE21JMfc8PhbpF11/En33j1dRvs7z7ZHfv01P/Ok9LmZpiJMK8hDkqD2DNsAnnDmR/ucnF+pi0EDu97/U+CCaDc89nAGxkqLD+x213+P9TkcfO7BOvaCcjVunXTg1pqN/sN9Z/vZmWvTSetqi3hkuvDNyUjiyR8LZYw4UICvH9mqoAh28qI7PyxjqCzaO5XOK6eqvzeMNDDZh4VpkvOqBxOc51IYeGyJs+Co37eNQJlgMsdnDghzLDy5eFtffei5NmVMS1iImLHjU/5CbBkNAZ3svNe/voF1b67l4BvpDYnzgifNJe5xDXuAIte7u6CeL1cThw3PmTaATzprIm7/CKESCBIP5XrWljj0XyDFHNfS25h4uKIYwNvwazy8qfq69Xupo6WWjCdIOTjlvMp149iQOfw9naCK6O8DyvmVVNa1VY4nesXhmYLCKt+ciEJGDNQRGBVTyxXyddfp4jmAaV14Q9S5MEDMIz1+3fBdHe2xdXc0F1jBn09TcjRcxONh1BLmfeC/hG2HezpyLe1FGJyphUDa9MKqiBoUZsYZsXLGLNny0i9+ZMEqlpCdQktqgx9s7weCv0oxQfAjmE8+eyCIdOb/ceQFzC3ciDF8L47N3ZxO98ODSmPGgBwuv9qZuFs2zzyij8VML+D2PMQlntX2skW8/vYpbs6I7Tjx1eAsYgzFXIJpnnDqOxemp55dzfvZwxOOK97bRohfX0aaVu7lOQ0ZOckxHJmKdsvc6WagjtQztyE44axLveeao+VM4Ljvq+51dW+u4KCciNratqWEjFGoGpY+wd8YI5OVjaezjCfSb1PGkjKG+oJAONo6w1mFhDOdCjucSm3mXw6NeTB72Gian2tiaZoiTol8Yj862PhbSeoTh44WNz3a7vWS1mXhzgXDFkVgULdxg4YdxAy9yi83CHgkU9JuhNtoTZxRxviMEvJ55XBAw+3a1cIGwHev3cvRDfU0rtaqXFF6ogZfUSG0zBG86wkkTkizcLqVkQi5NmlWsxj6XUxEyOIw/kRJTbBwpY4aBgl/sat4rgY/NB9IWIFwxZgjh3VvVRLu3NVBjbRuHPEI4wgqP9WMktBLGvEUOMcQh1kGEWReXZdPUk0upfHYxz1vUvtA7MgEG0/rqVh5vtNyE8bRhbzuHIsMAkp6p5q51FNS98GnGCYTAYz2GWC9W68a0k0o5H7Z4Qg7fE73CTGEo2L+nhTuZIF8TRikIctwLrG+IuElItsaNF/R471M8+xAcCHvH/gPrczjfdxB1MN4iQsUQg+2bcE14/rvUGDj6XPyM4V0RzjHAPOZ1V80bbxwb+Dlqq62PnTyInBuvBPqMU0pp/NRCjmrkVJuMRK7hgnuOfRSep74eOz/PcHpUVzSyoRz1MxB9gp/Fe4n3oL74Ggve76jvZbWaeTzGTSlgA8YEtd8pLVf7nfE5HA2gF8iT37uzWa1VzVSxvlaNaw3V723jd4YJ+x0Yzy0maasYH3xZHc+EKtDhet+sDouMo/4PPorF6fM2In7xxPPmAuHliAYw6LHqYHxgGBFBPqwx9KhNH3L1kUIB0Yg5jcJhBaWZlMsCKFf9Pot/n6s24MijxosM3hvkRGKOmvzikTc4SjzCcILPYwOWEpFdaqPQXNehBHgbv5Sa93dS4/52LnyCAkD4LHwmvCG86TQZRkXdADzaCGVz9ru5Aj82SBA8GFdshBCSh7BoiL5ABAE2kLhndrXhYM+yGr+e7n5+FvDvsNnCrwHP0kgdN9QmcNgxZi7+1anmMApmjhmXw9W4ERECIxPC47Ehy1J/Z1NjGZi78AJhTLF+YJ2C0QNeOGxUsantVwdC7BHxgHZGKEqIA4YQHBCB2MzCaAoDCjav+DXeNq/huh94D/I6ou6Fw+5k4zLuB/qJQ7gj8gHGE3QMyC5IpcycVG7JifsRmN84AkKRDbAuLUoKn9vd3seh3tjQ7t/TymuHdh80YxSeDTwrWD9gkDKhovQIvg+Yq3i3hvM7whOP/UbgPsT8/kKNQbgjIjAGJqNxROwrgp/LwHOE93NyaiI/m3i/WGwmNoQHHB54p0DIIocbH4BinXiX4NmK9yi2wH4H7wqHetdinYcjDGsSjBaIzoChHN51pIFh3UrNTCKbWtuxVkFAG/3rlE/7OH5f8DqFz1Sfh8hajB284XXVLbznaanv4ndHnVq3kGqIQm+811G/4rNHy35nhIBW5jPVsTNUgQ4WqeMCGUtBEIb0QvcSb7DtfS4Wi7xxNmsvJYgabKYRzYGIBWyu8XIJrpLPglO9rJBq0KU21diw82aSRZCXNwjYBEIsJSRq1nt5OR258cTYQ4SykQsbUf8gadE62EQbyKjuC8Y+VqrDR3vz5fIbmSDYAcaFx0nNW/weXjGOtEmx8XzG2MHAhM0pj7dfFCIqCgeLdhhhed5q8xfPAuYtRCDaCsncHRiMKSI9sHnFnDX7N7gYcxiRUIQLhQF58++fy+Q3vvA9UfcTBj7UUYDAwGb64Dri5bUD/1YzuMgmVxAGA9Y4pH3gXRx4txj8zg6sixaOTDCPiKir470zoLSxtuC9ASM5jDMw7gWMtzC8BvY7ENT83sD71q/QMY4uvzMC6YP4LH5neL0c8XJgv5OoGTk4skrWqXjmA3V85pjTahAC/afq+LOMpSAIw0Hb9PoObH4htvHSYfHof7kHW9XxUoMgCgh3o98bY/D/n8EgEQ9CpOau5mH0USDayXtA/Pm8vgNzO2D0wNTkTaqatxCMgblq8E9embphvB9+L3nACBW8jhy4H3wv/MbBwDoi90IQhFjZ76iFiI2Ost8ZLfxCHX8arkBHmPsOGUtBEARBEARBEARBCJkppHVKG5DBJAjhA5bIWAqCIAiCIAiCIAhCSCw6njgfrEAHC2Q8BUEQBEEQBEEQBCEk3h/MDw1WoL9BAzRSFwRBEARBEARBEARhQPrV8WY4BTpy0D+VcRUEQRAEQRAEQRCEIQEtvT2cAh08J+MqCIIgCIIgCIIgCEPimcH+4FAE+kJ19MjYCoIgCIIgCIIgCMKg6FLHe3oI9GqSYnGCIAiCIAiCIAiCMFhQvX2vHgIdPCnjKwiCIAiCIAiCIAjh19BDFejoh14lYywIgiAIgiAIgiAIx2QnaR503QQ6ctBflnEWBEEQBEEQBEEQhGPyojp69RToANXcnTLWgiAIgiAIgiAIgnBUoJnnD/UfhSLQN5JW0V0QBEEQBEEQBEEQhCNBaPumSAh08LiMtyAIgiAIgiAIgiAclcdC+UehCvQ3SEt4FwRBEARBEARBEAThIBXqeC2SAt1N0nJNEARBEARBEARBEA4HWtkbSYEOnlBHt4y9IAiCIAiCIAiCIDCo2v50qP94OAJ9H2kV3QVBEARBEARBEARBIHpWHXujIdABisX55B4IgiAIgiAIgiAIoxyEtf97OB8wXIG+krSCcYIgCIIgCIIgCIIwmkFhuE+jKdDBQ3IfBEEQBEEQBEGIWXxEBhxe35GHjyQmWAgXjw73A8xhuIiF6liujrPkfgiCIAiCIMQOhgiIDp8hRLF09D8++l9EaZx8oV6LLzJfY0jXF+I1+QzxOvmJjC4fme0eMrm85DMayGs28K8+o/8HfL4g0a5+3q39nDvBRG6rUXNl+iI01yI094+1JsTtvY4dPlLHglgQ6OB+EeiCIAiCIAixATbaJiVOrD1u3c/lTDGTx2JUG//BKxlrn5tMTiWGDIZgPcXX7Ug1k9dkiIhxASc1eHxk63azSAu+HuBIG/q1QOBZet1kUcLw8M8Ln8jyKbFp5LEa7Hyw9ntYrA76mgyaajR6fAf+G5+jCVxN7LptRvKZDDHlfcZ3NDu8LModqRbqKE2m3hwr9eXaqC/TyvPVnWA8oIrxc9ZeDyV0uSipxaEOJ6U02Sm52cF/71Hf0W0zkdcyzO/pH088k2wIOOw+4L+cySY+F+Zi2NcEdc8wNlY1N484t5pPrkQTuZLMupx7FHFvWJ7vK8p+Ha4LQj76XLkvgiAIgiAI0cWixFj7uGTadlWREhZGMrq8YT8HBBq8jlPfrKPsnT1qc2867r8JiL0dlxdS89RUJWQ9B4V+spnytnXRzJf2sVjA5+sNjAR9WVba8vliFrsQdixmIDqVUJn9XC2lNtr5egaLTQm9nRfl097Tc9gQoYd4xVinNthp1vO1bGDg6x1QzGvfc/d5ubR3bjYLtKGAe4ZzYE7huyU3Oymtrt8vYp2sOh1pFjZkRHXO92nisy/bSs1T0qhhRhq1l6VQd0ECedWfkVG7pwFhfogyDvwK4drtosRGB6Wr75i7o4vytnZRxt4+NnjZM0L/nhi/jtIk2nxdCXvuje6DFwEDV4I67+xn97KAhwc/rOJcXbJNfW53QSJtuqGEowNMgTXBpxmiMmv6aNb8Wv7vSDx7I5AV6pgXjg8yh/GiHhSBLgiCIAiCEH0gyLHpbjozR+3MjWoHHn6BTggBViJj/IfNvNl30fFFBbxzuJK2qUo8KcFIHa4gBWOkjhMyKG1fP01Y1kQ9uTbdvegQSfACN52WTZ4cJeL6/AYDCBQlSj2v1ZFRiVsagkA3273UMS6ZOs7PU9/PqY93Od1CjspuIgh033FOgTBut7qmMv81tTuHdi6/55fFLQwsLhxeSmq0U25lDxVu6KCCTZ0sLCHUfTqEhR9LeFrVPWPxOzaJts8tpNq5WdRbkqTumVm7ENzTLtfgr0nd+34lpPsnpVDDGdlkanNS3rZuKlnZSoUbOyhRCWl7qkUzUA3he+LnU9TcNloM1HRxIVGT46BxAMYDNcdS6+00S4l0N+ZbGMcQRhazGqPKSwuo8XJ1bkTWBIwVMDikmGnM/VVk7Vb3UM0tISQeCdcHhVOgoxn7reo4Ve6PIAiCIAhCFDEYNA+dEhcspJ36CXScZ7C5qwitxY+aIBBa1bV1Bgl06IU0M22+uZTydnRRovo7DuHWU+whTxm5x0q0eiAsAwI9ELYNQWocmjcR3myIIWpxDE0YDgUlkA3BYzeI+WDq81/TUP7d4ULd/1n4fZ8SxDVT06jmonzK2NxJ096so+I17eRMMnHEgZ7GFU7hUPMuocNF/VlW2nr1GNp9Xh65SxKJ7B7tPnaGaBzBcxNIDYGdJtlM9RfkUf3ZOZShBHr5ggYa+0kbeU3EBokDBozj4FHPi02N/awnqmnxhBTywnDWdzCChNS4VV1WSKUftVCKEu8wsIVj7mCs8Cw1zkinmnNyier6NYOdwW90yUug/IWNVP7Gfg7/lzz0kFjt18LhMaiE81lRxz1yfwRBEARBEISQBGCXmxxK+G3+cimL4+AwYCHKBCqdBzzpEJfI01Zir+OULFrxq2n06TfG8z1DOLVeQo+95sgZV+J8txKc7/9xBlV+ZRy5EcbORhG3dn2+o8wvGF7M/sNi1A78Hn9+NEMMPgPGLXzPXjd1nJhJq34+hZb+tJy6CxMpWZ3PMFgDFULJ0y2UtbOHyt+sI0o+TICr7+TOt1HlZ4s44oHCZFODIQP1CrZfO4YNYAfEOYCnvs9NU1/exyH8nGcvhMJfKWx3LLwedDBfHT9Rx0lynwRBEARBEGJQZME9YzMNv2K034Me1pBmXFOrg2rPy6XczZ00cWED9eXYRs7YQwxaw+AfSzJr93C4QGzjc1A/4PDiYAb//6H4H6QHcpZxHH6v8WdNdqIEE1VfV0K9+Ql02oNVHHrOdQnCaGOBEE7odHEI+IqvTaB9F+ZrHv1G+2HXHQQ81Ul+yQPvOq6XBbz/woxBgh0/i3Ho9f9c8GfCWISoDyVim8/NpcXlqTTz2b008YNGLq7mSjAeP2oA2QEpZpr4bgPVnpZNPaVJmkHB4D+H+m571GeXfNzC9RiQ8z7c8YPXvvrsHGo6NUuLnjAEzUd1LWWv11GuOhciEaTVXEisUscL4fxAsw4XebdfqAuCIAiCIAixBLSh0h22Zoe/avkwtB0qtyuhgwJkFM4CYS7NQ7vtumLK3dpJKepa7emWyFR113nsjQ4vWducw/YuO3vdZIW3+GiCdIhGFmuHk1IqHEcvDObTQvaRp4974IGIw89BrKLYnNd/fohcv6e5+bw8WqvEOUQ65gZCu8Mi/NQpkpVA7ixKpJW3TaTOEzO1FA6n99Ax8AVEuYn/kVmJd4Tgp9XZKaXBzp53a7/7QGoGrg/V3vszLdSbl6A+P4G6SpPJi+/q9UcKBM4REOpNDnIr8bz+e5OosziRTnhmLwv+wYT2IwUAIexT3qijNbdPOlDvQDMgqPPk2mjnZYUs0NEmLuSCbQatHgLuW+UVRdq1u3wHQ/KVOE/Y30/lSqB7rEZZG0Pnb+H+QD0EOiwI31XH2XK/BEEQBEEQYgibicxKkJ3+j52UpMROOKpFo3UTKrCHDX+ou70kiTbePI7O+vMOLkKHMN24Rgmi3JVtdNLje7hqt89oGNYYGfyibljV0zOsfE1n/6VCiVPb0QW6UWs15kwyU2+OjVqmpFLtKVlkn5ii5Woj3z5wCbimJjvVXZxPO3f10LRX9h/9c0MR50r8t5al0Mc/K6f+8cma195Lh3qEIWYzrWw8yP60jUrVd8ve2U2pSpyjkJxXCVEvppE/jz7w77gPuj+lAnUPupTobp2UQjWnZlPHzHQtNBwFDd2+g0K9282GgN1fGkvdhQl08n+quYr88cQuBDw846UfNtO+07OpYV6OFkIf+Nx2J9XPzaLaudlUuryZevNt3C1hyKjzJKhnfcv1JdSJ7wDvf+A7Y84kGGnyW/WUvq+PevITZG0MjeXqeDEeBDr4kwh0QRAEQRCEGAO6RG32Ic7hmXaFQaBzL2xzmHth+4VKw1k5VLUunyYtbKS+nDgPwUUfaoeHheZwBTr3QYdnOwz3j3UhBOoA/a8NbrRpc1NCu4syq3upeG07TVHCrvIiJcKvLCJvilkT6gGB6dJCxJFLXbSmnZJbHcMy4HCRM3XutnHJ9OEvppCzKJGoMUjQBsQ5rkONSZ4SvpMXNFDujm42HkEwI9TeOciiaxDpmXt6uXVg2ZJmapyeRlUX5FOTEtMcFh8cko6QefXzPaXJ5FLPga17cBMU14QWg/BeN8xKZ7F8oNMCjADqe+y4spCK1rezFzwUDzeMBahsX3VxgRYF4AnyniMXfkMHjVvSRPYMq6yLoXOnHh+ql0B/Vx2vqeNquW+CIAiCIAixJdKRw4tQ27D1W9ZDOEOoOL206YtjKaeym9L298d3qLtP83YjX9ljMQzPgx7Oy/KHecNoMGgBoYTpiU/WcH/wVbdOJEo2aXnbAeGKlmuFCVw1fOZze5V4Dm2OcM55t5t6s6204sfl5CxW4rzFeagwx2Wrv7ep+TH9+VoqW9rMBgzMFc6BH+IcRUg5V2f3Gy7GrG3nVnI183Jo0w1jyYlK8exNV4I620YJ1b105l07KK3BPviuA34vOlI4JixspF2fLz7Ydo0jSFzUOSOdi+CVv9sQknEKnQQQKm/H9QZ7zyH2lViHcQDF/PozRaCHyMvqWKDHB+sZK/RnuW+CIAiCIAjCoEW+zV9V20cHwog9SuhtUcIIwtysR7s4Yei2k0QT9eTbaMKSJprzZLVWaC441B6/VSKw7uRMrlweUjV+fw41/uW6/1dGvVNSDxWa+AucM9dGmes76LzfbqXJ7zWQM9nEBc/CYQDBZ+CzYFSZuKiRLvzNFsr7qIUIgrkggRLq+umsO3dQ1p5esg+1JaBBq+PAQnlfP1Hwv8c0V2NWcWUR9arvZ+nzDL7WgL+QXkt5Ku2C97zXc+gzlmGh4mXNNGZ1GxsxhJD5i14frKdAX6mOB+TeCYIgCIIgCMdFCfNkJXisCPUNFMbiqu5Oqj8zh3ZeUsBh1kIM4NPEa09uAk1Y3EyZ69o1gRlMv4e6xiRSW1kyh1sPWZ+raZDQ5aLtV4+hRnX/2cMcLDThHFcCs3BxE53zf9u58FqPEs0QvWGN6PBpXvVuCPIOJ531t0oa+0YdGevsdPq9lZRV08t59kOO7EDbNTVmqQ12mvL6fm3OG4MMHN0usquxq7ownyxq/Aabh462b4jU2KHGjcP++z0HxyzJROZGB015dT8X//OZpK1aiDxIWvX2uBPo4C51tMk9FARBEARBEAZWFZrYKv2whUqXNRMFt3yC99Xhoa3XlVDbhGT2DvpEV8QEHquBK7WXrmg9mOMcANEO6p52FSVyNfKhzgebEueN09Ko4uoiLcfd4zt0vmTZKP/jFjr9vp1k8vq0UG0d0x+4uBsq2VuNNPuZvfSZ326ljJo+9nCHet5Awbhxi5soe1MnF+07xIuuvvfuC/KorSyFrIE8/+OMW2KHiyMX6s7IPrStmlET6GhdmF3Vo4XxS1u1UFCTnf6o5wn0Fuh1pLVdEwRBEARBEISBMRm4Wvusp2rIgr7WgZBff06zO99Gm24aR14UWzu8tZYQFSAwIVgh+AzdriPb7aFLmRKw+JmBitAd9XP9XuBt15eQF6I1uFI8PifbRunbuujUh6q4+rpdic2hfP5wvm+g33lyi4Pbqg1X5KJCvs1fMI6NEDbjQSMEeskXJdLOywo4p9zgOfbJkBLgVNdUeUWh+g+jZiTx3wdSY5S6s4d7sDvxbMnzEyoohl4fzwIdoDfcOrmXgiAIgiAIwrGAhzKjtY9moq80xF4g1B35xG1OapyXTTsvLeBe1uL9iw0Q/o1iY8nNTq0AWTBuL4tneNqHEgKO0PZ9c7OoSR3U4TxUTCabyaj+7OSHq7iAHBcO9EZuMhj8Ie8szsOB+jz0YC9c104lS5o46uCQua3GoubsXK72busa2Ivu80cd7PlMHrWhrVrwuFkM/DzBCJDUGh7DwigFmvbvep8kEgIdSSd3yP0UBEEQBEEQjiVUIH76bVYqW9xERQh1D64wjVD3Pg9tv3YMNZenskiXUPcYEOhGLcwdedJH86C7UbHeMPg2fCgoh57rCO1mDg+PTzDS1Ff2UU5FD4e1G0aA0OSCduqYogS0qcXBoegHQE2GFDMXjPOYDRxdcDSsvR4u3FdxRZE2Zr6D9wDe87yVrVT8Sau0VRsed/i1bdwLdPCGOp6TeyoIgiAIgiAcC4RDQ3jPnF9L1rp+FheHhLrn2mjjl8byz1rsUtU96hgCfdTx+yMtJlyIbAgVyG3dLmqekUYt09PZe3xI1XZEWGzvpknvNpAjzTyihhHfJ6uqhya/08BRAsFjgm4GDWdkU/1JmZxjfrTxtKCt2qWFZB+XxD9/AITM93lo6iv7yeL0kNciVq0QedavaXXHGMEv9Wt19Mu9FQRBEARBEAbUaKgJp4RY+r5+mv1kjRbmbgmq6t7mpNa52bTjyiIO6ZVc2ujfL4/ZyIYVOjzUHJHVzoB4H8RnebVj76lZWgXyYG+xWRP6Ze83UkKXm1u9jSjUV0Vu+MR36iltR9ehoe5cc8FAFZ8t4nZuJof3UKOGeg5aJqdypwMW58FjnWbhMSvY3En2dKuEtodGrzp+FamTRVKg7yYJdRcEQRAEQRAGIVZQ3bp0eQuVLGo8VKzg1143bb2+mJqmpWn56CLSo4bR4yN3gpEc6YcJamAycD650eUdVDqCpc9NnWMSqVnd10O8wEAJ8uSdPVSwoYP6M0ZmBXLkhie2O2nym/4aZMGGqU4Xtc9Io5pzcrmTQWDOIyUARo3KywvIl2k9tK1aipkSa3pp0tv1/Nk+o8zXEPmDOqpHokAHfyatP7ogCIIgCIIgDAjybX1KoMx8ei8l7e0jChZlfR7yZVhpyxfHktti5OrVItKjJNBRCE7dGzta47kOSzlAb/tWB5kdXi3P+rif5aP2iSnkyE/g1noH8PfwLlndRsnNDvJYRq7SRI54yYoWKljVptVgCEQloIK7OqouLaDeHCtZej08pjBQ1Z2YQfvm5WiF4YKMIzBqTHyngTJq+8iZYhbveWis9GvYyD1TUfiSv5D7LAiCIAiCIBwLDnVPNVNqg51mPLtX+0NrUAuqNic1n5pFlVcWKpHi1PpGCxEFXnGj00tNU9OUgDYfGuIO72+Xm1Lr7NwybXAfSNz7nMPZg8Uk7nuni3K3dWlCfwQbY5AjbnL5aMrL+7T+70nmg3NejWdvWYoS6YUcbWB2eMitxmb71WOIEkwHC+rhlwwLZa7v4IKLqHQvBqyQ+XmkTxgNgb6UIlCeXhAEQRAEQYh3BUjUl22lsR+3Uum7DUSZloN/B49it5t2XDWG6melU6IS6VLVPYIYtCJ9jjQL7T09W90r36GiOtFMyfv7KXNPLzmTj58vjkJzyCvvHJt05F8mmSitpo8yq/u0Ht4jfM4jIiF3RzeVvYeCcUEt0bg3upt2XlxAbUqop9bbac95udQ+K+PItmpOL015dT9Z1c+j17p4z0PiHnUsGw0CHfxGHXvknguCIAiCIAjH1CtmAxcgm/FiLSXs7j2Yjw4x0u8hr/rvTTeNI1eCSavqLiI9IuIc4ejIl65UYrF3Sqrm7Q0SmRCJ+Vs6KbHVQd5BhKQjDL4n10Z9CJV3eo84X9q+Pu63PmhvfJzjSTBS+Rt1lFjbT5QaFJ7e6yFPvo2qz8+j3mwrVVxWqEUueIPGXj0TRR+1UPHqNs17LuI8FKBV/zcaJ46WCapHHbeo412594IgCIIgCJFUvGhl5eZCUy7n0OPCUZAKgtkV7NnT+XqRP5vSaKc5T1TTyp9P0UKenX4xrkRi+0mZtP2qIprzzF5yW22xKdLVJRtdPh53jJ83BDcZxt6VZCJ3gok9ztGaP5Y+jybOLy2k7TeUcNE+ClRqx2UpcWnocFHph81am7VBgF7qfTlWciJKwnlolXKEbmdU942qCAlnspnS9/fT5DfraOMtE4j6DJoQ5znvov2nZFJXgY36ihOJul0Hx17ND3Ozg6a9sp/HHgYNgwj0UIBW7R1NAh0sIC3U/fty/wVBEARBECKAx8cb9roTMlgouq1DV4les4HbXGXU9HLrp0iIJohReFbHrmylpnfrafc1xUQtDv8FEffLrrh6DOVt66KCTZ0cFh9zosTlpX71HfaelqXG0BjSuEHYQ7SlNNi1tmZhEtzwhqMa+0B/b/D5+GfM/R4tylqN75ZrxtPOq4r8YddBkQv4Nc1C417dT7kVPdQfnJZwLPuF+nyEy3N7tTbnYZPORynNjlH3uPZnWql0WTPtOz2bWmdnaOOC8XWquaTGqv/ETK1qe8A4gimhhP3El/dT9q4e6s2xiTgPjXv8WjUqRDuJA2EDF6hjpswDQRAEQRAEnVEbe+Sjrv36+NA/I91COava6My/VZLP5ItYRW0YBpCjPPWV/dQ8LZ26JyYrweL3HPYpkaLE75Ybx1J21Tayqv+GpzmmQnt7PdQ2IZlW/GByiFYKdSjBNfXR3TT7uVrqybOFyfqhFXsbcKjU7XVbTRzFgBD0tgkpVHtqFvVPTNHC2tX3OiDO8SFKvCdX9dCU1+u4/Rp70I93H3zaNXClceNhP4//dnnJ1jn62unBCINIhfLX99OKGela5IjLbwyBQQXiPJDu4Q9tT6nspgmLGsnBY0kS3j50NlCUQttjRaB3q+Nb6lghc0EQBEEQBCFCBCphh7J5h+DimlMBZRAZuKq7Eh3JLU6a9VQNffzbaRxKTY6gUPc5GbTtc8V0wuPV3Pc5pvD5x90Y4pgZtLEPa8SCGjP0kn/3r7MHzO3G+ZBD7kRovRLoaN3FBpF250HPbeD7wVuu/u6kf+6mlCY7RwwMZo7xVDQbtHt2eOi+Gi8jVywfXKu2kG4NCt4psTvccyDSwJlkZmEdrhQEtF0bs7qdSpY2Ue3FBURNjkPH/ICqM/CBwnDJauz7cK9EnIdC1ELbY0Wgg0/U8ftoWyoEQRAEQRBGDa5h9CRDfrDbRwaEt0f4siHSIfqK1rbTxNfqqOrzxUqgB4U+d7mo8qoiyt/YQQWbOwctECNz8eQv5uUL/d+rsTd4wviV1DxwpVmoszDh2G3qfL6DHtvgYnABIw88tWqsTW1OmnvfTirY2qkVexvsharP96n5xNEYh/8b9UdoO4YQfF3SKdT5TOqzO0uSOKTcOIxnA1Ee6fv6ucYDfh+WyzNqn1uuhHfD7AxywTPe5znUNub3nud+0kalH7ewqBdxHhJ3+LVpVImVPgW/VceF6jhd5oUgCIIgCIIwoGBRwsSdZKJpL9ZS0/Q06pqcwkWzWLCginu2lTZ9uZTS79zOxcxiLtQ9lvCHj1NHCKIUYwoRCsGofk3b2Ekn/bea24OxOA/FADGApjVwCzd9bqLR6+N5gtZl+y7OPzL/fSgoYTz3ru00dkWrZhwKkwEBufnZu3tpwoIG2vHlsWqee47sE9/upKmv7WdDhsciheFC4CN1/C4WLiSWGgne4h+YZJkfgiAIgiAIeqhb0ryd2TYtVD0U0ZNpJV+GRf3TyIa4B4NwaxQNm/V0DX30q6la2HW/50Coe+fsDO6PfvK/95DbZtQtNHpIwHOO62TvZgjjblDfId9GXvXdDZ4YUF+YR+o6kpRwLFvSRBMXNXKbOxSQCyl9wqsVojtiSsF5bzFqIfg+/R4LzpWHB988jJoKEMoGHa7Tn5+PMd53cib1lKVolfMDhg31d+OVOC/c2BGbBRJjn26/Fo0JYkmgb/APzH9ljgiCIAiCIOiAEhAmtbGf+s9dHIYbSiVweOeQB869raOkeyFA+rJtVLSunSYrYVJ5UymRw+9VhDO4w0lVlxdS3pZOKl7TTr05MSBaks2UUdFNExY3sdgMxWgAY0N2VQ/ZB1kZ/fg308dtuWB0oYFEP6aI06flnAfbZDKsVKiE+Rn3V5HZ6SFHqoX61HXxOA9xrBHebvSiF7pHE7iHXSMKG2K+6dVajp33+P5I3xhu+ofPF/7nwm+kgKc/tcFOPeWpQRevGdpS6+08Pj4dDRkjmO+qY7MI9KPzJGlh7t+WeSIIgiAIghBmlLiGl3LCB01cxMsdQiE19OKGUOzPsGg6JFrtuNEKXYnCKW/WU+OsDOqclnawDRVC3dX1bfxyKeXs7I6Nqu5qzNAebcpb9WwY8YXSB92jtSJDsTxjOLzoyWZKru2jQnVNA80F9CfvzbVRw0mZXHvgQA693UPt45KpJ9/G0Qyo2B6yEcSgfTcL8tuP4kEnm0nda7P+RpZjhNkfTTRHdsJrHRPQou+Ic/u0iu8izkPiIXU8FUsXZI7BQbpNHWepY7rMF0EQBEEQhHBu8jUB0s9hsD4lqkKvdB51j7Q6v0uJwqRWJ815opqW3TH90FD3Thf1TkulrZ8voZMe26O1/DJEMdTdS+wJhthFFMJwwu6N4QpxTzNT9s4eOucfO6gnLeHoAt3hJYcSxwvvmknd8NwG8v3VONsnJtOOK4votAeqyKnE/nCKuMFgYYNAx/2D0Ax8R3ik1d/1BkLndZhHSNfwwYCDvPHjeun9HRC63VrUhtEg60r8skUd34u1i4pFgY6Eiq+oY4k6UmTeCIIgCIIgCAMZCVB5u3BTB019ZR9tDw51x9Hhol1KQOYj1H1VG/XlSHXroxoNUhKUALYNqEdhBCl/q57WQKAbg2oXdLmp5txcGr+kmSMV7Omhh95rPb9dZOx0kVeJffJ4ghSLkTqLk45daT5UfW4ykDvJTGXv1FP+6jYyHSfEHREkZruHtl4zhjqnph1a1V6IJ5B3/j+YeiLQB8caddyqjidk7giCIAiCIAgDYiQlDK00+c067undemImUWtQqHuCiTbfWEKZu3rYQ4tiWyLSDxOpxwntdqSZqWRlK1Vt6qSOWels+ND+Qo1vjpUqryikrPt7tBzoED3KbiXQkXaR1O6kHuTE2/26yV/YsHNsEnn91cnD2W6N+7yrc+dWdFPRho7jXj++o63LTXvOyaVOm7qwHpk/cQq05roYXdJiFhSLu1fmjiAIgiAIgjCwwiJyJRo5z3zmc7Vadetk08GCZp0u6p6SRts+X0yWXk9sVECPMyCeLf0eKl/QoOWhm/wi1h/qXXdmDvfoTuhwhRyGjiJw+PfJDfYjFYrdy33KO8ckqnsYfo81RDdC9HtzbNwi7ngHig5yz3avzI045W+k1T6LSYwxPng/VMcymUOCIAiCIAjCgALLH+qOUPbpz9dy8bMDu1x/qPueywqpRgnJxDZXWD2wo2V8HekWGrOqjfLWd3ABvgNRCPCiWwy08/JCLh6IonIhoz4zr6L7SOFr95CnMIFaytPI7BBVLAyLxer4cSxfoDEOBvHL6tglc0kQBEEQBEE4FsiBLn+7nrJXtfr7jZPm0fWLRlR17y6wkbXXE7UWcfEKcsSRnz1hYYOWOhBo0Ydx7HBR8+x0qp2XQ7bO0A0gKBSXXdmjFWAzHfYh6tx1J2aQM9kUviJ5wmijSh03xfpFxoNA30daAr8gCIIgCIIgDAh7cJWQm/30XjKhb/dhoe79E5Np6+eKOVwb7eZEpA9FPStdnmGhgg0dVLi6jSvAH/CiYyyNBtp5aSHn+FvsodXdQqu3zD29lLtLifQ0y6G1Avo81DwrnVonp5KtS6IghJCApqwTgR4ePiatsrsgCIIgCIIgHJVAqHve9m6a/uI+LdTdbDggMNEibO/FBVR9dg4ltjqlVtxQNbrJQGanlya+XX+kF73TRZ3TUmnP+Xlk7XaHJKDhpbf2uKlgXbv2mcFedIS2p1io6sJ8rqRucsndE4YEPOcr4uFCjXE0qCgad6fMLUEQBEEQBGFgla5EepaFyt5vpPyPWogyDwt19/lo841jqbsggau6iyd2KApdSyNArn/RCjW2qYc1hFLju+OyQupRY4uifUOOUPBpFeOL1rRTQk2f1tc+6L5Sp5PqT82ivadnU0KHU+6dMFj+oI6n4+VijXE2uL9Sx3yZY4IgCIIgCMJAIo/zpd1emvV0DZlaHUSB1moQdF1u6h+XTFuUSDe6fBzqLr7YIQwvvNoGA018r1GNpYvIEiQnetzkKEum3efladXWQ6jn5raZKL2un8Z+3KLdt2DgNVfn23RjCdkzrGJgEQbD8+r433i6YGMcDjJyB5bKXBMEQRAEQRAGEumoOp5d1UMz0HoN/aqDW4N1umjvJflUc1YO992WXPQhjm2qmQo2dVDJyjatonsArybSd12YT+3jkskGkT7UsTWibZ6JJnzQRDZ40YNz0dnA4qK+KWm04eZSMjm8XNVdRLowAKjYfnO8XXQ8CnSHOq5TR43MOUEQBEEQBGEgIdmfZaVJ7zVQ/vIWIvX7AyDU3aWFureXJJENVcMNovIGPbRmA0cpTFzYSIZWp2YACQjoPg+5ihKo6uJ8Mts93GN8qPfNmWSi1AY7TXlln2ZYObyie6uD9l5SQJu/UEIJnS7Oi4+UkcWn5gmMAtxOzihzIYbZ7deMLhHokUGtsvRZdTTL3BMEQRAEQRCOhluJSHhXZ86vJUt9v5YzfSDU3UXdSpxvvb6ERRfaeAlDENGpFsqu7KZxyPM/vOJ6t5tqzs6lpnJUXB+6F93gz0WfuKiR8la2HqwjEACh7r1u2nFDCW26rpgS2pVI7/dExJOe2OHkavY9hQla4TohFmlUx5XqaIvHi49nu89mdVxPJGlDgiAIgiAIwkBCTwnJXf5Q9wTToVXd+93UNiWV+vJsIraGqtGNWj76xAUNZESaQFJQQTe7l7zZNtp5RRERPOgh5qLj/s35bzXZYFxBBETAG2/QzgGhvv3r42mNOkxOHyW1OQ/+fVgnErHHPKXRTp1jEmnpr6ZS96RUrV/7UX5WiCqYbV9Qx9Z4/QLxHpixVB3XyDwUBEEQBEEQBgKt1yYsbqIxHzQRZVoOetHxq8PDld1FWA1VoWu56OhbPn5RkybQD8sV33dWDjXMyaDEzqFHGSM0Hp7qjH39dNI/d2lpCamH5aP3e1gk7/pCCS37xRRqK0tmEW3p84Ttaxo9Svi3ODmMfvtni2jpHdOpc2a6ViDPcOh48BiYjQcNCUI0uFody+L5C4yEzInX1fFNmYuCIAiCIAiDFD8erXo5xEc4jljHYzGwt3fmMzWUUBsU6h4QVpH4CgbNo290e8Mz9uozDDEgBN02I5UtaiRrvf1QkY6IBPV3Oy8t5FQDXG8oRoC+TCsVr2mnEx7epeWiH24IwHlaHdRyahYt/c00Wv+lUrKnWSixzcn56Xxew9DuE8bXpgQ4PgNjXHNGNi3+xRTa+J0J5Ey3EDU7DhXmINtKSVu7KH1XD7mTzbLIRIdvqOPNeP8SI2X2PKqOdHX8RealIAiCIAjCsUUPwnXhEfSZDMP+LAgaX4KJQ55jNfEwkNOcUdtHM56vpTU/nExkNWi5zJG8DiX2uLiYj4Y99gafj7wmoxLI0XX9O5UYzd7dS6XLmmnnF8cS2T0HIxSUQG6cm0V1p2TSuKXN1JNn43sxJIxa7/Xyd+vZ0LLpm2Vq12/hz+ZzBCIh2p3kUddS8dVxtOfcXCr9uIXGrO2gzJpeSmx3q39r5DHn0HzUHDAcnMMYS4NXM1yZXF7+Th3jkqlpahrVqOvvmqFkhjo3tatzwiBlDEqTQMpEro1SN3TQWX+tpKRWB0dsGMSLHml+qI7HRsIXGUnmnb+qI4G0RvSCIAiCIAjC4Ti85E4w0spbJ5JRCRGfcXjizmvWKlrPebqGUpoc3B4rlg0TfVk2GqeEZOPMdKq9rICo0RG50PZeNzVPTqUlv5p6qEAchjDO39pF017fz9/Na46SUDfiWkxUtriJaublkFOJVbRa4+8HA4j6rpWXFVLhmnay2L3scR/qffOo79aXbaOpb9WTVX322lsmki/HStTqPPRnEdpu95AzP4GNBTsvL6KMXT2UWd2rhHofJTc72DMOEW7w58V7TVpF+v4MC/Wqa+8qTqSOkiTqVALdm63OAQ98n9v/XegQYU+Y7+kWKljYSKf8ezcldLmpL9Mi4jzy/Eod946ULzPS4i/+Tx2p6vipzFNBEARBEITD8PjYi9g2OyM8iY4Wo9ZW64VaFvwUywIdYsxi4GPG/FpqnJZGzoKEg55YvXF6yZlppRYlAMNChpVsiIJQYlC7lVES6NwWzUzp+/upbEkT7fjKODZGHLikTie1q7GuOSeXJr1TT66EoXvR8fO4b31KMI9f3kIpLQ5a/Y0y6p2SqhkDkItuNBz0puP8PcRe747Z6erIoD39bq7Ub/T3Tjf5q/Z7bCZ1TUbyYS7jwBxGTYJej2YACAxrsDBH9IMS9AY1d6Y8upumvV6nnisYgMRzHgXuUsedI+kLjcQEiZ+pAyvfbTJfBUEQBEEQgpWOX2B0hak1sBI0RiWOTPhMYxxUWUOoe4qZ0ur6afbTNbT6x+Va6LIrAkXijP5Wbh3esH0XoxKiMTHqStciegJe9D3n55EDVfEDFc79Of4VlxdS8SetZFHzxZ1gCun7wriE3vZ527rp/N9vo03XF1PNJQVEeX5DS3A/dPwK73eH3wCD8VeHN9lMTrjzAn3vA1XmIcpxfxyeQ3Pcg87P4eyoX2A2UsbqNpr9Qi0Vbuxk7zsiA0ScR5z71PHLkfaljCP0Zn1PHX+XOSsIgiAIgiAcYqNQGgoir2xZM5W+16D12JYK7sM2FjiTTJTSYKfJCxo0T3QwXS7qm5RCuy7M5xD14ZwH9OZY2Qs+91976OzfbqXsj1u4IB3BMGA1Hnk/8e+QOw7BDhGPFm3wuuNAkTkIc/wdfuZwjY3PwvdBSH2ahZIreuiEeyrp/D9up7zt3RwW74E4F20eaaD1vj8Sv9hILjH4A/8jdbvMX0EQBEEQRpdg8nFuLXv7bCbNK6gHSgzhPF4DDapAHBc2g1ZCGLESOwf7Wmshw15bZFpUIafZpQTltJf2UeuUVOqZnk7UHRRVEGiVZdTGckgGAPXvEDbNhcx8Q//3g0aNn2+wKQUY98A1BY8v/hufEYYxh0B1pZipdEkT7Tkvj3qm+sPPA6h5suNzxZS3pZOy9vRyDv2wzpVsIre6dnjTc3ZWUN2cDM6Bb5iVTr4Mq+bt7vccLFo3FOBtT1A3H55+VMvvdFH2ilYau7KNita3U1Krk+xpZnKk+oV5BMQ5HjGvuo9HPDu4VnUfkUdP3lGzwt3n13ojkpHeAwBWFaxct8qbWhAEQRCE0YJXCUz0gk7b3k1etLhy6rNzR16w2Y58Xr9B4Hg6UQnx/8/enQD5WRZmAH83IQgiYrWtjo4HqAgKhBATQIocooBQx1EURu1olakKlXrUA0UuRfGoR6GidKzVqVjwKmNFvIWWS0VUkBsqhxBCCIkJ5CDJ9nn3+wIMBiFxd9/d/f9+M8+sAYfdffJfwvP/rvr/2vzmu8vSSxffdzQ1f3H5rTPKprevGPl6x3zs1AOpGZOPyufb/rQbyy9f9ZSR72Oof2RcPZW6vplQextez5uv1buFbzZ/edlk7fc3RuNt5Ouvj4xLp3/0Uwx1j5h75G3917TkvtG8/NblZdNblo1a5/VNj/rM8Gd+65ZyxdATy8b1WvA19y3MenfzBVtvnkG99L47vW+oerC7vm7qTdny+/bkny4ceRzbwi03K/NmPqbM32bzsugpjyyr6lH1tW+4DD/EAl47eDPqN563omyRbv786iUjN+N77PVLy0bL1pQVW2w0ci382tfReHnQn51p3Q0DN71z5bj87EwAJ5cpeuT83pfigVsdNQi/kR9N3umPawBgkIzXNbHrezf4On7XOZbqmBzn081nZIytnj5t5C7oQw842r2hd7kfGssj5xvY14N+TWPQeT39vPY50t/azznc9VmP9E5ftWb037iol5ivGs6IXt19/hlD5fdP3LQsecImZenjax5Rlj1m45E7ztdT0kcG73B97N3wyHXxdfBusmjlyJs2m81fMXLH90ffunxk/Nfry2vWzGg/gCfSz04DJyZHTvVvcqMyGOpd3e9OjvFHNQAwEON8uBssY/+JSlm9no8NG1q97jcP1tTzHusR63E8MnnPI6aPDMbp63gmen3u9nof5R3qnqe99mj82L4xUh72Ef7a97q+ppF/xoxR7Hyo662+9v7g8+XX05IxeSTccPfItHpmQb0JXP3cdWhvcdPdI28M1M+5Znr/psEDbv5Wf1bW9jM9X/fIJesZ5PX568PTyri+Hjf4Z6euumlDE+prHWVHlwF5nPagDPTq2NKdZHOcP7IBgKmuHk1bPUFPee0G2tCDDq3xXTzdaemjPRTL9Il1OPOPfk2j2fm9R8obfv/911BPua8pa2/SP/wQ57gPZeAPNX49TqafnfFTT/k+YVD+3T1IA706PrmjdNcuAAAAU93aA8tDbtc/Cb05+ewgfcPTBvA3+V+Sg73WAQAAJqyDBm2cD+pAr85IXpQs8boHAACYMH6fvDD5+iB+89MG+Df++8keyTw/AwAAAM39Ltk9+cGgFjBtwF8AlySzkkv9LAAAADTzq2Sn5NeDXMI0r4ORI+hzk7NVAQAAMO7OSnZO5g96EQZ6Z3myfxnAmxAAAAA0dFJyQLJCFQb6A9Xb+B+hBgAAgDF3mP1loD+U+g7OXyeLVQEAADDqFpXuqPkpqjDQH47/TnZJrlEFAADAqLkimVO6684x0B+2K5NnlQF9/h4AAMAoOyN5dnKtKgz0DTGcHJS8VxUAAAAb7MjkYDUY6KPhw8m+yV2qAAAAeNjqvb32Tk5UhYE+mr6XPCP5sSoAAAAe0g+TrW0oA32szCvduz8nqAIAAOBBfSDZJ5mvCgN9rB2V7J/crgoAAIB73Za8IDlaFQb6eDq7dHcg/LYqAAAAyrf6jfQjVRjoLSxIDkzekqxUBwAAMICWJ4clL0kWqsNAb+3kZKfkElUAAAAD5GfJzOQUVRjoE8lv+pF+nCoAAIABcEwyN7laFQb6RHVsP9QvVQUAADAFXVy6o+bHq8JAnwzqqe6zSnc0fbU6AACAKaBum/pEqznJr9VhoE+2F++xpXtn6WfqAAAAJrGLkh2SE5JhdRjok1W9Nr1el3FE6e5uCAAAMFnclbwx2SW5XB0G+lRxUvLM5KuqAAAAJoEzkq2TU1VhoE9FNyevTPZLblAHAAAwAV2bvDA5OLlFHQb6VPfd5OnJe5Nl6gAAACaAuk3eVbozf3+gDgN9kNSbyH24f/Gfrg4AAKCh05JnJB9ThYE+yH6XHJLskfxcHQAAwDi6INk1eXVxOruBzr3OLd3zBF+RXK8OAABgDF2XvDx5XnKhOgx01u1ryXOStyUL1QEAAIyi25LDkmcn31CHgc5Dq89L/1Ty1OSDyWKVAAAAf4K6KY5LtkpOSVaqxEBn/SxN3p9smXyidDeWAwAAeLjqwb+PJE9Ljk3uVomBzp/mzuQdpTui/k9+qAAAgIdQN8PH+2H+nmSRSgx0Rle94/s/lu60lHpE3anvAADA/dUhXo+Y17Nw31m6a84x0BlD9YesHlGvzyk8vnRH2AEAgMFVbzB9dLnviPl8lRjojK8FyTGlO/X9iOLxbAAAMGiuSg7vh/kHirNsDXSaW5KclGyd/E1ygUoAAGBKOz85ONkm+Uy/CTDQmUDqXd7/I3leskvy9eLO7wAAMFXck/xnMjfZLTlDJVPLRiqYsi5KDirdqS6vSw5NnqQWAACYdG5KTk2+ULobRzNFDR241VFaGAz1zZiXJa9P9lUHAABMaGuSbydfTP6rODPWQGfKenrpjqjXa1a2VAcAAEwY9cbP9TT2zyU3qsNAZ3DMSPZM3pAckDxKJQAAMO7qndfPLN0p7OeV7lpzBpBr0Adb/cH/fp+/SF5SuuvW9042Vg8AAIyZ5ckPkm/24/wOleAIOutSn6ter1d/ebJz8UYOAACMhnqA7MLS3X29DnM3fMNAZ71sleyXvLJ0j3Iw1gEA4OFbkfxP8tXku8kNKsFAZzQ8LXlhsk//8c9UAgAAf2BB8r3kR/0ov1klGOiMpUcne5Xu6PruybbJNLUAADCA6iPQLk/OSc5Kzk3uUgsGOk1eR/1Af37p7gY/N/lLtQAAMIXNS85PvlO6U9ivUgkGOhPRZsmc0t1gbtc+BjsAAJPZLf0gvyD5WXJxcrdaGE1u+MVYqKfz/KRPVZ+vPrMf6jslOybPKk6JBwBgYqqnrP8m+VVyST/K6/9ephoMdCa7pcl5fUo/zJ+ebF+6I+2zS3eK/JNKd7o8AACMl1Wlu4nblcnPS3d0/LLketUw3pzizkSxSbJNsnWfbfsBXx/ztpl6AAAYBb9Pru0HeB3kV/cfr0lWqofWHEFnolie/LLP/T0heUafetR9y+SpyZOTJyYzVAcAwP3U547f3Oe3yf8l1/XDvGaBijDQYcPM6/O/D/jrmyeP6wf8ln3qaK+nyT++dM9or3//McW17gAAU0U9yr04WdhnXj/Eb7rfGJ/fj3A3cMNAh3GypE/9F/GF6/j700t35/jH9iN9bR7Xpw78R/fZov91Pc1+0/7jJv0/Y1r/cbh018dPL66TB2DiWNP/mbWxKpgCLi3dndFX9CO8no6+qB/id/ZZ++sF/X+fgYEOk0C98+atfdbH2lG+Uf8fO/Xj2tPo6zB/RP/RHwgATAT1ErH6JvNJyb7qYJI7OTlVDRjowP2Hfc09xWM0AJgc6im++/Xj5nB1AExers0FAJga/j55fXGWF5OXywgx0FUAADBlfCHZpaz/JV4AGOgAAIyynyY7JOeqAsBABwCgrXqH6z1Kd/M4AAx0AAAaOyJ5U+kexwaAgQ4AQEOfS/ZKblMFgIEOAEBb9Xr07Ut3fToABjoAAA3dnuycfF4VAAY6AADtHZr8gxoADHQAANr752TPZIkqAAx0AADaOifZrrguHcBABwCguRuT3ZMvqwLAQAcAoK2VyWuS96gCwEAHAKC9jyT7J4tVAWCgAwDQ1tnJTsmlqgAw0AEAaOv6fqSfrgoAAx0AgLZWJYck71YFgIEOAEB7H01eUjwvHcBABwCguW8lc5OrVAFgoAMA0NaVyax+rANgoAMA0NCy0p3ufoIqAAx0AADaOyo5OBlWBYCBDgBAW2ckzyndI9kAMNABAGjoitI9L9116QAGOgAAjS0u3XXpH1UFgIEOAEB7705elaxQBYCBDgBAW19Jdk1uUAWAgQ4AQFuXJDOTH6oCwEAHAKCtel36PsknVQFgoAMA0N7bk9eqAcBABwCgvS8lOye3qgLAQAcAoK2fJjsm56sCwEAHAKCt+cluyWdVAWCgAwDQ3puTw5NhVQAY6AAAtPWZZM9koSoADHQAANo6N9mmuC4dwEAHAKC525Pdk39VBYCBDgBAW2uSv0veogoAAx0AgPZOTvZI7lAFYKADAEBb9br0WckvVAEY6AAA0NZNyezkNFUABjoAALT36uRdagAMdAAAaO9jyb7JUlUABjoAALT1vWRmcpkqAAMdAADauj6Zm5yhCsBABwCAtpYlBydHqQIw0AEAoL0TkpclS1QBGOgAANDWN5PnJteoAjDQAQCgrauTbZNvqAIw0AEAoK3VycuT41QBGOgAANDesaW7Lv0eVQAGOgAAtFWvS98xuVYVgIEOAABtXZ7MSb6jCsBABwCAthYlL04+oQrAQAcAgPbekbymdDeSAzDQAQCgoS8ns5MbVQEY6AAA0NavklnJD1UBGOgAANDWwmSf4rp0wEAHAIAJoV6X/rpklSoAAx0AANr6YvL85GZVAAY6AAC0dUGyQ3KeKgADHQAA2roz+avkFFUABjoAALR3WPImNQAGOgAAtPe5ZLfSHVUHMNABAKCh85Pt+o8ABjoAADR0S7JH8nlVAAY6AAC0VZ+RfmjydlUABjoAALT3yWTvZKEqAAMdAADa+nEyM/mFKgADHQAA2ro5mZN8SRWAgQ4AAG2tSV6bvE0VgIEOAADtfSp5UbJIFYCBDgAAbX0/eW5ymSoAAx0AANq6Ltkp+boqAAMdAADauic5KHm/KgADHQAA2vtg8tJkpSoAAx0AANo6M9kuuUoVgIEOAABtXZPMLq5LBwx0AABo7q7SXZf+AVUABjoAALR3dPKKZJkqAAMdAADa+lrpTnm/ThWAgQ4AAG1dkcxMvqMKwEAHAIC26nXpL05OVAVgoAMAQHtHJoeoATDQAQCgvdOTnZIbVAEY6AAA0NYlpbt53DmqAAx0AABo645kz+TTqgAMdAAAaO+tyRuSVaoADHQAAGjr35Ldk9tUARjoAADQ1oXJtsV16YCBDgAAzd1ZuuvST1IFGOgAAEB7RyRvVAMY6AAAQHunJs8rrksHAx0AAGjugmTH5CJVgIEOAAC0NS/ZJfmCKsBABwAA2nt96Z6ZDhjoAABAY59O9koWqwIMdAAAoK2fJDskF6sCDHQAAKCtG0t3h/fTVAEGOgAA0NbK5NXJO1UBBjoAANDex5MDkkWqAAMdAABo66xkdnK5KsBABwAA2ro+eU5yuirAQAcAANo7JDlSDWCgAwAA7Z2YHJjcrQow0AEAgLa+ncxKrlQFGOgAAEBbVydzkjNVAQY6AADQ1tLkpcmHVAEGOgAA0N77klcm96gCDHQAAKCtryY7JtepAgx0AACgrcuT2clZqgADHQAAaGtxckDpHscGGOgAAEBjRyaHJCtUAQY6AADQ1unJbslvVQEGOgAA0NbFyQ7JT1QBBjoAANDWkmSv5JOqAAMdAABo7+3J36oBDHQAAKC9f0/mJPNVAQY6AADQ1s+T7ZNzVAEGOgAA0FY9gl6vS/+MKsBABwAA2hpODu8zrA4w0AEAgLbqUfTdk9tVAQY6AADQ1nnJdslFqgADHQAAaKtel75r8nlVgIEOAAC0Va9FPzQ5TBVgoAMAAO2dkuyZLFAFGOgAAEBb9Tnpz00uUQUY6AAAQFs3JLOT01UBBjoAANBWvS79kORdqgADHQAAaO9jyf7JXaoAAx0AAGjr7NI9L/0yVYCBDgAAtPXbZE7yFVWAgQ4AALS1PHlV8j5VgIEOAAC096HkpckSVYCBDgAAtHVmMiu5ShVgoAMAAG1dl+zQj3XAQAcAABpaWbrT3Y9XBRjoAABAe8ckL0tWqwIMdAAAoK1vJjsm16gCDHQAAKCty5K5yXdVAQY6AADQ1qJkv+TT/a8fqRIG3UYqAAAAGnprcm1ylyoYdP8vwAD8nSrqT6R2+wAAAABJRU5ErkJggg==");

		Configuration conf = configRepository.findByConfigName("logo");
		// new String(Files.readAllBytes(Paths.get("duke.java")));
		String hexaImg = conf.getValue();// new
											// String("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA+gAAAIPCAYAAADglfRqAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA/lpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ1dWlkOjY1RTYzOTA2ODZDRjExREJBNkUyRDg4N0NFQUNCNDA3IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjIxNzcwQzdBOTJEQzExRTdBNEFDRjM3MTc4N0U3NzcwIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjIxNzcwQzc5OTJEQzExRTdBNEFDRjM3MTc4N0U3NzcwIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIElsbHVzdHJhdG9yIENDIDIwMTcgKE1hY2ludG9zaCkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0idXVpZDpjMGIyMDZhOC01MjkwLWM1NDEtODliMS0xMGQyNzEyMjg5Y2MiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MjkxMDNmZWQtYmRiZS00MzRjLWJiODktOWI3YTg5OTcwN2IyIi8+IDxkYzp0aXRsZT4gPHJkZjpBbHQ+IDxyZGY6bGkgeG1sOmxhbmc9IngtZGVmYXVsdCI+VW50aXRsZWQtMTwvcmRmOmxpPiA8L3JkZjpBbHQ+IDwvZGM6dGl0bGU+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+XwW6OgAA06dJREFUeNrsnQd8ldX5x5/sPSELkgCBsPcGEdwTR7WOuq2jaod7tH9bbWuXWrVVq3VVrdaqrXvUjTIFkb3DCIRNgJC9/+f33BtEZNwk9z33vTe/7/9z/qgF7s15z3vO8zvPCptccKcQEqKkmZFhRor3n/cdyWYken9t+ec4M2L3Gfj3cO+I5nQSQgghhLSLOjOavKPajJp9Bv69wow93tHyz7v2G2VmbPf+MyEhRySngAQpEMyZXgGeZ0YP769dvQP/PdUrzuM4XYQQQgghIUG1V6Tv9gr1jd6xwYy13l/x37d5LwQIoUAnxI/A293djN5mFJrR04xuXhHeRTyeb0IIIYQQ0jGI845sM/oe5PfA+77JK9yLzVhtxiozVpqxTuh9JxTohPi0FnuZ0c8rxPuY0d/7axqnhxBCCCGE+AgcOL29Y38gzpebscyMFV7hvtz7awOnjlCgk45Kd68AH2rGGDMGiidEPYpTQwghhBBCHAKOn3He0UK9eELjF5sx24x5ZiwVj7edEAp0EnKg4BpCkMZ7xfgQrzinGCeEEEIIIYEGNmmBd5y+j2iHSF/gFe0zxON1r+F0EScJYxV34gAx4vGMQ5CP9v6az2khhBBCCCFBzHqvUG8R7PPNqOW0EH9CDzrxFyjedoQZJ5sxwYxcTgkhhBBCCAkh8r3jfO+/l5gxzYz3zZgunmJ0hLQLetBJW4nzCvJTzTjKjAHCkHVCCCGEENIxQUj8EjOmmPGeV7hXc1oIBTpxkhwzjjfjWO+vOZwSQgghhBBCvsNmMz4y4xPvr5s5JYQCnfgDhKqfYMb3xeMpj+OUEEIIIYQQ4jPwpE8x479mfCCe0HhCDghz0MmByBZPBcvzxJNPHs0pIYQQQgghpE3AwXWyd9SJJ/z9FTPeEnrWyX7Qg05aSDFjsng85fCYx3NKCCGEEEIIcYwqMz4Uj2f9HTN2c0oIBXrHJkI8hd4uNeNMM9I5JYQQQgghhFhnpxlvmvGceDzsjZwSCnTScehqxuVmXGRGH04HIYQQQgghrmGlGf804x9mbOR0UKCT0OU0M64UT2u0CE4HIYQQQgghrgVe9HfNeMqMtzkdFOgkNOhixiVm/NCMQk4HIYQQQgghQUeRGU+b8bwZmzgdoUs4pyBkGex9gdeZ8QeKc0IIIYQQQoKWXl6bfp3Xxh/MKaFAJ8HBWWZ8bsYCMy42I4pTQgghhBBCSEgQ5bXxF3ht/rM4JRToxH3EmnGVGUvF06ZhIqeEEEIIIYSQkGai1/Zf6tUCcZwSCnQSWJLNuNWMtWY8YUY/TgkhhBBCCCEdin5eLbDGqw2SOSUU6MQuqWbcY0axGfeakc0pIYQQQgghpEOT7dUGxV6tkMopCT4ieqcxGjqIyDLjF2a8aMYJ4gltJ4QQQgghhJAWoBEg8q4Rjzd9iRmVnJbggB704CDBjN+IJ2wFAp23YYQQQgghhJBDkerVDtAQv/VqCkKBTtpBjBl3mLHBjF+aEc8pIYQQQgghhLQCaIg7vZri516NQSjQSSuINONH8k0P8zROCSGEEEIIIaQdQFP83qsxrvFqDkKBTg7DKWYsNONxYfE3QgghhBBCiH+BxnjMqzlO5XRQoJMDM8qML8x4V9gujRBCCCGEEOIs0BzvmDHVjNGcDgp04iHDjH+YMduMIzkdhBBCCCGEEItMMONLM541I5PTQYHekbnBjCIzLuNUEEIIIYQQQgLIpV5tciOnggK9owFP+QozHhRPb0JCCCGEEEIICTRJZjxgxkphdC8FegcAISPPiSfXvDengxBCCCGEEOJCCr2a5XkzsjgdFOihyBVmrDLjEk4FIYQQQgghJAi4WDze9Cs5FRTooUKBGVPMeEoYzk4IIYQQQggJLqBhnvRqmp6cDgr0YOY2M5abMYlTQQghhBBCCAlioGmWeTUOoUAPKgaIp23an8yI4nQQQgghhBBCQoAor8aZ49U8hALd9dxqxkIzRnEqCCGEEEIIISHISK/muZVTQYHuVpCPMcOMezmvhBBCCCGEkA6gJaF9Zgpz0ynQXcYPzVhkxjhOBSGEEEIIIaQDMdarha7gVFCgB5pUM14242kz4jgdhBBCCCGEkA4ItBC6Vr3i1UiEAt06E8VTxfBcTgUhhBBCCCGEyDlejcQuVhToVvk/Mz43I5tTQQghhBBCCCF7gUaaYsadnAoKdKfpbMa7ZtzDqSCEEEIIIYSQg/Jbr3bqzKmgQHcChLSvNOMUTgUhhBBCCCGEHJZTvBqKIe8U6H7lJvGEtKdxKgghhBBCCCHEZ6Chpng1FaFAbzcvmPFnTgMhhBBCCCGEtBloqhc5DRTobSXfjIVmXMipIIQQQgghhJB2c4F4eqZ341RQoLeGY82Ya8YgTgUhhBBCCCGE+I2BZnxlxnGcCgp0X7jKjI+F1QYJIYQQQgghxAmgtT7yai9CgX5Q7jfjCU4DIYQQQgghhDgOtBfrfVGgf4dIM14342ZOBSGEEEIIIYRY4yavFovkVFCgg05mzDTjTE4FIYQQQgghhFgHWmyWMM24wwv0AeIpBjeS7wQhhBBCCCGEBIwRXm02gAK9YzLRjKnCEv+EEEIIIYQQ4gbQ6nqaV6tRoHcgTjfjMzPS+A4QQgghhBBCiGtI9Wq10ynQOwZXmPGmMLyfEEIIIYQQQtyqU9/0ajcK9BDmVjOe4nonhBBCCCGEENfzlFfDdRgieqd1mPD+n5vxR65xQgghhBBCCAkajjejTjy56RToIcJvvIMQQgghhBBCSHBxLLSreHLTKdCDnAfMuJ1rmhBCCCGEEEKClklmpJjxAQV68HK/GTdxLRNCCCGEEEJI0DPOjCQzPqRADz7uM+MWrmFCCCGEEEIICRnGm5FoxkcU6MHD/RTnhBBCCCGEEBKyIj0kPemhKNBRDO4OrllCCCGEEEIICWmRHnKF40JNoKNH3j1cq4QQQgghhBAS8qBwXLUZ0ynQ3cePzXiQa5QQQgghhBBCOgzok15qxuxQ+GHCQ+ShXGLGI1ybhBBCCCGEENLheNiMSynQ3cFJZjzHNUkIIYQQQgghHZZnzTiZAj2woDDAG1yLhBBCCCGEENLhed2rESnQA0BvM141I4brkBBCCCGEEEI6PNCG/zGjDwW6XVLNeNuMLlyDhBBCCCGEEEK85Hi1YioFuh3CzPi3eDzohBBCCCGEEELIvhR6NWPQ6d1gFOjPmnEi1xwhhBBCCCGEkIMAzfiPYPvSwdYH/Vdm3MC1RgghhBBCCCHkMAwxo9mMzynQ/c+5ZjzKNUYIIYQQQgghxEeONmO5GUuC4csGS4j7GPHkEBBCCCGEEEIIIa3h315NSYHuBzLFk3cexnVFCCGEEEIIIaQNQFNmUaC3n+fN6Mv1RAghhBBCCCGkjfT1aksK9HbwJ2HFdkIIIYQQQggh7ecEr8akQG8D55lxG9cQIYQQQgghhBA/AY15PgV660A5/Me4dgghhBBCCCGE+Jm/eTUnBbqPPGdGGtcNIYQQQgghhBA/k+bVnK4rRO5Ggf6QuPQ2gxBCCCGEEEJISADN+SAF+qFB3vn1XCuEEEIIIYQQQhwG2tNV+ehuEuj9xJMLQAghhBBCCCGE2OBRrxalQN+Px81I5/oghBBCCCGEEGKJdK8WpUDfh/8zYyLXBiGEEEIIIYQQy0z0atKAEza54M5Af4dRZszmmiCEkAPT3NQsjY1N0mR+xT/rr82e4fkN3g09PEwiIsMlOjpSwiLC9v53QgghhBDiE6PNmBPILxAZ4AmIFfY7J4SQb4nv+toGqautN6NBR6QR3bEJMRITGyXRsZHm3yMkMipCxXhYGIR5uIp1/LmqilrZWrJLooxIT8tINL8n4hshTwghhBBCDgW06QQzajqqQP+1GSO4DgghHY0wo6zr6xukck+N1FbXS1RMpMTGRUlsfLTk5GdIVl6adM5JkfSMJEk1QjspNV6SUuIkITlWYszvw4iOidK/B0K9qalJqitrZfeOSilesVVmfbxMZn6wVP/35LR4Ff6EEEIIIeSQjPBq1NsDZiMGMMT9KDM+4xoghHQsYS4Ch/b2jbslLjFGeg7oInm9MqTXoC5S0D9H8ntlSnpWssQlRLf7s2YYgX7P1S9KVUWNpKQnUKQTQgghhPjG0WZM6UgCHaHtC8zozWdPCOlINDY0qUi/4IZjZeLkQZKdn6bh6E4x9/NV8osLn9HPdPJzCCGEEEJCiJVmDJEAhLoHqor7bynOCSEdUqA3Nmk4+3HfH6aec6dF84hJhXL8OcNl1/YKTj4hhBBCiG/09mpW6wRCoCPp/hY+c0JIRyRMPCHuNhl+ZC/NXW+ob+QDIIQQQgjxjVu82jXkBfrv+awJIcQe+YWZkpgSJw0NFOiEEEIIIW7WrrYF+k1mHMnnTAgh9kBLtvBw9kUnhBBCCGklR3o1bEgK9G7iKVlPCCHEItpjneKcEEIIIaQtQMN2D0WB/hszEvl8CSGEEEIIIYQECYli0dFsS6CfbMYlfLaEEEIIIYQQQoKMS7yaNiQEOooW38VnSgghhBBCCCEkSLnLq22DXqDfaMYYPk9CCCGEEEIIIUHKGK+2DWqBnmnG7XyWhBBCCCGEEEKCnNu9GjdoBfodTv8AhBBCCCGEEEKIBTK9GjcoBfoIM37GZ0gIIYQQQgghJET4mVfrBp1Ah/s/gs+PEEIIIYQQQkiIAI3rmBfdKYF+vBnn8NkRQgghhBBCCAkxvu/VvEEj0H/OZ0YIIYQQQgghJERxRPM6IdDPNONoPi9CCCGEEEIIISHK0V7t63qBzrZqhBBCCCGEEEJCHb9rX38LdMTij+VzIoQQQgghhBAS4oz1amDXCvSb+IwIIYQQQgghhHQQ/KqB/SnQLzBjHJ8PIYQQQgghhJAOwjivFnadQP8xnw0hhBBCCCGEkA6G37SwvwT66WaM53MhhBBCCCGEENLBGO/VxK4R6NfzmRBCCCGEEEII6aD4RRP7Q6Af4x2EEEIIIYQQQkhHxC+62B8C/Vo+C0IIIYQQQgghHZx2a+P2CvQRZnyPz4EQQgghhBBCSAfne16NHDCBfrkZEXwOhBBCCCGEEEI6OBFejRwQgZ4jfuz3RgghhBBCCCGEBDkXeLWydYF+iRlpnH9CCCGEEEIIIURJ82plqwIdf+4yzj0hhBBCCCGEEPItLmur1m6rQJ9sRl/OOyGEEEIIIYQQ8i36ejWzNYF+OeecEEIIIYQQQgjxn2Zui0AfaMbJnG9CCCGEEEIIIeSAnOzVzo4L9PPNiOF8E0IIIYQQQgghByTGq50dFejxZpzNuSaEEEIIIYQQQg7J2V4N7TORrfyAScLicISQttJsRphIU2OT1Nc3SmNDk/5zoxnN5n9r9vw/CQszv8mM8PAwiYgIl4jIcImMijC/RuA/E2JlfTY1eNZmU2OzNHnXZrN3fYaZtRnWskYjw3VtYo3i31v+HhKAfaSpWfcS/CZ9TnhGERjhupfgGWGQ0FkLzYf4n8MkNN9FrPHGhkapr2uQBu/617Vvxt69KSLsmzUfHenZm0gA9qlms081+GzvhJvzJErtnXDP/0ZCgb5eDf2+UwL9Us7xQQ4B8w41mpewrqZeN0x9EZs8Lx5euOi4SImNi/YcFM2cLxLq70OYGg+15n2oqa5XoaPGQZjnBYiJjZLk9ASJT4qVuIRoiY2P9hgS5kCCId0AcdTkeZ+qq+qkuqJW9uyqkrKdFcYA8Z59TU3690XHROqfj4qO8BrmhByeBqxPszaxxrDWwr1GLYymmLgoSTHrMy4hRgf+XcW3d41ifeLPY5+vr22QyvJaqSir1lFn/r3FgoaoDw8P1z+vf4f5s1yjbdhHzHOqwXMyhm142D77iDlTU3QfMc8pPsbsA1F6UQLDFs9TL1nMn6mraZDqyloz6sw+Uim7d1TsFfEt5zT2Efx92EeI6NrGGldB4bVnPJcfzXvFBR4D3omoaNg3nrlvdmiB61ow36XGnAdYD01N36yFvRrmW2Km+Rvxvs93hvDBc8YZpDGkzcHxDlSZMxDrWMLEe/EkkpQaJxldUiUxJU7XPp4D1r4+O7P2sbdVmb1pz+5qKSutUNsU6H5nnltcvOfspV3qH/u/ttqzNrFOWy5xsfCiYz3nSXxijA6cBREQ4N5LQ7V3zO+rwz4He8fsU2U7K2XPzip9Vh57p1mfU4u9w0vGoORSpwR6rhkncX6//UJiw8MLWbmnRl/GzC4pkpWbpgYDNku8qDAMtm7YLZvWlhpREm821XjdDd1qqIV5b/xwK+vE5V3LxhWst7nfXL74aT68t6ZBb9A1esQK3oeKPdXGEIqUrLw06d4nW7Lz0yWvV4Z0Leis70da5wRJMEYFDISYeI+xdKD1UF/XqIceDq3K8hoVQNtKzLtUXCola3bI+pXbZMfmMv33cvO/JSR6BD8OMRiLhOwV5DBYzfqsqazTPTnOGEo5Zl1mmD0b6zO3Z4Z06d5J/z21c6IkJMfqpSoM3+iYKDV89wXGfoshDOMZo8b8vbt3VMqmdaWyef1O/RVj+8bdsmXDLr2wSjR/L9Z8dHQE1+hB9lecqzV6rlbr3GflpkqPftmSY55PrtlDcgsyJNP8NzwnzGfLJUr0gfYRc87W6TmNfQSCpUbKdlXJ9k279dmUrN6ue8n2jWWytWSXGVW6L3n2Ec/FTCh7YBu9Ahxzjv22vrZebRv8/BB+CcmefTrK7KnYVzEf6ngw7wPEO9b0ru0Vsrl4p4rmTlnJavu0W6hD2zTJXhurfHeVRJr3JbtbuhT0z5Ec8yve16yuqZKCdWC+a0xspF6I4XvU1Tbqs8a5sGtbub5/W8w7iee+1fzzxnU79HviPcf54ybBg6lrqG/Qc6/ciGtcGuUXZurP23NAF/35u/ToJJ2zU/T7t4i+/b2tLftdZYWZB7Pmt5l9aEPRdlm9ZJMUm7OzZe3jcgXzh/cnIiKMl4ittHdgm8CGy8732Duwe/LV3jH7lFmfaZme9akXIuZMicY6PYDN12LvtNhQsHe2byrz7lPG3inapmcJ3jWs63hcICdG6zqmYA8KTvJq6RJ/C/QTzUihMhf1Bu7aUaEitlN2svQa2EWGjCuQ3kNy9YWEgQch3iK6IN63mIN//tQiee3JabJ2+RazsSa7+vahocGz8YT7WTi2GLU41BuNYYvDJdEYAGFBItZx/uHQg2Hir++MecamjFtReJWD7YCEEVFWWqmHDm7zB47pIYNGd5deg7oaoyJDhU9bDw8YJlHRcXq4dc7xbD8DRn3790Cgr1u+VYqM0bH4y7WyYn6JGtq4hfZ4QaN5LHRQsN+U76qWKiOc4W3C5RD26X7D86SHMXLze2WqUdWWMEL8mZZwaby76ZlJBxWcMIJhDK9ZulkWmTW6evEmXbdYo0lp8Wpgd3Swj+ByA0IDRu3gcdnmXe8mhYO7qjiBKN//ksTXMzvaKy6TUuWgZgwM4Q3GAF69ZLMsm1ssKxeUyCZjCO/YuscYwtH6nII93BQXyzhrKspqVJyrAE+KlaSseMk2oiKnWycVF52ykiQtI0mSzc/sEemey6oYvayK1EltmQo8N92DV2yVL95eJB+9Olf/G84ynJNtpXxnlRGWtZKekSh9hubKsCN7Sd9heSpOcUnTVtsEor141TZZY57z0rnrZcGM1Sp+qoyITe2UqO9ycwAPYIgyCL7ktATzc+fJiEm9pf/IfOk3Il8vP1pDy7qHPYrLSOx9+15YQqQvNWt97uerZOGMNZ5LC7Of4eILF10U6oeyd6LUjh9obJ2BLfZO70zJM/tUZHT77Z1OB9EIpWY/WrN0i6xdttnYO+tk2dfrVbRjzaR08kR9EdeS4tXST/t0dE0uuNPXv/gjM47rkJrcexDhJhNeEtzYQ4SMOa6vjD+xv3Tvm+3z37W7tELuOP9p3Qwh5FvCV9wENp/Rx/aRC64/VsOimv02j9+EPeMz4GFatWCjLJ+3XkO3sLngMHHjnLSATfCiG46VQeN66Hpo73zAEEDo9uZ1pbrRLpq1Vuci1RgluOBpduEJie8NDyQMCfxzbs/OMuSInjJ8Qi8ZPqlQRVAg2W3W1tdfrJI5n67QX9cbYwzfEwY2jP/mAK8v3LrDg/rEpzdYmysIwxvPfFyNUw1pDOG9Gq8MvG3wwMIz1scYpUMn9FQDf8j4nq4Qw6Vb9siCmWuMYbzSrNEiXaMQM0j5gGBq7gCW8bf2ESMG8npm6DMair1kYqGK9ECCsx77MfaQedOK9OIPl6mIqEAUXMv+HRRzjXD/Wo9HFp7XHn1zjJjIUG9ft95ZGtkEu8YfQOz97poXjZAo1zPd1/225TvCNsA/42LmiJMHyhEn9Ze+w/Mdi7jDM51rnvG0dxfJjA+WqrcSewQuJzyXfM4+G/xctebM37OzUm2tngNyZPxJA2Ti5EEqzBERYGtPmvLWQvn0tXmywNin8BCnGaEOsdnc1HGVOtYiohCwT+GyD1EMQ42tM8zsUyOOKpTsvPSA2zvzzf4029g7c6eslA2rt+uaxfrF+dfMWxa38bEZx/tToPcyY54ZiR1LmIdpqBReTIiovJ6ZctSZQ+TUi0Z/6yaytcC7d+WkBzQ3CKHwbgIbcem2crnyzpPlip/byWjALeC/H5kiH70yV28OE1NiXSnSW8JZH//4er3Fd4Ilc4rlmT/8Tz5/e6Fk5KT4J1TQX++CObDh0SjbUaG3uyOP7iPHnjVURh/bd68x4zbw7sLo+uDfX6lgh5ckPTNZhToFemjt1QiFRRgnvOUIA51wykA56owhMmhsD1en0+CZzJ++Wj7+7zyZ9eEy2by+VCM/EFrs1ku69jwnGP4aZm4MS0TFjD7G7CNnD9P9BFEObgR7H/bmT1+fL9PeW6wREHFeEeeWPfpw+yAimX7+6PmaKuC0l23e1CK56XuPa1i85nr78O7uNHYH/nnCKQPk9MvGG5Ha33rYLmoTvP3cLHnr2ZlStHijnhUJxkZz4vF6ovEazc+9R9fQqKN7y+mXj5cJJw9Q72zAbEDzw875dKW8+NAnMtOcnfguaRmJQXUh5S/bH5d0WBO4qBh9XF89T3B5kpTizn0KDqTp7y/RKBacJbiQg7NHz3zqdNdsx2YMM6PIXwL9FjPu62jiHF4YHGyFg3Nl8iVj5JQLR2vojz/4+93vyHP3fSTpWUmuCpuDCEVRrtv+cq6cfMEoq5/94ctz5Q8/fklD19zoRUKhsqz8NHnk/Z/qhu0kj9/1jjx774ca0oZKrIF+F1CwBD9/j/7Zctz3R8jx5wyX7n2yguqdXjZ3vRpeH//nay2+gncvEMY1Bbp/jVzky8L7g9QQhIOe+IORMnHyYNeKvUOB3MJPjFD/30tzZNXCjRpSjLDbUDCMdR8prdDzpWf/LnLCeSPkmLOGSbfemUH1c8AumPruYnn/X7Nl3rTV0lDXqBeWbk5NQljsqKP6yF/euc7aZ/7hupfk7ednHTIsG+8vPO1Y35NOHyzn/+QojXJxg9D5z+NT5eVHpujc4bI83E+XZS3iDxcSuICbcOpAOe/HR2nkiNuY8uYCdRgs+apY5wA1GTqCSEd0JGz/ngNz5Ogzh6otjEiTYGL51xvk7edm6sXvTrOGsUd1lOcXBNxqxv3+Eugfio8u+WAHnhZU5IUggeHw/R9NVHGe6OcbsxXzN8j1pz2mB5Sbijt4qnyGye//9UMZfmQv658P8XTP1S9KbEKM2UzcVZUbHh+EYP7lbTtGzq8ufU4+eW3eQXNbnbWmNcvQc0m1p0ZzAE+/dJycfOHooBQ++7J22RZ56eHP9EII+ZjpWclWPZUU6P4RezByd22r0AusUcf00b163An9gqaexaGA5+bDl7/SmiXL5m6QRPPO4b0LtlDTMG+PK1ROx7naf0Q3Of2ysXLi+SP9fqYGgpkfLpXXn5yuUTpYj8jbdmPUA8QgBOCj//uptc+c+u4iueXsJw6YqgA7y+OdrJTB43rIFf93kow/cYDrni8K+z5655vGLpknCSmx6jltT3Qf9i14ZOtq6/Xnvejm4wJiZ7UGeGGf+O178sqjn2sNiNROCa5OQ2zzszFrUiOwKjwRWKeZfQpOOUQzBTNIn3rxoU/l41e/1ghCj9MnnEI9sCBl/ITD/aaI3mkTD/d7cK33kIR4V9eW0Lst63dp+OuFNxwjv3ryIhkxqdCRcKOEpDiZ8f5iraoZyHCm/UEIN37+8396lLfavF0QOr5j8x75aspKDfF0E7i0gZGDm34boODg528t1Gdis8o73gXkXCEVAwLyR3dNljseOd8YUgWHDVcMBhCud+Spg2SsEXOoaIvcUuxuaL1jIwwM4bK4lDvt0rFaINEGqLKMMH9cwAVztdeWYCOkHMFrPmxCL7n1oXPlyv87WbsEhErPWER2IO/2tEvH6XpdPm+DbES15SBqr4NnUVVRp10XuvToLNfcPVluf/hcLagUHQL7CEDe/PHnjpBBY3pooSZcvKM1GQqquemiCMUI0ang1IvGWPtMFMeFKNC+zt65aHk9t5o1gV7PV//qFPnVExdpEUA3grolSL9A8dNpxl7DetYaFq18tJpnXl2v1eNR4O6OR34g1/x6slaidzvYb1Bvqe+wfPny4+VqFySlxEuogH0KzwYV/pFyc/UvT5HbHzlPzxZtjRzkoA7EkacOlNHH9JYtG3bLotnr9GcOhZ8tiCkw4wWYZofcN3z4i87oCOIcN5oIA8Fm/MzUm+Xa35zmqEBFZen+o7qph9JNNmVjfZPeGCanBm4D/v61E9WYQAEht9By2ZiRY6+RQe/BXaWfMdJRq8DWewCBiksjVKq/6s5T5PlZt8t5P57krdwbWqAiMDxKdz19kfZQ3lK8U59zWEjvdsG9TzeY/QntktIzkuQ3z14qf//kBhl3Yv+Q/ZlhHCP89Z/mPbzg+mPUw7NruydX162nckuuKvaRxsZG+dHdp8qz02+V719zZMi2AkIEx8Pv/UT+9MpV0qVbJ7NGd2ox1FCI5mgrnhaF0er42Pv+NjRpGgcqkv/94xvksttOCIo5OvOK8fLkZzdpxwcI1DBfXz5vz/IdW/ZoBMnlPz9Rnpt5mxxz1tCge56oCfDkZzdqZXkU+NUpCOLl3XLOb9u0Wy+uEcXx4pyfy/k/Ozok67T0G9FNHnrrWrnn+cs0egmXRbR3Arf8vNpa2ivQQ773OcQIQj7uePQH8qeXr7SWa4IwGhgsyPt2z1zUazuOQIYfIrd5+MReUl1R55p5QfgiRBwqeNp8hfN6dpaaaufnwZPaUaNGNTzLT025SS+p3Fr8zZ/AS/nklBtl/MkDzM+/Syvqhofz1HITeB6IYNlpxOnZV0+Qp7+4SSZfMrbD/PyofXLLg+fIX9/9sXYN2VxcqpepbhM3eE7o34uWZTDon/niFrn6V6cGfVqMrxzzvaHyj2m3yOV3nKReOUR5dFgDOOzb6wIX7ju3mvf3R0d6hV5uUP04uNB9+N2faOs/XMAcTpxqVKZ5RyHoYVP+9Z0fy09+d4a2rAtWYP889uHPNLIU73iwLm3PeqzTfRRFKv/2wc/kx/ecoe3oQp1TLx6j6XVHTh4kW9aXetop094JBIfV1ocT6AhvnxDqs4TWXxBf406w64npPyJfMnJS9abdTZcV8F4HmjHH9VNh6hbjBmHJsQnRGqppk0iHi5i1hARDmOMW+cb7z5IH37hWW9x0JLqa5/rQm9fKD41hjRxBhFDz0HKBjQ9vbFOzemyQ/4kLVKRbpLeyH3CoMPKo3vLYR9fL9648QkMyK8uqXbFOW/YRhC7jeSHt4IHXr9GK4R0NtMq77renyV/fvU669cmSkjWlmqbU0faTlmMLPzf2U7SDuv5P39NK8kjhCEYQkg6RjloK2zbsPugFWcuFN4Q80gpw4Q2nQygA5839/7laBo/todEQwRQlEub1+nvsnUa54d6z9eIEER0dCVy03P/fq+Wau0/T97JsJ+2dADDBq7HbLNCRsBTyV9/Ih0Nrm4//M9fq5/Yc2EV7kqLvtVuora3XMK5AA8MOVbbdMjdNjc0a9tS1Ryern4veqJGRzoSFekIOG7XvK/LLEIZ6/k+P7tAhT8gL/N0Ll2tYJgor8dAKrOhDQb2NZn0ecdIAeXrqzTLptMEdfl7Qr/oXj10gdz9ziYYM79xeEdB16kk9aFRjfcDobvIPbzh7R2fw2AJ5bsZt8oOfHa2e4z27O5YRHOZdGxDnWB9/+vcVOhfBDjzguHzqNaiL7NhU9p1nin9HzQ94aH/5xEXyq6cucl07XX+I9N8+f5n0GthVay8EutOM7/ZOk5Ss3qFtkp/45Aa56KZjO/QehXbKf/z3lcbGDNc0DNo7Vonzauw2C/TTOsIsYVFCgC2ZXWx9w0DYlKdyuhtEaJPExkZbzbM+GNhAu/fJ1gribgBCFtVL0fLIFohmKFm7w5Ge3RriVVWrYWrnXjdJc7Gd6u0ebBz3/eF6q46wYrQA4qEVmD0ZIbGl2/bIFb84Se5/7UfWKt4HC6dfPs4IhR9pEbntm8sC4slqeU7bN+3WwqJ/+9/Pgq79opNERUfIrQ+dI79+7lI97zvSfqJVsXdXaZG4P7x0hbbUCxXgPPjV0xdLenayeiBbnil+3WHeRZwdf33nOo10CVWwH9/1zMVaq6mirMbVF/tYi4jIRMrJ2VdNkMc/vkF6B1mKhVMcfeYQeeCNa/QcoUi3zmltFehIlBnfUWYJlQ4Xz14nG40gsgnChBBq44ZkHnyP1M4JkpUXeEMYm0SPvtmafuAGIJYR7WDzJhw5t/Bu+7tyOuotIKSpYne13Pzns+X2h88LuRv+9oJq/fe+epUeWtsO4CUhzr77WJ9o73PrX87VvE2bXQyCCfR9/8tb10l2XrpWS7dZxV6fkxEnuES97a/naY68E5eJocBJ54+UR9//qWTmpmpOsoqGEN9S0Eca5+adT1woE04ZGHI/X58huXLjvd/TCyotCGgeaMmaHZLfO1Meef8nmo4S6sDB9ON7TteK/fBOu3FNh3vbp2Hgu2I9okgz2UeHjCuQh8w50ikriSLdLuO9WrvVAh2xHx0mMSM6NtIszDJZMseuF717v2zJ6JIiddWBz0OHJx8XFW7IQVeRNKGnRMVEuqL3L56P1QJxBrRVwsEX7kdxgo231Kxz9DO995WrNKSdHBhU0P/zaz/S3GeGu9szphAeimgehFCec81ETsphQDrQ3z74qXqu4cm24UlXT6Ex5CKiIjSX8Zxr+ZwOu5+MyJfHP7peBo7uIRvXlkoTasOG8JaCU/uOR86TE84dEbI/47FnD5dLbjlePbNI8YDQeeyjG1zbNs4JzvjheDnx/JEa6u62BY19CilAKMSM1DU8K3Jgeg3sIn9+/RpJz/SK9AjaOxbI92rtVgv0cR1qmrwacNaHy6x+LCq5I7TYDaHc8KCndU6UzK6prngk/Ud2k4Sk2L1tWgI6N/UN1gV68cqtng4DfjK4VZxvLd9b5AVVPMmhQaoFwjPRIx3vaBh7kjhqTCFfFZdyaFd11BlDOCk+gkvVP71ypfaCL3XYA+LZR/ZoGC9ycVEfgPgGztYH37xG+xJvgye9OXRFOvrdn3556Adhom82OivgAubR93+iqXAdDaQh5fbMkPKyatd40fWyd0eF1uzAPhVKKRZOUTioq9zzz8slLj5aykqrOnSbSIuMa4tAH9/RZgmVRZfP26B5UzaBB6SpqVmaA+woRrXwrLx01zwPVExFuFig+6GjwE1CUpz1i4t1y7dKbVWd2STb70FvEedoI4Jq5cOO7CXEN9BS5qY/ny3VFd+EMhIHxLl330V/83En9OOktBK0csLcxSXEfCsv1v/ivNwYvXHy5/9eLUPGF3DiWwlydvVi4+QBsgW9iJtCM9wda6UjRB2hyPAvn7hQfv2PS7SCf0cEEQOIokFR2+Zmd6w9eIHhjLjv1atl5NG9hfgG9vTbHj5PaqvrtAUb7R3HGd9agd5FOpoHXTzVcdcs3Szzp6+x+rnId42OiZTAK3RxVYEf5F6junj57uqAehlQSRq5OV0tt1hD/jmWRHv3R4TIw+OFXsT3vXqV9B2eL6R1nHLhaLnwxmO1T3pTUxMnxI+EeVsS1VTWy/89foEKF9I28G7/3+M/0HQl5PD707jae8mXFq9FhbiPtB1NMTLCAZ70Tet2uELUkLaD0PaO2FJwX866aoJGPaJNaaDFOdKkYuOi5I8vXSkDx3TnAm0lSEu5/I4TNe3XDSmmIc44r+b2WaDjD3S4q8CIyAj1li6aZVegY1OD0YMiG4Gk0QgPt+VO9RqQowU9GusDNzd1xthFOKfNEHdcSiCnrb3FTFoKOeGy4/cv/lAGjOJh1VauuXuyMagHaeV75qP7D1yAYY3ecO/3tII+aR9HnzlULrvtBGMoV2pklr+MXhTuw0UyagPgzCLtAxXe737mYhk+sVD7MnNPIcEM2tCeddURfttz2gIuJFFRPjIqQtuHDR7Xgw+mjVz9q1Pl6DOGyLZNu+lFd/jVkYM4xA8m0I/riLOEEG+ExMybWqS5v7bIzkvT29eq8sDloWNTjTHGl1sKxLUwYHR3SctMCmgrOhQY6ZSdrAeQLeA9R0eB9gh0bKroxVpXUy8//9sPGNbeTuD1uvG+szXHEB5fnln+AW2JzvvJUTqI/4yrsSf280vRuP33EaR8EP+QnJYgf3zpCsnvlcmWjiToOfH8UVpsDGmits9HbaVWVaft1G7767ky6pg+fCDt5JpfnyadspK9tQW4NznIca0R6B22ehQ8jeuLtsuKeRusfSZCkPsMy5OKPdUB+7lhfGXmpmlFeTcBj35OfrrVC5MDgfxOm2wuLtVDDjfBbTWq0aIO1cevu+d0eib9BC7SLr31BPUmMiy1/QYVPIcwpNCii/iXa+8+TYtsVrWjAClsMhTpRIrMj+4+VY4/h/uIv+mckyK/euoivYxFkUSKdBKsxCfGyLFnD1Mvtm1PekNdo2zfXCZX/t/JctIPRvFh+AFctlxyy3He2gI0eBxkkK8CHW62kR11lqJiImSXETVzP19p90UY0EUL7zQEqO83bh7hPXdLBfcWIFAHjumh3y9QeejIwSnobze/bPXiTRIZGdFmEYjNdGvJbm2BctGNx3L78yPn/+xoGTmpUC8/eKvcdnGOQz8rN43i3CH6Ds/TqASIvrZ60bH/4BLl9MvG6cUUccg6G9tDbrzvLI1UqK1p4ISQoGXSaYM1HbDWYuvglsveMy4fp7nTxH/gDBl1dB+1d4TmjlNAc/f8jv45wG9EucOYjmw4RkZHyKIv11n9XBSyQBh1uTGmIhMjrP/cqE6NUHs3gn7UenERgAs8GKiIcMjrZTc3f9WiTW3uQwkPzLZNZWr0Xf/HM139vpUZkYaNH/3ecaDjYiHCzDdabSHdBMX5UPXYTWB+f2BE+vwZazT1oq1RDh0ZeDsqy2vl5gfO0TaTxBmwTj99bZ4ar3ifWrvO4ZHqOyxPfvbH73EyHeaUi8bI8nkl8sKDH0tuQWdG6JCgpFufLBlk7NnP3lygUSFOr2PY7Du3lus+detfznX13OCydOfWPdqyFTY3nD9q70TD3ok1GiBFi/m6ShOFhcmFNx4jv7zkWWlqaFJ7mPgdaG7kZKw+nEAf16GnyWwmKekJsvSrYtlQtM2aMOvSrZN06dFJFpmXN87y/Qg2CWwQtvt8+wrCiuFpgxfdZh44qKutl845yVZD//Fzblq7o00bITZT5EdHRobLrQ+dI8np7unJigKMa5dvkcVfrpPlX6+XDau3a3EwreBtfuZ6I9qwFnExAdGLXpzxybGS1jlJeg7M0b66wyb00pDQQDPxtMFabXzau4s16oThX60TfluM8Dvx3BFy2qVjXfkd62oatLr2xnWlsqV4p/bTRZs91KPABS5SoVA4Es8e7SC7GkGV4MIWSyg+irzQJ37zriSYd8nXiA/8tirz8+L33/zA9yUtI9GVzwn1C1BMc1NxqfZ/hwGsF30wfKPC9ZmkZyZpdBjONww3X6hdd89pMn96kaxevFk6mXOno1dQxjMt3VYuZeb9Q8pXtTknPPVyoiSlU4I6NWA7xSeFpk8JLWZRlBSV0dE6saq81nMpbM53tHRDfR7YJtiHIlwknCacOkjef2mO8+Lc7E81lXVavPKG+85y1R7c1Ngka5ZukSVfrfPqiR2yZ2eFivO99o6ZIJyHiJaMTYjW749n2qNvtnYGQMszN0S1ojju6GP7yudvLVRbnPaOI0B7v3c4gX5UR58lHOCeMPdV1gQ6bgEHjy2Q2Z+s0CJUNtc/DjzcdLrVk4U8GLR/WzB9jXWBjo2054AuVovnodUfenhCBLT6ssUsHBipP/ndGa6ptFy8cqt8+PJcfZ9WLNigB2o4ersbERBl3rUIDGNc4L2DfGjWw838HLurZef2Cu0H//XUVfLKo59rwRL0NEWO2djjA9srG21lZry/RA/iMOaN+mxQIT8Rh/x1vzvddcbwlx8vN3vwclm5YKMxqLZ7ih0d5NnivzaZ9w0XSTlG+GGfgEE10RgznV1Uy+PkC0bKW8/O0AuGaJ/3lDAVBVf98lRtA+oWcMm3cOYa+dKck6gTg0t0RAcgTx6G7sHOTeyLuKzIL8wy50mOjJjUW8Yc17fVUQVOExsXLTfce5bces6TUmvOnpi46A5lDKOo4VdTVhpBs17Wr9omm9fvlNLNe7Tw1/53S7BbkPOMS5eC/l30eR51+mCJSwxesY5aO4tnrzO2zmopWrxJL+qxvsvMmY7LGs8FW7O+n1gX+HeciXmFGdJnSK4cfeYQTQkMNLA9cgsypKqixtiWzj0PnL1aZ+e3p8nIo9zR67x4xVb55LV5asuvWliiF50t9g5snMgD2Tvm2aJzD9rDrTN//usvVsmrj30hGTnJMnRCL23zCnsnkHbGGZePl1kfLlOnFRx6xO9M+o4W3e/fk81gXwLxFMaBoDjziiPsbWoj8j1G396N2JZAb1Ix6LYWa/vSc0COCnTv2WRRoHtC/23eTmODhmcoo5U3p1gz+HOjjuojl9xyfMCf2ZI5xfKfx7+QmWZTR1hXTFyUGslJxihui82JVwLP470XZ8unr8+X4Uf2kivvPFkGjg7MljX+xP5aGX++MabgpSO+7TUVZdWaJwjPlxvYumGXvPP8LPnsjfkqyqsq6yTeGJXxyTHqofPFSNy0ttQYYxvlo1fnyvP3fSTjzNpA/QeEXQaaHDPPg4zRDqOxkw8CHfvIzu3l6sH54c/dkc8JT+oH//5K3/t1y7eoMQsPOeq2wJPqy3kJcb983nr1UL/z/JcasXbESQPk1IvHuOpyGm3XcPn37J8+MGdPesjnfeISfOo7i+QLMxbOWmtESrn+N3hFIe5i46MO6iGHnYZ3FqkBH71i3r37P5Jzr50kky8dE1QiAmflF28vlFkfL5ONa0qlck/13gsInJtpnRIPvA6aMX+1Mn9akcz+eLm8/tR07bJw0U3H6WVhoOjWO1N6Deqigs4pga6pfGZfGHlUoVzogjo7KxaUyMsPT5EvzTPcsXmP1rNCNC4il9pm74TpxRScG5+9sUCf62W3n6BRhIEAEYP4DrM/XaGph3Si+50CrwbfczCBPtiMrpwnT0/HZXPXaw5ehqWQWoRywxMDAzbe4i0w8kEzuqVqKLdbGXpEL3nj6RlWjRXcUCOUzHboPzwHDQ1NEhER1qpNEJs5PGSXB9ioRrugJ3/7rooeFDyCeIXHtOXZtb3wnaixgr8LhtmMD5aqxxNVW68wIxAcdcYQFegt3gxyaIMDHoL+o7rJOddODPj3gWD7118+lVf+9rmUrN2hRnBCSlyr00KQigIjDANGNVI28HfiImnyJWO05VlKgFNNkB7yzj9n+fR74SHBSsYlSqDDwbGnweh9/enpsm7lVklOjdcwUFxetvZ1w8+C54CBSxWEDj9774fy2pPT5MTzR+qlplvSvC42Amum2d8QfZSWkRSSXnTUHXnbnBFvPztTVhpxExEZYd49zwWur+8LLs4RBYGBdw/tSX999T/lszfnyx2PnO/atL0WIHZeNXvFnM9Wyp5dlXrZhCgKXAz6dJ6Y34IzvyUyBnsaLjqmvb9ExdzVvzwlYOcSLicRjYSl68RXQCoL/t6r7zq1TdGG/gIe/Gd+/z954x8zpKayVvPIdX8K91ygtKfQL36uzNxUtXe+NHMJewfP9ao7T9G2r7ZBFw9cplGcO0JXrwaftte22P8c5xx5SEiO08Nx6Zxia5+Z2zNDevTN0lBEmyCvq7v5XLcV49qX3kNz1XDGAWQLbIq4ucdNsE1WL9lk1l9MqzZBhD7By3TaZWMDGur18X++lsvG3ysvP/q55sihRR48If6+WIFhhr8bhtkjd74pt57zhObm2QYtZeCJs1mxNlhB279aI7jO+/EkvWgJJAiTvtSs04dufU3zOvPN3oviPO2NlIFXB5e7XXt0VuMKFwCXjPmTTDcGcyDJykvzdAk5zP6J7w/vD9oyTjglsOYALuAuGXOv/OX217VWRV5BhqZ/aWhoO/cTXKrgEhzPCX8fwkkvP+J+efGhT13xrkCoXnLr8Rox1Bigzi5O8t4Ls+XyCffJ/Te8oh5w5Nli4J1paxEqrF0I+67dO+vlxlVHP6DC340smrVWbjzjMbl+8qMy9d1FRmBHakg43lHP+m7bAsef9bzrsfLIXW/InRc/G7AWtcOPLDT7aYQ4Ud0X84PaBN+78gj9nECBZ4dz5KWHP9Ooqy5mP4G9szcTwY/2Dt6PpLQ4+duv35Lbzn1SC0rbZtwJ/aVgQI5GMBFH+Nahu/9O2Jvz07LZew5x5EPZpHBwrootmzdUyL3M65Xh6ueRZwxo5A4iusAWzY3Namz36Gcv/BF5n8Urt+ktemuoMBsmvAU/+OnRAXk+8F488os3jUHwDyk3zyjfrCcYW056flpqJ8DI/vS/8+XW7z+pbYpsguiAERN7awEfOtAPDXrHI3z3+HNGBPR7QIz9bPLfZO3SLXop2hKC6M+lqt6PuCjzHmRq1MDt5z0lLzzwcQAFX4Lm5uLS8VDA+4/wxUC3Znz0zrfM+/yEekTxjFpyxf29neA5YY9H1fTGxkZ54Ob/mLXxqGxcsyPg78sJ546QI04ZoAUKQyXMfX3RNn2ud13+nLYB7WLEdErnBLW1/HFWtBTdwlmIyt4//8HTWozUNXugOSceuPm/8uOTH5ZZHy2T9KxkI7zS/HpWNnvPxfzuWfL+v2bLn376ckB+Vlxcp3b2v1OlpRBurjn3L7ohcPsUCm/ecvYT+kyxf2C/d7Kooz5Xs1fl98jSYm2/uPAZqw4rgAJ2OMNRgZ44Qu9DCfThnB/Zawggd2bhrDVWvWPDJvT0hq7YUegQObh1zenWyfXPpOfArnqZYIt6s/mhAEvnbHuh/2uXbVGR3prQUi28tada8xYDEdKH9wMG1xN/eFdSOyVqGGqTperDnvC5MMnpni6fvT1fDWzbDD2iQG/NG+qbuHEedI16POgI+Q5EaF4LuET640/+rd8BhdycDh3Ge4Bq7zCY7zdrE0ZdIIBoUa/cIX5cT2/6KjnpgtFmr+0SkO9ZZQzvG898XJ763fsa6owLMBvh3XrZlxijFfnhuf/RsQ/J118UBfy9Ofe6SZpLjfZGwc5nr8+Xq496cG8l6JT0eM+zbXbmeWZ0SdV6Lg/d9porfn44e64+9kG9qIO3FdXXPYUN/T8B+CvhdUVx27eenSn/fWKq9Z8XtXvyeyMitM7vzxaiGB1AcgKUwnD3D5+Xx+9+R/d2DKv2TrjoPjXt/cXy26tftP6zjz9pgNmTIljJ3RmGH0ygo0z1AM7PN8TGRUnJ6h1aVMYWKFaTnpmsLRisiNDaBv08FPVwO72H5KonpcFSyB+qjXfvk2210i8quCI3z9cwPxjdqDSNKvdn/+jIgDwXeM2RS5jXLUNz4QKxcaNKape8TvLaE9PkzX/MsPrZIyYWarg9ChuRA4tzRBjg/T3hvJEB+x4P3vJf+fsf3tU2feo1t2ZUecRfphEMj971lvzjjx9Y/9m3rN+pRi0MqwM/JNHUqkwjnNA7PRCgc8r1p/1NPn1znnTt0cn+XuK97MMlJ9brT099RAvrBRIUokR1ctT1COYaF0/d857cfNbfNZ0OotFGlGCz+T98FnJm33h6ekB//mf/9KFcd+Jf1Z5ES0aEtDv+82sNnQiJT4iWZ/7wgVaDt3omGxumixGS/naqoIAe6jWdfrn9jtCIQLrj/Kfl9X9M1zNfIx9st0L0FkrOye8kbzw7XSPCbNJveL6G2wcqdSLEGeDV4t8R6Hn7/g9EJCom0hg1FVpZ1BY4UHoP7qqiywZ4ydDjtlvvLNc/j8Fje0hq5yQtamcDDf0vtBv6v27FFs2lDvexnQaKHSGH9vTLx2uFdNvcdfnzWmEU4WbwSgbqVhWfC08TcjdhDCGs2BYoCAODIRA58MEAvAt1NfWarx+oYj5//8278uJDn0huXueAGFX4PIRSZ2anqncY1cht8tWUVWrZhR8sesFMB7znCKuG58s2iMJBvuz86WukW89MFaMB20vMs0KYP6JifnnJs1o9PpCcftk4rWQerAYxQqwfu+sdjVjxtJC19FybIRLD9H1/45kZ1sOBW2wIeFsf/vkbGl3WEo1nbQrMB6WYz91SvFPefGaG9Z8fF34t38MfeBwS1dp2rHOO/VaW9/7sFfnfy3Mkt3uG39Iy2rq2EWWZlp6odU5KLKbkIPKj/4hu2s6X+J10rxb/jkAfKN8Nee/wxCXGysIZa6yFsIBCI9Drauwcxgg71XCzTgmufxZZuanqWbFhqED4RsdFae67LVCxuHjFNok3a641BkB+70w5MQCeSQiNN5+doVVGbddNOJgxkpQWLyWrt8tLf7Vb7GnAqO6ed5Z56N8B84KLx2POGhaQz3//X3Pk2T9+oOkquMQJpPBD2hS82PDmoyWiDdAuFF5EVAM/WDgxnlG6EaUnnBeY+gC/ufKf2mIqp1uaKyoE47zHhWd0TJT87pp/ycwPlwbsu6BY36CxPfTSPti86Jg7dDSAjYG6Kk0B8DYiBBkdeWw/Q7xTyFF++7lZkt0tXS/orP/83nMxMTVOvnhnoaaQ2ASXfYgeamr0z8+NGkQI7z7pB6Osz+Nz932kbWO75HfSDjuBRu2d1HgtZv2W5ahBFIqDo4xR7n4nXPYpFLevIB/CufkuyINbuXCj9l61RZ+heVqN1EaYe2NDk14IBANowzJoTHfNt3baUEF7MNx2d++bbe3n27Bqu3rQD9bzdX8ginfvqJSJpw3SW02bTHtvsTx1z/uSkZ2iYXTiko0aIgjV4+GhRC6/LQqHdJUmh/Ipgxm8p7tLK7SwDArp2Gbj2h3y5xtf1QI+McZADnTenHq0zN6O7/XXn7/h+OfhAu+hW/8rVRU1B+0Lre3vzLsy6pg+AenbjpD/d/71pV7iuOn1gZhCnjT49RX/lDXLtgTsu5x60RjtgBAIgddWVswvkfde+FLrCMDbF6h3D+sbZ+WUNxda/dwNRdtk0Zdr1dPraZkauGeHjgW4/EdbN5vALsHFxOGKU/oKisNNPG2winSboL0Z0jRwielZy245X0UvXj/57zwtimhNoPfPUadeQz2jBh1gyIEEenfOywGuM8zGipzgWR8tt/aZA0Z1043A6ZBZvNwohFboQBsx5LY78f37DMvX4if+2vAP/v3r1ePWrY+93HwUiEO4uq+tnpAjj6qax51tt7ZjVUWtPPart9UTiNtxtxULwa0yKnTjULVFVtc0vdCpY3XTb4EIHaRrHHFSYMqbPHjra1K2s1JFcbNLxA1EFjyK/3tpjqPt1yC6bzjjMb1gPlQvbYT+Ij0FPW5tM29akTx334eSkZni2fdcpj/xrJAChovQe656wWqR0n1BYSZ0eLGV+uYPsKaS0xL0uQbyjGjpJ71yfomeXbZAZFmPvp7Up0AfkRCVELfLv15v9XNhQ6GWU5Mf7DU4k7CPT754jNWfAV57XKYiCgARUG6yd/BVcPmyZcMumfreYmufi5pHsLNYGNcRuh1IoOdxXg4kYsPUyFwwY7W9TQ2eW/MCOG3s4+VKSPL0gnXC8Fq9eLPf/95eA7toEZ8ahw0lXADgc1rb7qw9oGNAWLjvkQE4OIYf2Uv6jci3+k7A47ViQYnH6HehRweCMComQuZ8Zs9bkJ2fpoVTamt4o/ytNbqnRqNQRh5lv4Mnei1PeWOBVnN2m+cR9U0gXF5+ZIoze8nMNfKTkx6W+dNW67o8lFGJfaTP0FwZfWxf6/Pw5G/f0/zzeG11507vsKcieIrMn75anvh1YKrwI9x+9DF9guoCUKPcwtxx54J6Aju2lOkluC3Q0xwpV4HIfT8Q8GSvW7HN7rrtlOCXtCIsJVw4ItXDtr3zwoOfyLKviiU92532ju5Rxl61ae+0dGFobGgU4nfy9xfonfb9j+TbJJiNdql5QUss9tPERoQbTydDueEN6FqQIbkO9ECf+u5iDeP0N+jXjr641Q5XzMZtLapO22TVwo0+99JuKaI06fTBVr/jmqWbtWpoWudErZLrRjAvyONf/vUGa33RUekfuY51tfSg7wu8R/2G5VuvcYGK+iieg/ZmkdER7luj6plNkq+nFvm1YFz5riptJXftCX/V3EQYUofaU/C/oabH2OP7WS/g9/Kjn2vrqU7ZKa41fPedJxQ5e/XvU2XWh8sC8h2OP3eEevCCKczdLUCgo3DohiJ7Nhwu2xOSYtWWcAPoob1p3Q6rxb3w8yO1qL056I3mz+NcH3tCP7s22aKNWlwPkYpurv6AjhdrjW2GAno2QMoYUjcaGuhBd0igd9pXoHfxDnKgjc0YeWhTs8wY/LboNairbqhO3r5CvKDoGsKG/A1yqSE4naDv0DzHc9BhBNnMzYfw3VRc6rPHvrqqVrqYZ4e8UZu89NfPtM0JwqrcnG+NkD7cuK83IsUWEKFNjTywvrFQPUJ0/En9rX802u0VLd6olyZuFX8RUeF6gfGpH1p5IfT5xYc+lR9O/LM8e++HahgjvBRG7aGcV40athktR1m+6IPX/rUnpqpXLzwIStNiDrE3Q2whJD8QwHPYe2iuXsKQ1oGK2zU1deZMKLf6uTgn3SLQI6MjZde2Ck3ZtHkOYy9qamrfHKD+QtfunWTi5EFW5wziHO3p4jWVz73rG99vc/FOq7WyEFVED7oj7NXjLUdjDufk0CBMZ/Yn9nJa4b2Fd9upnDcYbsivd6K9GsLDN6/bKUvnFjvy3YdO6OmoQNfe8FlJRgDbK2pVtHiTbF2/S2+bfQE9jYce0VPDV22BCxfkzKJti9u9OMh/xLuzcV2pPYGeFq/92FnZ1Pse1TSoSISosPq5RvR++MpcrcDtbtXnKfCDKuvrV7Ut9LRo0SYNE79i4gPyl9tfk9Ite/TSFR4OX95ReNNw1tiOFkL+PS4l0XoqWN4XnJmoM7Fgxhp5/Sn7fbWREjHMnH2IHuMe0waxGBGhrQRtgvew0SWXtkj9QoSXzToGOIfbW70eph5q8/Qf2U0jgmyxydgOn7+1UM8w16/tqAittbLD7P/W7J10OiQcJGdfgV7I+Tg0CCFZMqdYb/5t0Nmbh15T7UzIrPbljYuWvsP9X3qgdPMe3SzQm7HagaIsyGlFZdh6h9qtVZrvnN8zU7r1tlcgDgIdB7kvBeLw+xCOOmhMgdV34LM35svm9TvV4+Z2YIygiF7pljJrn4l8w3Btv0LrGZSbvbLnwC6OXAIeipkfLNXLwWBoHYnQW3QbmNaKAj94B996dqbccvbf5ZrjH5LH7npb82txWZeYEuuzMQyRh5zmweMK1MNoCxh1/3vpKyNeol2bJnMosYC5eu2paVIbgHzwERMLtZc4qye37YKjpqrO8vvtrktCvPO20r5a5jwmtn056PijeG5jjrNbIwPt8eA9xyVLMIB9yVbrTpCQHOu39nnkOxTuK9C7cT4ODW4BNxrBCW+HLXBjGBHujKe4qckT2lg4yP9h3PAGITR/u9ncljlQNRTtmhB+vsehm2AYrXmFGT5XU28vmKsls9dpHrMvBxna73XOTpGxx9s7sFDs64t3FqlxGAy9vsPCw6WurkHKd9dY3SM0soNnlhpVWNc9B9gPzoL3HO9uMPSM1vfdfM+5n6886O+BV3zWR8vkmT/8T27+3uNy5cQ/y++vfUlmfLBU81xzCzI0jNRTl8L3z0Z4ItqIwitrE9QnwQVKUmpc0L0rzd6+2kvnFGtrI9v0H9VdC1LWsRhlGw4FaXeodWuJjAp31ZmA/cbp7kD7g4KYze2YdlwoIJ2v/wh7MgU2FvZXXKAGCzjzbNYXiHVB29IQRhd7JAW6j5tMdIRsL6uWJV8VWyvMNWR8gfb+xkvgb2MTlXNhPKPQg98FetE23VRrampl3fKt2gPZ3+BiYeq7i8Rr3/r14gLe6R797PU/R4sMFCD0tUhTbVWdDBzVTTIthnvNn1akF1Ruzz3fa4vBGGu0a4wgzCwYRKEN4CWNT4rRWho2gXcZBT3d1g7nUKCTxtplW7UtILz+KK4Jzw1CLFHUCheeyDtGASAIcoQW7luZva0/Jy5Q0DHEdlVk/JwoTOeP6s6BANE5ME4Rpn/KhaOtfjb2377D8jW1AR4s0mqNblmgR2iNBUSKhLnlZtvyK+dxdLT9QxGF2XdYnhRYvOydP71IVqFTTWZS8KztMLFr70RGMNWGAt09IIR13herNNwmNt75MF9ULM/KT5Nd28r9+3lhniI9BQO6eASXvwWnMZIRfh4XFyPL5zlTWK/v8Hz1/sALhEPQb2eXEejRsZFWb2sXzVyjKQGoPO7LJoxnhyr/4eH2DvyZHy7THrLw8gcPzWL3BKE43yvQm5p0zyq0LNDnTS2SDat3WK3N0H7RFatFkH5z5T9VNGMvQLs+eG/QQxih4NjjOuck770A8oewxfuMsFHkwdsCtTMQLeDJPQ9O6w7fG/vgollrZc6nK6wX6hw4prv85+9TuckEAcjBFrdd2obZf1/a9aFhYr1GxuxPVki92YtxuRBM+5TV70pzx3GBjqstqJt0zocvhlSMrFu5VYvb2ADe7T5mY/J32ApEKDzFBQ55ieFpjU2IlrhECPT1UlXu/zDjAaO6qbfJ31Xu8ffBYM23mH++fH6JVlbVw/yw388In4QY6TnAXtMFzMnyr9drHYZg0uYo2IbKtbbA7TVDvr5ZM+nmPcrKS7P6ucvmrtf9LSIiPIiWarPmDyKsEssHRYmQxoNLhuT0BM2B9Ht0BgovVdRYN3wXzloj2zbt1kvQYAZ5tbhImRmAlmv5vTK1BktdLcPc3S+YhClP7QR1XUZMslcmC7bx/OmrNQU0uMS5p5i1tTPenFcMGHQMaHK1YrIo0H3fKFBN0uahjCJLCGv0Z6sgrVJuDngnQoZgtCAkE5sbNosdm/dIcRsrFB/68iJZevTL0VB9fwKvUkH/HGuVO3EYFC3cqCG5vlBTXSfZuan6HW2BXqBrl23RiIVgAR5ciIDk9Hh7Ar22QdrrLAgV8F52NSIzOc3e/COyCRdJiHQKqosS71eNUW95lJWCbY31Tbrn5PbMsPqjzp+2Wqor6vTyLNiFF6IAEA1gq3BsC9j7s/PSrBc8I8Q2uOhNSo3XaFJbwAG3pXin+7uA7L+nNzRaLYyKGj9M6XNUoGfhlERD9GTOx+HBYoSgWjx7nbXPHDi6uySbDarBj/0G67wCvfdg/3tPUNBo26Yy3dwiIz1FKxAK6MSzgBcdlaL9uUnA22+zsFXxyq1StGSTz6HjKA6U0TXV6oGFOgIwQv2ZSuD4YdXYrCHWGQ7UWDgYFXuqvUWIeGhhj8nOs3vvu61kt/aCDabCPgG7QKmpVw+9zVobLcYvLrpDwa7DJfSG1dtl5cISq58LIzynW7r1Yl+E2AatUrsVZkp2vr2zBJe8O7buCbooH2iTzC72Ursqja0cFk5bxyGgyTu1CPQozoePs5YWL8vmFlsLc0dxDBTyQfijv8CtJDwnTty2rV6yWaugt7SjQW4l/psTwJMQZ0SYv8LcGxs8ha1stoVaMW+Dil9fwtsBPIN5vTKtrnl40COjI4LKK4nbZOT2du9r71nu2lGhxdF4qWwEYG299fB2XHShR7Sn1R05FIj2SOucpBXgbYECfsUrt0lCclxIzCGMU3ixv/xoufXPzjeihd4rEuogYhXOCJuXrmgPjPfaV5vMDcDmRtQnOjzYonxnVVClkgUZUS0CvTPnwndQabt0a7nmOtoAnlW0FKup9E8/cZzp8J7A++yIkWzEHLxnLTdrMMZWG8PZiXA8VB9G+41qP80N5qVTdopeitjiqykrWy18bYpOsGHVtqAzBmuq6yXfHOw2LzMqEc0RzgMLN/lRUZGSYjG9ACC1pqYy+MOnbdDY2KRpQuhOYoutG3Z5+grHhkaEQ0tbu1WLNln/bOxrWiSU+c0kRPG0oBTJ7Gr3ohdFjrUocxC9W2iDC7uwz1B7tuvO7eVW0rE6MJ1xUjL/vJWbBm7zZn6wVE69eIyVzxwwspu8/dwsvzyoJm8ue5+hzhQHQlsgeC9bBB080sUrtmrhOOTT+5Os3DQtmIOwVn+AkEH9Oy0ViIMXa/XiTa26hVQPusW8UeTkr1xQImUVlUHjGUbP1a2Vu+SaU061dsOLnOvdOyokOjp40gAcE3/m/UdfbtstaiD+cDkYzrA7n4AX1ib7nw2hAArHbijapmvPZueAvSlOXOokVM+RxiY9R7r2tOdDREs3ON+qqmpk1/bgeLlg05dVVsqoo+11k4DtigvXYEp7DELSIdBTOA+tAwJ9hREtpVv3WCkmhlDu1E4JKiDbW6URnuyu3Ts7EsaNSuTo4btvSzgIpDJsevM2+F2g6+XFqG4y6yP/FO3D/PYdnmfNgFz05VpZu3yrz/1sW3q0Z+babSF1y4PnqPAJls0YeeDogT58or3Krzu2lGlkTVQMs4VaUkVQRMsmaEcZxQsSn8BFX3Y3u3fzG9dsDzmPC1KscOYhLNamQEenEXTzwLsWTKG4hPh8jpszHJ2AunbvZO0zsT/95PdnaEppsIRvYy9HEenRx/a19pllu6qkDCHu3HucJAVqL43z0MpD2RyMOJTnfVEkx50z3PHPQyh31x6d9aY+Kr19Ah05PQNGddcKy/4GIaaYl+9UJG8WWThjtUx2IOIA/cD9oqfDcCvYqHNji6LFm2TPzkpJTuvsU7tuzRvNSNTLGlvAQ3Tk5EF86Q/DlvWe8F2bz8a9FyTNEhMTpWvHnjHXJOW7q7RWAvHBqDPPqHO23dqwWzbsCrl5RL0DGPMlRdtl+JG97Flu6fGSbs6CndvKjZEczQVNQlCgN+kZ0tlioVd00TjyVNo7hwNpj5V7qrUQNHGMNMwuPeitJDIqXIsyLJ6zzsrnIQ+9W58s7YHdLqPM2wLKqcq9m9aVSllp5XeMZOSjw1PsRJExRAKgwifaj7WHFvHbzWLY54IZa/QA8nVa6uvRRiNR244Qd4EUDoS580bZI/6iYiPV+2ELpGIggicykgL98OeAp++6rVaSLezYsicE51IkKipCq7nbBK0EUzsn+rV4LCGuEujmHEGnhOR0Xnq7jbXLNntsfYa4O0kKrMlUzkPrD+UUs2l8/UWRtlaywdDxBdLUboHrKd40xPxdToB2M/rC7vc1scmWoB3NAv+3o0Gl6F6Dukr5rvY9Bxj3EPuFQ7paeZ7IV15l5ism3nfvR0Ndg1beT0yJ40voMpZ8VaxtWZpZtMnTgz46UsN/bYECjygMyAruhwdh0YnJsT6n1vgDXICihWUoVv3FmkPkmE2Q6oSLWn91MCHEbWBtaypHHNPG3Ma6lds89V5YJM5JUulBbyPRZtPYVFxqROdGK583YHR3iTWHckuRt7ZteE2SnB7vWKXHFfNKDnijhpz0rSW7Ze2yLY58LnL04aVvj4cenghEFtgyIOdPXy3btV+87ykLMKxRNIW4z5DAZUt760OECngNcXDbvF1HRBNaOrKCu2/7CKIbvpOK5CDlZdUaYRKKBh06N5Ruth8dgItvFNIiJBRBiDvaGtNL6y5w1q6cX0JHkfOoB53xI20AQg5tlWZ/YqcHKqqVo7o4QjnbCnJGeg7IkS4OFN1ALtzm9aUH3kzDPGkBK+aXODI3Q8YVGOEa02ZjBSG58H4OHNPd2vpZ+lWxlO+ubtXho4Z1PPMN3QaqviK9A14t4lHo8CraDPdHQSEMtob2YR8x+yTEeazFvQTFSetDtMJ+hFnrFeU1up9bFeiJMdLUQIFOQnefiqdDwnWgIOa6FVus1pjpoCTAguI1SBtApW94a5bMXmfl8xJT47QKemU7QupRIM4p7zn6n+/cUi7RB6pi3ewpNgZRikrp/qbPsFzNx2truJ8n1ylGBo8tsPIsIbQXm3WDStet+p5G+MQmUKC7jYWz1nr6OzMUr+V11/0xjO3OXEmTCvRoqwId4ZCooRGKawJRAYjeKNtZafVzY+PoQSehvE81q+OFuIsZHyyVit3VDG93njgK9HaAfOBlX693JLf6QPQe3FW9dG0Jc4d4TTIiv3CQMznW61ZsVS961EFCthH+i37l8DT6G+QpFQ7O1QuItlBdWSvd+2RJjqW2Q5grVHBvTYiQhg0b4zaWHnR3iVHzYL78eJkn9YB6VAmTb1q/WBNJ5t2A154lAHxYs+a5RERGWI1wwMUsLiZDMcIBF/V1NZ4ce5ugGGsYQ0ZICJ+tMXG0d9zG3CkrVYNw67Ej0FkSuq0HZFSEVJTVaDVuGwxGKHdynDF0Wu8pRnhhelaSY2HcyC+PiAo/6EsLgQ4Pw5I5xY58ft9heW0L/zffF6GJiCywJX7nTV2llwkRrcqXbVbvE6uEu4tFX66T5V9v8FTWpzr0vlNh6v1otBh+G2H24sioSKuXAkFr+IonRctmvj6eS3NLG5GQE+hhegGBIoVW7Q9zFoSFCwtTkpAV6LR33AUiP+fPWK21rIjjxFOg+2EDsZWHjirjmbmp2q+7tSDEMK9nhlY99zcQm4giSEw+uEcY81RRVi2rF29yZG6QW4+CIq1tOwMRgfzzngNzrK0bFIhrwCVLK23VcCN8UIWfuIdP/vO1XjzRkPiWPtdK7jYFOiKLkGLQxJBfn8RyeKTdyz719IaF7nrHWscluE0Qrea5ZKFCJ6FoXwsLxLnN3vnvPO2YFM16O9YEOi3LdhqGqxZttNJmBW1x+o/IV6HbmvASGEeV5TUybGKhIyFxW0t2aUX7w+XgIud61SJnBPrA0d0lB/3Qq1rnRUdoYuecFBl6RE8r6wW5yvC4xrU2l7zZ8xwpBN0DWgd+9Mpc9qU/wH7TWN8odbX2PIqIfolPiGFOru9PyeqnIcIBXvvmUHT3ImKkqcl6yzPPXFKck9BV6BHMc3aVvfPZ6/O1xTQj1awQToHeTlBJdePaUlk0a62Vz0MoN7yvrclDx++HeMafdYKlc4ulprLusBV6E5LiZM3SzbJxjf8vM1AkLq8ws9VGEkREbkGG5PXKtPL8UPF7fdG21rdLC/MUiauvb+BL5xJef2q6bN+yp9XF/kL/VAmXWs3JrbX2mdjfUEiTfaF92ErMPt1kzgSbEQ7R0RESGRkRmgLdoyWs/2wNdS12AJNBSQjuU2Fh3M9dxDv//FJrSMWxertVgc4qDO0AN3w4HudPt5OHjkru8PjC8+srKF6Tb8SrUwIdHmEUWjtcTiPClfbsrJSiJc540YeM66Eh7r4GCeAAqK6sk8Hmz9lq//P1F6v2iphWG4FNdvN6yaHW/Hp567mZvE0+0KkSEaa9Uisr7BbNQl5cXS0vsA6/73lCsm2mA6DYE0KyQ/Vd8RQptOvrgHhpZrEmErIblbSp3hLxP2uXb5F3np+lhbHD6dK1RTSnup3g1hy5zwtmrLbSB7Xf8HztY46+sr5SW12vOdrwMjv18qIq8OEu8vE/IwR1/tQiR74HwtxROMfX6AKEJYZ5/5wNao1oQYGN+MTYVntbwsz/4c/UU4C4gifveV/KSivpPT+gWAnXtV65x65A75SVrJduLJp1OIEeJg0NTVaN38SUWI1yCMUUBK2Kb8R5dLTd+iAq0LnWSQjvU/X0oLuCR3/xpuzYXKbtiLnnWLSlOAXtB56BbSW7ZcFM573o8EL3GtilVYYO8paHjHcmx7p4xVat4O5Ty7Awz4XG6qWbHfkuCHHHqPaxmjtCcBFZ0HtIrpV1gjSITWtLtW5B608rT792ePxJYHn69+/L9P8tkcyuqfSeH2S/gTjftb3C6ufmFnTWXHRcvJFDHPpGTCLiqbrK3l4Cww4jFIv4abFYcy6j2KhNaqrqWZOEhPQ+1abOPMSvvPDAx/LFO4ukU3ZKyKYoUaCHMMitK99dJfOnFVn5vCFHFGhbF18KvsEggmE07Mhezgj0Vdv0Zs1X4wTfZUPRdkfy0OFB69EvRwvi+QKMVKQMQGhZEehfrtVe8W015CIiwjTXnwSOd1/4Up763fuSkhZvtU1VsAn06qpa2b2j3Orn5vfOlNi4KF6aHHYfCdcIrJoqu3tJWufEkPS+YL1FGYFuu2dzlTm/WESLhKw4CQ+TKstRWOTbvP/ibHnsrnc0+pZ7DQV6cGJ0cmxCtCycscZKUYvCQblaOdqXzyovq1aPe4++2Y58l4Uz13hy73w0vFC9vMSI8zXLnPGi9x7cVaMMDmukN7dEFhRYWybzp632FNhoY84g0ghglJHA8PIjU+Q3V7ygKQrw1PI2+VAiMEIvo2yCPS7R7Ius03C4fSRco4eqK+wK9Oz8tJCcz0Zz1iB8Pyk1zurnIlIsnB50ErJnSLhUGIHOczYwvPK3L+R3176kexvsdj6HwAj0ek5D+4FgLlq8SVuuOQ3yyQv652i7NV8O8QGjujvWT3LFvA2tulnTYmzmRV85v8SR74NIAQ2lPIxARxgsft/Io3pbWR9rl23WXvFqxLVxn9Mie7sqW93rnbSPzcU75ZeXPCsP3faaFiJLTI5tVReFjgiiRJD2Y5O0jCQV6dW8xDqMQI/QKKPKPdVWP7drj84haeQhSg0XdigYaQtEP+zZVaWee0JCcp+K8lzyooYSsQcqtd91+fPywM2vqjBPSomjvRMY6hFrS2vfHzcdRnji0Pzqs5VayM1JINQg0hceJucdHvaE5DjpP7KbI98DfRHhDW9NyDbsMwjjxXPWOfKduvXO0lD30q17jCF68JBDGKi9BnWVfPP7bTDrw2WaBtGeQn0wxlCYrNwYZulZSXzpHDa6l35VLJ+8Nl/e/9cc2b29XDrlpOhlFA+rw4M6C9gbaqrrJNZi6G+/4XnmmX1txHoii9kcBGRGYX1jj7QJWlmGYvoB5jIpLV49TbZAQdqyHRWOXbwTEnCBbs5a2Ey4cMUFGHEO1LRaMb9EPv7P1/Lhy1/J9o1l0jknWS9zae8E7rFAWTEe0G+Wj8jcz1fJxTcf57whOiJfhQOMg4O1d0HLIeRXO5V/vmROsWwuLlVB3CqhGR2heejbN5dJhhE9/gSGeV9jpP/vpa807eBg3mqE/g8a00NzVm3w9dQiDb0Na0dPHBQj3Lm1XHYbw8yWQIe3HpEa+rVDpJ8Pfgp48nAoNTU2az0HGAE7tuyRktU7ZPXijbJq4UY9sJBSgNzZjNxUXUsM8/KNaLNWt5bs0sskmwK999BcSUyO03VL8XKIdyA8zOy/dgV6Vl6qnhXoRIG9LGQEujFgs3Pthu+X7ayUXeYcCKV5JGRf4PRCNxCcy4iOsqKIjI2GKMWwEKovs6+9gwtS6ALYO6VmXlELqiXyd/m8DdqSGXOdmeepy0R7J7BHC3b3Ks6Df4hPjDELvUTWLN2sIehOMnhsgSQkx+pLd0CBbt5KVMCceGq+ilYnwIsNQxg5ja15j6NiolRoLjUCf9Lpg/3+vfoMzZO3n53luXo6gKZEZEFSSrwR6N2trIvilVtl6Vfrfat0fwgivSFfGAUDcqx8d/Sz/sUFT2uYd6LlHEtnDyyzDhoa9UBG5AveFbSdUsFu1gdu75GOkKqFrZrbnJbQYY0rVAo3c4oikhldUq197oiJhRpFs2H1dm1/SQ7yDoSFyZYNO61+Jp4LCvmhm0VqTGLIzCUuybsWdLb6mTgDsG/Rs0hC+wypk83rdkrhoK5WPhMRX3df/k8pWbPdUy8oxOwd2DcQ5/vaO7CHMdcIZU/tRHvHRVRBoFdzHvwDQrc3ri3V0FinBXpOt3TJLciQVQtLJOpA/Veb0f+8ToZPKnRGuNU2yJI56zT3vrWXbPCgb9+0W1Yv2eSIQEdRvLTMRKmra1BP3ndFZ4Nk5ToXWbA/uIiAN7FL93S/hN2WrN0uI4+2kzuPSyB85fVF2yQ9M0TC6ps9pxZECkZ4RJgaui0BAvtGOfAGue3GFaJUVny9QUZO6m3tc+OTYrXwY9HijRKWnsDndwijbf3KbdY/t3vfbJk7ZVUIXXR4LnzRrtMmG4q2fWsvIyTUgOMH3myIZVskmPMj0tinKGLc2shQ2jvEz1RToPv5sI6JjdQ89MmXjHX0s/CCIdd97ucr1dO3/3uFftnZeenSf4Qz+edb1u+U9au2tTnvDjmqCCN2AoT/Z3ZN02IX+wt0PCOELfcdnm8tbAo9s/Hz+mvvK15h17AeMraHLJi+Wi+gCPFJoIeHSV11vaxdvsX6Zx979jB57alpWggyLIzq5YDPJyJcQxwRIRMday93GgVL3/3nl4dMzQomEEGG/POcbp2sfm7xym2e3FAubxLKZ0hNg2zZsMvq5yJF8tPX59PeIQEX6OEU6P4DAgw3cEvnFmsIt9MUDuqiYc8HaitUVVEjvYd01T7fTjBvapGU76qWyDa2eUG4NAT69k1lfv9uCCVHEb2G+oYDPiNEFow6uo+VNQHP+bK56yUm3n9G8NpldkVP/9HdNRSKWoe0BqT8rDMCHWGDNhk+sVAGjyuQXdsr+BAOAgp77tperqkAdp9NL00bsdGO1AYIFc3vlSE9+mVZ/VwUaKW3i4Q6cESVWN6jEP0Kp1eo7FEkuAV6JefBf6Boy7aNZTL3C+fD+PqqpzhVC2kcSIgOO7LQsc+G6Kyuqm2zFwRh+cijQ362E8BAR3uO/T1oyL+Bt6P/yHwr62H2pys07SHOT7mCSA/YumGn1R7TPQd0kczcVKmpYrsT4jtIj1izdIsR6Vutf/axZw3TgjgUMQcT6FHmnNpt/bIvJx9RXfmyZ3dVSEQ34LIXYfs2vW3Y+1ETJJoF4kiIE58Uo6k4cHTYAvWd1K5mezcSWCqgrso4D/4DHm1UvUYhHOeFU46KTYQB7QtC39C/cNyJ/Rz5XIjc5fM3SHxibJv/DthmyGNfMGO1I98ReegxcdFaCGNfqsprpe/QPMdrBLQwf9pqLeSHdhX+ADfKCPlCjq0tcgs6azoF+u4S4itY8/Aw2tgL92fyxWOke79sbUfFMPcDnFOR4RrZYNuDDsYc30/PLKQgBDO4/MFF88DRPax+LorQIsWMBeJIqINLKNQrwoWULTK6pEjhwK66P/LoIAFkDwT6bs6Df0F4DIRn5Z4aRz8Hhic8wfX7heKgVzYEVe/BuY58LrwuGInJse367gghWrnAGaFZOKSr9DAG+oGewahj7YS379hcZgR6kbcns388eTAId5dWyJoldj1fo47p463WT48k8V3AYM18NWWF9c/+f/bOA06q6uz/z/TtvbPLwlKWDlZU7MZubIlGk+ib9k8xGtN73sTkjSYm0WgsMcZo7Ni7iEgRRZDe2WWBXRa29zp9/uf33BkYysLu7Nwpu883nxsQlrl3zj333PN7KorFXf21M1igI99ZOPzeIB0rkSrW74v4uc+4eBqNK8+n3m57XI8hUsvQKWBuhN4nAVD7pUO9449aHFYQRhDYJ8LBsV7toyLJ2VfOYg+67HaEKNIhHnQdQB46XqK7ttTpfi708uZcGcPBTTH6OqOSsV5sXLGbiwsZTMMzL8LLj3HSI1cUvZAh0O1BYUrYUCH3/dTzI7Oh+vSDCu71Hu6NVFJyAncKiCSotp9fnClhX8KQQHFEGOHq9rRG/Nwo1DlnXhn3i0bfb+HI9RfvKBSLiyQIHz3twqlsPI3X+wLhwIbwk0upJMIV3Lesqg5bypQgxDoej49TKiPJyedO5s4MPZ12uQFCtGAPeruMQ5hf3mrTgbzwFe9t0/1cEKE5BWkHwtzdLs2qf+r5U3Q757rlVVru+TDNiygiBYGOkD09KJ9TzDnb7PU1HIwsiFR4O/LPIWiNYd6EJqZYqWJDLX+fiG6qL5pKrY3dEjIcjjVilHxPziFUz/gGnVJZjre+3PzjC8nlcLPRUjgUpGO1NXfT1tU1ET/3lV85nRISrWzojU/R4OU2nqdfODWi5+3rtvPan5AsAl0YHSQkWmj31vqI5qEjzH3epdOpt7NfwtyFaNEuHnTdNuAG2vTJbt3PA7GJo6dDK8Zv73OwaNerCBryn9G/PBwFapCjCgG7c7M+Ye4nnDmR28AhJx8FozweT8R6n2OcNnxcRanpiWH/bKvNol5WHbR6SWRDhy+98RTKzEnm4oDCMNYGo4HTUo7WfUEvDmQmRHizYTQaea34+N2tURnrc6+azZ70JvW8iBf9MIGu1t/ujj7d6oAci/ITSui8a+ZwwbN43ABDKCNM/5wrZ0f0vBvVngJCRQrECaMFFButrmikrZ9G1pB4zTfmUWZeKjng/JJXhxAlgd4m46DDopKeQFVb6iISmoNicV7/DhyFvBA+qFdv262fVtP+3S3snRq+aPBxoRu9ikgVT8ilonHZbARwOTyUlZfG+Y8R2UipTS/6sMODGG6Q14sNYiQMQMHMPG08b6o7mnvCHhUw2kBedCQFutFk0IRQhJPq8IyjT/Tmlbu55Vo0uO3Oq2jyrDHcVkxEehAGregkUpYQZRBprr/lbMrMTdXSZuLotmAOwbBxzmdnUU5hWkTPjfamXW19ZLGIQBdGB9hrYM8TaYcEutecDyNiYxdJMroQBdog0FtkHMIPwnJQJCwSAn3W6RM419Pe56SM7BSaM08/L/HWNTUsLMJVlRxhlti461FQD6H+k2cX82YKlefRE36iTn3hD2fZG5vUJspEetVUQy79mqU7qbMtsl0SETKclpVMPcgfFa0zLNzuyPVZhbc0WuIU3j5EfCx5bWNUzg8vyO13X0tety+u8571IC0jiXZu2kcVGyNfLG76KePooutPpOa6+AriwxyCYQFh+pEEXU9QLCsRxnGZwsIogQtapiXQho93RXy/c913zqa84kzuzCSpfUKEaYVAR/UeSdDTYVGB93Tlou0R2OiM5crx8J5DkJ54tj4C3d7rpA3Lqyg1MzFs1bxtCWbeoO1Yr48hIyDIOzt76YxLpoXct30o7NvdwpEGNh0L+aAQYXVFQ8Srm6Jwypd/cAF1tPSQFHQPEYPmWXa7IifQURDMZIxOFX54QJBqsuzNTSwyogGiim6762pqberSClzKZku7NyYD35Mlr26Iyvlv+tGFVDa9kKNy4sFwohWH66GrvnYGlZbnR/Tc21bX0M5N+/ldLwijCUT6oJbJR29vieh5kT76xe+dR+3qmY/3tpBCXIHNYVtAoHfJeOiwqCRaqWpzHecj60l+SRZ7h7scvbwR1YvKzftpf3Ur2WzhC5+32Mych1i1RZ9CcdNOLuV+7ZnZqXTiWZMict/XLKmk/Xtaw5IGcCygtZZGwSv51Z9fzKkC6E8qQicUfW7gmgiIeIkUaDuGTY7XE3mBjnmanpXM4mLp6xujNu433HYufe3nl3DVckQvyNzV7g3W4E8/2MFpM5EGxSdv+f1n2UgQKHQa0+K8rZcmzhhDX/npRRE///svruV0AJm3wmgDIe4waK9atCPi5/7SDy6gc66YRU37OyS1T4gUCCtjD3ojSSV3XUAeOB7qNTrnzmDRKJtayBv/sy6fodt51i6t5MrhZqspbJ8Jr4nJZKQqnQrFIaIA/drREx5V3SPByve386YXBbL0JDnFxi8svargH4vv330tZRekc16vvLSGrNC5CnS3v7BjJIA4R75sJMPqjxSDPnrnmU+jOvTfu+tquvabZ1HD3jau7C7h7sSFLCs37adVH1RE5fznX3sCh5I2q3dl4PmIPXGuhZgjVeprv7yEUtIj68Vub+qm1YsrOBJFEOKJsARtqc/IykulNUsruGBcpPnp/V+gwrFZ7EyS/Y4QAVAbrh4KAmbrVhmP8GO2GNlLtuXTat3PlV2QSmecPZ096XqB74HFKaybWrXwImR+x7paDtHXQ5iMn1ZIp104JSL3HGFYW1btofTMJN3DieEVRXTG0tc3RXxuY5798uEbWeR0dfSJ0BmaPmeB3hXBfDo8t2PG50S1rRW86Kve3x4VL0gwv3jwBvrS9y+g/bUtnLYz2j2SqCeCMVg4f03UruHH915Hp108leprWtnQHIsio35fK13z9Xl00fUnRfz8y9/eQru21VNqRpIsoEKc7YNNYdkLwTEEgfz2U6si/h3GjM+mX/7zi1q7XvXeFpEuRECgewIuvr0yHvq81DNykrnaNnJ29eTkcydzWwjdhGdlExe8S89ODntFS24btr+dq8PrwRU3zY1YezWE8OIlEs4og4Hnl48y1P1Y/Op6ruwbaeZdMp1+95+bydnvluJbQ1LoBg41j6QHHcCo4rBHr2K2xd8a6oWHlkX9Fvzons/T9++8ljdbKAA0mjdcgXVk7Yc7aZNOHTUGw/8++mWacsJYaqxtj6m1BHMDRQ5PObucI4eicX8WPL+aEpNtEt4uxB2I+giLs8IHh4uNlry2gfdYkWbuBVPo1498iduu4d0t+x1BR2r53eP/jxoZD31AHnpddRtVbtyv63kQyn3xDSfr9vnov8rh7ZbwC08sdIg00Kvd2gWfO4Fmzh0fkfv96QcV/H0itZGCFx25ve9Fyft1yY2n0C8euoEc/U42QolleVD6nPPpuH1LBCmfU8KtBh190fGiI+8+IyeFQ3WjVZQsmK/94hL63eM3k8Vq4kgUbCJHq/6B8aSzpZfeU0IwWuQXZ9Kf53+DSibmaiIdNyPK9yMgzkvL8+j/nvqqVkE9wqAjyJZV1VwczieVOYV4E+gJFl77wwGiLdH1Z+H8tVH5Lhd/4WS64z83ceSg7HcEHakJFujVMh46bcbVA4yw0o/f1bf6JDYzeojnACsXbtNtc4BFDsVvKjbW6vL5GBc9xyYAIgw2r9rD3qhIgfx9WKjfeOKTiBYdC+aKm0+ju577BofKBgoixqOnB5es9Sf36CrUMDYQ6E2BnNsIMf2UUpp60lhuOxit22Oxmjm8//kHlsaE2Lj0xlPo4UW308y542jfnhbq7XbE1dzFtWIcEQVQv7eN+nocvCaEQkZuCi16aT3VVDZG7fuMKcuhf7zzXZo4s4j2q/vh8/iicz8M2oGOHEXjsujPz3+DCsZmRmVMXn98BQsCPDuCEI41I5Ig6pLrfRjC81gmpybSW0+tpO7O/qiM30VKpP/lpW9SYpKNiybDsx/v+x1p2xhzVAcL9CoZD/1AK5ttSrzFq/Ubomv7+lpdC9Sgb/ye7Q0s1OOVxa9uYE9yuHrED4ZAeCp6Gb/y6EdR++4oTvifD3/IkQp16qXliLdWVupSIc4QOocQNq/OwgBVaVujEKZ32ZdOJa/XR74odYzBfEWxH/S0nf/Aspi49Siw+e9lP6If3v05NuQhDxoGlFifvniddLT2UMPediqZmEc/+fv1NGFaIbW3hNayDJ4uFH2c/8DSqH6vwtJs+sfbt9L518yhfdUtvKZGci3BubxuL9XtaeVe7Q+99z1utxQN4D1fu3QnZeWnifdcCAsQZZEEtU/4nROOKHfULMpIpB1qP/rG459EbQzRLelfS75PJ541kQ2JcI7Em0jn/U5zD9nVnhvrnaTPxBQ7ggV6vYyHfqCwC6qUb45ift9wQNGz2p3NlJyWoNs5ktMSuTrnrm3xORWxQCN0F/n0kd5I+XxaMbxXHv04KrlZAcYroXP/29+lr//yEh6Pxn3t5MHCH6NhYAHvY0drL4fUol7ET++/nlsoITfZo+NGBmII7b46I1goLiDQUa8CNR+iGZ6HFoTP/WMJj3uscPNPLqR/LrqdLvvyXPZEN+3r4MrdsRTGiDlrV4K1ua6TxfTEGUVKmF/HIvIL3z2HbvzeeWzkdIXQbx7PAgr5vTd/LW+AowmMOH+a/w265Y7PUl+vk1oaOg98fz3BvcYz2VzfRZ+9+TR6eOH3qGBsVtTG4YWHlvI6JKG0wvAXD+0Zh/ExksC4lVOYHrYIP6PJyJ0n3nh8he61nY5F6eR8Xnf/3/9ezs/ogf2OIcb3O2rMEL2XlpnE7w6kevWrNdbjkT7vMURjsECvU0eDjIk+IDQNFcojUc1dD1YvqeANgp5tw+C5QuGN3XEq0FGZunLjPkpJT4jK+dMyk3nsnrt/SVTHAcLrlj9cSf9a/AM6/aJp1NrYdUDoxMpLCtZ8FmBKpEIgjp+ST7f/6Rp6fPlP6JpvnEk3/egzNPO08SyA9HrX2hKtVF/TRvXVkW+g8f2/XEs5BekcGTNc4wnGB4IQRQKHQqraHOzb1Uz/+sM7MfUcj59SQHc8fjM98M6t9JnrTuQq7whzRgi5Jwq90wNhiGjv1d7cw9diVH943tWz6c5nvsbP2RduPffAunPeNXNo3qXTeRMWyrXi+UV3gaf++n7U7wVC9b+pNr//eOu7NO2kUvXdmzk6AOMRzvsQ+CiM8d6qJkpOTaDfPnYT1yfQ0yh9PJC2tPL9HZSZmyKbKCEswJjvdEb2XYz2tlNOHMs1jMJhrIfIhNMLzpyn7/0gquOJfet37riCHlxwG515+Qxqru9k8evkCMJY2O9Q0H6ng/c7Yyfn0a1/vIoe/+jHdO3/O5O+/IMLaPYZZewwkMJ3MSPOWQiZJmeejV9RAvp6dYyRsdEHWNYQNnvpF0+Jq+uGN+GxPy6ISA6c0+6mtKwkOvuKmXF3f5/9+we0dXUNpWdFZzOFhdhsMVPF+lquWI+CS9EkpyCNC8jNPHU854rtrWyktqYeMpuN6jBprZQi9C7ACx0vKbw08RLq67FTbmE6zbtsBhsTvv27z/KYBadwJKcn0tLXNrKQ1uNFyyHu6mV+2kXTaPzUgojem+z8NJp1xgRasWArpyNAlBkHmbeMDR6Pp1rL+rrt1FzXRSlKxGTlpyoRayerzTy4UEb1M6hKjQ4XiLyIVgjxQOD5QX/uc66cxYKNQ8nV5gYiGSksGC8Dhd+ji7FFQSWPV4nyHniOu9jzlJmTwjUEvnj7+Txnr/3mmTSuPP+o9w2b18WvrOf5PNTrC0Tj7NhQy8YK3JtoAw/2pV86lcaU5XKnj9qqZupXY4IoFK4jF+I9CMxlGJcQkZCuxvi675zDnSlmn14W1e+Mjf6fb53PqUJ4ToYLPGQYx8u/PDdi3wHPyjvPfMrjjPUu2vSq9Qq1JrDmRoo1Sys5nScpNQYq8KsbAXGOauQTZ0Z2q59TmEYLntMK2SLKMBxY1X5044rddPpFU9lDH9X9jjo/Cshh3cD+Yu/OZo7CgYAPtLGM3G3W3iFYOxBR2aPWt2y1HztT7Xe+pfY6EOcIzcc6HyAtK5nef2Et7/GNpug/q6Oc7eq4jw1AQX+IVmunytjoAzZLe3Y0cBg3NlbxAqqS8yY+Vf/qtXiJ795azyFYkSjqFjZz1752blGECtXRyhPEaSG0mus66Ik/L6S/vfKtmBib09TLEwdepKjcveqDHVqOer+L73eKEsJWW/gNPwjxxSY+cB68jCDKz7piJp1w5kQ69fxyyi8Z2Ihxzmdn0oy54zm9A8Wzwt1aEJ+HOV6phBBybSMNNqqPLv0hPfSbN+iThdv5RR4YJzagGA0HxaLby88koiCwz8BaBnEEUT173gTuklA8PoduueR+FlCD7dWMzQDO98gdb9MstbHJLUqPuWcb3/G2u66mr/z8Yk5hWas23CgEic4cyI3GmKAKPAw5mMdDWbcwtm63R81VjK2LPwv3QBtfKxtupp44lgv7zVD3CyGVg+GMi6fx3EVKVSjeV9wXfI/H715IZ1wy/ZCNXLTAGF/11dPpws+fQEte20gfvLyetqyupt42O0c2QMTy3D3G+GPuYi4j57K/x8HzG/8GVeO/9IML6JIbTqbiCbkxMe8QwbB7ex0VlGRJ7rkQHqLU3hOccl453X73NfTgr17nCJ2UjEQW2Bx2fdhGJiBqjzfvE5OtHJn6yO/foXte/VZMhJbP/cwUPhAtu+ildfSpemfU+XPU8Z1gzLYmhL+WExxoiPay+2sg4R2C/Q68+nPOmMB7sGM5bfDOOPGcSbTho10SsRN9qgO/Cd4ZS6s1XQW6lcNL1ikhF08Cff1HVWx5hmdbb7BwwUtVtaWOppxQEjdjtPT1TVSvNuyZealRvQ680LIL0mn525vp+X8soRtuOy9mxgghVDj6uh20bvlOfnGhsF31jkY2cCCFImBp5nQKk5GLK+K/tePgdwz24nq9XhY6OOAlRx4V/i4zN5UmTC9UG9xMmjSrWInyCTRhxhguMDO4vYyBC9+tX16lVZLWIfQLG5Gta/ZG7Z4Ujcvm1lGI/Pjg5XXcChIpCT1d/eR2evh+QKzB8IOQ9IzsFCoszeJxLVfP5/jyAjJbDwqia79xJv3thy/525UZBjVfkfO8Z3s93X37fPrLi9+M2WccOY8wpOCA4WeXWqPQ+qpqy36qq2njaAiMHQwd+F5IBzIYiIImbsAuw7/H3MXYwZiROyadc67RAq+4LEfN1zHcs75IjXWomzlsuOC5w3Mx1LmrFZ5MoW1qXjz6h3fYQBEroK3k5TfN5QPviVXvb6fNajNcu7OJ3x2IONDSsQyHjD2Gn4W8msvYqBaeUkrls4vplPPL2chkS7DEzHdEZAsKYGXnp/NXEH0uhEmf8zPQ1hydOjU3qv3IhOlF9PIjy7lVGjy7MJgFL0+Y6zAGczqlkY5pGMf7Hp5hFFJEah+ii2KFGaeO4wNRZliHkQKJdrjokIF1CutTwBAerv3OuKkFVDg2i/c7s+eVcVvVlCGk6ODdtmZJxYFcdSG2BPomGRf9MJm0SQ/vC/I+4gGEqK1jz3Bk2oahkjvEWuWGfXEl0LGhOniPo3stWOzhlcbG+tTPTOEK1bEEIjEQaoUDLxh4XPHSqqls4hzTxtoOtrAjHxTebw+3AfG3PmMRb+SXN3sa1aYaAgYCEi9qiPG8MRlUoIQNKscWlWYPq/MAwptfeHAZG6j08CIi1A/CAiG78OJFC4RO4wDIXYZXgjdJatMArzBCvGHYOF7oG1IakDeLPN6UtMEZQjAHIJjQ3us/dy3ggjWxTqKaC4ENGG+i1HfAprelHkX/etQY9nLOOrwmSNvBHIahw2Iz8aYMzwBaD2GMkOOMlIOsMBv3ECnywkPLOK0jFJGPdxXqFDzz98XsWZl3yfSYuw8okIcDwKiEtQT3ACK9p7OP1w+sx1gDMIfhGUKUBuZbtENiBwLezft+/iq51ZzR0kVkoyyES6AbyOX0UPO+jqhdAyLXcCB1sr2pm9/tATWKX/BcPvbHd3ntGswzijoVWXkp9N+7F3J4+XT/mhw7+50EjkLCgdoZMObyfmdHI7f1hNMOufn9fdp+x+3ysgj3oIuIf5+DmiMmi3+/o9YEGBmxNufzfiedu17A2I5jOPuUuZ+Zqj4vkyPDrDFksByFbD6aQMcfooyfJCDoAN6z8ErA64I8WAiKWAfhvWg1g/yUiLxATNpCHU+V3NH7HOOEzV8s7KW4gIoS6I37O+ju216ge177NgvYWATGBAhTHGdeduh3gEjsVgc2FIHwaliYIXTw0sKvsA7DA6lXfiNEPqzQK97bqotAT0jSIkZgYY+mQA8GaRo4QgFiE0aNB3/9xqAFOs8DtclCjiIE+rgpBVEJ+R/WuqXmMUQ2jlihZEIuh+cjZDHUzRbmZ2+Pie5XgnHi9KJjpoREG8w3PKvl8TV1juD+X7xKuzbXUZFae0ScC+EG78podnoJgMip9AH2lWdfMYvefW71oIyLeEYggrGn/tuPXuKq6rGQkjPQew4RUjiCDZ74DjDMYc/jcmgindOd1M8jygq/WpQwx74O71i90j/HjM+mWWeU0aIX18VkutlokYrq2HpgzgT9BWIt22V89AMPGXKEt3waH+3WPnxrM+e2RCy1R01NeH93rNvLVrx44P0X13I/yUj2Pj8e8ErmFqRz9f2HlFiKN2Dpx8sb+aDIw0XILzy8yMeFxwzFq/CSg5DUu/jQnLMmcCiePoXiTGwt36gE+kjhxLMnsVCFN2DQjz02Wck2Ho+//uDFqLf4GikbcXj44VkOtRgj1pGs3BTas62B7v3JyzKoOvPSI8vptX9/TLljMkScC7oALywKEEIMxirTThnLkXCD7fyCCCa8c2Dovu9nr8blfgctz7CnQVHOwH5nyokl2n5nqrbfQdSV3rWZkPaDdwfWfiEqQIPXHE2go9/Pdhkf/YDH0N7n4tYpsQ7yKZF/i9z5iL5AEi3cfqmhtiPmxwgvuRXvbeNrjrUNFbx6ecUZNP+hZfTSwx/Kwxci4ybns6cenvxww7m+OSm0dvlOriI9EpgzbwKNm5I/5J632BBkqA0Iwv1+fsO/uSWMMDwQlYF3DmooDAesIwtfWMeREYI+IEf1gV++ztFqFptZBkTQBXiXuROC2mPFKij4iIKYQ3nn+khLlZr/4DJ69r7FcqNDBMVIkc6GlEIhKmz2a/EjBDpYK+OjL9YEM4dFD8XDFA0gzpErA492RI0YJiP19jhoaxz0jP9k4TYuFpUa4TEarPizWMzsib7/F68dyJMXhi5y2Jpv1+d5RU4ZcgJR4X6kgJ637hBe8IGiP+gP/7PrH2UjoTAcYZ3JrcOGY1yC3REiH7mOT/71fXr9PytkYMMMalDc+Z1nOZoGxkCfeK8EnUA3hO6OPq59EsugEKlrKP3afVqEKmp5/PN3b9GHb0lJrVAYOzGP63V4PLIGRYlDNoKHC/QKGR99Qc4sKv9uX7c3pq9z+dtbOJzGaIxs6wrk26AFDvrwxjoobBXLfSMh0pPRHk/dwju+/hRtWyONGoYKXvioYI48eD0ItJlZ8vrGkSPQTyjhKvChhFb7uGhcBleW/83NT8R0KGasg7BJpA54PJ5hriNahw2IR6QgoEuEEB5Q1A4RIyiOijomEloq6Lsn0IzCqE0Ry8AbPtR3Lt4dKMCJEO0/fPMZ2vTJbrnhQwTjh6g+j0s86FGi4lgCXdxsERCgqOy7dlllzF5jw942XtxQfCMaodsQvfBMxzIQu5tW7GLxFsv5gtjwoQUHipD8/IbHaNfWenkIhwAqpqK7gJ4WZWzMN3xURR+/OzKWX7R6wTM8nNBqFCRDK74fXP0w9XbZZSKGgOHA/4VhY6/WEURTIXUGxj509xCGBypZ//KLj1HFhn1cPdkrXishApjV2oz9S39v7Nb5Sc9JZqE91L0V1qm0jCRu5/qT6x6lnZv3yw0f4t5b86B7ZTCiw/ZjCXS4cepkjPQDCw5yltctq4rZa4RQqKtujVo1TGwEd2+vpz07GmJ2jJa+sYmroVrjIF8Q7T1QlRMhwz/+3CO0e5uI9MGCFz3yqU06Rklwz1clpF7+1/IRMWZaJfjkoYUoHrJGHhT6mz/ZQ9++8D7aX90qk3GI1O9t41aZ2HSFZR1hY18KF2/66fX/pnXLRaSHvK702OmnSkBsXLGbCsdlSVE4IWKgq0t1RSOtXhy7tZASEq1c0C4UoxXWqZyCNA7lxzMGA5gwOBx2F0et6V18Vzgq0N7rjyXQUamoWsZJ58VHCV+Iz4oYDeNe+f52FiQmkyEq50e/4PamHtpb2RiT49PV1kcfvb2Z0xXIEB9zLvDSQt/N2z/7EFVIpexBgVQU9GhPTNHPWMXF4rJTuE7AktfiP9QdYXI4uMftMClQIn3npn10+xUPUeVG2WgNBXTD6Ou2h7XyLzbMEOkOu1Ntfv/NRTKFoQFD6fcuf4irTueXZGiNdQQhUvsrq4n6ex20clHsCnSIc+SUoy5DqPud3MJ0Lr76k88/QltXi6wZDLu31vMe0SqFKqPBLr8GH1CgAyn5rPfik2ilhto22rwy9tqtVW2po02f7GEvWNSM+ihMZDLQxk9isx3dh29vouodjZScnhBXmyt+aRWlU0uD2iAqwbNmSaU8jMfh/RfXcYi11WbR9TzYjKDNGApxDba9zGgAxgsUO6uvaWVPuuQ/Dw54QRDlg9Y8YV9HlEjPyktjb8vPvvBvWvDcahnwQVJb1US3XvoArf+oiotPiuNciPyaSpz29smCrZzOGJN7FY+Xw9UNw+hvykVH81OptbGbbr3sAfpYCuUel/fmr6H2lvBFXQlD4qPD/+BoAv1jGSd9QUQrRPq65bEX5v7BS+uoqyP6IS4oTlcZo6FJ77+w7oAhId7ASytPifT+Pgf98Np/0ltPrpQHcgAQSbLoxbWUpV7yeoegYjOCgnToXvCvO96O63FD6kdbU0/Y2kX5/NEf8Mj/+HP/ov/86T2ZnMfhhQeXUdXm/ZSUkqDbBho90uGN+93XnqL/3LVABv04rFlaSd+58H6qqWikMeNzZECEqIE0y7qaNnrjiU9i8vpQnwF1c2C0Hu5+J/Du+OWNj9Erj34kN38AENHz7rOrud2pEBVWDEago4qcS8ZKx824j7jXIEIQUb01VkA7HoQ9mWMg/wRVg/fvaeGe6LEE2s+hQFJaVlLczj/OJc1JIavVTL//f0/TP37xmvS9PAx4IB/81ev8TOjtPQ8AZ0GmEukvPrwsrkOHEYWD/L+whlb7+6Tj+Odv32ShLr3SB16jnn9gKaVlJrMxWM91BPVC4KVHj/Tffe1Jqbo/AC89spx+cNXDbPxGFJPknAvRBs/uG0+spIba9pi7tsqN+zmK0hCGFMID+x21p7z7tvn0tx+9pFtXlngFtUruUePi6HOy8UaIOJiQOwcj0PFD0g9dZyxq84rQm7XLYqfQzpqlFVzdE72zo01ikpX7Ie+IMS/6gufXcNEwLPbxDF5aSWkJHKr6xJ8X0q2XPUj7d7fIg6lAfh76cKO4DPJtI7WZxmlQMR735q5bnqN9cXo/Fr+yQRejBsYFkUcIDV76xkb6yhl/oaUjqD1dONi/p5V+q4Syvd9JiclW3UOoEd2AfFHUCnjryVX0zfPupe1rpZ1jgJ7OfvrN//yXn2fMXQgFaaUmxIRAV+//hr2t9J87Yyv6BRXEV6u9aGKyLazvDnweDOBP3bOIvnvJP2hvZZNMAgXeFVob3r2UlZ8m61N0QChrxWAEOpBEP51B72wIvVgKc184fy1bLGOhrzdC7J0OV0xVHIc3H2HP8Bj5RsAihu+AYiCoIoyogK/M+8uoD3lHAacfXvMIffpBBbf6ivTLiq39ahOByJrffvVJDvWLJ95/YS198t42SstM1MmIoeUlFpVmU2+3nXOgMU6oqzDaqalspB9e/TAX+clWcyhScxf3BAVFsY7UVjXTN8//O6chhFrFf6SwYsE2+p/T76YFz37KfZ1ROFE2v1HGYJAxCHrX5BRm0OuPr6BFL62Lmeta9vpG2ra6hqvNh3udQm51SVkuh3N/49x76LXHVozqOYBItx9f+wgXqC0szSKpWBk1jlogYSAl9oGMl/5gAcJChKrgsSA+ERqZnJYYE+F3uISUNC0NIFY2NSi6FM32c3oKngIlRpGn9X/ffpb7pWOjPdrAXLvtsgf5ORhTFr0cURhOCkqyOB/9l1/8D1fijgfgvX3szgUcIme2mHWft4j0yS5I4yJlXzvzr/TSPz8ctQX21n1YxZXuEXVREAXDEr8y1JFTmMaeKqQh3HbZA7R5VfWouxcw8t39vfn0k+v+RU11nVQ0Llvr6Rzt95hoU9Efh2FNMHOkDVJUYsEZgnXrpX8u5/VEj0Jlgb0t73c8Xvrjd57l53TP9oZRd+/RRerbn7mP1izdyc4IrA+SeRM1Fg9FoMOs5JAx0xfkAHG7tRhoH7T87S28ucNiHSvYkixcLb21oTPq19Lf46CF89dQcoqNC9iNNAL5pNn5abT41fX01Xl/oSf+/F7ciMPhfnfk7MLzBy9kXnFG1I1UPvU/hHJ/+sEOuuXif3C7mFgGaQG/ufkJHj/kiUdi/DTPrZG9kwglvvOW5zl08eN3R0+1XhjVUPn/1kv/wcX5UBApmgZNnBsGTNwTdAP51vn30l++/yKL1pEO8lpfe+xj9pq/8NCHlJaZFDMh7TDChqPtYTyDMZAOGYetoWpupmUlc9QNIpGwjkaTf//xXVqzrFL31DI8k8mpCfyOXfbGJvXuv5ce++MC9R5zjor7/uLDH9J3LrqfjTIYA/+mQ4jSq4O0EPcjME3OPPtof4636UXqKJWx0/OFQRymmZmTTHM/MzVq14FF+d4fv8RtcxISY8s73KeE8bSTS2lceX5Ur+OZvy+mBc+tYQE7kq2M2MSkpieR0+mmD9/YTMvf2cx50RNnjhmRhgmE9iP/Ct7X5LSEmEtfQDHJ3dsbuD/6hGmFUfXsD0T1jgb6/pUPc894CLNoGDeQB42cSkR+vPP0p7Tl02pusROL4xUuNq7YTf/7lf+yKEQ0AQRhLIVQ43lCuhTaOaJdob3PQZNmjBmRRYgWvbye/vjtZ+lFtY5glcwuTFPrpTFmrs/tcvO7/fxr50QsAgyFp9555lN+X5pioPCs2+lh4XfhdScOq33XUEDlfoRTI73BEKvh9T7tWYUzZPXiCjrriplhDy8fDFi37/3Jy9wCzmyJzHzh/U5GErkcblr25iZa+vomri9Upt61sTBnw82mT7R3BgQ61oFI1tgRBgSd0/4+FIEOJqnjLBk7fUGeHvrKXnHTXDJESQDd+5NXOG80Qz2ssWRFw3h0tPRQ8YRcOvncyVG7Dry0/vbDlzi6wGw2jYp5iRZZsKy3NXZx0a+V7+/g+1EyMW9E9MjcvnYvPfy/b9JDv3mT871hRUZhs1h8WUF4dbT2sshBJMfM08aHtUL6cHjziU/o/771LNXVtFL+mMyojh82W2grhs3lri119IESTdgcw8AEoT5SNlw7N+3nufvAr16npn0dPHfxTMbc3FWXg/UyPSuJDa2IbECkFgzCxWW57MGKZ5x2N33wynq658cv07P3fsDvqtyiDM3IHWO3AnMfc2X2GRNo7KS8USnQ8f7q6ein0y+aRhk5KSLQD3tWIVQRAbVS7QWnnjT2oGc1Eu+R/35Cf7n9BRaNWL8jupT5w+lhnG9v7uZURuyH4UErmZjLdXrincqN+/id8aDa7yBNE/fWlmCWkPbY4GkaIMT9WAIdpbxvlLHT/6XR3tRDs+dN4Eq4kebh375Jz963mD3DaGsRU2OjFkiEzkKgXHjdSVG5hqWvbaQ/fPNpji5IUy+wUbWg+TTPJKzrdXtaaMlrG+ijd7Zw1EeeEmPw7sYTCPHcqDZLmPN4WcHLiugVeF5j+jagurvauBjU/z5+ZytvHjD2E6YXRe2a4L39823z6al7PuDnNJYs8ZpQt7GRadeWejZsIFWgWwlDrLHJafEnDNF3fNPKPfSvO96mh379Bm38ZA+nEiAtJeaXEf8GOEXNWRiaPnp7My15dQM17e9koZRTmB5X9wLt/d5+ahXd+9NXuN88hG9WfmpYq06HXaCbTGwkaanvpPOumRMRI2usCXQYi1BMsqfLTudcOUsE+lHAM4r5jGhBCNPpp5Tq6jhCtBravP7zt29xlwOsZ1GLAvJp/eGTkhOoobaNDbwfL9hKXW29VFiaHRdr7eFs+KiK/vX7d+h+NcbY76RlJ3GEpBBT/BU2lKPuZa4o+/VA/wh3EWXfi2X89KV2dzP97L4v0I3fOy8i50Me1uolFfTMvYtp9eIdlF2QzsVCYrEyuaPfxQvjQ+/dFjEDBqIa0HICYc/wHlvU2CCEFJvkUWtI4hxGD/WqzQ2EDnr5nnxeOV34+RPppHMnx7TIbdjbxu24lry6UQmb3SwkIW6wIYin8C7cA1xvpxI56AAxY+44uvrr8+jcq2azEUtv+rodtGLhNnr7yZW8fqBHPHKeTWrjG6vjiDFDbnBvVz9vzOHhPPncSRzGecbF09hrFMugR/HiV9bTh29sok2r9vB3ychOYYNNPIYmQqP41DLa1+vgeQwv+pwzJ/AcnnfJdK7/EIvAUIxiSlhHVr2/nSNG8F7CYY7h+X/4s9DS0EmzTi+jH93zeZo0c4yu50PINGoj4H0aE21JMfc8PhbpF11/En33j1dRvs7z7ZHfv01P/Ok9LmZpiJMK8hDkqD2DNsAnnDmR/ucnF+pi0EDu97/U+CCaDc89nAGxkqLD+x213+P9TkcfO7BOvaCcjVunXTg1pqN/sN9Z/vZmWvTSetqi3hkuvDNyUjiyR8LZYw4UICvH9mqoAh28qI7PyxjqCzaO5XOK6eqvzeMNDDZh4VpkvOqBxOc51IYeGyJs+Co37eNQJlgMsdnDghzLDy5eFtffei5NmVMS1iImLHjU/5CbBkNAZ3svNe/voF1b67l4BvpDYnzgifNJe5xDXuAIte7u6CeL1cThw3PmTaATzprIm7/CKESCBIP5XrWljj0XyDFHNfS25h4uKIYwNvwazy8qfq69Xupo6WWjCdIOTjlvMp149iQOfw9naCK6O8DyvmVVNa1VY4nesXhmYLCKt+ciEJGDNQRGBVTyxXyddfp4jmAaV14Q9S5MEDMIz1+3fBdHe2xdXc0F1jBn09TcjRcxONh1BLmfeC/hG2HezpyLe1FGJyphUDa9MKqiBoUZsYZsXLGLNny0i9+ZMEqlpCdQktqgx9s7weCv0oxQfAjmE8+eyCIdOb/ceQFzC3ciDF8L47N3ZxO98ODSmPGgBwuv9qZuFs2zzyij8VML+D2PMQlntX2skW8/vYpbs6I7Tjx1eAsYgzFXIJpnnDqOxemp55dzfvZwxOOK97bRohfX0aaVu7lOQ0ZOckxHJmKdsvc6WagjtQztyE44axLveeao+VM4Ljvq+51dW+u4KCciNratqWEjFGoGpY+wd8YI5OVjaezjCfSb1PGkjKG+oJAONo6w1mFhDOdCjucSm3mXw6NeTB72Gian2tiaZoiTol8Yj862PhbSeoTh44WNz3a7vWS1mXhzgXDFkVgULdxg4YdxAy9yi83CHgkU9JuhNtoTZxRxviMEvJ55XBAw+3a1cIGwHev3cvRDfU0rtaqXFF6ogZfUSG0zBG86wkkTkizcLqVkQi5NmlWsxj6XUxEyOIw/kRJTbBwpY4aBgl/sat4rgY/NB9IWIFwxZgjh3VvVRLu3NVBjbRuHPEI4wgqP9WMktBLGvEUOMcQh1kGEWReXZdPUk0upfHYxz1vUvtA7MgEG0/rqVh5vtNyE8bRhbzuHIsMAkp6p5q51FNS98GnGCYTAYz2GWC9W68a0k0o5H7Z4Qg7fE73CTGEo2L+nhTuZIF8TRikIctwLrG+IuElItsaNF/R471M8+xAcCHvH/gPrczjfdxB1MN4iQsUQg+2bcE14/rvUGDj6XPyM4V0RzjHAPOZ1V80bbxwb+Dlqq62PnTyInBuvBPqMU0pp/NRCjmrkVJuMRK7hgnuOfRSep74eOz/PcHpUVzSyoRz1MxB9gp/Fe4n3oL74Ggve76jvZbWaeTzGTSlgA8YEtd8pLVf7nfE5HA2gF8iT37uzWa1VzVSxvlaNaw3V723jd4YJ+x0Yzy0maasYH3xZHc+EKtDhet+sDouMo/4PPorF6fM2In7xxPPmAuHliAYw6LHqYHxgGBFBPqwx9KhNH3L1kUIB0Yg5jcJhBaWZlMsCKFf9Pot/n6s24MijxosM3hvkRGKOmvzikTc4SjzCcILPYwOWEpFdaqPQXNehBHgbv5Sa93dS4/52LnyCAkD4LHwmvCG86TQZRkXdADzaCGVz9ru5Aj82SBA8GFdshBCSh7BoiL5ABAE2kLhndrXhYM+yGr+e7n5+FvDvsNnCrwHP0kgdN9QmcNgxZi7+1anmMApmjhmXw9W4ERECIxPC47Ehy1J/Z1NjGZi78AJhTLF+YJ2C0QNeOGxUsantVwdC7BHxgHZGKEqIA4YQHBCB2MzCaAoDCjav+DXeNq/huh94D/I6ou6Fw+5k4zLuB/qJQ7gj8gHGE3QMyC5IpcycVG7JifsRmN84AkKRDbAuLUoKn9vd3seh3tjQ7t/TymuHdh80YxSeDTwrWD9gkDKhovQIvg+Yq3i3hvM7whOP/UbgPsT8/kKNQbgjIjAGJqNxROwrgp/LwHOE93NyaiI/m3i/WGwmNoQHHB54p0DIIocbH4BinXiX4NmK9yi2wH4H7wqHetdinYcjDGsSjBaIzoChHN51pIFh3UrNTCKbWtuxVkFAG/3rlE/7OH5f8DqFz1Sfh8hajB284XXVLbznaanv4ndHnVq3kGqIQm+811G/4rNHy35nhIBW5jPVsTNUgQ4WqeMCGUtBEIb0QvcSb7DtfS4Wi7xxNmsvJYgabKYRzYGIBWyu8XIJrpLPglO9rJBq0KU21diw82aSRZCXNwjYBEIsJSRq1nt5OR258cTYQ4SykQsbUf8gadE62EQbyKjuC8Y+VqrDR3vz5fIbmSDYAcaFx0nNW/weXjGOtEmx8XzG2MHAhM0pj7dfFCIqCgeLdhhhed5q8xfPAuYtRCDaCsncHRiMKSI9sHnFnDX7N7gYcxiRUIQLhQF58++fy+Q3vvA9UfcTBj7UUYDAwGb64Dri5bUD/1YzuMgmVxAGA9Y4pH3gXRx4txj8zg6sixaOTDCPiKir470zoLSxtuC9ASM5jDMw7gWMtzC8BvY7ENT83sD71q/QMY4uvzMC6YP4LH5neL0c8XJgv5OoGTk4skrWqXjmA3V85pjTahAC/afq+LOMpSAIw0Hb9PoObH4htvHSYfHof7kHW9XxUoMgCgh3o98bY/D/n8EgEQ9CpOau5mH0USDayXtA/Pm8vgNzO2D0wNTkTaqatxCMgblq8E9embphvB9+L3nACBW8jhy4H3wv/MbBwDoi90IQhFjZ76iFiI2Ost8ZLfxCHX8arkBHmPsOGUtBEARBEARBEARBCJkppHVKG5DBJAjhA5bIWAqCIAiCIAiCIAhCSCw6njgfrEAHC2Q8BUEQBEEQBEEQBCEk3h/MDw1WoL9BAzRSFwRBEARBEARBEARhQPrV8WY4BTpy0D+VcRUEQRAEQRAEQRCEIQEtvT2cAh08J+MqCIIgCIIgCIIgCEPimcH+4FAE+kJ19MjYCoIgCIIgCIIgCMKg6FLHe3oI9GqSYnGCIAiCIAiCIAiCMFhQvX2vHgIdPCnjKwiCIAiCIAiCIAjh19BDFejoh14lYywIgiAIgiAIgiAIx2QnaR503QQ6ctBflnEWBEEQBEEQBEEQhGPyojp69RToANXcnTLWgiAIgiAIgiAIgnBUoJnnD/UfhSLQN5JW0V0QBEEQBEEQBEEQhCNBaPumSAh08LiMtyAIgiAIgiAIgiAclcdC+UehCvQ3SEt4FwRBEARBEARBEAThIBXqeC2SAt1N0nJNEARBEARBEARBEA4HWtkbSYEOnlBHt4y9IAiCIAiCIAiCIDCo2v50qP94OAJ9H2kV3QVBEARBEARBEARBIHpWHXujIdABisX55B4IgiAIgiAIgiAIoxyEtf97OB8wXIG+krSCcYIgCIIgCIIgCIIwmkFhuE+jKdDBQ3IfBEEQBEEQBEGIWXxEBhxe35GHjyQmWAgXjw73A8xhuIiF6liujrPkfgiCIAiCIMQOhgiIDp8hRLF09D8++l9EaZx8oV6LLzJfY0jXF+I1+QzxOvmJjC4fme0eMrm85DMayGs28K8+o/8HfL4g0a5+3q39nDvBRG6rUXNl+iI01yI094+1JsTtvY4dPlLHglgQ6OB+EeiCIAiCIAixATbaJiVOrD1u3c/lTDGTx2JUG//BKxlrn5tMTiWGDIZgPcXX7Ug1k9dkiIhxASc1eHxk63azSAu+HuBIG/q1QOBZet1kUcLw8M8Ln8jyKbFp5LEa7Hyw9ntYrA76mgyaajR6fAf+G5+jCVxN7LptRvKZDDHlfcZ3NDu8LModqRbqKE2m3hwr9eXaqC/TyvPVnWA8oIrxc9ZeDyV0uSipxaEOJ6U02Sm52cF/71Hf0W0zkdcyzO/pH088k2wIOOw+4L+cySY+F+Zi2NcEdc8wNlY1N484t5pPrkQTuZLMupx7FHFvWJ7vK8p+Ha4LQj76XLkvgiAIgiAI0cWixFj7uGTadlWREhZGMrq8YT8HBBq8jlPfrKPsnT1qc2867r8JiL0dlxdS89RUJWQ9B4V+spnytnXRzJf2sVjA5+sNjAR9WVba8vliFrsQdixmIDqVUJn9XC2lNtr5egaLTQm9nRfl097Tc9gQoYd4xVinNthp1vO1bGDg6x1QzGvfc/d5ubR3bjYLtKGAe4ZzYE7huyU3Oymtrt8vYp2sOh1pFjZkRHXO92nisy/bSs1T0qhhRhq1l6VQd0ECedWfkVG7pwFhfogyDvwK4drtosRGB6Wr75i7o4vytnZRxt4+NnjZM0L/nhi/jtIk2nxdCXvuje6DFwEDV4I67+xn97KAhwc/rOJcXbJNfW53QSJtuqGEowNMgTXBpxmiMmv6aNb8Wv7vSDx7I5AV6pgXjg8yh/GiHhSBLgiCIAiCEH0gyLHpbjozR+3MjWoHHn6BTggBViJj/IfNvNl30fFFBbxzuJK2qUo8KcFIHa4gBWOkjhMyKG1fP01Y1kQ9uTbdvegQSfACN52WTZ4cJeL6/AYDCBQlSj2v1ZFRiVsagkA3273UMS6ZOs7PU9/PqY93Od1CjspuIgh033FOgTBut7qmMv81tTuHdi6/55fFLQwsLhxeSmq0U25lDxVu6KCCTZ0sLCHUfTqEhR9LeFrVPWPxOzaJts8tpNq5WdRbkqTumVm7ENzTLtfgr0nd+34lpPsnpVDDGdlkanNS3rZuKlnZSoUbOyhRCWl7qkUzUA3he+LnU9TcNloM1HRxIVGT46BxAMYDNcdS6+00S4l0N+ZbGMcQRhazGqPKSwuo8XJ1bkTWBIwVMDikmGnM/VVk7Vb3UM0tISQeCdcHhVOgoxn7reo4Ve6PIAiCIAhCFDEYNA+dEhcspJ36CXScZ7C5qwitxY+aIBBa1bV1Bgl06IU0M22+uZTydnRRovo7DuHWU+whTxm5x0q0eiAsAwI9ELYNQWocmjcR3myIIWpxDE0YDgUlkA3BYzeI+WDq81/TUP7d4ULd/1n4fZ8SxDVT06jmonzK2NxJ096so+I17eRMMnHEgZ7GFU7hUPMuocNF/VlW2nr1GNp9Xh65SxKJ7B7tPnaGaBzBcxNIDYGdJtlM9RfkUf3ZOZShBHr5ggYa+0kbeU3EBokDBozj4FHPi02N/awnqmnxhBTywnDWdzCChNS4VV1WSKUftVCKEu8wsIVj7mCs8Cw1zkinmnNyier6NYOdwW90yUug/IWNVP7Gfg7/lzz0kFjt18LhMaiE81lRxz1yfwRBEARBEISQBGCXmxxK+G3+cimL4+AwYCHKBCqdBzzpEJfI01Zir+OULFrxq2n06TfG8z1DOLVeQo+95sgZV+J8txKc7/9xBlV+ZRy5EcbORhG3dn2+o8wvGF7M/sNi1A78Hn9+NEMMPgPGLXzPXjd1nJhJq34+hZb+tJy6CxMpWZ3PMFgDFULJ0y2UtbOHyt+sI0o+TICr7+TOt1HlZ4s44oHCZFODIQP1CrZfO4YNYAfEOYCnvs9NU1/exyH8nGcvhMJfKWx3LLwedDBfHT9Rx0lynwRBEARBEGJQZME9YzMNv2K034Me1pBmXFOrg2rPy6XczZ00cWED9eXYRs7YQwxaw+AfSzJr93C4QGzjc1A/4PDiYAb//6H4H6QHcpZxHH6v8WdNdqIEE1VfV0K9+Ql02oNVHHrOdQnCaGOBEE7odHEI+IqvTaB9F+ZrHv1G+2HXHQQ81Ul+yQPvOq6XBbz/woxBgh0/i3Ho9f9c8GfCWISoDyVim8/NpcXlqTTz2b008YNGLq7mSjAeP2oA2QEpZpr4bgPVnpZNPaVJmkHB4D+H+m571GeXfNzC9RiQ8z7c8YPXvvrsHGo6NUuLnjAEzUd1LWWv11GuOhciEaTVXEisUscL4fxAsw4XebdfqAuCIAiCIAixBLSh0h22Zoe/avkwtB0qtyuhgwJkFM4CYS7NQ7vtumLK3dpJKepa7emWyFR113nsjQ4vWducw/YuO3vdZIW3+GiCdIhGFmuHk1IqHEcvDObTQvaRp4974IGIw89BrKLYnNd/fohcv6e5+bw8WqvEOUQ65gZCu8Mi/NQpkpVA7ixKpJW3TaTOEzO1FA6n99Ax8AVEuYn/kVmJd4Tgp9XZKaXBzp53a7/7QGoGrg/V3vszLdSbl6A+P4G6SpPJi+/q9UcKBM4REOpNDnIr8bz+e5OosziRTnhmLwv+wYT2IwUAIexT3qijNbdPOlDvQDMgqPPk2mjnZYUs0NEmLuSCbQatHgLuW+UVRdq1u3wHQ/KVOE/Y30/lSqB7rEZZG0Pnb+H+QD0EOiwI31XH2XK/BEEQBEEQYgibicxKkJ3+j52UpMROOKpFo3UTKrCHDX+ou70kiTbePI7O+vMOLkKHMN24Rgmi3JVtdNLje7hqt89oGNYYGfyibljV0zOsfE1n/6VCiVPb0QW6UWs15kwyU2+OjVqmpFLtKVlkn5ii5Woj3z5wCbimJjvVXZxPO3f10LRX9h/9c0MR50r8t5al0Mc/K6f+8cma195Lh3qEIWYzrWw8yP60jUrVd8ve2U2pSpyjkJxXCVEvppE/jz7w77gPuj+lAnUPupTobp2UQjWnZlPHzHQtNBwFDd2+g0K9282GgN1fGkvdhQl08n+quYr88cQuBDw846UfNtO+07OpYV6OFkIf+Nx2J9XPzaLaudlUuryZevNt3C1hyKjzJKhnfcv1JdSJ7wDvf+A7Y84kGGnyW/WUvq+PevITZG0MjeXqeDEeBDr4kwh0QRAEQRCEGAO6RG32Ic7hmXaFQaBzL2xzmHth+4VKw1k5VLUunyYtbKS+nDgPwUUfaoeHheZwBTr3QYdnOwz3j3UhBOoA/a8NbrRpc1NCu4syq3upeG07TVHCrvIiJcKvLCJvilkT6gGB6dJCxJFLXbSmnZJbHcMy4HCRM3XutnHJ9OEvppCzKJGoMUjQBsQ5rkONSZ4SvpMXNFDujm42HkEwI9TeOciiaxDpmXt6uXVg2ZJmapyeRlUX5FOTEtMcFh8cko6QefXzPaXJ5FLPga17cBMU14QWg/BeN8xKZ7F8oNMCjADqe+y4spCK1rezFzwUDzeMBahsX3VxgRYF4AnyniMXfkMHjVvSRPYMq6yLoXOnHh+ql0B/Vx2vqeNquW+CIAiCIAixJdKRw4tQ27D1W9ZDOEOoOL206YtjKaeym9L298d3qLtP83YjX9ljMQzPgx7Oy/KHecNoMGgBoYTpiU/WcH/wVbdOJEo2aXnbAeGKlmuFCVw1fOZze5V4Dm2OcM55t5t6s6204sfl5CxW4rzFeagwx2Wrv7ep+TH9+VoqW9rMBgzMFc6BH+IcRUg5V2f3Gy7GrG3nVnI183Jo0w1jyYlK8exNV4I620YJ1b105l07KK3BPviuA34vOlI4JixspF2fLz7Ydo0jSFzUOSOdi+CVv9sQknEKnQQQKm/H9QZ7zyH2lViHcQDF/PozRaCHyMvqWKDHB+sZK/RnuW+CIAiCIAjCoEW+zV9V20cHwog9SuhtUcIIwtysR7s4Yei2k0QT9eTbaMKSJprzZLVWaC441B6/VSKw7uRMrlweUjV+fw41/uW6/1dGvVNSDxWa+AucM9dGmes76LzfbqXJ7zWQM9nEBc/CYQDBZ+CzYFSZuKiRLvzNFsr7qIUIgrkggRLq+umsO3dQ1p5esg+1JaBBq+PAQnlfP1Hwv8c0V2NWcWUR9arvZ+nzDL7WgL+QXkt5Ku2C97zXc+gzlmGh4mXNNGZ1GxsxhJD5i14frKdAX6mOB+TeCYIgCIIgCMdFCfNkJXisCPUNFMbiqu5Oqj8zh3ZeUsBh1kIM4NPEa09uAk1Y3EyZ69o1gRlMv4e6xiRSW1kyh1sPWZ+raZDQ5aLtV4+hRnX/2cMcLDThHFcCs3BxE53zf9u58FqPEs0QvWGN6PBpXvVuCPIOJ531t0oa+0YdGevsdPq9lZRV08t59kOO7EDbNTVmqQ12mvL6fm3OG4MMHN0usquxq7ownyxq/Aabh462b4jU2KHGjcP++z0HxyzJROZGB015dT8X//OZpK1aiDxIWvX2uBPo4C51tMk9FARBEARBEAZWFZrYKv2whUqXNRMFt3yC99Xhoa3XlVDbhGT2DvpEV8QEHquBK7WXrmg9mOMcANEO6p52FSVyNfKhzgebEueN09Ko4uoiLcfd4zt0vmTZKP/jFjr9vp1k8vq0UG0d0x+4uBsq2VuNNPuZvfSZ326ljJo+9nCHet5Awbhxi5soe1MnF+07xIuuvvfuC/KorSyFrIE8/+OMW2KHiyMX6s7IPrStmlET6GhdmF3Vo4XxS1u1UFCTnf6o5wn0Fuh1pLVdEwRBEARBEISBMRm4Wvusp2rIgr7WgZBff06zO99Gm24aR14UWzu8tZYQFSAwIVgh+AzdriPb7aFLmRKw+JmBitAd9XP9XuBt15eQF6I1uFI8PifbRunbuujUh6q4+rpdic2hfP5wvm+g33lyi4Pbqg1X5KJCvs1fMI6NEDbjQSMEeskXJdLOywo4p9zgOfbJkBLgVNdUeUWh+g+jZiTx3wdSY5S6s4d7sDvxbMnzEyoohl4fzwIdoDfcOrmXgiAIgiAIwrGAhzKjtY9moq80xF4g1B35xG1OapyXTTsvLeBe1uL9iw0Q/o1iY8nNTq0AWTBuL4tneNqHEgKO0PZ9c7OoSR3U4TxUTCabyaj+7OSHq7iAHBcO9EZuMhj8Ie8szsOB+jz0YC9c104lS5o46uCQua3GoubsXK72busa2Ivu80cd7PlMHrWhrVrwuFkM/DzBCJDUGh7DwigFmvbvep8kEgIdSSd3yP0UBEEQBEEQjiVUIH76bVYqW9xERQh1D64wjVD3Pg9tv3YMNZenskiXUPcYEOhGLcwdedJH86C7UbHeMPg2fCgoh57rCO1mDg+PTzDS1Ff2UU5FD4e1G0aA0OSCduqYogS0qcXBoegHQE2GFDMXjPOYDRxdcDSsvR4u3FdxRZE2Zr6D9wDe87yVrVT8Sau0VRsed/i1bdwLdPCGOp6TeyoIgiAIgiAcC4RDQ3jPnF9L1rp+FheHhLrn2mjjl8byz1rsUtU96hgCfdTx+yMtJlyIbAgVyG3dLmqekUYt09PZe3xI1XZEWGzvpknvNpAjzTyihhHfJ6uqhya/08BRAsFjgm4GDWdkU/1JmZxjfrTxtKCt2qWFZB+XxD9/AITM93lo6iv7yeL0kNciVq0QedavaXXHGMEv9Wt19Mu9FQRBEARBEAbUaKgJp4RY+r5+mv1kjRbmbgmq6t7mpNa52bTjyiIO6ZVc2ujfL4/ZyIYVOjzUHJHVzoB4H8RnebVj76lZWgXyYG+xWRP6Ze83UkKXm1u9jSjUV0Vu+MR36iltR9ehoe5cc8FAFZ8t4nZuJof3UKOGeg5aJqdypwMW58FjnWbhMSvY3En2dKuEtodGrzp+FamTRVKg7yYJdRcEQRAEQRAGIVZQ3bp0eQuVLGo8VKzg1143bb2+mJqmpWn56CLSo4bR4yN3gpEc6YcJamAycD650eUdVDqCpc9NnWMSqVnd10O8wEAJ8uSdPVSwoYP6M0ZmBXLkhie2O2nym/4aZMGGqU4Xtc9Io5pzcrmTQWDOIyUARo3KywvIl2k9tK1aipkSa3pp0tv1/Nk+o8zXEPmDOqpHokAHfyatP7ogCIIgCIIgDAjybX1KoMx8ei8l7e0jChZlfR7yZVhpyxfHktti5OrVItKjJNBRCE7dGzta47kOSzlAb/tWB5kdXi3P+rif5aP2iSnkyE/g1noH8PfwLlndRsnNDvJYRq7SRI54yYoWKljVptVgCEQloIK7OqouLaDeHCtZej08pjBQ1Z2YQfvm5WiF4YKMIzBqTHyngTJq+8iZYhbveWis9GvYyD1TUfiSv5D7LAiCIAiCIBwLDnVPNVNqg51mPLtX+0NrUAuqNic1n5pFlVcWKpHi1PpGCxEFXnGj00tNU9OUgDYfGuIO72+Xm1Lr7NwybXAfSNz7nMPZg8Uk7nuni3K3dWlCfwQbY5AjbnL5aMrL+7T+70nmg3NejWdvWYoS6YUcbWB2eMitxmb71WOIEkwHC+rhlwwLZa7v4IKLqHQvBqyQ+XmkTxgNgb6UIlCeXhAEQRAEQYh3BUjUl22lsR+3Uum7DUSZloN/B49it5t2XDWG6melU6IS6VLVPYIYtCJ9jjQL7T09W90r36GiOtFMyfv7KXNPLzmTj58vjkJzyCvvHJt05F8mmSitpo8yq/u0Ht4jfM4jIiF3RzeVvYeCcUEt0bg3upt2XlxAbUqop9bbac95udQ+K+PItmpOL015dT9Z1c+j17p4z0PiHnUsGw0CHfxGHXvknguCIAiCIAjH1CtmAxcgm/FiLSXs7j2Yjw4x0u8hr/rvTTeNI1eCSavqLiI9IuIc4ejIl65UYrF3Sqrm7Q0SmRCJ+Vs6KbHVQd5BhKQjDL4n10Z9CJV3eo84X9q+Pu63PmhvfJzjSTBS+Rt1lFjbT5QaFJ7e6yFPvo2qz8+j3mwrVVxWqEUueIPGXj0TRR+1UPHqNs17LuI8FKBV/zcaJ46WCapHHbeo412594IgCIIgCJFUvGhl5eZCUy7n0OPCUZAKgtkV7NnT+XqRP5vSaKc5T1TTyp9P0UKenX4xrkRi+0mZtP2qIprzzF5yW22xKdLVJRtdPh53jJ83BDcZxt6VZCJ3gok9ztGaP5Y+jybOLy2k7TeUcNE+ClRqx2UpcWnocFHph81am7VBgF7qfTlWciJKwnlolXKEbmdU942qCAlnspnS9/fT5DfraOMtE4j6DJoQ5znvov2nZFJXgY36ihOJul0Hx17ND3Ozg6a9sp/HHgYNgwj0UIBW7R1NAh0sIC3U/fty/wVBEARBECKAx8cb9roTMlgouq1DV4les4HbXGXU9HLrp0iIJohReFbHrmylpnfrafc1xUQtDv8FEffLrrh6DOVt66KCTZ0cFh9zosTlpX71HfaelqXG0BjSuEHYQ7SlNNi1tmZhEtzwhqMa+0B/b/D5+GfM/R4tylqN75ZrxtPOq4r8YddBkQv4Nc1C417dT7kVPdQfnJZwLPuF+nyEy3N7tTbnYZPORynNjlH3uPZnWql0WTPtOz2bWmdnaOOC8XWquaTGqv/ETK1qe8A4gimhhP3El/dT9q4e6s2xiTgPjXv8WjUqRDuJA2EDF6hjpswDQRAEQRAEnVEbe+Sjrv36+NA/I91COava6My/VZLP5ItYRW0YBpCjPPWV/dQ8LZ26JyYrweL3HPYpkaLE75Ybx1J21Tayqv+GpzmmQnt7PdQ2IZlW/GByiFYKdSjBNfXR3TT7uVrqybOFyfqhFXsbcKjU7XVbTRzFgBD0tgkpVHtqFvVPTNHC2tX3OiDO8SFKvCdX9dCU1+u4/Rp70I93H3zaNXClceNhP4//dnnJ1jn62unBCINIhfLX99OKGela5IjLbwyBQQXiPJDu4Q9tT6nspgmLGsnBY0kS3j50NlCUQttjRaB3q+Nb6lghc0EQBEEQBCFCBCphh7J5h+DimlMBZRAZuKq7Eh3JLU6a9VQNffzbaRxKTY6gUPc5GbTtc8V0wuPV3Pc5pvD5x90Y4pgZtLEPa8SCGjP0kn/3r7MHzO3G+ZBD7kRovRLoaN3FBpF250HPbeD7wVuu/u6kf+6mlCY7RwwMZo7xVDQbtHt2eOi+Gi8jVywfXKu2kG4NCt4psTvccyDSwJlkZmEdrhQEtF0bs7qdSpY2Ue3FBURNjkPH/ICqM/CBwnDJauz7cK9EnIdC1ELbY0Wgg0/U8ftoWyoEQRAEQRBGDa5h9CRDfrDbRwaEt0f4siHSIfqK1rbTxNfqqOrzxUqgB4U+d7mo8qoiyt/YQQWbOwctECNz8eQv5uUL/d+rsTd4wviV1DxwpVmoszDh2G3qfL6DHtvgYnABIw88tWqsTW1OmnvfTirY2qkVexvsharP96n5xNEYh/8b9UdoO4YQfF3SKdT5TOqzO0uSOKTcOIxnA1Ee6fv6ucYDfh+WyzNqn1uuhHfD7AxywTPe5znUNub3nud+0kalH7ewqBdxHhJ3+LVpVImVPgW/VceF6jhd5oUgCIIgCIIwoGBRwsSdZKJpL9ZS0/Q06pqcwkWzWLCginu2lTZ9uZTS79zOxcxiLtQ9lvCHj1NHCKIUYwoRCsGofk3b2Ekn/bea24OxOA/FADGApjVwCzd9bqLR6+N5gtZl+y7OPzL/fSgoYTz3ru00dkWrZhwKkwEBufnZu3tpwoIG2vHlsWqee47sE9/upKmv7WdDhsciheFC4CN1/C4WLiSWGgne4h+YZJkfgiAIgiAIeqhb0ryd2TYtVD0U0ZNpJV+GRf3TyIa4B4NwaxQNm/V0DX30q6la2HW/50Coe+fsDO6PfvK/95DbZtQtNHpIwHOO62TvZgjjblDfId9GXvXdDZ4YUF+YR+o6kpRwLFvSRBMXNXKbOxSQCyl9wqsVojtiSsF5bzFqIfg+/R4LzpWHB988jJoKEMoGHa7Tn5+PMd53cib1lKVolfMDhg31d+OVOC/c2BGbBRJjn26/Fo0JYkmgb/APzH9ljgiCIAiCIOiAEhAmtbGf+s9dHIYbSiVweOeQB869raOkeyFA+rJtVLSunSYrYVJ5UymRw+9VhDO4w0lVlxdS3pZOKl7TTr05MSBaks2UUdFNExY3sdgMxWgAY0N2VQ/ZB1kZ/fg308dtuWB0oYFEP6aI06flnAfbZDKsVKiE+Rn3V5HZ6SFHqoX61HXxOA9xrBHebvSiF7pHE7iHXSMKG2K+6dVajp33+P5I3xhu+ofPF/7nwm+kgKc/tcFOPeWpQRevGdpS6+08Pj4dDRkjmO+qY7MI9KPzJGlh7t+WeSIIgiAIghBmlLiGl3LCB01cxMsdQiE19OKGUOzPsGg6JFrtuNEKXYnCKW/WU+OsDOqclnawDRVC3dX1bfxyKeXs7I6Nqu5qzNAebcpb9WwY8YXSB92jtSJDsTxjOLzoyWZKru2jQnVNA80F9CfvzbVRw0mZXHvgQA693UPt45KpJ9/G0Qyo2B6yEcSgfTcL8tuP4kEnm0nda7P+RpZjhNkfTTRHdsJrHRPQou+Ic/u0iu8izkPiIXU8FUsXZI7BQbpNHWepY7rMF0EQBEEQhHBu8jUB0s9hsD4lqkKvdB51j7Q6v0uJwqRWJ815opqW3TH90FD3Thf1TkulrZ8voZMe26O1/DJEMdTdS+wJhthFFMJwwu6N4QpxTzNT9s4eOucfO6gnLeHoAt3hJYcSxwvvmknd8NwG8v3VONsnJtOOK4votAeqyKnE/nCKuMFgYYNAx/2D0Ax8R3ik1d/1BkLndZhHSNfwwYCDvPHjeun9HRC63VrUhtEg60r8skUd34u1i4pFgY6Eiq+oY4k6UmTeCIIgCIIgCAMZCVB5u3BTB019ZR9tDw51x9Hhol1KQOYj1H1VG/XlSHXroxoNUhKUALYNqEdhBCl/q57WQKAbg2oXdLmp5txcGr+kmSMV7Omhh95rPb9dZOx0kVeJffJ4ghSLkTqLk45daT5UfW4ykDvJTGXv1FP+6jYyHSfEHREkZruHtl4zhjqnph1a1V6IJ5B3/j+YeiLQB8caddyqjidk7giCIAiCIAgDYiQlDK00+c067undemImUWtQqHuCiTbfWEKZu3rYQ4tiWyLSDxOpxwntdqSZqWRlK1Vt6qSOWels+ND+Qo1vjpUqryikrPt7tBzoED3KbiXQkXaR1O6kHuTE2/26yV/YsHNsEnn91cnD2W6N+7yrc+dWdFPRho7jXj++o63LTXvOyaVOm7qwHpk/cQq05roYXdJiFhSLu1fmjiAIgiAIgjCwwiJyJRo5z3zmc7Vadetk08GCZp0u6p6SRts+X0yWXk9sVECPMyCeLf0eKl/QoOWhm/wi1h/qXXdmDvfoTuhwhRyGjiJw+PfJDfYjFYrdy33KO8ckqnsYfo81RDdC9HtzbNwi7ngHig5yz3avzI045W+k1T6LSYwxPng/VMcymUOCIAiCIAjCgALLH+qOUPbpz9dy8bMDu1x/qPueywqpRgnJxDZXWD2wo2V8HekWGrOqjfLWd3ABvgNRCPCiWwy08/JCLh6IonIhoz4zr6L7SOFr95CnMIFaytPI7BBVLAyLxer4cSxfoDEOBvHL6tglc0kQBEEQBEE4FsiBLn+7nrJXtfr7jZPm0fWLRlR17y6wkbXXE7UWcfEKcsSRnz1hYYOWOhBo0Ydx7HBR8+x0qp2XQ7bO0A0gKBSXXdmjFWAzHfYh6tx1J2aQM9kUviJ5wmijSh03xfpFxoNA30daAr8gCIIgCIIgDAh7cJWQm/30XjKhb/dhoe79E5Np6+eKOVwb7eZEpA9FPStdnmGhgg0dVLi6jSvAH/CiYyyNBtp5aSHn+FvsodXdQqu3zD29lLtLifQ0y6G1Avo81DwrnVonp5KtS6IghJCApqwTgR4ePiatsrsgCIIgCIIgHJVAqHve9m6a/uI+LdTdbDggMNEibO/FBVR9dg4ltjqlVtxQNbrJQGanlya+XX+kF73TRZ3TUmnP+Xlk7XaHJKDhpbf2uKlgXbv2mcFedIS2p1io6sJ8rqRucsndE4YEPOcr4uFCjXE0qCgad6fMLUEQBEEQBGFgla5EepaFyt5vpPyPWogyDwt19/lo841jqbsggau6iyd2KApdSyNArn/RCjW2qYc1hFLju+OyQupRY4uifUOOUPBpFeOL1rRTQk2f1tc+6L5Sp5PqT82ivadnU0KHU+6dMFj+oI6n4+VijXE2uL9Sx3yZY4IgCIIgCMJAIo/zpd1emvV0DZlaHUSB1moQdF1u6h+XTFuUSDe6fBzqLr7YIQwvvNoGA018r1GNpYvIEiQnetzkKEum3efladXWQ6jn5raZKL2un8Z+3KLdt2DgNVfn23RjCdkzrGJgEQbD8+r433i6YGMcDjJyB5bKXBMEQRAEQRAGEumoOp5d1UMz0HoN/aqDW4N1umjvJflUc1YO992WXPQhjm2qmQo2dVDJyjatonsArybSd12YT+3jkskGkT7UsTWibZ6JJnzQRDZ40YNz0dnA4qK+KWm04eZSMjm8XNVdRLowAKjYfnO8XXQ8CnSHOq5TR43MOUEQBEEQBGEgIdmfZaVJ7zVQ/vIWIvX7AyDU3aWFureXJJENVcMNovIGPbRmA0cpTFzYSIZWp2YACQjoPg+5ihKo6uJ8Mts93GN8qPfNmWSi1AY7TXlln2ZYObyie6uD9l5SQJu/UEIJnS7Oi4+UkcWn5gmMAtxOzihzIYbZ7deMLhHokUGtsvRZdTTL3BMEQRAEQRCOhluJSHhXZ86vJUt9v5YzfSDU3UXdSpxvvb6ERRfaeAlDENGpFsqu7KZxyPM/vOJ6t5tqzs6lpnJUXB+6F93gz0WfuKiR8la2HqwjEACh7r1u2nFDCW26rpgS2pVI7/dExJOe2OHkavY9hQla4TohFmlUx5XqaIvHi49nu89mdVxPJGlDgiAIgiAIwkBCTwnJXf5Q9wTToVXd+93UNiWV+vJsIraGqtGNWj76xAUNZESaQFJQQTe7l7zZNtp5RRERPOgh5qLj/s35bzXZYFxBBETAG2/QzgGhvv3r42mNOkxOHyW1OQ/+fVgnErHHPKXRTp1jEmnpr6ZS96RUrV/7UX5WiCqYbV9Qx9Z4/QLxHpixVB3XyDwUBEEQBEEQBgKt1yYsbqIxHzQRZVoOetHxq8PDld1FWA1VoWu56OhbPn5RkybQD8sV33dWDjXMyaDEzqFHGSM0Hp7qjH39dNI/d2lpCamH5aP3e1gk7/pCCS37xRRqK0tmEW3p84Ttaxo9Svi3ODmMfvtni2jpHdOpc2a6ViDPcOh48BiYjQcNCUI0uFody+L5C4yEzInX1fFNmYuCIAiCIAiDFD8erXo5xEc4jljHYzGwt3fmMzWUUBsU6h4QVpH4CgbNo290e8Mz9uozDDEgBN02I5UtaiRrvf1QkY6IBPV3Oy8t5FQDXG8oRoC+TCsVr2mnEx7epeWiH24IwHlaHdRyahYt/c00Wv+lUrKnWSixzcn56Xxew9DuE8bXpgQ4PgNjXHNGNi3+xRTa+J0J5Ey3EDU7DhXmINtKSVu7KH1XD7mTzbLIRIdvqOPNeP8SI2X2PKqOdHX8RealIAiCIAjCsUUPwnXhEfSZDMP+LAgaX4KJQ55jNfEwkNOcUdtHM56vpTU/nExkNWi5zJG8DiX2uLiYj4Y99gafj7wmoxLI0XX9O5UYzd7dS6XLmmnnF8cS2T0HIxSUQG6cm0V1p2TSuKXN1JNn43sxJIxa7/Xyd+vZ0LLpm2Vq12/hz+ZzBCIh2p3kUddS8dVxtOfcXCr9uIXGrO2gzJpeSmx3q39r5DHn0HzUHDAcnMMYS4NXM1yZXF7+Th3jkqlpahrVqOvvmqFkhjo3tatzwiBlDEqTQMpEro1SN3TQWX+tpKRWB0dsGMSLHml+qI7HRsIXGUnmnb+qI4G0RvSCIAiCIAjC4Ti85E4w0spbJ5JRCRGfcXjizmvWKlrPebqGUpoc3B4rlg0TfVk2GqeEZOPMdKq9rICo0RG50PZeNzVPTqUlv5p6qEAchjDO39pF017fz9/Na46SUDfiWkxUtriJaublkFOJVbRa4+8HA4j6rpWXFVLhmnay2L3scR/qffOo79aXbaOpb9WTVX322lsmki/HStTqPPRnEdpu95AzP4GNBTsvL6KMXT2UWd2rhHofJTc72DMOEW7w58V7TVpF+v4MC/Wqa+8qTqSOkiTqVALdm63OAQ98n9v/XegQYU+Y7+kWKljYSKf8ezcldLmpL9Mi4jzy/Eod946ULzPS4i/+Tx2p6vipzFNBEARBEITD8PjYi9g2OyM8iY4Wo9ZW64VaFvwUywIdYsxi4GPG/FpqnJZGzoKEg55YvXF6yZlppRYlAMNChpVsiIJQYlC7lVES6NwWzUzp+/upbEkT7fjKODZGHLikTie1q7GuOSeXJr1TT66EoXvR8fO4b31KMI9f3kIpLQ5a/Y0y6p2SqhkDkItuNBz0puP8PcRe747Z6erIoD39bq7Ub/T3Tjf5q/Z7bCZ1TUbyYS7jwBxGTYJej2YACAxrsDBH9IMS9AY1d6Y8upumvV6nnisYgMRzHgXuUsedI+kLjcQEiZ+pAyvfbTJfBUEQBEEQgpWOX2B0hak1sBI0RiWOTPhMYxxUWUOoe4qZ0ur6afbTNbT6x+Va6LIrAkXijP5Wbh3esH0XoxKiMTHqStciegJe9D3n55EDVfEDFc79Of4VlxdS8SetZFHzxZ1gCun7wriE3vZ527rp/N9vo03XF1PNJQVEeX5DS3A/dPwK73eH3wCD8VeHN9lMTrjzAn3vA1XmIcpxfxyeQ3Pcg87P4eyoX2A2UsbqNpr9Qi0Vbuxk7zsiA0ScR5z71PHLkfaljCP0Zn1PHX+XOSsIgiAIgiAcYqNQGgoir2xZM5W+16D12JYK7sM2FjiTTJTSYKfJCxo0T3QwXS7qm5RCuy7M5xD14ZwH9OZY2Qs+91976OzfbqXsj1u4IB3BMGA1Hnk/8e+QOw7BDhGPFm3wuuNAkTkIc/wdfuZwjY3PwvdBSH2ahZIreuiEeyrp/D9up7zt3RwW74E4F20eaaD1vj8Sv9hILjH4A/8jdbvMX0EQBEEQRpdg8nFuLXv7bCbNK6gHSgzhPF4DDapAHBc2g1ZCGLESOwf7Wmshw15bZFpUIafZpQTltJf2UeuUVOqZnk7UHRRVEGiVZdTGckgGAPXvEDbNhcx8Q//3g0aNn2+wKQUY98A1BY8v/hufEYYxh0B1pZipdEkT7Tkvj3qm+sPPA6h5suNzxZS3pZOy9vRyDv2wzpVsIre6dnjTc3ZWUN2cDM6Bb5iVTr4Mq+bt7vccLFo3FOBtT1A3H55+VMvvdFH2ilYau7KNita3U1Krk+xpZnKk+oV5BMQ5HjGvuo9HPDu4VnUfkUdP3lGzwt3n13ojkpHeAwBWFaxct8qbWhAEQRCE0YJXCUz0gk7b3k1etLhy6rNzR16w2Y58Xr9B4Hg6UQnx/8/enQD5WRZmAH83IQgiYrWtjo4HqAgKhBATQIocooBQx1EURu1olakKlXrUA0UuRfGoR6GidKzVqVjwKmNFvIWWS0VUkBsqhxBCCIkJ5CDJ9nn3+wIMBiFxd9/d/f9+M8+sAYfdffJfwvP/rvr/2vzmu8vSSxffdzQ1f3H5rTPKprevGPl6x3zs1AOpGZOPyufb/rQbyy9f9ZSR72Oof2RcPZW6vplQextez5uv1buFbzZ/edlk7fc3RuNt5Ouvj4xLp3/0Uwx1j5h75G3917TkvtG8/NblZdNblo1a5/VNj/rM8Gd+65ZyxdATy8b1WvA19y3MenfzBVtvnkG99L47vW+oerC7vm7qTdny+/bkny4ceRzbwi03K/NmPqbM32bzsugpjyyr6lH1tW+4DD/EAl47eDPqN563omyRbv786iUjN+N77PVLy0bL1pQVW2w0ci382tfReHnQn51p3Q0DN71z5bj87EwAJ5cpeuT83pfigVsdNQi/kR9N3umPawBgkIzXNbHrezf4On7XOZbqmBzn081nZIytnj5t5C7oQw842r2hd7kfGssj5xvY14N+TWPQeT39vPY50t/azznc9VmP9E5ftWb037iol5ivGs6IXt19/hlD5fdP3LQsecImZenjax5Rlj1m45E7ztdT0kcG73B97N3wyHXxdfBusmjlyJs2m81fMXLH90ffunxk/Nfry2vWzGg/gCfSz04DJyZHTvVvcqMyGOpd3e9OjvFHNQAwEON8uBssY/+JSlm9no8NG1q97jcP1tTzHusR63E8MnnPI6aPDMbp63gmen3u9nof5R3qnqe99mj82L4xUh72Ef7a97q+ppF/xoxR7Hyo662+9v7g8+XX05IxeSTccPfItHpmQb0JXP3cdWhvcdPdI28M1M+5Znr/psEDbv5Wf1bW9jM9X/fIJesZ5PX568PTyri+Hjf4Z6euumlDE+prHWVHlwF5nPagDPTq2NKdZHOcP7IBgKmuHk1bPUFPee0G2tCDDq3xXTzdaemjPRTL9Il1OPOPfk2j2fm9R8obfv/911BPua8pa2/SP/wQ57gPZeAPNX49TqafnfFTT/k+YVD+3T1IA706PrmjdNcuAAAAU93aA8tDbtc/Cb05+ewgfcPTBvA3+V+Sg73WAQAAJqyDBm2cD+pAr85IXpQs8boHAACYMH6fvDD5+iB+89MG+Df++8keyTw/AwAAAM39Ltk9+cGgFjBtwF8AlySzkkv9LAAAADTzq2Sn5NeDXMI0r4ORI+hzk7NVAQAAMO7OSnZO5g96EQZ6Z3myfxnAmxAAAAA0dFJyQLJCFQb6A9Xb+B+hBgAAgDF3mP1loD+U+g7OXyeLVQEAADDqFpXuqPkpqjDQH47/TnZJrlEFAADAqLkimVO6684x0B+2K5NnlQF9/h4AAMAoOyN5dnKtKgz0DTGcHJS8VxUAAAAb7MjkYDUY6KPhw8m+yV2qAAAAeNjqvb32Tk5UhYE+mr6XPCP5sSoAAAAe0g+TrW0oA32szCvduz8nqAIAAOBBfSDZJ5mvCgN9rB2V7J/crgoAAIB73Za8IDlaFQb6eDq7dHcg/LYqAAAAyrf6jfQjVRjoLSxIDkzekqxUBwAAMICWJ4clL0kWqsNAb+3kZKfkElUAAAAD5GfJzOQUVRjoE8lv+pF+nCoAAIABcEwyN7laFQb6RHVsP9QvVQUAADAFXVy6o+bHq8JAnwzqqe6zSnc0fbU6AACAKaBum/pEqznJr9VhoE+2F++xpXtn6WfqAAAAJrGLkh2SE5JhdRjok1W9Nr1el3FE6e5uCAAAMFnclbwx2SW5XB0G+lRxUvLM5KuqAAAAJoEzkq2TU1VhoE9FNyevTPZLblAHAAAwAV2bvDA5OLlFHQb6VPfd5OnJe5Nl6gAAACaAuk3eVbozf3+gDgN9kNSbyH24f/Gfrg4AAKCh05JnJB9ThYE+yH6XHJLskfxcHQAAwDi6INk1eXVxOruBzr3OLd3zBF+RXK8OAABgDF2XvDx5XnKhOgx01u1ryXOStyUL1QEAAIyi25LDkmcn31CHgc5Dq89L/1Ty1OSDyWKVAAAAf4K6KY5LtkpOSVaqxEBn/SxN3p9smXyidDeWAwAAeLjqwb+PJE9Ljk3uVomBzp/mzuQdpTui/k9+qAAAgIdQN8PH+2H+nmSRSgx0Rle94/s/lu60lHpE3anvAADA/dUhXo+Y17Nw31m6a84x0BlD9YesHlGvzyk8vnRH2AEAgMFVbzB9dLnviPl8lRjojK8FyTGlO/X9iOLxbAAAMGiuSg7vh/kHirNsDXSaW5KclGyd/E1ygUoAAGBKOz85ONkm+Uy/CTDQmUDqXd7/I3leskvy9eLO7wAAMFXck/xnMjfZLTlDJVPLRiqYsi5KDirdqS6vSw5NnqQWAACYdG5KTk2+ULobRzNFDR241VFaGAz1zZiXJa9P9lUHAABMaGuSbydfTP6rODPWQGfKenrpjqjXa1a2VAcAAEwY9cbP9TT2zyU3qsNAZ3DMSPZM3pAckDxKJQAAMO7qndfPLN0p7OeV7lpzBpBr0Adb/cH/fp+/SF5SuuvW9042Vg8AAIyZ5ckPkm/24/wOleAIOutSn6ter1d/ebJz8UYOAACMhnqA7MLS3X29DnM3fMNAZ71sleyXvLJ0j3Iw1gEA4OFbkfxP8tXku8kNKsFAZzQ8LXlhsk//8c9UAgAAf2BB8r3kR/0ov1klGOiMpUcne5Xu6PruybbJNLUAADCA6iPQLk/OSc5Kzk3uUgsGOk1eR/1Af37p7gY/N/lLtQAAMIXNS85PvlO6U9ivUgkGOhPRZsmc0t1gbtc+BjsAAJPZLf0gvyD5WXJxcrdaGE1u+MVYqKfz/KRPVZ+vPrMf6jslOybPKk6JBwBgYqqnrP8m+VVyST/K6/9ephoMdCa7pcl5fUo/zJ+ebF+6I+2zS3eK/JNKd7o8AACMl1Wlu4nblcnPS3d0/LLketUw3pzizkSxSbJNsnWfbfsBXx/ztpl6AAAYBb9Pru0HeB3kV/cfr0lWqofWHEFnolie/LLP/T0heUafetR9y+SpyZOTJyYzVAcAwP3U547f3Oe3yf8l1/XDvGaBijDQYcPM6/O/D/jrmyeP6wf8ln3qaK+nyT++dM9or3//McW17gAAU0U9yr04WdhnXj/Eb7rfGJ/fj3A3cMNAh3GypE/9F/GF6/j700t35/jH9iN9bR7Xpw78R/fZov91Pc1+0/7jJv0/Y1r/cbh018dPL66TB2DiWNP/mbWxKpgCLi3dndFX9CO8no6+qB/id/ZZ++sF/X+fgYEOk0C98+atfdbH2lG+Uf8fO/Xj2tPo6zB/RP/RHwgATAT1ErH6JvNJyb7qYJI7OTlVDRjowP2Hfc09xWM0AJgc6im++/Xj5nB1AExers0FAJga/j55fXGWF5OXywgx0FUAADBlfCHZpaz/JV4AGOgAAIyynyY7JOeqAsBABwCgrXqH6z1Kd/M4AAx0AAAaOyJ5U+kexwaAgQ4AQEOfS/ZKblMFgIEOAEBb9Xr07Ut3fToABjoAAA3dnuycfF4VAAY6AADtHZr8gxoADHQAANr752TPZIkqAAx0AADaOifZrrguHcBABwCguRuT3ZMvqwLAQAcAoK2VyWuS96gCwEAHAKC9jyT7J4tVAWCgAwDQ1tnJTsmlqgAw0AEAaOv6fqSfrgoAAx0AgLZWJYck71YFgIEOAEB7H01eUjwvHcBABwCguW8lc5OrVAFgoAMA0NaVyax+rANgoAMA0NCy0p3ufoIqAAx0AADaOyo5OBlWBYCBDgBAW2ckzyndI9kAMNABAGjoitI9L9116QAGOgAAjS0u3XXpH1UFgIEOAEB7705elaxQBYCBDgBAW19Jdk1uUAWAgQ4AQFuXJDOTH6oCwEAHAKCtel36PsknVQFgoAMA0N7bk9eqAcBABwCgvS8lOye3qgLAQAcAoK2fJjsm56sCwEAHAKCt+cluyWdVAWCgAwDQ3puTw5NhVQAY6AAAtPWZZM9koSoADHQAANo6N9mmuC4dwEAHAKC525Pdk39VBYCBDgBAW2uSv0veogoAAx0AgPZOTvZI7lAFYKADAEBb9br0WckvVAEY6AAA0NZNyezkNFUABjoAALT36uRdagAMdAAAaO9jyb7JUlUABjoAALT1vWRmcpkqAAMdAADauj6Zm5yhCsBABwCAtpYlBydHqQIw0AEAoL0TkpclS1QBGOgAANDWN5PnJteoAjDQAQCgrauTbZNvqAIw0AEAoK3VycuT41QBGOgAANDesaW7Lv0eVQAGOgAAtFWvS98xuVYVgIEOAABtXZ7MSb6jCsBABwCAthYlL04+oQrAQAcAgPbekbymdDeSAzDQAQCgoS8ns5MbVQEY6AAA0NavklnJD1UBGOgAANDWwmSf4rp0wEAHAIAJoV6X/rpklSoAAx0AANr6YvL85GZVAAY6AAC0dUGyQ3KeKgADHQAA2roz+avkFFUABjoAALR3WPImNQAGOgAAtPe5ZLfSHVUHMNABAKCh85Pt+o8ABjoAADR0S7JH8nlVAAY6AAC0VZ+RfmjydlUABjoAALT3yWTvZKEqAAMdAADa+nEyM/mFKgADHQAA2ro5mZN8SRWAgQ4AAG2tSV6bvE0VgIEOAADtfSp5UbJIFYCBDgAAbX0/eW5ymSoAAx0AANq6Ltkp+boqAAMdAADauic5KHm/KgADHQAA2vtg8tJkpSoAAx0AANo6M9kuuUoVgIEOAABtXZPMLq5LBwx0AABo7q7SXZf+AVUABjoAALR3dPKKZJkqAAMdAADa+lrpTnm/ThWAgQ4AAG1dkcxMvqMKwEAHAIC26nXpL05OVAVgoAMAQHtHJoeoATDQAQCgvdOTnZIbVAEY6AAA0NYlpbt53DmqAAx0AABo645kz+TTqgAMdAAAaO+tyRuSVaoADHQAAGjr35Ldk9tUARjoAADQ1oXJtsV16YCBDgAAzd1ZuuvST1IFGOgAAEB7RyRvVAMY6AAAQHunJs8rrksHAx0AAGjugmTH5CJVgIEOAAC0NS/ZJfmCKsBABwAA2nt96Z6ZDhjoAABAY59O9koWqwIMdAAAoK2fJDskF6sCDHQAAKCtG0t3h/fTVAEGOgAA0NbK5NXJO1UBBjoAANDex5MDkkWqAAMdAABo66xkdnK5KsBABwAA2ro+eU5yuirAQAcAANo7JDlSDWCgAwAA7Z2YHJjcrQow0AEAgLa+ncxKrlQFGOgAAEBbVydzkjNVAQY6AADQ1tLkpcmHVAEGOgAA0N77klcm96gCDHQAAKCtryY7JtepAgx0AACgrcuT2clZqgADHQAAaGtxckDpHscGGOgAAEBjRyaHJCtUAQY6AADQ1unJbslvVQEGOgAA0NbFyQ7JT1QBBjoAANDWkmSv5JOqAAMdAABo7+3J36oBDHQAAKC9f0/mJPNVAQY6AADQ1s+T7ZNzVAEGOgAA0FY9gl6vS/+MKsBABwAA2hpODu8zrA4w0AEAgLbqUfTdk9tVAQY6AADQ1nnJdslFqgADHQAAaKtel75r8nlVgIEOAAC0Va9FPzQ5TBVgoAMAAO2dkuyZLFAFGOgAAEBb9Tnpz00uUQUY6AAAQFs3JLOT01UBBjoAANBWvS79kORdqgADHQAAaO9jyf7JXaoAAx0AAGjr7NI9L/0yVYCBDgAAtPXbZE7yFVWAgQ4AALS1PHlV8j5VgIEOAAC096HkpckSVYCBDgAAtHVmMiu5ShVgoAMAAG1dl+zQj3XAQAcAABpaWbrT3Y9XBRjoAABAe8ckL0tWqwIMdAAAoK1vJjsm16gCDHQAAKCty5K5yXdVAQY6AADQ1qJkv+TT/a8fqRIG3UYqAAAAGnprcm1ylyoYdP8vwAD8nSrqT6R2+wAAAABJRU5ErkJggg==");
		/* Company logo */
		if (hexaImg.contains("data:image/png")) {
			Image img = Image.getInstance(Base64.decode(hexaImg.substring(hexaImg.indexOf(",") + 1)));
			temp = new PdfPCell(img, true);
			temp.setHorizontalAlignment(Element.ALIGN_RIGHT);
			temp.setBorderColor(BaseColor.WHITE);
			temp.setFixedHeight(75);
			imageTab.addCell(temp);
		}
		document.add(imageTab);
		String barCode = "";
		Account account = null;
		if (statement.getAccountId() != null) {
			account = accountRepository.findOne(statement.getAccountId());
			barCode = account.getPaymentCardNumber() == null ? "" : account.getPaymentCardNumber() + "";
		}
		StringBuilder accountAddressBuilder = new StringBuilder("");
		if (account != null) {
			BillablePerson person = billablePersonRepository.getBillablePersonForAccountId(account.getAccountId());
			if (person.getFirstName() != null && !person.getFirstName().equals(""))
				accountAddressBuilder.append(person.getFirstName()).append(",");
			accountAddressBuilder.append(person.getLastName()).append("\n");

			if (account.getAddress() != null) {

				if (account.getAddress().getAddressLine1() != null
						&& !account.getAddress().getAddressLine1().isEmpty()) {
					accountAddressBuilder.append(account.getAddress().getAddressLine1()).append("\n");
				}
				if (account.getAddress().getAddressLine2() != null
						&& !account.getAddress().getAddressLine2().isEmpty()) {
					accountAddressBuilder.append(account.getAddress().getAddressLine2()).append("\n");
				}
				if (account.getAddress().getAddressLine3() != null
						&& !account.getAddress().getAddressLine3().isEmpty()) {
					accountAddressBuilder.append(account.getAddress().getAddressLine3()).append("\n");
				}
				if (account.getAddress().getCountry() != null && !account.getAddress().getCountry().isEmpty()) {
					accountAddressBuilder.append(account.getAddress().getCountry()).append("\n");
				}
				if (account.getAddress().getPostCode() != null && !account.getAddress().getPostCode().isEmpty()) {
					accountAddressBuilder.append(account.getAddress().getPostCode()).append("\n");
				}
			}
		}

		/* This pdfContentbyte is needed for both barcode generation and footer text */
		PdfContentByte pdfContentByte = writer.getDirectContent();

		/* Generate bar code for payment at the Paypoint */
		Barcode128 barcode128 = new Barcode128();
		barcode128.setCode(barCode);
		barcode128.setCodeType(Barcode128.CODE128);
		Image code128Image = barcode128.createImageWithBarcode(pdfContentByte, null, null);
		code128Image.setAbsolutePosition(28, 775);
		code128Image.scalePercent(150);
		document.add(code128Image);

		/* Paypoint logo */
		Image img = Image.getInstance("C:\\Downloads\\pdf\\output\\pp.png");
		img.setAbsolutePosition(240, 776);
		img.scalePercent(8);
		document.add(img);

		Paragraph para = new Paragraph("Pay using this barcode at your nearest PayPoint store");
		para.setIndentationLeft(2.5f);
		document.add(para);
		document.add(new Paragraph("\n"));
		PdfPTable table = new PdfPTable(3);
		table.setWidthPercentage(100);
		StringBuilder builder = new StringBuilder();

		// builder.append("Ms Hilda Ellis").append("\n").append("c/o Hervin
		// Francis").append("\n")
		// .append("118 The
		// Nettlefolds").append("\n").append("Hadley").append("\n").append("Telford");
		PdfPCell cell = new PdfPCell(new Phrase(accountAddressBuilder.toString(), dataFont));
		cell.setBorderColor(BaseColor.WHITE);
		table.addCell(cell);
		cell = new PdfPCell();
		cell.setBorderColor(BaseColor.WHITE);
		table.addCell(cell);
		builder = new StringBuilder();
		builder.append("Account number: ").append(account.getAccountNumber()).append("\n");
		builder.append("Statement number: ").append(statementNumber).append("\n");

		builder.append("Statement date: ");

		if (statement.getCreationDate() != null) {
			String pattern = "yyyy-MM-dd";
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			builder.append(simpleDateFormat.format(statement.getCreationDate()));
		}
		builder.append("\n");
		cell = new PdfPCell(new Phrase(builder.toString(), dataFont));
		cell.setBorderColor(BaseColor.WHITE);
		table.addCell(cell);

		/* Adding the generated table to the document */
		document.add(table);
	}

	/**
	 * Populate the heading bar and the payment details
	 * 
	 * @param document
	 * @throws DocumentException
	 */
	private void renderHeadingAndPayment(Document document, PreStatement statement) throws DocumentException {
		document.add(new Paragraph("\n"));
		PdfPTable table = new PdfPTable(1);
		table.setWidthPercentage(100);

		Address propertyAddress = statement.getPropertyAddress();
		StringBuilder builder = new StringBuilder();
		if (propertyAddress != null) {
			if (statement.getPropertyAddress().getAddressLine1() != null
					&& !statement.getPropertyAddress().getAddressLine1().isEmpty()) {
				builder.append(statement.getPropertyAddress().getAddressLine1());
			}
			if (statement.getPropertyAddress().getAddressLine2() != null
					&& !statement.getPropertyAddress().getAddressLine2().isEmpty()) {
				builder.append(",");
				builder.append(statement.getPropertyAddress().getAddressLine2());
			}
			if (statement.getPropertyAddress().getAddressLine3() != null
					&& !statement.getPropertyAddress().getAddressLine3().isEmpty()) {
				builder.append(",");
				builder.append(statement.getPropertyAddress().getAddressLine3());
			}
			if (statement.getPropertyAddress().getRegion() != null
					&& !statement.getPropertyAddress().getRegion().isEmpty()) {
				builder.append(",");
				builder.append(statement.getPropertyAddress().getRegion());
			}
			if (statement.getPropertyAddress().getCountry() != null
					&& !statement.getPropertyAddress().getCountry().isEmpty()) {
				builder.append(",");
				builder.append(statement.getPropertyAddress().getCountry());
			}
			if (statement.getPropertyAddress().getPostCode() != null
					&& !statement.getPropertyAddress().getPostCode().isEmpty()) {
				builder.append(",");
				builder.append(statement.getPropertyAddress().getPostCode());
			}
		}

		PdfPCell cell = new PdfPCell(new Phrase(builder.toString(), headerFont));
		cell.setBackgroundColor(new BaseColor(0, 9, 23));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setPaddingBottom(5);
		table.addCell(cell);
		document.add(table);

		AccountBalance accountBalance = accountBalanceRepository.findByAccountId(statement.getAccountId());
		String balanceBroughtForward = "Balance brought forward: "
				+ (accountBalance == null ? 0 : accountBalance.getBalance());
		Paragraph paragraph = new Paragraph(balanceBroughtForward, boldFont);
		paragraph.setIndentationLeft(2.5f);
		document.add(paragraph);
		paragraph = new Paragraph("Payment(s) Received in Period");
		paragraph.setIndentationLeft(2.5f);
		document.add(paragraph);
		document.add(new Paragraph("\n"));

		table = new PdfPTable(4);
		table.setWidthPercentage(100);

		if (statement.getFromDate() != null && statement.getToDate() != null) {
			List<Financials> financials = this.financialRepository
					.getAllTransactionsBetweenTheDates(statement.getFromDate(), statement.getToDate());
			if (financials != null && financials.size() > 0) {
				addCell(table, "Payment Date", boldFont);
				addCell(table, "Payment Method", boldFont);
				addCell(table, "Amount", boldFont);
				addCell(table, "Reference", boldFont);
				String pattern = "yyyy-MM-dd";
				SimpleDateFormat formatter = new SimpleDateFormat(pattern);

				for (Financials financial : financials) {
					addCell(table, formatter.format(financial.getDate()), dataFont);

					if (financial.getPaymentMethod() != null)
						addCell(table, financial.getPaymentMethod().getMethod(), dataFont);
					else
						addCell(table, "N/A", dataFont);

					if (financial.getCredit() == 0)
						addCell(table, financial.getDebit() + "", dataFont);
					else
						addCell(table, financial.getCredit() + "", dataFont);
					addCell(table, financial.getReference(), dataFont);
				}

				document.add(table);
			} else {
				document.add(new Paragraph("\n"));
				document.add(new Paragraph("\n"));
			}
		} else {
			document.add(new Paragraph("\n"));
			document.add(new Paragraph("\n"));
		}

		String chargePeriod = "Your charges for the period of " + statement.getFromDate() + " to "
				+ statement.getToDate();

		paragraph = new Paragraph(chargePeriod, boldFont);
		paragraph.setIndentationLeft(2.5f);
		document.add(paragraph);
	}

	/**
	 * Box section
	 * 
	 * @param document
	 * @throws DocumentException
	 */
	private void renderBoxSection(Document document, PreStatement statement) throws DocumentException {
		float[] widths = { 0.2f, 0.25f, 0.05f, 0.1f, 0.2f, 0.2f };
		PdfPTable table = new PdfPTable(widths);
		table.setWidthPercentage(100);
		PdfPCell cell = new PdfPCell(new Phrase("Your charges split by utility type", boldFont));
		cell.setBorder(PdfPCell.NO_BORDER);
		cell.setBackgroundColor(new BaseColor(237, 237, 235));
		cell.setPadding(4);
		cell.setPaddingBottom(6);
		cell.setColspan(2);
		cell.setRowspan(1);
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		table.addCell(cell);

		cell = new PdfPCell();
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		cell = new PdfPCell();
		String statementDeclaration = "Statement issued by Welcome Energy on behalf of "
				+ clientRepository.getClientNameFromPropertyId(statement.getPropertyId());
		cell.addElement(new Phrase(statementDeclaration, boldFont));
		cell.addElement(new Paragraph("Payment of this bill is due within 28 days"));
		cell.addElement(new Phrase("Contact us", smallBoldFont));
		Phrase p = new Phrase("Telephone: 0203 744 9518\n", smallFont);
		p.add(new Chunk("E-mail: ", smallFont));
		p.add(new Chunk("help@welcomeenergy.co.uk", smallBlueFont));
		cell.addElement(p);
		cell.addElement(new Phrase("Payment Options", smallBoldFont));
		cell.addElement(new Phrase("www.welcomeenergy.co.uk", smallBlueFont));
		p = new Phrase("By Phone: 0800 368 9590\n", smallFont);
		p.add(new Chunk(
				"By Bank Transfer: Please quote your account number, payments to be made to Account Number: 25747151 Sort Code: 23-05-80 By Cash: At your nearest PayPoint location using the barcode at the top of this statement. See ",
				smallFont));
		p.add(new Chunk("www.paypoint.com", smallBlueFont));
		cell.addElement(p);
		cell.setBorderColor(BaseColor.BLACK);
		cell.setPadding(4);
		cell.setPaddingBottom(6);
		cell.setColspan(3);
		cell.setRowspan(6);
		table.addCell(cell);

		cell = new PdfPCell(new Paragraph("\n"));
		cell.setUseVariableBorders(true);
		cell.setBackgroundColor(BaseColor.WHITE);
		cell.setBorder(PdfPCell.NO_BORDER);
		cell.setColspan(2);
		cell.setRowspan(1);
		table.addCell(cell);

		cell = new PdfPCell();
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		List<PreStatementEnergy> preStatementEnergy = statement.getPreStatementEnergy();
		for (PreStatementEnergy energy : preStatementEnergy) {

			String usage = energy.getEnergy() + " £" + energy.getTotalUnitsUsed();
			cell = new PdfPCell(new Phrase(usage, boldFont));
			cell.setBorder(PdfPCell.NO_BORDER);
			cell.setColspan(2);
			cell.setBackgroundColor(new BaseColor(237, 237, 235));
			cell.setPadding(4);
			cell.setPaddingBottom(6);
			cell.setRowspan(1);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.addCell(cell);

			cell = new PdfPCell();
			cell.setBorder(PdfPCell.NO_BORDER);
			table.addCell(cell);
		}

		if (preStatementEnergy != null && preStatementEnergy.size() == 1) {
			cell = new PdfPCell(new Phrase("", dataFont));
			cell.setUseVariableBorders(true);
			cell.setBorder(PdfPCell.NO_BORDER);
			cell.setColspan(3);
			cell.setRowspan(3);
			table.addCell(cell);
		}

		document.add(table);
	}

	/**
	 * This is the bottom table for the page 1 of Statement
	 * 
	 * @param document
	 * @throws DocumentException
	 */
	private void renderBottomTable(Document document, PreStatement statement) throws DocumentException {
		float[] widths = { 0.35f, 0.1f, 0.05f, 0.1f, 0.2f, 0.2f };
		PdfPTable table = new PdfPTable(widths);
		table.setWidthPercentage(100);
		document.add(new Phrase("Subtotal", boldFont));

		PdfPCell cell = new PdfPCell(new Phrase("Total charges before VAT", dataFont));
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		cell = new PdfPCell(new Phrase("£" + statement.getTotalChargeBeforeVat(), dataFont));
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		addEmptyCell(table);

		cell = new PdfPCell();
		StringBuilder builder = new StringBuilder();
		/*
		 * builder.append("Your Direct Debit Details:").append("\n");
		 * builder.append("Type: Fixed").append("\n");
		 * builder.append("Amount: £30.00").append("\n");
		 * builder.append("Collection Date: 21/04/2019");
		 */
		if (statement.getCreationDate() != null) {
			Date date = new java.sql.Date(statement.getCreationDate().getTime() + 30l * 24l * 60l * 60l * 1000l);
			SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
			builder.append("Your payment is due by:").append("\n").append(format.format(date)).append("\n");
		} else {
			builder.append("Your payment is due by:").append("\n").append("N/A").append("\n");
		}
		cell.addElement(new Paragraph(builder.toString(), dataWhiteFont));
		cell.setBackgroundColor(new BaseColor(75, 34, 124));
		cell.setBorderColor(new BaseColor(75, 34, 124));
		cell.setRowspan(3);
		cell.setColspan(3);
		cell.setPaddingLeft(20);
		table.addCell(cell);

		cell = new PdfPCell(new Phrase("VAT at " + statement.getVat() + "%", dataFont));
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		cell = new PdfPCell(new Phrase("£" + statement.getVatAmount(), dataFont));
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		addEmptyCell(table);

		cell = new PdfPCell(new Phrase("Total invoice for this period(incl. VAT)", dataFont));
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		cell = new PdfPCell(new Phrase("£" + statement.getTotalCharge(), dataFont));
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		addEmptyCell(table);

		cell = new PdfPCell(new Phrase("Your new account balance to pay", dataFont));
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		AccountBalance accountBalance = accountBalanceRepository.findByAccountId(statement.getAccountId());
		double total = statement.getTotalCharge();
		if (accountBalance != null) {
			total += accountBalance.getBalance();
		}
		if (total < 0)
			cell = new PdfPCell(new Phrase("£0", dataFont));
		else
			cell = new PdfPCell(new Phrase("£" + total, dataFont));
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		cell = new PdfPCell(new Paragraph("\n"));
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);

		cell = new PdfPCell(new Paragraph("\n"));
		cell.setBorder(PdfPCell.NO_BORDER);
		cell.setColspan(3);
		table.addCell(cell);

		cell = new PdfPCell();
		cell.setBorder(PdfPCell.NO_BORDER);
		cell.setRowspan(3);
		cell.setColspan(3);
		table.addCell(cell);

		cell = new PdfPCell();
		Phrase p = new Phrase("Your new account balance to pay\n", dataWhiteFont);
		p.add(new Chunk("£" + total + (total < 0 ? "credit" : "debit"), dataWhiteFontLarge));
		p.add(new Chunk("\n\n"));
		cell.addElement(p);
		cell.setBackgroundColor(new BaseColor(75, 34, 124));
		cell.setBorderColor(new BaseColor(75, 34, 124));
		cell.setRowspan(3);
		cell.setColspan(3);
		cell.setPaddingLeft(20);
		table.addCell(cell);

		document.add(table);
	}

	private void addEmptyCell(PdfPTable table) {
		PdfPCell cell = new PdfPCell(new Paragraph("\n\n"));
		cell.setBorder(PdfPCell.NO_BORDER);
		table.addCell(cell);
	}

	private void addCell(PdfPTable table, String content, Font font) {
		content = content == null ? "" : content;
		PdfPCell cell = new PdfPCell(new Phrase(content, font));
		cell.setBorderColor(BaseColor.WHITE);
		cell.setPaddingBottom(5);
		table.addCell(cell);
	}

	private void addCell(PdfPTable table, String data, int colspan, int padding, Font font) {
		PdfPCell cell = new PdfPCell(new Phrase(data, font));
		if (colspan > 0)
			cell.setColspan(colspan);
		if (padding > 0)
			cell.setPadding(padding);
		cell.setPaddingBottom(5);
		table.addCell(cell);
	}

	/**
	 * This is the code for the generation of secondary page
	 * 
	 * @param document
	 * @param writer
	 * @throws IOException
	 * @throws DocumentException
	 */
	private void generateOtherSheets(Document document, PdfWriter writer, PreStatement statement)
			throws IOException, DocumentException {
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		List<PreStatementEnergy> preStatementEnergy = statement.getPreStatementEnergy();
		if (preStatementEnergy == null || preStatementEnergy.isEmpty())
			return;
		for (PreStatementEnergy energy : preStatementEnergy) {
			PdfPTable imageTab = new PdfPTable(2);
			imageTab.setWidthPercentage(100);
			PdfPCell temp = new PdfPCell(new Phrase(""));
			temp.setBorderColor(BaseColor.WHITE);
			imageTab.addCell(temp);

			/* Company Logo */
			Image img = Image.getInstance("C:\\Downloads\\pdf\\output\\welcome.png");
			temp = new PdfPCell(img, true);
			temp.setHorizontalAlignment(Element.ALIGN_RIGHT);
			temp.setBorderColor(BaseColor.WHITE);
			temp.setFixedHeight(75);
			imageTab.addCell(temp);
			document.add(imageTab);
			document.add(new Paragraph("\n"));

			PdfPTable table = new PdfPTable(5);
			table.setWidthPercentage(100);

			/* Heading */
			PdfPCell cell = new PdfPCell(new Phrase(energy.getEnergy() + "Used", headerFont));
			cell.setBackgroundColor(new BaseColor(0, 9, 23));
			cell.setColspan(5);
			cell.setPadding(3);
			cell.setPaddingBottom(5);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);

			String meterSerialNumber = "";
			if (statement.getMeterId() != null)
				meterSerialNumber = meterRepository.getMeterSerialForMeterId(statement.getMeterId());
			/* Row1 */
			addCell(table, "Meter serial number", 3, 3, dataFont);
			addCell(table, meterSerialNumber, 2, 3, dataFont);

			/* Row2 */
			addCell(table, "Tariff", 3, 3, dataFont);
			addCell(table, "Energy", 2, 3, dataFont);

			/* Row3 */
			addCell(table, "Charge period from " + statement.getFromDate() + " to " + statement.getToDate(), 5, 3,
					dataFont);

			/* Row4 */
			addCell(table, "Meter Readings", 5, 3, boldFont);

			List<PreReadings> meterReading = energy.getReading();
			if (meterReading != null && !meterReading.isEmpty()) {
				for (PreReadings reading : meterReading) {
					addCell(table, "Actual", 3, 3, dataFont);
					addCell(table, simpleDateFormat.format(reading.getReadingDateTime()), 0, 3, dataFont);
					addCell(table, (reading.getValue() == null ? 0 : reading.getValue()) + "kWh", 0, 3, dataFont);
				}
			} else {
				addCell(table, "Actual", 3, 3, dataFont);
				addCell(table, "N/A", 0, 3, dataFont);
				addCell(table, "N/A", 0, 3, dataFont);
			}
			/* Row5 */
			/*
			 * addCell(table, "Actual", 3, 3, dataFont); addCell(table, "30/04/2019", 0, 3,
			 * dataFont); addCell(table, "7278.0 kWh", 0, 3, dataFont);
			 */

			/* Row6 */
			/*
			 * addCell(table, "Actual", 3, 3, dataFont); addCell(table, "31/05/2019", 0, 3,
			 * dataFont); addCell(table, "7290.0 kWh", 0, 3, dataFont);
			 */

			/* Row7 */
			addCell(table, "Meter Units used in the charge period", 3, 3, boldFont);
			addCell(table, energy.getUnitsUsed() + "", 2, 3, dataFont);

			/* Row8 */
			addCell(table, "Price £/Unit", 3, 3, boldFont);
			addCell(table, energy.getUnitPricePerUnit() + "", 2, 3, dataFont);

			/* Row9 */
			addCell(table, "Units used", 3, 3, boldFont);
			addCell(table, energy.getUnitsUsed() + "", 2, 3, dataFont);

			/* Row10 */
			addCell(table, "Unit charge for " + statement.getNoOfDays() + " days", 3, 3, boldFont);
			addCell(table, "£" + energy.getTotalUnitsUsed(), 2, 3, dataFont);

			List<PreStandingCharge> standingChargeList = energy.getStandingChargeList();
			if (standingChargeList != null && !standingChargeList.isEmpty()) {
				for (PreStandingCharge charge : standingChargeList) {
					/* Row11 */
					addCell(table, "Price £/Day", 3, 3, boldFont);
					addCell(table, charge.getStandingCharge() + "", 2, 3, dataFont);

					/* Row12 */
					addCell(table, "Standing charge for " + statement.getNoOfDays() + " days", 3, 3, boldFont);
					addCell(table, charge.getTotalStandingCharge() + "", 2, 3, dataFont);
				}
			}
			/* Row13 */
			addCell(table, "Cost of " + energy.getEnergy() + " supplied. Total (excluding VAT)", 3, 3, boldFont);
			addCell(table, "£" + statement.getTotalChargeBeforeVat(), 2, 3, dataFont);
			document.add(table);
			document.add(new Paragraph("\n"));

			PdfPTable footerTable = new PdfPTable(1);
			footerTable.setWidthPercentage(100);
			PdfPCell footerCell = new PdfPCell(new Phrase("Compare your energy usage to your Neighbours", boldFont));
			footerCell.setBorderColor(new BaseColor(237, 237, 235));
			footerCell.setBackgroundColor(new BaseColor(237, 237, 235));
			footerCell.setPadding(4);
			footerCell.setPaddingBottom(6);
			footerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			footerTable.addCell(footerCell);
			document.add(footerTable);

			writeChartToPDF(generateBarChart(), 400, 200, writer);
			document.add(new Paragraph("\n\n\n\n\n\n\n\n\n\n\n\n"));
			this.generateFooterTable(document);
		}
	}

	private void generateFooterTable(Document document) throws DocumentException {
		PdfPTable table = new PdfPTable(3);
		table.setWidthPercentage(100);
		addCell(table, "Estimated Meter Reads", 0, 0, boldFont);
		addCell(table, "Do you have a complaint", 0, 0, boldFont);
		addCell(table, "Could you pay less?", 0, 0, boldFont);

		StringBuilder builder = new StringBuilder();

		addCell(table,
				"Estimated readings are based on your previous usage to date. If we do not hold details of your previous usage we base the readings on site average consumption levels",
				0, 0, dataFont);

		builder.append("Phone: 0203 744 9518").append("\n").append(
				"Email: help@welcomeenergy.co.uk or write to: Customer Services, Welcome Energy, Monarch House, 7-9 Stafford Road, Wallington, Surrey, SM6 9AN. We will respond to all complaints within 10 working days.");
		addCell(table, builder.toString(), 0, 0, dataFont);

		builder = new StringBuilder();
		builder.append("1. Thermostat – turning it down by 1\u00B0C, could reduce your heating bill by up to 10%")
				.append("\n");
		builder.append("2. Water efficient shower head – These reduce the amount of hot water used").append("\n")
				.append("3. Dripping taps put a constant demand on your system. Fix it to consume less");
		addCell(table, builder.toString(), 0, 0, dataFont);
		document.add(table);
	}

	private void writeChartToPDF(JFreeChart chart, float width, float height, PdfWriter writer) {
		try {
			PdfContentByte contentByte = writer.getDirectContent();
			PdfTemplate template = contentByte.createTemplate(width, height);
			Graphics2D graphics2d = new PdfGraphics2D(template, width, height);// template.createGraphics(width,
																				// height);
			Rectangle2D rectangle2d = new Rectangle2D.Double(0, 0, width, height);
			chart.getPlot().setBackgroundPaint(Color.WHITE);
			chart.draw(graphics2d, rectangle2d);
			graphics2d.dispose();
			contentByte.addTemplate(template, 100, 223);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static JFreeChart generateBarChart() {
		final String yours = "Yours";
		final String Peers = "Peers";

		final DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		dataset.addValue(1.0, yours, "Dec");
		dataset.addValue(3.0, yours, "Jan");
		dataset.addValue(5.0, yours, "Feb");
		dataset.addValue(5.0, yours, "Mar");
		dataset.addValue(5.0, yours, "Apr");
		dataset.addValue(5.0, yours, "May");

		dataset.addValue(4.0, Peers, "Dec");
		dataset.addValue(2.0, Peers, "Jan");
		dataset.addValue(2.0, Peers, "Feb");
		dataset.addValue(1.0, Peers, "Mar");
		dataset.addValue(5.0, Peers, "Apr");
		dataset.addValue(8.0, Peers, "May");

		JFreeChart chart = ChartFactory.createBarChart("", "Months         ", "Consumption", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		return chart;
	}

	private boolean isGreaterThan(Date date1, Date date2) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date1);
		int month1 = cal.get(Calendar.MONTH);
		int day1 = cal.get(Calendar.DAY_OF_MONTH);
		int year1 = cal.get(Calendar.YEAR);

		cal.setTime(date2);
		int month2 = cal.get(Calendar.MONTH);
		int day2 = cal.get(Calendar.DAY_OF_MONTH);
		int year2 = cal.get(Calendar.YEAR);
		if (year1 > year2) {
			return true;
		} else if (year1 == year2) {
			if (month1 > month2) {
				return true;
			} else if (month1 == month2) {
				if (day1 > day2) {
					return true;
				} else
					return false;
			} else
				return false;
		} else
			return false;
	}

	private boolean isEqualTo(Date date1, Date date2) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date1);
		int month1 = cal.get(Calendar.MONTH);
		int day1 = cal.get(Calendar.DAY_OF_MONTH);
		int year1 = cal.get(Calendar.YEAR);

		cal.setTime(date2);
		int month2 = cal.get(Calendar.MONTH);
		int day2 = cal.get(Calendar.DAY_OF_MONTH);
		int year2 = cal.get(Calendar.YEAR);
		if (year1 == year2)
			if (month1 == month2)
				if (day1 == day2)
					return true;
				else
					return false;
			else
				return false;
		else
			return false;
	}

	private boolean isLessThan(Date date1, Date date2) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date1);
		int month1 = cal.get(Calendar.MONTH);
		int day1 = cal.get(Calendar.DAY_OF_MONTH);
		int year1 = cal.get(Calendar.YEAR);

		cal.setTime(date2);
		int month2 = cal.get(Calendar.MONTH);
		int day2 = cal.get(Calendar.DAY_OF_MONTH);
		int year2 = cal.get(Calendar.YEAR);
		if (year1 < year2)
			return true;
		else if (year1 == year2) {
			if (month1 < month2) {
				return true;
			} else if (month1 == month2) {
				if (day1 < day2)
					return true;
				else
					return false;
			} else
				return false;
		} else
			return false;
	}
}
