package com.monarch.mabdeck.dto;

public interface IDto extends java.io.Serializable{

}
