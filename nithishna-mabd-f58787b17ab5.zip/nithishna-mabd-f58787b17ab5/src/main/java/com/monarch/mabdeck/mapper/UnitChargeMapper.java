package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.UnitChargeDto;
import com.monarch.mabdeck.entity.UnitCharge;

@Mapper
public abstract class UnitChargeMapper implements IBaseMapper<UnitChargeDto, UnitCharge>{
	public static final UnitChargeMapper INSTANCE = Mappers.getMapper(UnitChargeMapper.class);
	
	@Mappings({
		@Mapping(target = "tariff", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract UnitCharge convertToEntity(UnitChargeDto dto);

	@Mappings({
		@Mapping(target = "tariff", ignore = true)
	})
	public abstract UnitChargeDto convertToDTO(UnitCharge entity);
}
