package com.monarch.mabdeck.controller;

import java.security.Principal;
import java.util.Base64;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.UserDto;
import com.monarch.mabdeck.service.LoginService;
import com.monarch.mabdeck.util.Constants;

@RestController
public class LoginController {

	@Autowired
	private LoginService loginService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.LOGIN, method = RequestMethod.POST, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public boolean login(@RequestBody UserDto dto) {
		return loginService.validate(dto);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.USER, method = RequestMethod.POST, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public Principal user(HttpServletRequest request) {
		String authToken = request.getHeader("Authorization").substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		loginService.updateLastLoginDate(username);
		return ()-> username;
	}	
}