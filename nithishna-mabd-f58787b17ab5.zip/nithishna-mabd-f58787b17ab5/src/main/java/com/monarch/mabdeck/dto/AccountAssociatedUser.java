package com.monarch.mabdeck.dto;

public class AccountAssociatedUser implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long accountId;
	private String name;
	private String accountNumber;
	private String bandName;
	private int numberOfTariffs;
	private String clientName;
	private String networkName;
	private int numberOfProperties;
	private AddressDto billingAddress;
	private AddressDto propertyAddress;
	private AccountAssociatedUser tenant;
	public String getName() {
		return name;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public String getBandName() {
		return bandName;
	}
	public int getNumberOfTariffs() {
		return numberOfTariffs;
	}
	public String getClientName() {
		return clientName;
	}
	public String getNetworkName() {
		return networkName;
	}
	public int getNumberOfProperties() {
		return numberOfProperties;
	}
	public AddressDto getBillingAddress() {
		return billingAddress;
	}
	public AddressDto getPropertyAddress() {
		return propertyAddress;
	}
	public AccountAssociatedUser getTenant() {
		return tenant;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public void setBandName(String bandName) {
		this.bandName = bandName;
	}
	public void setNumberOfTariffs(int numberOfTariffs) {
		this.numberOfTariffs = numberOfTariffs;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}
	public void setNumberOfProperties(int numberOfProperties) {
		this.numberOfProperties = numberOfProperties;
	}
	public void setBillingAddress(AddressDto billingAddress) {
		this.billingAddress = billingAddress;
	}
	public void setPropertyAddress(AddressDto propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	public void setTenant(AccountAssociatedUser tenant) {
		this.tenant = tenant;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	
}
