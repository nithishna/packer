package com.monarch.mabdeck.dto;

import java.util.Date;

public class MeterDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long meterId;
	private String unit;
	private String meterType;
	private String manufacturer;
	private String model;
	private String location;
	private String serialNumber;
	private boolean childMeter;
	private String parentSerialNumber;
	private int pulseInputNumber;
	private String readingFrequency;
	private String readingImportFactor;
	private String initialReading;
	private String offset;
	private SupplyPointDto supply;
	private ClientDto client;
	private NetworkDto network;
	private PropertyDto property;
	private Date startDate;
	private Date endDate;

	public ClientDto getClient() {
		return client;
	}
	public void setClient(ClientDto client) {
		this.client = client;
	}
	public NetworkDto getNetwork() {
		return network;
	}
	public void setNetwork(NetworkDto network) {
		this.network = network;
	}
	public PropertyDto getProperty() {
		return property;
	}
	public void setProperty(PropertyDto property) {
		this.property = property;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public SupplyPointDto getSupply() {
		return supply;
	}
	public void setSupply(SupplyPointDto supply) {
		this.supply = supply;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getMeterType() {
		return meterType;
	}
	public void setMeterType(String meterType) {
		this.meterType = meterType;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public boolean isChildMeter() {
		return childMeter;
	}
	public void setChildMeter(boolean childMeter) {
		this.childMeter = childMeter;
	}
	public String getReadingFrequency() {
		return readingFrequency;
	}
	public void setReadingFrequency(String readingFrequency) {
		this.readingFrequency = readingFrequency;
	}
	public String getReadingImportFactor() {
		return readingImportFactor;
	}
	public void setReadingImportFactor(String readingImportFactor) {
		this.readingImportFactor = readingImportFactor;
	}
	public String getInitialReading() {
		return initialReading;
	}
	public void setInitialReading(String initialReading) {
		this.initialReading = initialReading;
	}
	public String getOffset() {
		return offset;
	}
	public void setOffset(String offset) {
		this.offset = offset;
	}
	public String getParentSerialNumber() {
		return parentSerialNumber;
	}
	public void setParentSerialNumber(String parentSerialNumber) {
		this.parentSerialNumber = parentSerialNumber;
	}
	public int getPulseInputNumber() {
		return pulseInputNumber;
	}
	public void setPulseInputNumber(int pulseInputNumber) {
		this.pulseInputNumber = pulseInputNumber;
	}
	public Long getMeterId() {
		return meterId;
	}
	public void setMeterId(Long meterId) {
		this.meterId = meterId;
	}
}
