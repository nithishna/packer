package com.monarch.mabdeck.dto;

public class ZeroConsumptionValidationDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long validationId;
	private boolean enabled;
	private int tolerance;
	private ValidationDto validation;
	public long getValidationId() {
		return validationId;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public int getTolerance() {
		return tolerance;
	}
	public void setValidationId(long validationId) {
		this.validationId = validationId;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public void setTolerance(int tolerance) {
		this.tolerance = tolerance;
	}
	public ValidationDto getValidation() {
		return validation;
	}
	public void setValidation(ValidationDto validation) {
		this.validation = validation;
	}

}
