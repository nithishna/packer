package com.monarch.mabdeck.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class CreditControlSetup implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long controlId;	
	
    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "client_id")
	private Client client;
	
	@OneToMany(mappedBy = "setup")
	private List<Stage> stage;

	public long getControlId() {
		return controlId;
	}

	public Client getClient() {
		return client;
	}

	public List<Stage> getStage() {
		return stage;
	}

	public void setControlId(long controlId) {
		this.controlId = controlId;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public void setStage(List<Stage> stage) {
		this.stage = stage;
	}
}
