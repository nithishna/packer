package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BankAccountHistory implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String sortCode;
	private long accountNumber;
	@Embedded
	private Audit audit;
	private Long bankId;
	private String accountHolderName;
	private Long clientId;
	private Long id;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long historyId;

	public String getSortCode() {
		return sortCode;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public Audit getAudit() {
		return audit;
	}

	public Long getBankId() {
		return bankId;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public Long getClientId() {
		return clientId;
	}

	public long getId() {
		return id;
	}

	public long getHistoryId() {
		return historyId;
	}

	public void setSortCode(String sortCode) {
		this.sortCode = sortCode;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}

	public void setBankId(Long bankId) {
		this.bankId = bankId;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setHistoryId(long historyId) {
		this.historyId = historyId;
	}

}
