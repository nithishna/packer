package com.monarch.mabdeck.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.UserDto;
import com.monarch.mabdeck.entity.UserDetails;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.UserDetailsMapper;
import com.monarch.mabdeck.repository.UserDetailsRepository;

@Component
@Transactional
public class LoginService{

	@Resource
	private UserDetailsRepository repository;
	
	public UserDetailsRepository getJPARepository() {
		return this.repository;
	}

	public IBaseMapper<UserDto, UserDetails> getMapper() {
		return UserDetailsMapper.INSTANCE;
	}
	
	public boolean validate(UserDto dto) {
		UserDetails user = repository.findByUsername(dto.getUsername());
		if(user != null) {
			if(user.getUsername().equalsIgnoreCase(dto.getUsername()) && user.getPassword().equals(dto.getPassword())) {
				Calendar cal = Calendar.getInstance();				
				user.setLastLoginDate(new Date(cal.getTime().getTime()));
				return true;
			}
		}
		return false;
	}

	
	public void updateLastLoginDate(String username) {
		UserDetails user = repository.findByUsername(username);
		if(user != null) {
			//valid user
			Calendar cal = Calendar.getInstance();
			user.setLastLoginDate(new Date(cal.getTime().getTime()));			
		}
	}
}
