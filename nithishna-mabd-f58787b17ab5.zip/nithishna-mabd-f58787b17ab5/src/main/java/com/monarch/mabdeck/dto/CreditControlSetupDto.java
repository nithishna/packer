package com.monarch.mabdeck.dto;

import java.util.List;

public class CreditControlSetupDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long controlId;
	private List<StageDto> stages;
	public long getControlId() {
		return controlId;
	}
	public List<StageDto> getStages() {
		return stages;
	}
	public void setControlId(long controlId) {
		this.controlId = controlId;
	}
	public void setStages(List<StageDto> stages) {
		this.stages = stages;
	}
}
