package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MeterHistory implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long meterId;
	private String unit;
	private String meterType;
	private String manufacturer;
	private String model;
	private String location;
	private String serialNumber;
	private boolean childMeter;
	private String parentSerialNumber;
	private int pulseInputNumber;
	private String readingFrequency;
	private String readingImportFactor;
	private String initialReading;
	private String offset;
	private Date startDate;
	private Date endDate;
	
	@Embedded
	private Audit audit;
	
	private long clientId;
	private long networkId;
	private long propertyId;
	private long supplyId;
	public Long getId() {
		return id;
	}
	public Long getMeterId() {
		return meterId;
	}
	public String getUnit() {
		return unit;
	}
	public String getMeterType() {
		return meterType;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public String getModel() {
		return model;
	}
	public String getLocation() {
		return location;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public boolean isChildMeter() {
		return childMeter;
	}
	public String getParentSerialNumber() {
		return parentSerialNumber;
	}
	public int getPulseInputNumber() {
		return pulseInputNumber;
	}
	public String getReadingFrequency() {
		return readingFrequency;
	}
	public String getReadingImportFactor() {
		return readingImportFactor;
	}
	public String getInitialReading() {
		return initialReading;
	}
	public String getOffset() {
		return offset;
	}
	public Date getStartDate() {
		return startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public Audit getAudit() {
		return audit;
	}
	public long getClientId() {
		return clientId;
	}
	public long getNetworkId() {
		return networkId;
	}
	public long getPropertyId() {
		return propertyId;
	}
	public long getSupplyId() {
		return supplyId;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setMeterId(Long meterId) {
		this.meterId = meterId;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public void setMeterType(String meterType) {
		this.meterType = meterType;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public void setChildMeter(boolean childMeter) {
		this.childMeter = childMeter;
	}
	public void setParentSerialNumber(String parentSerialNumber) {
		this.parentSerialNumber = parentSerialNumber;
	}
	public void setPulseInputNumber(int pulseInputNumber) {
		this.pulseInputNumber = pulseInputNumber;
	}
	public void setReadingFrequency(String readingFrequency) {
		this.readingFrequency = readingFrequency;
	}
	public void setReadingImportFactor(String readingImportFactor) {
		this.readingImportFactor = readingImportFactor;
	}
	public void setInitialReading(String initialReading) {
		this.initialReading = initialReading;
	}
	public void setOffset(String offset) {
		this.offset = offset;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public void setClientId(long clientId) {
		this.clientId = clientId;
	}
	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}
	public void setPropertyId(long propertyId) {
		this.propertyId = propertyId;
	}
	public void setSupplyId(long supplyId) {
		this.supplyId = supplyId;
	}
}
