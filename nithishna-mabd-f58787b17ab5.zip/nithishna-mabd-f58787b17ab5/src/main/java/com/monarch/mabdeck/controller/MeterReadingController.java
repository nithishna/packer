package com.monarch.mabdeck.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.Base64;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.MeterReadingDto;
import com.monarch.mabdeck.dto.MeterReadingItemDto;
import com.monarch.mabdeck.dto.MeterReadingSearchDto;
import com.monarch.mabdeck.service.MeterReadingService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;

@RestController
public class MeterReadingController {

	private Logger logger = LoggerFactory.getLogger(MeterReadingController.class);
	@Autowired
	private MeterReadingService service;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.METER_READING, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createMeterReading(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody MeterReadingDto dto) throws ParseException, InvalidFormatException {
		logger.info("MeterReadingController: createMeterReading - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("MeterReadingController: createMeterReading - Service call, Username : " + username);
		service.createNew(dto, username);
		logger.info("MeterReadingController: createMeterReading - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.METER_READING_TEMPLATE, method = RequestMethod.GET, produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> getReport(@PathVariable("network_id") Long networkId)
			throws IOException, InterruptedException {
		logger.info("MeterReadingController: getReport - Start");
		byte[] meterReadingTemplate = service.downloadTemplate(networkId);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "MeterReadingTemplate.csv");
		header.setContentLength(meterReadingTemplate.length);
		logger.info("MeterReadingController: getReport - End");
		return new HttpEntity<byte[]>(meterReadingTemplate, header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.UPLOAD_METER_READING_TEMPLATE, method = RequestMethod.POST, consumes = "multipart/form-data", produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> uploadBulkMeterReading(@RequestParam("file") MultipartFile file) throws IOException {
		logger.info("MeterReadingController: uploadBulkMeterReading - Start");
		byte[] result = service.uploadCSV(file);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "result.csv");
		header.setContentLength(result.length);
		logger.info("MeterReadingController: uploadBulkMeterReading - End");
		return new HttpEntity<byte[]>(result, header);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.METER_READING_FOR_ACCOUNT, method = RequestMethod.POST, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, consumes = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<MeterReadingItemDto>  getMeterReadingsForAccountId(@RequestBody MeterReadingSearchDto input) throws ParseException {
		logger.info("MeterReadingController: getMeterReadingsForAccountId - Start");
		return service.getAllMeterReadingsForAccount(input);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.METER_READING_FOR_PROPERTY, method = RequestMethod.POST, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, consumes = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<MeterReadingItemDto>  getMeterReadingsForProperty(@RequestBody MeterReadingSearchDto input) throws ParseException {
		logger.info("MeterReadingController: getMeterReadingsForProperty - Start");
		return service.getAllMeterReadingForProperty(input);
	}	
}
