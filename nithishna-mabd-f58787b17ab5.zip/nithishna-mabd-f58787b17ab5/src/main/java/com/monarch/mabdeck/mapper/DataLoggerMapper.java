package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.DataLoggerDto;
import com.monarch.mabdeck.entity.DataLogger;

@Mapper(uses = {ClientMapper.class, NetworkMapper.class})
public abstract class DataLoggerMapper implements IBaseMapper<DataLoggerDto, DataLogger>{
	public static final DataLoggerMapper INSTANCE = Mappers.getMapper(DataLoggerMapper.class);
	
	@Mappings({
		@Mapping(target = "audit", ignore = true)
	})
	public abstract DataLogger convertToEntity(DataLoggerDto dto);

}
