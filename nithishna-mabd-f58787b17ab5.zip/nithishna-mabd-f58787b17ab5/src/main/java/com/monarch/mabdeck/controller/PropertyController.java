package com.monarch.mabdeck.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.PropertyDto;
import com.monarch.mabdeck.dto.PropertyLimited;
import com.monarch.mabdeck.dto.PropertyListItemDto;
import com.monarch.mabdeck.service.PropertyService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class PropertyController {

	private Logger logger = LoggerFactory.getLogger(PropertyController.class);

	@Autowired
	private PropertyService propertyService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createProperty(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody PropertyDto Property) {
		logger.info("PropertyController: createProperty - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyController: createProperty - Service call, Username : " + username);
		propertyService.create(Property, username);
		logger.info("PropertyController: createProperty - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_PROPERTY_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody PropertyDto getPropertyById(@PathVariable("Property_id") Long PropertyId)
			throws NotFoundException {
		logger.info("PropertyController: getPropertyById - Start");
		return propertyService.read(PropertyId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyDto> getAllProperties() throws NotFoundException {
		logger.info("PropertyController: getAllProperties - Start");
		return propertyService.readAll();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_V2, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyDto> getAllPropertiesV2(@RequestParam("index")int index, @RequestParam("size")int pageSize) throws NotFoundException {
		logger.info("PropertyController: getAllPropertiesV2 - Start");
		return propertyService.readAll(index, pageSize);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_COUNT, method = RequestMethod.GET)
	public long propertyCount() {
		return propertyService.getCount();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.SUPPLY_PROPERTY, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyDto> getAllPropertiesForSupplies() {
		logger.info("PropertyController: getAllPropertiesForSupplies - Start");
		return propertyService.getAllPropertiesWithSupplies();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.SUPPLY_PROPERTY_V2, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyDto> getAllPropertiesForSuppliesWithStartAndEndIndex(@RequestParam("index")int index, @RequestParam("size")int pageSize){
		logger.info("PropertyController: getAllPropertiesForSupplies-v2 - Start");
		return propertyService.getAllPropertiesWithSuppliesV2(index, pageSize);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_LIST_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<PropertyListItemDto> getPropertyListForId(@PathVariable("property_id") Long propertyId) {
		logger.info("PropertyController: getPropertyListForId - Start");
		return propertyService.getPropertyListForId(propertyId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void updateProperty(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody PropertyDto Property) {
		logger.info("PropertyController: updateProperty - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyController: updateProperty - Service Call, Username : " + username);
		propertyService.update(Property, username);
		logger.info("PropertyController: updateProperty - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.PROPERTIES_TEMPLATE, method = RequestMethod.GET, produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> getReport(@RequestParam("client_id") Long clientId,
			@RequestParam("network_id") Long networkId, @RequestParam("band_id") Long bandId)
			throws IOException, InterruptedException {
		logger.info("PropertyController: getReport - Start");
		byte[] meterReadingTemplate = propertyService.downloadTemplate(clientId, networkId, bandId);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "propertiesTemplate.csv");
		header.setContentLength(meterReadingTemplate.length);
		logger.info("PropertyController: getReport - End");
		return new HttpEntity<byte[]>(meterReadingTemplate, header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.PROPERTIES_TEMPLATE, method = RequestMethod.POST, consumes = "multipart/form-data", produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> uploadBulkPropertyFile(@RequestParam("file") MultipartFile file) throws IOException {
		logger.info("PropertyController: uploadBulkPropertyFile - Start");
		byte[] result = propertyService.uploadCSV(file);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "result.csv");
		header.setContentLength(result.length);
		logger.info("PropertyController: uploadBulkPropertyFile - End");
		return new HttpEntity<byte[]>(result, header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_TO_MOVE_IN, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyDto> getAllPropertiesNotAssociatedWithAccountForNetwork(
			@RequestParam("account_id") Long accountId, @RequestParam("network_id") Long networkId) {
		logger.info("PropertyController: getAllPropertiesNotAssociatedWithAccountForNetwork - Start");
		return propertyService.getAllPropertiesNotAssociatedWithAccountForNetwork(accountId, networkId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_UNDER_MOVEMENT_OUTSIDE, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyDto> getAllPropertiesInTheProcessOfMovementOutside(@RequestParam("account_id") Long accountId,
			@RequestParam("network_id") Long networkId) {
		logger.info("PropertyController: getAllPropertiesInTheProcessOfMovementOutside - Start");
		return propertyService.getAllPropertiesUnderMovementOutside(accountId, networkId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_UNDER_MOVEMENT_INSIDE_OWNER, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyDto> getAllPropertiesUnderMovementInsideOwner(@RequestParam("account_id") Long accountId) {
		logger.info("PropertyController: getAllPropertiesUnderMovementInsideForOwner - Start");
		return propertyService.getAllPropertiesUnderMovementInsideForOwner(accountId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_UNDER_MOVEMENT_OUTSIDE_OWNER, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyDto> getAllPropertiesUnderMovementOutsideOwner(@RequestParam("account_id") Long accountId) {
		logger.info("PropertyController: getAllPropertiesUnderMovementOutsideForOwner - Start");
		return propertyService.getAllPropertiesUnderMovementOutsideForOwner(accountId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_UNDER_MOVEMENT_INSIDE, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyDto> getAllPropertiesInTheProcessOfMovementInside(@RequestParam("account_id") Long accountId,
			@RequestParam("network_id") Long networkId) {
		logger.info("PropertyController: getAllPropertiesInTheProcessOfMovementInside - Start");
		return propertyService.getAllPropertiesUnderMovementInside(accountId, networkId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_LIST, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyListItemDto> getPropertyListItemForAccountId(@RequestParam("account_id") Long accountId) {
		logger.info("PropertyController: getPropertyListItemForAccountId - start");
		return propertyService.getPropertyListItemForAccountId(accountId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_OWNER_LIST, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyLimited> getAllPropertiesWithOwnerAndTenant(){
		logger.info("PropertyController: getAllPropertiesWithOwnerAndTenant - start");
		return propertyService.getAllPropertiesWithOwnerAndTenant();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_BY_NETWORK, method = RequestMethod.POST, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, consumes = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyLimited> getAllPropertiesForNetwork(@RequestBody List<Long> networkIds) {
		logger.info("PropertyController: getAllPropertiesForNetwork - start");
		return propertyService.getAllPropertiesForNetwork(networkIds);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_BY_NAME, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyLimited> getAllPropertiesByName(@RequestParam("name") String name){
		logger.info("PropertyController: getAllPropertiesByName - Start");
		return propertyService.getAllPropertiesByName(name);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_BY_CLIENT_NETWORK_BAND, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyDto> getAllPropertiesByClientIdAndNetworkIdAndBandId(@PathVariable("client_id")long clientId, @PathVariable("network_id")long networkId, @PathVariable("band_id")long bandId){
		logger.info("PropertyController: getAllPropertiesBy client and network and band");
		return propertyService.getAllPropertiesByClientIdAndNetworkIdAndBandId(clientId, networkId, bandId);
	}
}
