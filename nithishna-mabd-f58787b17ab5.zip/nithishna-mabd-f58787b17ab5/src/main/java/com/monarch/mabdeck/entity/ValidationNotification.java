package com.monarch.mabdeck.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ValidationNotification implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long validationId;
	private String emailIds;
	public long getValidationId() {
		return validationId;
	}
	public String getEmailIds() {
		return emailIds;
	}
	public void setValidationId(long validationId) {
		this.validationId = validationId;
	}
	public void setEmailIds(String emailIds) {
		this.emailIds = emailIds;
	}
}
