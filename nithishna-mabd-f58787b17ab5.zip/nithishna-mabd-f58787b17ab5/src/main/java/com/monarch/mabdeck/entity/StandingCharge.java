package com.monarch.mabdeck.entity;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class StandingCharge implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long standingChargeId;
	
	private String name;
	private float dailyNetCharge;
	
	@ManyToOne(cascade = CascadeType.ALL, targetEntity = Tariff.class, fetch = FetchType.EAGER)
	@JoinColumn(name="tariffId",referencedColumnName="tariffId", insertable = true, updatable = true)
	private Tariff tariff;
	
	@Embedded
	private Audit audit;
	
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Long getStandingChargeId() {
		return standingChargeId;
	}
	public void setStandingChargeId(Long standingChargeId) {
		this.standingChargeId = standingChargeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getDailyNetCharge() {
		return dailyNetCharge;
	}
	public void setDailyNetCharge(float dailyNetCharge) {
		this.dailyNetCharge = dailyNetCharge;
	}
	public Tariff getTariff() {
		return tariff;
	}
	public void setTariff(Tariff tariff) {
		this.tariff = tariff;
	}

}
