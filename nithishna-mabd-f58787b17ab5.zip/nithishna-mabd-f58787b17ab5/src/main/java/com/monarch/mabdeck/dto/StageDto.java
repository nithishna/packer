package com.monarch.mabdeck.dto;

import java.util.List;

public class StageDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long stageId;
	private String name;
	private boolean overDue;
	private int noOfDays;
	private List<ActionDto> actions;
	public long getStageId() {
		return stageId;
	}
	public String getName() {
		return name;
	}
	public boolean isOverDue() {
		return overDue;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public List<ActionDto> getActions() {
		return actions;
	}
	public void setStageId(long stageId) {
		this.stageId = stageId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setOverDue(boolean overDue) {
		this.overDue = overDue;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public void setActions(List<ActionDto> actions) {
		this.actions = actions;
	}
}
