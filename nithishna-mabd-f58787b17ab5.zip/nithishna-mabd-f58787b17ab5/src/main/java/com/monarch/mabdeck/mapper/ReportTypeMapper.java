package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.ReportTypeDto;
import com.monarch.mabdeck.entity.ReportType;

@Mapper
public abstract class ReportTypeMapper  implements IBaseMapper<ReportTypeDto, ReportType>{

	public static final ReportTypeMapper INSTANCE = Mappers.getMapper(ReportTypeMapper.class);
	
	public abstract ReportTypeDto convertToDTO(ReportType entity);

	public abstract ReportType convertToEntity(ReportTypeDto dto);
	
}
