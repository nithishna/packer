package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Tariff;

@Repository
public interface TariffRepository extends JpaRepository<Tariff, Long>{

	@Query(value = "select count(*) as count from tariff where property_id=?1", nativeQuery = true)
	int getTariffCountForPropertyId(Long propertyId);
	
	@Query(value="select * from \r\n" + 
			"tariff \r\n" + 
			"where band_id=?3 and deleted=0 and (cast(active_from_date as date)<=?1 and (cast(active_to_date as date)>=?2 or active_to_date is null))", nativeQuery = true)
	Tariff getTariffForRange(String startDate, String endDate, long bandId);
	
	@Query(value="select * from \r\n" + 
			"tariff \r\n" + 
			"where band_id=?3 and deleted=0 and \r\n" + 
			"(cast(active_from_date as date) <=?1 and cast(active_to_date as date) >?1 and cast(active_to_Date as date) < ?2) or\r\n" + 
			"(cast(active_from_date as date) > ?1 and cast(active_from_date as date)<?2 and (active_to_date is null or cast(active_to_date as date)<=?2 or cast(active_to_date as date)>?2))\r\n" + 
			"order by active_from_date", nativeQuery = true)
	List<Tariff> getTariffsForRange(String startDate, String endDate, long bandId);
	
	
	@Query(value="select * from tariff \r\n" + 
			"where \r\n" + 
			"(active_from_date<=?1 and (active_to_date>?1 or active_to_date is null) and (active_to_date >=?2 or active_to_date <= ?2 or active_to_date is null))\r\n" + 
			"or\r\n" + 
			"(active_from_date >=?1 and active_from_date<?2 and (active_to_date is null or active_to_date>?2 or active_to_date < ?2)) and supply_type=?3 and band_id=?4 and deleted=0", nativeQuery = true)
	List<Tariff> getOverLappingTariff(String startDate, String endDate, String supplyType, long bandId);
	
	@Query(value="select * from tariff where active_from_date <= ?1 and (active_to_date > ?1 or active_to_date is null) and supply_type=?2 and band_id=?3 and deleted=0", nativeQuery = true)
	List<Tariff> getOverLappingTariff(String startDate, String supplyType, long bandId);
}