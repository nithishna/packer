package com.monarch.mabdeck.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.DataLoggerDto;
import com.monarch.mabdeck.service.DataLoggerService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class DataLoggerController {
	private Logger logger = LoggerFactory.getLogger(DataLoggerController.class);

	@Autowired
	private DataLoggerService dataLoggerService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.DATALOGGER, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createDataLogger(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody DataLoggerDto DataLogger) {
		logger.info("DataLoggerController: createDataLogger - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("DataLoggerController: createDataLogger - Service call, Username : " + username);
		dataLoggerService.create(DataLogger, username);
		logger.info("DataLoggerController: createDataLogger - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.DATALOGGER, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void updateDataLogger(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody DataLoggerDto DataLogger) {
		logger.info("DataLoggerController: updateDataLogger - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("DataLoggerController: updateDataLogger - Service call, Username : " + username);
		dataLoggerService.update(DataLogger, username);
		logger.info("DataLoggerController: updateDataLogger - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_DATALOGGER_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody DataLoggerDto getDataLoggerById(@PathVariable("DataLogger_id") Long DataLoggerId)
			throws NotFoundException {
		logger.info("DataLoggerController: getDataLoggerById - Start");
		return dataLoggerService.read(DataLoggerId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.DATALOGGER, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<DataLoggerDto> getAllDataLoggers() throws NotFoundException {
		logger.info("DataLoggerController: getAllDataLoggers - Start");
		return dataLoggerService.readAll();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.DATALOGGER_TEMPLATE, method = RequestMethod.GET, produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> getDataLoggerTemplate(@RequestParam("client_id") Long clientId,
			@RequestParam("network_id") Long networkId) throws IOException, InterruptedException {
		logger.info("DataLoggerController: getDataLoggerTemplate - Start");
		byte[] dataLoggerTemplate = dataLoggerService.downloadDataLoggerTemplate(clientId, networkId);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "DataLoggerTemplate.csv");
		header.setContentLength(dataLoggerTemplate.length);
		logger.info("DataLoggerController: getDataLoggerTemplate - End");
		return new HttpEntity<byte[]>(dataLoggerTemplate, header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.DATALOGGER_TEMPLATE, method = RequestMethod.POST, consumes = "multipart/form-data")
	public void uploadBulkDataLoggerFile(@RequestParam("file") MultipartFile file) throws IOException {
		logger.info("DataLoggerController: uploadBulkDataLoggerFile - Start");
		dataLoggerService.uploadCSV(file);
	}
}
