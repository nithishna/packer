package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class TariffHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long tariffId;
	private String tariffType;
	private String supplyType;
	private String tariffName;
	private String tariffCode;
	private float vatRate;
	private Date activeFromDate;
	private Date activeToDate;
	private int deleted;
	private Long propertyId;
	private Long bandId;
	@Embedded
	private Audit audit;
	public Long getTariffId() {
		return tariffId;
	}
	public String getTariffType() {
		return tariffType;
	}
	public String getSupplyType() {
		return supplyType;
	}
	public String getTariffName() {
		return tariffName;
	}
	public String getTariffCode() {
		return tariffCode;
	}
	public float getVatRate() {
		return vatRate;
	}
	public Date getActiveFromDate() {
		return activeFromDate;
	}
	public Date getActiveToDate() {
		return activeToDate;
	}
	public int getDeleted() {
		return deleted;
	}
	public Long getPropertyId() {
		return propertyId;
	}
	public Long getBandId() {
		return bandId;
	}
	public Audit getAudit() {
		return audit;
	}
	public void setTariffId(Long tariffId) {
		this.tariffId = tariffId;
	}
	public void setTariffType(String tariffType) {
		this.tariffType = tariffType;
	}
	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}
	public void setTariffName(String tariffName) {
		this.tariffName = tariffName;
	}
	public void setTariffCode(String tariffCode) {
		this.tariffCode = tariffCode;
	}
	public void setVatRate(float vatRate) {
		this.vatRate = vatRate;
	}
	public void setActiveFromDate(Date activeFromDate) {
		this.activeFromDate = activeFromDate;
	}
	public void setActiveToDate(Date activeToDate) {
		this.activeToDate = activeToDate;
	}
	public void setDeleted(int deleted) {
		this.deleted = deleted;
	}
	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}
	public void setBandId(Long bandId) {
		this.bandId = bandId;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
}
