package com.monarch.mabdeck.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.AccountDto;
import com.monarch.mabdeck.dto.AccountLimitedDto;
import com.monarch.mabdeck.service.AccountService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class AccountController {

	private Logger logger = LoggerFactory.getLogger(AccountController.class);

	@Autowired
	private AccountService accountService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ACCOUNT, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createAccount(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody AccountDto account) {
		logger.info("AccountController: createAccount - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("AccountController: createAccount - Service Call, Username : " + username);
		accountService.create(account, username);
		logger.info("AccountController: createAccount - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_ACCOUNT_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody AccountDto getAccountById(@PathVariable("account_id") Long accountId)
			throws NotFoundException {
		logger.info("AccountController: getAccountById - Start");
		return accountService.read(accountId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ACCOUNT, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<AccountDto> getAllAccounts() throws NotFoundException {
		logger.info("AccountController: getAllAccounts - Start");
		return accountService.readAllAccounts();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ACCOUNT_V2, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<AccountDto> getAllAccountsV2(@RequestParam("index")int index, @RequestParam("size")int pageSize) throws NotFoundException {
		logger.info("AccountController: getAllAccountsV2 - Start");
		return accountService.readAllAccountsV2(index, pageSize);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ACCOUNT_COUNT, method = RequestMethod.GET)
	public long accountCount() {
		return accountService.getCount();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FETCH_ACCOUNT, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<AccountLimitedDto> fetchAllAccounts() throws NotFoundException {
		logger.info("AccountController: fetchAllAccounts - Start");
		return accountService.getAllAccounts();
	}
	
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FETCH_ACCOUNT_UNDER_NETWORK, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<AccountLimitedDto> getAllAccountsUnderClientAndNetworkForProperty(@PathVariable("property_id")Long propertyId) {
		logger.info("AccountController: getAllAccountsUnderClientAndNetworkForProperty - Start");
		return accountService.getAllAccountsUnderClientAndNetworkForProperty(propertyId);		
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ACCOUNT, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void updateAccount(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody AccountDto account) {
		logger.info("AccountController: updateAccount - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("AccountController: updateAccount - Service Call, Username : " + username);
		accountService.update(account, username);
		logger.info("AccountController: updateAccount - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CUSTOMER_MOOD, method = RequestMethod.PUT)
	public void updateCustomerMood(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestParam("account_id") Long accountId, @RequestParam("mood") String mood) throws IOException {
		logger.info("AccountController: updateCustomerMood - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("AccountController: updateCustomerMood - Service Call, Username : " + username);
		accountService.updateMoodForAccount(accountId, username, mood);
		logger.info("AccountController: updateCustomerMood - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ACCOUNT_STATUS, method = RequestMethod.PUT)
	public void updateAccountStatus(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestParam("account_id") Long accountId, @RequestParam("status") String status) throws IOException {
		logger.info("AccountController: updateAccountStatus - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("AccountController: updateAccountStatus - Service Call, Username : " + username);
		accountService.updateAccountStatus(accountId, username, status);
		logger.info("AccountController: updateAccountStatus - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.ACCOUNT_TEMPLATE, method = RequestMethod.GET, produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> getDataLoggerTemplate(@RequestParam("client_id") Long clientId,
			@RequestParam("network_id") Long networkId) throws IOException, InterruptedException {
		logger.info("AccountController: getDataLoggerTemplate - Start");
		byte[] accountTemplate = accountService.downloadAccountTemplate(clientId, networkId);
		logger.info("AccountController: getDataLoggerTemplate - End of Service Call");
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "AccountTemplate.csv");
		header.setContentLength(accountTemplate.length);
		return new HttpEntity<byte[]>(accountTemplate, header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.ACCOUNT_TEMPLATE, method = RequestMethod.POST, consumes = "multipart/form-data", produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> uploadBulkAccountFile(@RequestParam("file") MultipartFile file) throws IOException {
		logger.info("AccountController: uploadBulkAccountFile - Start");
		byte[] result = accountService.uploadCSV(file);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "result.csv");
		header.setContentLength(result.length);
		logger.info("AccountController: uploadBulkAccountFile - End");
		return new HttpEntity<byte[]>(result, header);
	}
}
