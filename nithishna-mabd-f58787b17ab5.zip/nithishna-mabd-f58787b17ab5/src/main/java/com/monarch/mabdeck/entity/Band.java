package com.monarch.mabdeck.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Band implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long bandId;
	
	@ManyToOne(cascade = CascadeType.ALL, targetEntity = Client.class, fetch = FetchType.EAGER)
	@JoinColumn(name="clientId",referencedColumnName="clientId", insertable = true, updatable = true)
	private Client client;
	
	@ManyToOne(cascade = CascadeType.ALL, targetEntity = Network.class, fetch = FetchType.EAGER)
	@JoinColumn(name="networkId",referencedColumnName="networkId", insertable = true, updatable = true)
	private Network network;
	
	@OneToMany(mappedBy="band")
	private List<Property> property;
	
	private String bandName;
	private String bandType;
	private Date startDate;
	private Date endDate;
	private int propertyPart1;
	private int propertyPart2;
	private String propertyUnit;
	private int numberOfBedroom;
	
	
	@OneToMany(mappedBy="band")
	private List<AdminCharge> adminCharge;
	
	@OneToMany(mappedBy="band")
	private List<Tariff> tariff;
	
	@Embedded
	private Audit audit;
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public Network getNetwork() {
		return network;
	}
	public void setNetwork(Network network) {
		this.network = network;
	}
	public String getBandName() {
		return bandName;
	}
	public void setBandName(String bandName) {
		this.bandName = bandName;
	}
	public String getBandType() {
		return bandType;
	}
	public void setBandType(String bandType) {
		this.bandType = bandType;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public long getBandId() {
		return bandId;
	}
	public void setBandId(long bandId) {
		this.bandId = bandId;
	}
	public List<Property> getProperty() {
		return property;
	}
	public void setProperty(List<Property> property) {
		this.property = property;
	}
	public List<AdminCharge> getAdminCharge() {
		return adminCharge;
	}
	public void setAdminCharge(List<AdminCharge> adminCharge) {
		this.adminCharge = adminCharge;
	}
	public List<Tariff> getTariff() {
		return tariff;
	}
	public void setTariff(List<Tariff> tariff) {
		this.tariff = tariff;
	}
	public int getPropertyPart1() {
		return propertyPart1;
	}
	public void setPropertyPart1(int propertyPart1) {
		this.propertyPart1 = propertyPart1;
	}
	public int getPropertyPart2() {
		return propertyPart2;
	}
	public void setPropertyPart2(int propertyPart2) {
		this.propertyPart2 = propertyPart2;
	}
	public String getPropertyUnit() {
		return propertyUnit;
	}
	public void setPropertyUnit(String propertyUnit) {
		this.propertyUnit = propertyUnit;
	}
	public int getNumberOfBedroom() {
		return numberOfBedroom;
	}
	public void setNumberOfBedroom(int numberOfBedroom) {
		this.numberOfBedroom = numberOfBedroom;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
}
