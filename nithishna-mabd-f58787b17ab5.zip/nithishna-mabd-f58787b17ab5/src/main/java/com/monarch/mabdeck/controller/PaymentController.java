package com.monarch.mabdeck.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.service.PaymentService;
import com.monarch.mabdeck.util.Constants;

@RestController
public class PaymentController {

	@Autowired
	private PaymentService service;
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value=Constants.PAYMENT_TEMPLATE,method = RequestMethod.GET, produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> getReport(@RequestParam("network_id") Long networkId, @RequestParam("transaction_type_id") Long transactionTypeId, @RequestParam("payment_method_id") Long paymentMethodId) throws IOException, InterruptedException {
		byte[] meterReadingTemplate = service.downloadTemplate(networkId, transactionTypeId, paymentMethodId);
	    HttpHeaders header = new HttpHeaders();
	    header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "paymentTemplate.csv");
	    header.setContentLength(meterReadingTemplate.length);
	    return new HttpEntity<byte[]>(meterReadingTemplate, header);
	}
}
