package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.UserDto;
import com.monarch.mabdeck.entity.UserDetails;

@Mapper
public abstract class UserDetailsMapper implements IBaseMapper<UserDto, UserDetails>{
	public static final UserDetailsMapper INSTANCE = Mappers.getMapper(UserDetailsMapper.class);

	@Mappings({
		@Mapping(target = "audit", ignore = true)
	})
	public abstract UserDetails convertToEntity(UserDto dto);
}