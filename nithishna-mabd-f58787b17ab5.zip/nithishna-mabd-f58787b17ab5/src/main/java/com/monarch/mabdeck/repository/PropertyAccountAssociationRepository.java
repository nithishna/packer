package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.PropertyAccountAssociation;

@Repository
public interface PropertyAccountAssociationRepository extends JpaRepository<PropertyAccountAssociation, Long> {

	@Query(value = "select * from property_account_association where tenure_type=?2 and account_id=?1 and deleted=0 and move_in_status='Completed' and (move_out_status not in ('Completed') or move_out_status is null)", nativeQuery = true)
	List<PropertyAccountAssociation> getAllAssociationsForAccountId(Long accountId, String tenuretype);

	@Query(value = "select * from property_account_association where account_id=?1 and property_id=?2 and tenure_type=?3 and deleted=0", nativeQuery = true)
	PropertyAccountAssociation getAssociationForAccountIdAndPropertyId(Long accountId, Long propertyId, String tenure);

	@Query(value = "select * from property_account_association where account_id=?1 and association_id=?2 and tenure_type=?3 and deleted=0", nativeQuery = true)
	PropertyAccountAssociation getAssociationForPropertyAndAccount(Long accountId, Long associationId, String tenure);

	@Query(value = "select * from Property_account_association where association_id=?1 and tenure_type=?2 and deleted=0", nativeQuery = true)
	PropertyAccountAssociation getAssociationByAssociationIdForOwner(Long associationId, String tenure);

	@Query(value = "select * from property_account_association where property_id=?1 and tenure_type=?2 and deleted=0 and move_in_status='Completed'", nativeQuery = true)
	PropertyAccountAssociation getAssociationForProperty(long propertyId, String tenure);

	@Query(value = "select count(distinct meter_id) from account a, property p, property_account_association pa, supply_point sp, meter m where a.account_id = pa.account_id and p.property_id = pa.property_id and sp.property_id = p.property_id and m.supply_id = sp.supply_id and pa.account_id = ?1 and pa.association_id = ?2", nativeQuery = true)
	int sanityCheckForMeterAssociatedToProperty(Long accountId, Long associationId);

	@Query(value = "select count(*) from property_account_association where property_id= (select property_id from property_account_association where association_id=?1) and tenure_type = ?2", nativeQuery = true) // owner
	int sanityCheckForUserAssociatedToProperty(Long associationId, String tenure);

	@Query(value = "select count(*) from property_account_association where property_id= (select property_id from property_account_association where association_id=?1) and tenure_type=?2 and (end_date is null or end_date > (select cast(start_date as date) as start_date from property_account_association where association_id=?1))", nativeQuery = true)
	int previousTenancyCheck(Long associationId, String tenure);

	@Query(value = "select * from property_account_association where deleted = 0 and start_date < ?3 and (end_date is null or end_date > ?3) and property_id = (select property_id from property_account_association where association_id=?1) and tenure_type=?2 and (end_date is null or end_date > (select cast(start_date as date) as start_date from property_account_association where association_id=?1))", nativeQuery = true)
	List<PropertyAccountAssociation> getActiveTenantForProperty(Long associationId, String tenureType, String endDate);

	@Query(value = "select count(*) from property_account_association pa, account a, property p, supply_point s, meter m, meter_reading mr where pa.property_id = p.property_id and pa.account_id = a.account_id and p.property_id = s.property_id and s.supply_id = m.supply_id and m.meter_id = mr.meter_id and CAST(mr.reading_date_time AS DATE)=cast(cast(?1 as dateTime) -1 as date) and pa.association_id = ?2", nativeQuery = true)
	int getPreviousDayMeterReadingForAssociation(String startDate, Long associationId);

	@Query(value = "select count(*) from property_account_association pa, account a, property p, supply_point s, meter m, meter_reading mr where pa.property_id = p.property_id and pa.account_id = a.account_id and p.property_id = s.property_id and s.supply_id = m.supply_id and m.meter_id = mr.meter_id and CAST(mr.reading_date_time AS DATE)=cast(?1 as date) and pa.association_id = ?2", nativeQuery = true)
	int getCurrentDayMeterReadingFromAssociation(String startDate, Long associationId);

	@Query(value = "select count(*) from property_account_association pa, account a, property p, supply_point s, meter m, meter_reading mr where pa.property_id = p.property_id and pa.account_id = a.account_id and p.property_id = s.property_id and s.supply_id = m.supply_id and m.meter_id = mr.meter_id and CAST(mr.reading_date_time AS DATE)=cast(pa.start_date-1 as date) and pa.account_id=?1 and pa.association_id = ?2", nativeQuery = true)
	int getPreviousMeterReadingForAccountAndProperty(Long accountId, Long associationId);

	@Query(value = "select count(*) from property_account_association pa, account a, property p, supply_point s, meter m, meter_reading mr where pa.property_id = p.property_id and pa.account_id = a.account_id and p.property_id = s.property_id and s.supply_id = m.supply_id and m.meter_id = mr.meter_id and CAST(mr.reading_date_time AS DATE)=cast(pa.start_date as date) and pa.account_id=?1 and pa.association_id = ?2", nativeQuery = true)
	int getCurrentMeterReadingForAccountAndProperty(Long accountId, Long associationId);

	@Query(value = "select count(*) from property_account_association pa, account a, property p, supply_point s, meter m, meter_reading mr where  pa.property_id = p.property_id  and pa.account_id = a.account_id  and p.property_id = s.property_id  and s.supply_id = m.supply_id and m.meter_id = mr.meter_id  and CAST(mr.reading_date_time AS DATE)=cast(pa.end_date-1 as date) and pa.account_id=?1 and pa.association_id=?2", nativeQuery = true)
	int getPreviousDayMeterReadingForMoveOutTenant(Long accountId, Long associationId);

	@Query(value = "select  count(*) from  property_account_association pa, account a, property p, supply_point s, meter m, meter_reading mr where pa.property_id = p.property_id and pa.account_id = a.account_id and p.property_id = s.property_id and s.supply_id = m.supply_id and m.meter_id = mr.meter_id and CAST(mr.reading_date_time AS DATE)=cast(pa.end_date as date) and pa.account_id=?1 and pa.association_id=?2", nativeQuery = true)
	int getCurrentDayMeterReadingForMoveOutTenant(Long accountId, Long associationId);

	@Query(value = "select concat(first_name, ' ', last_name) from billable_person where deleted=0 and account_id in (select top 1 account_id from property_account_association where tenure_type='owner' and property_id=?1 and move_in_status='Completed' and deleted=0 order by association_id desc)", nativeQuery = true)
	String getAccountOwnerForProperty(Long propertyId);

	@Query(value = "select top 1 * from(\r\n" + "select * from\r\n"
			+ "(select top 1 account_id  from property_account_association where property_id=?1 and deleted = 0 and tenure_type= ?2 and move_in_status='Completed' order by start_date desc)t1\r\n"
			+ "union all\r\n" + "select * from\r\n"
			+ "(select top 1 account_id  from property_account_association where property_id=?1 and deleted = 0 and tenure_type= ?2 and move_in_status != 'Completed' order by start_date desc)t2)d", nativeQuery = true)
	Long getAccountAssociationDetails(Long propertyId, String tenureType);

	@Query(value = "select top 1 account_id  from property_account_association where property_id=?1 and deleted = 0 and tenure_type= ?2 and move_in_status != 'Completed' order by association_id desc", nativeQuery = true)
	Long getAccountAssociationDetailsInProgress(Long propertyId, String tenureType);

	@Query(value = "select concat(first_name,' ', last_name) as name from billable_person where account_id = ?1 and deleted=0", nativeQuery = true)
	String getBillablePersonNameForAccount(Long accountId);

	@Query(value = "select \r\n" + "	a.account_number, c.client_name, n.network, count(*) as count \r\n"
			+ "from \r\n" + "	account a, client c, network n, property_account_association pa\r\n" + "where \r\n"
			+ "	a.client_id = c.client_id and a.network_id = n.network_id \r\n"
			+ "	and a.account_id = pa.account_id\r\n" + "	and a.account_id = ?1 and pa.deleted = 0\r\n"
			+ "   and pa.tenure_type = ?2 \r\n"
			+ "	group by a.account_number, c.client_name, n.network", nativeQuery = true)
	List<Object[]> getTenantDetailsForProperty(Long accountId, String tenureType);

	@Query(value = "select \r\n"
			+ "	pa.association_id, concat(b.first_name,' ', b.last_name) as name, pa.start_date, pa.end_date  \r\n"
			+ "from \r\n" + "	property_account_association pa, account a, billable_person b\r\n" + "where \r\n"
			+ "	pa.account_id = a.account_id\r\n" + "	and a.account_id = b.account_id\r\n"
			+ "	and pa.property_id = ?1\r\n" + "	and b.deleted = 0\r\n" + "	and b.billable_person_id in \r\n"
			+ "	(select \r\n" + "		max(billable_person_id) \r\n" + "	from \r\n"
			+ "		billable_person b, property_account_association pa \r\n" + "	where \r\n"
			+ "		b.account_id = pa.account_id\r\n" + "		and pa.property_id = ?1 \r\n"
			+ "		and pa.deleted = 0 \r\n" + "		and pa.tenure_type = ?2 \r\n" + "		and b.deleted=0 \r\n"
			+ "	group by b.account_id)\r\n" + "	and pa.tenure_type = ?2\r\n"
			+ "	order by start_date desc", nativeQuery = true)
	List<Object[]> getAccountHistoryForProperty(Long propertyId, String tenureType);

	@Query(value = "select * from property_account_association where account_id= ?1 and property_id= ?2 and deleted=0", nativeQuery = true)
	PropertyAccountAssociation findByPropertyIdAndAccountId(long accountId, long propertyId);

	@Query(value = "select top 1 CONVERT(VARCHAR(10),start_date, 103) as date from property_account_association where property_id=?1 and tenure_type = 'owner' and deleted=0 order by start_date desc", nativeQuery = true)
	String getLastOwnerAccountAssociationDate(long propertyId);

	@Query(value = "select top 1 CONVERT(VARCHAR(10),start_date, 103) as date from property_account_association where property_id=(select property_id from property_account_association where association_id=?1) and tenure_type = 'owner' and deleted=0 order by start_date desc", nativeQuery = true)
	String getLastOwnerForAssociation(long associationId);

	@Query(value = "select * from property_account_association where deleted=0 and property_id=?1 and tenure_type= ?2 and move_in_status='Completed' and (move_out_status!='Completed' or move_out_status is NULL)", nativeQuery = true)
	List<PropertyAccountAssociation> findExistingPropertyOwnerAssociation(long propertyId, String tenureType);

	@Query(value = "select * from property_account_association where property_id= ?1 and tenure_type= ?2 and deleted=0 order by association_id desc", nativeQuery = true)
	List<PropertyAccountAssociation> findAllOwnersForProperty(long propertyId, String tenureType);

	@Query(value = "select top 1 * from property_account_association \r\n" + "where \r\n"
			+ "	move_in_status='Completed' and \r\n" + "	deleted=0 and \r\n"
			+ "	(move_out_status!='Completed' or move_out_status is null) \r\n" + "	and property_id=?1\r\n"
			+ "order by start_date desc, created_date desc", nativeQuery = true)
	PropertyAccountAssociation findRecentActiveUser(long propertyId);

	@Query(value = "select association_id, created_date, created_user, updated_date, updated_user, CAST(CAST(end_date AS DATE) AS DATETIME) as end_date, CAST(CAST(start_date AS DATE) AS DATETIME) as start_date, account_id, property_id, deleted, move_in_status, move_out_status, generate_letter, counter, message, move_out_message, tenure_type, final_statement, associated_ids from property_account_association \r\n"
			+ "where property_id=?3 and move_in_Status='Completed' and tenure_type='tenant' and\r\n"
			+ "((cast(start_date as date)<=?1 and ((cast(end_date as date)<=?2 and cast(end_date as date)>=?1)or end_date is null or cast(end_date as date)>=?2)) or \r\n"
			+ "(cast(start_date as date)>?1 and cast(start_date as date)<=?2 and (cast(end_date as date)<=?2 or cast(end_date as date)>=?2) or end_date is null)) order by start_date", nativeQuery = true)
	List<PropertyAccountAssociation> getAllPropertyAccountAssociation(String billStartDate, String billEndDate,
			long propertyId);

	@Query(value = "select * from property_account_association where tenure_type='owner' and start_date<=?1 and (end_date is null or end_date>=?2) and property_id=?3 and move_in_status='Completed' order by start_date", nativeQuery = true)
	List<PropertyAccountAssociation> getAllOwnersForProperty(String billStartDate, String startDate, long propertyId);

	@Query(value = "select \r\n"
			+ "	association_id, created_date, created_user, updated_date, updated_user, CAST(CAST(end_date AS DATE) AS DATETIME) as end_date, CAST(CAST(start_date AS DATE) AS DATETIME) as start_date, \r\n"
			+ "	account_id, property_id, deleted, move_in_status, move_out_status, generate_letter, counter, message, move_out_message, tenure_type, final_statement,associated_ids \r\n"
			+ "from \r\n" + "	property_account_association\r\n" + "where \r\n"
			+ "	property_id=?3 and move_in_Status='Completed' and tenure_type='owner' and\r\n"
			+ "	((cast(start_date as date)<=?1 and ((cast(end_date as date)<=?2 and cast(end_date as date)>=?1) or end_date is null or cast(end_date as date)>=?2)) or \r\n"
			+ "	(cast(start_date as date)>?1 and cast(start_date as date)<=?2 and (cast(end_date as date)<=?2 or cast(end_date as date)>=?2) or end_date is null)) order by start_date", nativeQuery = true)
	List<PropertyAccountAssociation> getSegregatedOwnersForProperty(String billStartDate, String startDate,
			long propertyId);

	@Query(value = "select cast(start_date-1 as Date) as start_date from property_account_association where association_id=?1", nativeQuery = true)
	String getStartDateForAssociationId(long id);
	
	@Query(value = "select cast(start_date as Date) as start_date from property_account_association where association_id=?1", nativeQuery = true)
	String getStartDate(long id);
	
	@Query(value="select cast(end_date-1 as Date) as end_date from property_account_association where association_id=?1", nativeQuery = true)
	String getPreviousDayToEndDateForAssociation(long id);
	
	@Query(value="select cast(end_date as Date) as end_date from property_account_association where association_id=?1", nativeQuery = true)
	String getCurrentEndDateForAssociation(long id);
	
	@Query(value = "select * from property_account_association where deleted=0 and property_id=?1 and tenure_type= ?2 and (move_in_status is not NULL) and move_out_status is NULL order by start_date desc", nativeQuery = true)
	List<PropertyAccountAssociation> getActiveOrInprogressOwnerToProperty(long propertyId, String tenureType);
	
	@Query(value = "select count(*) from property_account_association where deleted=0 and property_id=?1 and tenure_type=?2 and start_date > (select start_date from property_account_association where association_id=?3)", nativeQuery = true)
	int checkForExistingAssociations(long propertyId, String tenureType, long associationId);
}