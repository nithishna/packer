package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.UnitCharge;
import com.monarch.mabdeck.entity.UnitChargeHistory;
import com.monarch.mabdeck.repository.UnitChargeHistoryRepository;

@Component
public class UnitChargeHistoryService {

	@Resource
	private UnitChargeHistoryRepository historyRepository;
	
	public void updateUnitChargeHistory(UnitCharge charge, String username) {
		if(charge != null) {
			UnitChargeHistory history = new UnitChargeHistory();
			history.setAudit(charge.getAudit());
			history.setName(charge.getName());
			history.setPricePerUnit(charge.getPricePerUnit());
			history.setTariffId(charge.getTariff() != null? charge.getTariff().getTariffId() : null);
			history.setUnit(charge.getUnit());
			history.setUnitChargeId(charge.getUnitChargeId());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
