package com.monarch.mabdeck.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.monarch.mabdeck.entity.DirectDebitConfig;

public interface DirectDebitConfigRepository extends JpaRepository<DirectDebitConfig, Long>{

	DirectDebitConfig findByNetworkNetworkId(long networkId);
}
