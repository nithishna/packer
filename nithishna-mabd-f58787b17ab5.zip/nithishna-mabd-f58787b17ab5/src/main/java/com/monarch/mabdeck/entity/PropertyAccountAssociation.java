package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class PropertyAccountAssociation implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long associationId;

	@ManyToOne(targetEntity = Property.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "propertyId", referencedColumnName = "propertyId", insertable = true, updatable = true)
	private Property property;	
	
	@ManyToOne(targetEntity = Account.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "accountId", referencedColumnName = "accountId", insertable = true, updatable = true)
	private Account account;
	
	@Embedded
	private Audit audit;
	
	private boolean finalStatement;
	
	private Date startDate;
	private Date endDate;
	
	private String tenureType;
	private String associatedIds;
	
	private boolean deleted;
	private String moveInStatus;
	private String moveOutStatus;
	private boolean generateLetter;
	private int counter;
	private String message;
	private String moveOutMessage;
	public Long getAssociationId() {
		return associationId;
	}
	public Property getProperty() {
		return property;
	}
	public Account getAccount() {
		return account;
	}
	public Audit getAudit() {
		return audit;
	}
	public Date getStartDate() {
		return startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setAssociationId(Long associationId) {
		this.associationId = associationId;
	}
	public void setProperty(Property property) {
		this.property = property;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	public String getMoveInStatus() {
		return moveInStatus;
	}
	public void setMoveInStatus(String moveInStatus) {
		this.moveInStatus = moveInStatus;
	}
	public String getMoveOutStatus() {
		return moveOutStatus;
	}
	public void setMoveOutStatus(String moveOutStatus) {
		this.moveOutStatus = moveOutStatus;
	}
	public boolean isGenerateLetter() {
		return generateLetter;
	}
	public void setGenerateLetter(boolean generateLetter) {
		this.generateLetter = generateLetter;
	}
	public int getCounter() {
		return counter;
	}
	public void setCounter(int counter) {
		this.counter = counter;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMoveOutMessage() {
		return moveOutMessage;
	}
	public void setMoveOutMessage(String moveOutMessage) {
		this.moveOutMessage = moveOutMessage;
	}
	public String getTenureType() {
		return tenureType;
	}
	public void setTenureType(String tenureType) {
		this.tenureType = tenureType;
	}
	public boolean isFinalStatement() {
		return finalStatement;
	}
	public void setFinalStatement(boolean finalStatement) {
		this.finalStatement = finalStatement;
	}
	public String getAssociatedIds() {
		return associatedIds;
	}
	public void setAssociatedIds(String associatedIds) {
		this.associatedIds = associatedIds;
	}
}
