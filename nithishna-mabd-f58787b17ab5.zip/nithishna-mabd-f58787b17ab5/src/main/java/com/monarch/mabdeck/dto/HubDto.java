package com.monarch.mabdeck.dto;

import java.util.Date;

public class HubDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long hubId;
	private String hubManufacturer;
	private String serialNumber;
	private String identifier;
	private ClientDto client;
	private NetworkDto network;
	private PropertyDto property;
	private Date startDate;
	private Date endDate;
	private String hubModel;

	public ClientDto getClient() {
		return client;
	}
	public void setClient(ClientDto client) {
		this.client = client;
	}
	public NetworkDto getNetwork() {
		return network;
	}
	public void setNetwork(NetworkDto network) {
		this.network = network;
	}
	public PropertyDto getProperty() {
		return property;
	}
	public void setProperty(PropertyDto property) {
		this.property = property;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getHubManufacturer() {
		return hubManufacturer;
	}
	public void setHubManufacturer(String hubManufacturer) {
		this.hubManufacturer = hubManufacturer;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public Long getHubId() {
		return hubId;
	}
	public void setHubId(Long hubId) {
		this.hubId = hubId;
	}
	public String getHubModel() {
		return hubModel;
	}
	public void setHubModel(String hubModel) {
		this.hubModel = hubModel;
	}
	
}
