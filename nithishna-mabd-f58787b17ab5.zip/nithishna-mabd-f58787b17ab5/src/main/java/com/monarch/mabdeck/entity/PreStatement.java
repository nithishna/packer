package com.monarch.mabdeck.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class PreStatement implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long preStatementId;
	private Long propertyId;
	private Long accountId;	
	private Long meterId;
	private boolean invalid;
	private String validityReason;
	@Embedded
	private Address propertyAddress;	
	private String fromDate;
	private String toDate;	
	private byte deleted;
	private String createdUser;
	private Date creationDate;
	private Date updatedDate;
	private Date lastBillDate;
	private String updatedUser;
	private double adminCharge;
	private double totalAdminCharge;
	private double totalCharge;
	private double totalChargeBeforeVat;
	private double vatAmount;
	private double vat;
	private long noOfDays;
	private Long queueId;
	
	@OneToMany(mappedBy = "preStatement", cascade = CascadeType.ALL)
	private List<PreStatementEnergy> preStatementEnergy;
	
	public double getAdminCharge() {
		return adminCharge;
	}
	public void setAdminCharge(double adminCharge) {
		this.adminCharge = adminCharge;
	}
	public Long getPreStatementId() {
		return preStatementId;
	}
	public Address getPropertyAddress() {
		return propertyAddress;
	}
	public String getFromDate() {
		return fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public byte getDeleted() {
		return deleted;
	}
	public String getCreatedUser() {
		return createdUser;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public String getUpdatedUser() {
		return updatedUser;
	}
	public void setPreStatementId(Long preStatementId) {
		this.preStatementId = preStatementId;
	}
	public void setPropertyAddress(Address propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public void setDeleted(byte deleted) {
		this.deleted = deleted;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}
	public List<PreStatementEnergy> getPreStatementEnergy() {
		return preStatementEnergy;
	}
	public void setPreStatementEnergy(List<PreStatementEnergy> preStatementEnergy) {
		this.preStatementEnergy = preStatementEnergy;
	}
	public boolean isInvalid() {
		return invalid;
	}
	public String getValidityReason() {
		return validityReason;
	}
	public void setInvalid(boolean invalid) {
		this.invalid = invalid;
	}
	public void setValidityReason(String validityReason) {
		this.validityReason = validityReason;
	}
	public Long getPropertyId() {
		return propertyId;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public Long getMeterId() {
		return meterId;
	}
	public void setMeterId(Long meterId) {
		this.meterId = meterId;
	}
	public double getTotalAdminCharge() {
		return totalAdminCharge;
	}
	public long getNoOfDays() {
		return noOfDays;
	}
	public void setTotalAdminCharge(double totalAdminCharge) {
		this.totalAdminCharge = totalAdminCharge;
	}
	public void setNoOfDays(long noOfDays) {
		this.noOfDays = noOfDays;
	}
	public double getTotalCharge() {
		return totalCharge;
	}
	public void setTotalCharge(double totalCharge) {
		this.totalCharge = totalCharge;
	}
	public Long getQueueId() {
		return queueId;
	}
	public void setQueueId(Long queueId) {
		this.queueId = queueId;
	}
	public Date getLastBillDate() {
		return lastBillDate;
	}
	public void setLastBillDate(Date lastBillDate) {
		this.lastBillDate = lastBillDate;
	}
	public double getVatAmount() {
		return vatAmount;
	}
	public double getVat() {
		return vat;
	}
	public void setVatAmount(double vatAmount) {
		this.vatAmount = vatAmount;
	}
	public void setVat(double vat) {
		this.vat = vat;
	}
	public double getTotalChargeBeforeVat() {
		return totalChargeBeforeVat;
	}
	public void setTotalChargeBeforeVat(double totalChargeBeforeVat) {
		this.totalChargeBeforeVat = totalChargeBeforeVat;
	}
}