package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.TariffDto;
import com.monarch.mabdeck.entity.Tariff;

@Mapper
public abstract class TariffMapper implements IBaseMapper<TariffDto, Tariff>{
	public static final TariffMapper INSTANCE = Mappers.getMapper(TariffMapper.class);
	
	@Mappings({
		@Mapping(target = "band", ignore = true),
		@Mapping(target = "unitCharge", ignore = true),
		@Mapping(target = "standingCharge", ignore = true),
		@Mapping(target = "propertyAreaCharge", ignore = true),
		@Mapping(target = "deleted", ignore = true),
		@Mapping(target = "audit", ignore = true),
		@Mapping(target = "supplyType", ignore = true)
	})
	public abstract Tariff convertToEntity(TariffDto dto);
	
	
	@Mappings({
		@Mapping(target = "band", ignore = true),
		@Mapping(target = "unitCharge", ignore = true),
		@Mapping(target = "standingCharge", ignore = true),
		@Mapping(target = "propertyAreaCharge", ignore = true),
		@Mapping(target = "supplyType", ignore = true)
	})
	public abstract TariffDto convertToDTO(Tariff entity);
}
