package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.CorrespondenceNotes;

@Repository
public interface CorrespondenceNotesRepository  extends JpaRepository<CorrespondenceNotes, Long>{

	@Query(value="select * from correspondence_notes where correspondence_id=?1", nativeQuery=true)
	List<CorrespondenceNotes> getAllNotesByCorrespondenceId(long id);
}
