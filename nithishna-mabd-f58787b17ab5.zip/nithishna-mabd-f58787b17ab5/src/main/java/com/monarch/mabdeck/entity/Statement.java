package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Statement implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long statementId;
	
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id")
	private Account account;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="property_id")
	private Property property;
	
	private Date fromDate;
	private Date toDate;
	private Date generationDate;
	private double netAmount;
	private double vat;
	private double grossAmount;
	private byte deleted;
	private String fileName;
	private boolean approved;
	private boolean invalid;
	private String message;
	private long queueId;
	
	@Embedded
	private Audit audit;
	public Long getStatementId() {
		return statementId;
	}
	public Account getAccount() {
		return account;
	}
	public Property getProperty() {
		return property;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public Date getGenerationDate() {
		return generationDate;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public double getVat() {
		return vat;
	}
	public double getGrossAmount() {
		return grossAmount;
	}
	public void setStatementId(Long statementId) {
		this.statementId = statementId;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public void setProperty(Property property) {
		this.property = property;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public void setGenerationDate(Date generationDate) {
		this.generationDate = generationDate;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public void setVat(double vat) {
		this.vat = vat;
	}
	public void setGrossAmount(double grossAmount) {
		this.grossAmount = grossAmount;
	}
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public byte getDeleted() {
		return deleted;
	}
	public void setDeleted(byte deleted) {
		this.deleted = deleted;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public boolean isApproved() {
		return approved;
	}
	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	public boolean isInvalid() {
		return invalid;
	}
	public void setInvalid(boolean invalid) {
		this.invalid = invalid;
	}
	public String getMessage() {
		return message;
	}
	public long getQueueId() {
		return queueId;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public void setQueueId(long queueId) {
		this.queueId = queueId;
	}
}
