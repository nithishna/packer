package com.monarch.mabdeck.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.AdminChargeDto;
import com.monarch.mabdeck.entity.AdminCharge;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Band;
import com.monarch.mabdeck.mapper.AdminChargeMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.repository.AdminChargeRepository;
import com.monarch.mabdeck.repository.BandRepository;

@Component
public class AdminChargeService extends CommonServiceImpl<AdminChargeDto, AdminCharge>{

	private Logger logger = LoggerFactory.getLogger(AccountService.class);
	
	@Resource
	private AdminChargeRepository adminChargeRepository;
	
	
	@Resource
	private BandRepository bandRepository;
	
	@Override
	public JpaRepository<AdminCharge, Long> getJPARepository() {
		return this.adminChargeRepository;
	}

	@Override
	public IBaseMapper<AdminChargeDto, AdminCharge> getMapper() {
		return AdminChargeMapper.INSTANCE;
	}
	
	@Override
	public AdminChargeDto create(AdminChargeDto dto, String username) {
		AdminCharge adminCharge = getMapper().convertToEntity(dto);
		updateAudit(adminCharge, username);
		if(dto.getBand()!=null) {
			Band band = bandRepository.getOne(dto.getBand().getBandId());
			adminCharge.setBand(band);
		}
		this.getJPARepository().saveAndFlush(adminCharge);
		return dto;
	}

	@Override
	public void updateAudit(AdminCharge entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
			}else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
}
