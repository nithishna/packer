package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CustomerServiceContact implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long custServiceId;
	
	@Embedded
	private Address address;
	private long mainContactNumber;
	private String emailAddress;

	@Embedded
	private Audit audit;
	
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public long getMainContactNumber() {
		return mainContactNumber;
	}
	public void setMainContactNumber(long mainContactNumber) {
		this.mainContactNumber = mainContactNumber;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public Long getCustServiceId() {
		return custServiceId;
	}
	public void setCustServiceId(Long custServiceId) {
		this.custServiceId = custServiceId;
	}
	
}
