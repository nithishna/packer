package com.monarch.mabdeck.controller;

import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.CustomerServiceContactDto;
import com.monarch.mabdeck.service.CustomerContactService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class CustomerContactController {

	private Logger logger = LoggerFactory.getLogger(CustomerContactController.class);

	@Autowired
	private CustomerContactService customerContactService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CUSTOMER_CONTACT, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createCustomerContact(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody CustomerServiceContactDto customerService) {
		logger.info("CustomerContactController: createCustomerContact - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("CustomerContactController: createCustomerContact - Service Call, Username : " + username);
		customerContactService.create(customerService, username);
		logger.info("CustomerContactController: createCustomerContact - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_CUSTOMER_CONTACT_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody CustomerServiceContactDto getCustomerContactById(@PathVariable("service_id") Long serviceId)
			throws NotFoundException {
		logger.info("CustomerContactController: getCustomerContactById - Start");
		return customerContactService.read(serviceId);
	}
}
