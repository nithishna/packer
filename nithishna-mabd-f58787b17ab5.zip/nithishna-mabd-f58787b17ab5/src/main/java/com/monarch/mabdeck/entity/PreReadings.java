package com.monarch.mabdeck.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class PreReadings implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long readingId;
	
	@ManyToOne(cascade = CascadeType.ALL, targetEntity = PreStatementEnergy.class, fetch = FetchType.EAGER)
	@JoinColumn(name="preStatementEnergyId",referencedColumnName="preStatementEnergyId", insertable = true, updatable = true)
	private PreStatementEnergy preStatementEnergy;
	private Date readingDateTime;
	private String type;
	private Float value;
	public Long getReadingId() {
		return readingId;
	}
	public PreStatementEnergy getPreStatementEnergy() {
		return preStatementEnergy;
	}
	public String getType() {
		return type;
	}
	public Float getValue() {
		return value;
	}
	public void setReadingId(Long readingId) {
		this.readingId = readingId;
	}
	public void setPreStatementEnergy(PreStatementEnergy preStatementEnergy) {
		this.preStatementEnergy = preStatementEnergy;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setValue(Float value) {
		this.value = value;
	}
	public Date getReadingDateTime() {
		return readingDateTime;
	}
	public void setReadingDateTime(Date readingDateTime) {
		this.readingDateTime = readingDateTime;
	}

}