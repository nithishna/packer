package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.BankAccountDto;
import com.monarch.mabdeck.entity.BankAccount;

@Mapper(uses = {BankMapper.class})
public abstract class BankAccountMapper implements IBaseMapper<BankAccountDto, BankAccount>{
	public static final BankAccountMapper INSTANCE = Mappers.getMapper(BankAccountMapper.class);
	
	@Mappings({
		@Mapping(target = "client", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract BankAccount convertToEntity(BankAccountDto dto);

	public abstract BankAccountDto convertToDTO(BankAccount entity);
}
