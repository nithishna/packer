package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AdminChargeHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long adminChargeId;
	private String chargeTo;
	private String description;
	private float dailyCharge;
	private float vatRate;
	private Date activeFromDate;
	private Date activeToDate;
	@Embedded
	private Audit audit;
	private Long bandId;
	public Long getAdminChargeId() {
		return adminChargeId;
	}
	public String getChargeTo() {
		return chargeTo;
	}
	public String getDescription() {
		return description;
	}
	public float getDailyCharge() {
		return dailyCharge;
	}
	public float getVatRate() {
		return vatRate;
	}
	public Date getActiveFromDate() {
		return activeFromDate;
	}
	public Date getActiveToDate() {
		return activeToDate;
	}
	public Audit getAudit() {
		return audit;
	}
	public Long getBandId() {
		return bandId;
	}
	public void setAdminChargeId(Long adminChargeId) {
		this.adminChargeId = adminChargeId;
	}
	public void setChargeTo(String chargeTo) {
		this.chargeTo = chargeTo;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setDailyCharge(float dailyCharge) {
		this.dailyCharge = dailyCharge;
	}
	public void setVatRate(float vatRate) {
		this.vatRate = vatRate;
	}
	public void setActiveFromDate(Date activeFromDate) {
		this.activeFromDate = activeFromDate;
	}
	public void setActiveToDate(Date activeToDate) {
		this.activeToDate = activeToDate;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public void setBandId(Long bandId) {
		this.bandId = bandId;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
}
