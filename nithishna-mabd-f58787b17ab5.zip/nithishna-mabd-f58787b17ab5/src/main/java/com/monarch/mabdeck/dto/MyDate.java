package com.monarch.mabdeck.dto;

public class MyDate implements IDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MyDate() {
		this.year = 1970;
		this.month = 1;
		this.day=1;
	}
	private int year;
	private int month;
	private int day;
	public int getYear() {
		return year;
	}
	public int getMonth() {
		return month;
	}
	public int getDay() {
		return day;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public void setDay(int day) {
		this.day = day;
	}
	
}
