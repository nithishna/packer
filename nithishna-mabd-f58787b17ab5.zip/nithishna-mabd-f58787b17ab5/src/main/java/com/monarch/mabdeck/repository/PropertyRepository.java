package com.monarch.mabdeck.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Property;

@Repository
public interface PropertyRepository extends JpaRepository<Property, Long> {

	@Query(value = "select * from property where  client_id=?1 and network_id=?2 and band_id=?3", nativeQuery = true)
	List<Property> fetchAllPropertiesByClientAndNetworkAndBand(Long clientId, Long networkId, Long bandId);

	@Query(value = "select * from property where network_id=?1", nativeQuery = true)
	List<Property> fetchAllPropertiesByNetwork(Long networkId);

	@Query(value = "select * from property where address_line1 = ?1", nativeQuery = true)
	Property findPropertyWithAddress(String addressLine1);

	@Query(value = "select p.* from Property p, Account a, property_account_association pa where p.property_id = pa.property_id and a.account_id = pa.account_id and a.account_id = ?1 and deleted=0", nativeQuery = true)
	List<Property> getAllPropertiesByAccountId(Long accountId);

	@Query(value = "select p.* from Property p where p.network_id = ?2 and p.property_id not in (select property_id from property_account_association where account_id = ?1 and deleted=0 and tenure_type=?3)", nativeQuery = true)
	List<Property> getAllPropertiesNotInAccount(Long accountId, Long networkId, String tenureType);

	//@Query(value = "select p.* from Property p where p.network_id = ?2 and p.property_id in (select property_id from property_account_association where account_id = ?1 and deleted=0 and move_out_status not in ('Completed'))", nativeQuery = true)
	@Query(value = "select pa.association_id as property_id, area, reference, band_id, client_id, network_id, address_line1, address_line2, address_line3, country, post_code, region, town, p.created_date, p.created_user, p.updated_date, p.updated_user, CAST(CAST(last_Billed_Date AS DATE) AS DATETIME) as last_Billed_Date, p.per_day_usage from property p, property_account_association pa \r\n" + 
			"where p.property_id = pa.property_id\r\n" + 
			"and p.network_id = ?2 and pa.account_id=?1 and pa.deleted=0 and pa.move_out_status not in ('Completed') and tenure_type = 'tenant'", nativeQuery = true)
	List<Property> getAllPropertiesUnderMovementOutside(Long accountId, Long networkId);

	//@Query(value = "select p.* from Property p where p.network_id = ?2 and p.property_id in (select property_id from property_account_association where account_id = ?1 and deleted=0 and move_in_status not in ('Completed'))", nativeQuery = true)
	@Query(value = "select pa.association_id as property_id, area, reference, band_id, client_id, network_id, address_line1, address_line2, address_line3, country, post_code, region, town, p.created_date, p.created_user, p.updated_date, p.updated_user, CAST(CAST(last_Billed_Date AS DATE) AS DATETIME) as last_Billed_Date, p.per_day_usage from property p, property_account_association pa \r\n" + 
			"where p.property_id = pa.property_id\r\n" + 
			"and p.network_id = ?2 and pa.account_id=?1 and pa.deleted=0 and pa.move_in_status not in ('Completed') and tenure_type = 'tenant'", nativeQuery = true)
	List<Property> getAllPropertiesUnderMovementInside(Long accountId, Long networkId);	
	
	
	@Query(value="select pa.association_id as property_id, area, reference, band_id, client_id, network_id, address_line1, address_line2, address_line3, country, post_code, region, town, p.created_date, p.created_user, p.updated_date, p.updated_user, CAST(CAST(last_Billed_Date AS DATE) AS DATETIME) as last_Billed_Date, p.per_day_usage \r\n" + 
			"from property p, property_account_association pa\r\n" + 
			"where p.property_id = pa.property_id\r\n" + 
			"and pa.account_id=?1 and pa.deleted=0 and pa.move_in_status not in ('Completed') and tenure_type = 'Owner'", nativeQuery = true)
	List<Property> getAllPropertiesUnderMovementInsideForOwner(Long accountId);
	
	@Query(value="select pa.association_id as property_id, area, reference, band_id, client_id, network_id, address_line1, address_line2, address_line3, country, post_code, region, town, p.created_date, p.created_user, p.updated_date, p.updated_user, CAST(CAST(last_Billed_Date AS DATE) AS DATETIME) as last_Billed_Date, p.per_day_usage \r\n" + 
			"from property p, property_account_association pa\r\n" + 
			"where p.property_id = pa.property_id\r\n" + 
			"and pa.account_id=?1 and pa.deleted=0 and pa.move_out_status not in ('Completed') and tenure_type = 'Owner'", nativeQuery = true)
	List<Property> getAllPropertiesUnderMovementOutsideForOwner(Long accountId);
	
	/*@Query(value = "select 	p.property_id as propertyId, p.address_line1 as addressLine1, p.address_line2 as addressLine2, p.address_line3 as addressLine3, \r\n" + 
			"	n.network as networkName, c.client_name as clientName, concat(b2.first_name, b2.last_name) as currentTenant, concat(b.first_name, b.last_name) as currentOwner, p.reference\r\n" + 
			"	from property p  \r\n" + 
			"	inner join client c on p.client_id = c.client_id  \r\n" + 
			"	inner join network n on n.network_id = p.network_id and n.client_id = c.client_id  \r\n" + 
			"	left outer join property_account_association pa on pa.property_id = p.property_id and pa.tenure_type = 'Owner' and pa.move_in_status='Completed' and pa.deleted=0\r\n" + 
			"	left outer join property_account_association pat on pat.property_id = p.property_id and pat.tenure_type = 'tenant' and pat.move_in_status='Completed' and pat.deleted=0\r\n" + 
			"	left outer join account a on a.account_id = pa.account_id   \r\n" + 
			"	left outer join (select * from billable_person b1 where deleted=0 and b1.billable_person_id   \r\n" + 
			"	= (select max(b2.billable_person_id) from billable_person b2 where deleted=0 and b1.account_id = b2.account_id)) b on a.account_id = b.account_id and b.deleted=0\r\n" + 
			"	left outer join account a2 on a2.account_id = pat.account_id\r\n" + 
			"	left outer join (select * from billable_person b11 where deleted=0 and b11.billable_person_id   \r\n" + 
			"	= (select max(b22.billable_person_id) from billable_person b22 where deleted=0 and b11.account_id = b22.account_id)) b2 on a2.account_id = b2.account_id and b2.deleted=0", nativeQuery = true)*/
	@Query(value="select 	p.property_id, p.address_line1, p.address_line2, p.address_line3, n.network, c.client_name, p.reference \r\n" + 
			"from property p, client c, network n\r\n" + 
			"where p.client_id = c.client_id and p.network_id = n.network_id\r\n" + 
			"order by p.property_id asc", nativeQuery = true)
	List<Object[]> getAllPropertiesWithTenantAndOwner();	
	
	@Query(value="select top 1 account_id from\r\n" + 
			"(select account_id from (select top 1 account_id from property_account_association where property_id=?1 and tenure_type=?2 and deleted=0 and move_in_status='Completed' and (move_out_Status != 'Completed' or move_out_status is NULL) order by start_date desc)t1\r\n" + 
			"union all\r\n" + 
			"select account_id from (select top 1 account_id from property_account_association where property_id=?1 and tenure_type=?2 and deleted=0 and (move_out_Status != 'Completed' or move_out_status is NULL) order by start_date desc)t2)d", nativeQuery = true)
	Long getActiveAccountIdForProperty(BigDecimal propertyId, String tenure);
	
	@Query(value="select concat(first_name, last_name) as name from billable_person where deleted=0 and billable_person_id = (select max(billable_person_id) from billable_person where deleted=0 and account_id = ?1)", nativeQuery=true)
	String getBillablePersonNameForAccount(Long accountId);	
	
	@Query(value = "select p.address_line1, p.address_line2, p.address_line3, p.region, p.town, p.country, p.post_code, b.band_name from property p\r\n" + 
			"inner join band b on b.band_id = p.band_id and p.property_id=?1", nativeQuery = true)
	List<Object[]> getPropertyDetailsForPropertyId(Long propertyId);
	
	@Query(value = "select property_id, area, reference, band_id, client_id, network_id, address_line1, address_line2, address_line3, country, post_code, region, town, created_date, created_user, updated_date, updated_user, CAST(CAST(last_Billed_Date AS DATE) AS DATETIME) as last_Billed_Date, per_day_usage from property where property_id in (:properties)", nativeQuery = true)
	List<Property> getRequestedPropertiesByPropertyIds(@Param("properties") List<Long> propertyIds);
	
	@Query(value = "select property_id, area, reference, band_id, client_id, network_id, address_line1, address_line2, address_line3, country, post_code, region, town, created_date, created_user, updated_date, updated_user, CAST(CAST(last_Billed_Date AS DATE) AS DATETIME) as last_Billed_Date, per_day_usage from property where network_id in (:networks)", nativeQuery = true)
	List<Property> getRequestedPropertiesByNetworkIds(@Param("networks") List<Long> networks);
	
	@Query(value = "select property_id, area, reference, band_id, client_id, network_id, address_line1, address_line2, address_line3, country, post_code, region, town, created_date, created_user, updated_date, updated_user, CAST(CAST(last_Billed_Date AS DATE) AS DATETIME) as last_Billed_Date, per_day_usage from property where client_id in (:clients)", nativeQuery = true)
	List<Property> getRequestedPropertiesByClientIds(@Param("clients") List<Long> clientIds);
	
	@Query(value = "select \r\n" + 
			"	property_id, area, reference, band_id, client_id, network_id, address_line1, address_line2, address_line3, \r\n" + 
			"	country, post_code, region, town, created_date, created_user, updated_date, updated_user, \r\n" + 
			"	CAST(CAST(last_Billed_Date AS DATE) AS DATETIME) as last_Billed_Date, per_day_usage \r\n" + 
			"from \r\n" + 
			"	property \r\n" + 
			"where \r\n" + 
			"	address_line1 like %?1% or address_line2 like %?1% or address_line3 like %?1% or post_code like %?1%", nativeQuery = true)
	List<Property> getAllPropertiesByName(String name);
	
	@Query(value="select \r\n" + 
			"	property_id, area, reference, band_id, client_id, network_id, address_line1, \r\n" + 
			"	address_line2, address_line3, country, post_code, region, town, created_date, \r\n" + 
			"	created_user, updated_date, updated_user, last_Billed_Date, per_day_usage \r\n" + 
			"from \r\n" + 
			"	(select p.*,RowNum = row_number() OVER ( order by p.property_id)  from property p)m \r\n" + 
			"where \r\n" + 
			"	RowNum between ?1 and ?2", nativeQuery = true)
	List<Property> getAllPropertiesBySupply(int startIndex, int endIndex);
	
	@Query(value="select count(*) from property", nativeQuery = true)
	long getCount();
	
	@Query(value="select property_id, address_line1, address_line2, address_line3, town, post_code from property where client_id=? and network_id=? and band_id=?", nativeQuery = true)
	List<Object[]> getAllPropertiesByClientIdAndNetworkIdAndBandId(long clientId, long networkId, long bandId);
}