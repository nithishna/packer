package com.monarch.mabdeck.controller;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.BandDto;
import com.monarch.mabdeck.service.BandService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class BandController {

	private Logger logger = LoggerFactory.getLogger(BandController.class);

	@Autowired
	private BandService bandService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.BAND, method = RequestMethod.POST, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void createband(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody BandDto band) {
		logger.info("BandController: createband - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("BandController: createband - Service Call, Username : " + username);
		bandService.create(band, username);
		logger.info("BandController: createband - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.BAND, method = RequestMethod.PUT, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void updateBand(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody BandDto band) {
		logger.info("BandController: updateBand - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("BandController: updateBand - Service Call, Username : " + username);
		bandService.update(band, username);
		logger.info("BandController: updateBand - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_BAND_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<BandDto> getBandById(@PathVariable("band_id") Long bandId) throws NotFoundException {
		logger.info("BandController: getBandById - Start");
		BandDto dto = bandService.read(bandId);
		List<BandDto> dtoList = new ArrayList<>();
		dtoList.add(dto);
		logger.info("BandController: getBandById - End");
		return dtoList;
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.BAND, method = RequestMethod.GET, produces = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public List<BandDto> getAllBands() throws NotFoundException {
		logger.info("BandController: getAllBands - Start");
		return bandService.readAll();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.BAND_BY_CLIENT_AND_NETWORK, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/json; charset=utf-8" })
	public List<BandDto> getAllBandForClientAndNetwork(@PathVariable("client_id") Long clientId,
			@PathVariable("network_id") Long networkId) {
		logger.info("BandController: getAllBandForClientAndNetwork - Start");
		return bandService.getAllBandForClientAndNetwork(clientId, networkId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.BAND_V2, method = RequestMethod.GET, produces = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public List<BandDto> getAllBandsV2(@RequestParam("index")int index, @RequestParam("size")int pageSize) throws NotFoundException {
		logger.info("BandController: getAllBands - Start");
		return bandService.readAllV2(index, pageSize);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.BAND_COUNT, method = RequestMethod.GET)
	public long bandCount() {
		return bandService.getCount();
	}
}
