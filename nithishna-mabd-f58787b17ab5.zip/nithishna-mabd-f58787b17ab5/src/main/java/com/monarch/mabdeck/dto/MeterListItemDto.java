package com.monarch.mabdeck.dto;

public class MeterListItemDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long meterId;
	private String meterName;
	public Long getMeterId() {
		return meterId;
	}
	public String getMeterName() {
		return meterName;
	}
	public void setMeterId(Long meterId) {
		this.meterId = meterId;
	}
	public void setMeterName(String meterName) {
		this.meterName = meterName;
	}
}
