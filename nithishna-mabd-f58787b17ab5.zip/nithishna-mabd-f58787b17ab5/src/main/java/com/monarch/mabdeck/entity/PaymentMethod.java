package com.monarch.mabdeck.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PaymentMethod implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String method;
	public Long getId() {
		return id;
	}
	public String getMethod() {
		return method;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setMethod(String method) {
		this.method = method;
	}

}
