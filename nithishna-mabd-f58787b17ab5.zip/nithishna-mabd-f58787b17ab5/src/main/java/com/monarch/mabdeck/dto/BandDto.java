package com.monarch.mabdeck.dto;

import java.sql.Date;
import java.util.List;

public class BandDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private long bandId;
	private ClientDto client;
	private NetworkDto network;
	private List<PropertyDto> property;
	private String bandName;
	private String bandType;
	private Date startDate;
	private Date endDate;
	private List<TariffDto> tariff;
	private int propertyPart1;
	private int propertyPart2;
	private String propertyUnit;
	private int numberOfBedroom;
	private List<AdminChargeDto> adminCharge;
	private int noOfTariffs;
	
	public long getBandId() {
		return bandId;
	}
	public void setBandId(long bandId) {
		this.bandId = bandId;
	}
	public ClientDto getClient() {
		return client;
	}
	public void setClient(ClientDto client) {
		this.client = client;
	}
	public NetworkDto getNetwork() {
		return network;
	}
	public void setNetwork(NetworkDto network) {
		this.network = network;
	}
	public List<PropertyDto> getProperty() {
		return property;
	}
	public void setProperty(List<PropertyDto> property) {
		this.property = property;
	}
	public String getBandName() {
		return bandName;
	}
	public void setBandName(String bandName) {
		this.bandName = bandName;
	}
	public String getBandType() {
		return bandType;
	}
	public void setBandType(String bandType) {
		this.bandType = bandType;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public List<TariffDto> getTariff() {
		return tariff;
	}
	public void setTariff(List<TariffDto> tariff) {
		this.tariff = tariff;
	}
	public int getPropertyPart1() {
		return propertyPart1;
	}
	public void setPropertyPart1(int propertyPart1) {
		this.propertyPart1 = propertyPart1;
	}
	public int getPropertyPart2() {
		return propertyPart2;
	}
	public void setPropertyPart2(int propertyPart2) {
		this.propertyPart2 = propertyPart2;
	}
	public String getPropertyUnit() {
		return propertyUnit;
	}
	public void setPropertyUnit(String propertyUnit) {
		this.propertyUnit = propertyUnit;
	}
	public int getNumberOfBedroom() {
		return numberOfBedroom;
	}
	public void setNumberOfBedroom(int numberOfBedroom) {
		this.numberOfBedroom = numberOfBedroom;
	}
	public List<AdminChargeDto> getAdminCharge() {
		return adminCharge;
	}
	public void setAdminCharge(List<AdminChargeDto> adminCharge) {
		this.adminCharge = adminCharge;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getNoOfTariffs() {
		return noOfTariffs;
	}
	public void setNoOfTariffs(int noOfTariffs) {
		this.noOfTariffs = noOfTariffs;
	}
}
