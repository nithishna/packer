package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.BankDto;
import com.monarch.mabdeck.entity.Bank;

@Mapper
public abstract class BankMapper implements IBaseMapper<BankDto, Bank>{
	public static final BankMapper INSTANCE = Mappers.getMapper(BankMapper.class);
	
	@Mappings({
		@Mapping(target = "account", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract Bank convertToEntity(BankDto dto);

}
