package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.AccountDto;
import com.monarch.mabdeck.entity.Account;

@Mapper(uses = {ClientMapper.class, NetworkMapper.class, PropertyMapper.class, AddressMapper.class, BillablePersonMapper.class})
public abstract class AccountMapper implements IBaseMapper<AccountDto, Account>{
	public static final AccountMapper INSTANCE = Mappers.getMapper(AccountMapper.class);
	
	@Mappings({
		@Mapping(target = "audit", ignore = true)
	})
	public abstract Account convertToEntity(AccountDto dto);
	
	
	@Mappings({
		@Mapping(target = "notes", ignore = true)
	})
	public abstract AccountDto convertToDTO (Account entity);
}
