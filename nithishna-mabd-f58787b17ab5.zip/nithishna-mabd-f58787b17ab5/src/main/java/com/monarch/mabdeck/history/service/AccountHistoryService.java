package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Account;
import com.monarch.mabdeck.entity.AccountHistory;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.repository.AccountHistoryRepository;

@Component
public class AccountHistoryService {

	@Resource
	private AccountHistoryRepository historyRepository;

	public void updateAccountHistory(Account account, String username) {
		AccountHistory history = new AccountHistory();
		if (account != null) {
			history.setAccountId(account.getAccountId());
			history.setAccountNumber(account.getAccountNumber());
			history.setAddress(account.getAddress());
			history.setAudit(account.getAudit());
			history.setClientId(account.getClient() != null ? account.getClient().getClientId() : null);
			history.setNetworkId(account.getNetwork() != null ? account.getNetwork().getNetworkId() : null);
			history.setPaymentCardNumber(account.getPaymentCardNumber() != null? account.getPaymentCardNumber(): null);
			history.setEmailLanguage(account.getEmailLanguage() != null? account.getEmailLanguage() : "ENGLISH");
			history.setSendInvitation(account.isSendInvitation());
			Calendar cal = Calendar.getInstance();
			if (history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			} else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
