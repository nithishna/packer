package com.monarch.mabdeck.dto;

public class BankDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long bankId;
	private String name;
	public Long getId() {
		return bankId;
	}
	public void setId(Long bankId) {
		this.bankId = bankId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
