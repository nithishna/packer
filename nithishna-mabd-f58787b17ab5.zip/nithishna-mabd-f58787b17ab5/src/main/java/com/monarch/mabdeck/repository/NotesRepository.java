package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Notes;

@Repository
public interface NotesRepository  extends JpaRepository<Notes, Long> {
	
	@Query(value = "select * from notes where account_id = ?1", nativeQuery = true)
	List<Notes> getAllNotesById(Long accountId);
	
	@Query(value = "select attachment from notes where note_id = ?1", nativeQuery = true)
	byte[] getAttachmentForId(Long noteId);
	
	@Query(value="select * from notes where account_id=?1", nativeQuery=true)
	List<Notes> findByAccountId(long accountId);
}
