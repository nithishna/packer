package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Client;

@Repository
public interface ClientRepository extends JpaRepository<Client, Long>{
	@Query(value = "select client_name from client where client_id=?1", nativeQuery = true)
	String getClientNameById(Long clientId);
	
	@Query(value = "select distinct c.* from network n , client c where n.client_id = c.client_id and hub_manufacturer in ('Secure', 'Guru')", nativeQuery = true)
	List<Client> getAllClientsWithHubManufacturer();
	
	@Query(value = "select client_id as clientId, client_name as clientName from client", nativeQuery = true)
	List<Object[]> getClientMetaData();
	
	@Query(value = "select client_id as clientId, client_name as clientName from client where client_name like %:name%", nativeQuery = true)
	List<Object[]> getClientMetaDataByName(@Param("name")String clientName);
	
	@Query(value="select top 1 client_name from client where client_id in (select client_id from property where property_id = ?1)", nativeQuery = true)
	String getClientNameFromPropertyId(long propertyId);
	
	@Query(value="select * from (select c.client_id,client_name, payment_term, start_date, m.mobile_number, count(n.network_id) as networkcount,\r\n" + 
			"RowNum = row_number() OVER ( order by c.client_id)\r\n" + 
			"from client c left join network n on n.client_id = c.client_id\r\n" + 
			"left join main_contact m on m.id = c.contact_id\r\n" + 
			"group by c.client_id,client_name, payment_term, start_date, m.mobile_number)t where RowNum between ?1 and ?2", nativeQuery =true)
	List<Object[]> getAllClientData(int startIndex, int endIndex);
	
	@Query(value="select count(*) from client", nativeQuery=true)
	long getCount();
}
