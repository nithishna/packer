package com.monarch.mabdeck.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("ActionLetter")
public class ActionLetter extends Action {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String templateName;

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
}
