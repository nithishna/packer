package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.AdminChargeDto;
import com.monarch.mabdeck.entity.AdminCharge;

@Mapper
public abstract class AdminChargeMapper implements IBaseMapper<AdminChargeDto, AdminCharge>{

	public static final AdminChargeMapper INSTANCE = Mappers.getMapper(AdminChargeMapper.class);
	
	@Mappings({
		@Mapping(target = "band", ignore = true)
	})
	public abstract AdminChargeDto convertToDTO(AdminCharge entity);
	
	@Mappings({
		@Mapping(target = "band", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract AdminCharge convertToEntity(AdminChargeDto dto);
	
}
