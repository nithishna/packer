package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Notes implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long noteId;
	private Date modifiedDate;
	private String author;
	private String summary;
	private String fileName;
	private byte[] attachment;
	private boolean pin;
	
	@ManyToOne(targetEntity = Account.class, fetch = FetchType.EAGER)
	@JoinColumn(name="accountId",referencedColumnName="accountId", insertable = true, updatable = false)
	private Account account;
	
	public Long getNoteId() {
		return noteId;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public String getAuthor() {
		return author;
	}
	public String getSummary() {
		return summary;
	}
	public void setNoteId(Long noteId) {
		this.noteId = noteId;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public byte[] getAttachment() {
		return attachment;
	}
	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public boolean isPin() {
		return pin;
	}
	public void setPin(boolean pin) {
		this.pin = pin;
	}
}
