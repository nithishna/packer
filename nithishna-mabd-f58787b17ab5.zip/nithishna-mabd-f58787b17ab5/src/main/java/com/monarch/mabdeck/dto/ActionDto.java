package com.monarch.mabdeck.dto;

public class ActionDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private boolean owner;
	private StageDto stage;
	private int type;
	public long getId() {
		return id;
	}
	public boolean isOwner() {
		return owner;
	}
	public StageDto getStage() {
		return stage;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setOwner(boolean owner) {
		this.owner = owner;
	}
	public void setStage(StageDto stage) {
		this.stage = stage;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
}
