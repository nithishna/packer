package com.monarch.mabdeck.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.BankDto;
import com.monarch.mabdeck.service.BankService;
import com.monarch.mabdeck.util.Constants;

import javassist.NotFoundException;

@RestController
public class BankController {

	private Logger logger = LoggerFactory.getLogger(BankController.class);

	@Autowired
	private BankService BankService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.BANK, method = RequestMethod.GET, produces = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public List<BankDto> getAllBanks() throws NotFoundException {
		logger.info("BankController: getAllBanks - Start");	
		return BankService.readAll();
	}
}
