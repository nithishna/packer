package com.monarch.mabdeck.history.service;

import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.MeterReading;
import com.monarch.mabdeck.entity.MeterReadingHistory;
import com.monarch.mabdeck.repository.MeterReadingHistoryRepository;

@Component
public class MeterReadingHistoryService {

	@Resource
	private MeterReadingHistoryRepository historyRepository;
	
	public void updateMeterReadingHistory(MeterReading reading, String username) {
		if(reading != null) {
			MeterReadingHistory history = new MeterReadingHistory();
			history.setAudit(reading.getAudit());
			history.setFlowTemperature(reading.getFlowTemperature());
			history.setInstantaneousFlow(reading.getInstantaneousFlow());
			history.setMeterId(reading.getMeter() != null? reading.getMeter().getMeterId() : null);
			history.setMeterReading(reading.getMeterReading());
			history.setMeterReadingId(reading.getMeterReadingId());
			history.setMethod(reading.getMethod());
			history.setNetworkId(reading.getNetwork()!=null?reading.getNetwork().getNetworkId():null);
			history.setReadingDateTime(reading.getReadingDateTime());
			history.setReturnTemperature(reading.getReturnTemperature());
			history.setTotalVolume(reading.getTotalVolume());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
	
}
