package com.monarch.mabdeck.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("ActionFlag")
public class ActionFlag extends Action {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean flag;
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
}
