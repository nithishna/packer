package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.BillablePersonDto;
import com.monarch.mabdeck.entity.BillablePerson;

@Mapper
public abstract class BillablePersonMapper implements IBaseMapper<BillablePersonDto, BillablePerson>{
	public static final BillablePersonMapper INSTANCE = Mappers.getMapper(BillablePersonMapper.class);
	
	@Mappings({
		@Mapping(target = "audit", ignore = true)
	})
	public abstract BillablePerson convertToEntity(BillablePersonDto dto);
}
