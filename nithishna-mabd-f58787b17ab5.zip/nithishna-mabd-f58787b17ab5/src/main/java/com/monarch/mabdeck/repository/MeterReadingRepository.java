package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.MeterReading;

@Repository
public interface MeterReadingRepository extends JpaRepository<MeterReading, Long>{

	@Query(value="select \r\n" + 
			"	meter_reading_id as meterReadingId, flow_temperature as reading, method, reading_date_time as readingDateTime, created_date as createdDate,created_user as createdUser,'Total Volume' as type, approved\r\n" + 
			"	from	(\r\n" + 
			"	select distinct mr.* from account a, property_account_association pa, property p, supply_point s, meter m, meter_reading mr\r\n" + 
			"	where\r\n" + 
			"	a.account_id = pa.account_id and\r\n" + 
			"	s.property_id = pa.property_id and\r\n" + 
			"	m.supply_id = s.supply_id and \r\n" + 
			"	mr.meter_id = m.meter_id and\r\n" + 
			"	a.account_id=?1 and m.meter_id=?2 and s.supply_id=?3 and pa.property_id= ?4\r\n" + 
			"	and reading_date_time between ?5 and ?6)t where t.flow_temperature is not null and t.flow_temperature <> 0\r\n" + 
			"union all\r\n" + 
			"	select \r\n" + 
			"	meter_reading_id as meterReadingId, instantaneous_flow as reading, method, reading_date_time as readingDateTime, created_date as createdDate,created_user as createdUser,'Total Volume' as type, approved\r\n" + 
			"	from	(\r\n" + 
			"	select distinct mr.* from account a, property_account_association pa, property p, supply_point s, meter m, meter_reading mr\r\n" + 
			"	where\r\n" + 
			"	a.account_id = pa.account_id and\r\n" + 
			"	s.property_id = pa.property_id and\r\n" + 
			"	m.supply_id = s.supply_id and \r\n" + 
			"	mr.meter_id = m.meter_id and\r\n" + 
			"	a.account_id=?1 and m.meter_id=?2 and s.supply_id=?3 and pa.property_id= ?4\r\n" + 
			"	and reading_date_time between ?5 and ?6)t where t.instantaneous_flow is not null and t.instantaneous_flow <> 0\r\n" + 
			"union all\r\n" + 
			"	select \r\n" + 
			"	meter_reading_id as meterReadingId, meter_reading as reading, method, reading_date_time as readingDateTime, created_date as createdDate,created_user as createdUser,'Total Volume' as type, approved\r\n" + 
			"	from	(\r\n" + 
			"	select distinct mr.* from account a, property_account_association pa, property p, supply_point s, meter m, meter_reading mr\r\n" + 
			"	where\r\n" + 
			"	a.account_id = pa.account_id and\r\n" + 
			"	s.property_id = pa.property_id and\r\n" + 
			"	m.supply_id = s.supply_id and \r\n" + 
			"	mr.meter_id = m.meter_id and\r\n" + 
			"	a.account_id=?1 and m.meter_id=?2 and s.supply_id=?3 and pa.property_id= ?4\r\n" + 
			"	and reading_date_time between ?5 and ?6)t where t.meter_reading is not null and t.meter_reading <> 0\r\n" + 
			"union all\r\n" + 
			"	select \r\n" + 
			"	meter_reading_id as meterReadingId, return_temperature as reading, method, reading_date_time as readingDateTime, created_date as createdDate,created_user as createdUser,'Total Volume' as type, approved\r\n" + 
			"	from	(\r\n" + 
			"	select distinct mr.* from account a, property_account_association pa, property p, supply_point s, meter m, meter_reading mr\r\n" + 
			"	where\r\n" + 
			"	a.account_id = pa.account_id and\r\n" + 
			"	s.property_id = pa.property_id and\r\n" + 
			"	m.supply_id = s.supply_id and \r\n" + 
			"	mr.meter_id = m.meter_id and\r\n" + 
			"	a.account_id=?1 and m.meter_id=?2 and s.supply_id=?3 and pa.property_id= ?4\r\n" + 
			"	and reading_date_time between ?5 and ?6)t where t.return_temperature is not null and t.return_temperature <> 0	\r\n" + 
			"union all\r\n" + 
			"	select \r\n" + 
			"	meter_reading_id as meterReadingId, total_volume as reading, method, reading_date_time as readingDateTime, created_date as createdDate,created_user as createdUser,'Total Volume' as type, approved\r\n" + 
			"	from	(\r\n" + 
			"	select distinct mr.* from account a, property_account_association pa, property p, supply_point s, meter m, meter_reading mr\r\n" + 
			"	where\r\n" + 
			"	a.account_id = pa.account_id and\r\n" + 
			"	s.property_id = pa.property_id and\r\n" + 
			"	m.supply_id = s.supply_id and \r\n" + 
			"	mr.meter_id = m.meter_id and\r\n" + 
			"	a.account_id=?1 and m.meter_id=?2 and s.supply_id=?3 and pa.property_id= ?4\r\n" + 
			"	and reading_date_time between ?5 and ?6)t where t.total_volume is not null and t.total_volume <> 0", nativeQuery = true)
	List<Object[]> getAllMeterReadings(String accountId, Long meterId, Long supplyId, Long propertyId, String startDate, String endDate);
	
	
	@Query(value="select\r\n" + 
			"		meter_reading_id as meterReadingId, flow_temperature as reading, method, reading_date_time as readingDateTime,\r\n" + 
			"		created_date as createdDate,created_user as createdUser,'Flow temperature' as type, approved \r\n" + 
			"		from	( \r\n" + 
			"		select\r\n" + 
			"			distinct mr.* from property_account_association pa, property p, supply_point s, meter m, meter_reading mr \r\n" + 
			"		where \r\n" + 
			"		s.property_id = pa.property_id and \r\n" + 
			"		m.supply_id = s.supply_id and\r\n" + 
			"		mr.meter_id = m.meter_id and \r\n" + 
			"		m.meter_id=?1 and s.supply_id=?2 and pa.property_id= ?3 \r\n" + 
			"		and reading_date_time between ?4 and ?5)t where t.flow_temperature is not null and t.flow_temperature <> 0 \r\n" + 
			"union all \r\n" + 
			"		select\r\n" + 
			"			meter_reading_id as meterReadingId, instantaneous_flow as reading, method, reading_date_time as readingDateTime,\r\n" + 
			"			created_date as createdDate,created_user as createdUser,'Instantaneous flow' as type, approved \r\n" + 
			"		from	( \r\n" + 
			"		select distinct mr.* from property_account_association pa, property p, supply_point s, meter m, meter_reading mr \r\n" + 
			"		where \r\n" + 
			"			s.property_id = pa.property_id and \r\n" + 
			"			m.supply_id = s.supply_id and\r\n" + 
			"			mr.meter_id = m.meter_id and \r\n" + 
			"			m.meter_id=?1 and s.supply_id=?2 and pa.property_id= ?3 \r\n" + 
			"			and reading_date_time between ?4 and ?5)t where t.instantaneous_flow is not null and t.instantaneous_flow <> 0 \r\n" + 
			"union all \r\n" + 
			"		select\r\n" + 
			"			meter_reading_id as meterReadingId, meter_reading as reading, method, reading_date_time as readingDateTime, created_date as createdDate, \r\n" + 
			"			created_user as createdUser,'Meter reading' as type, approved \r\n" + 
			"		from	( \r\n" + 
			"		select distinct mr.* from property_account_association pa, property p, supply_point s, meter m, meter_reading mr \r\n" + 
			"		where \r\n" + 
			"		s.property_id = pa.property_id and \r\n" + 
			"		m.supply_id = s.supply_id and\r\n" + 
			"		mr.meter_id = m.meter_id and \r\n" + 
			"		m.meter_id=?1 and s.supply_id=?2 and pa.property_id= ?3 \r\n" + 
			"		and reading_date_time between ?4 and ?5)t where t.meter_reading is not null and t.meter_reading <> 0 \r\n" + 
			"union all \r\n" + 
			"		select\r\n" + 
			"			meter_reading_id as meterReadingId, return_temperature as reading, method, reading_date_time as readingDateTime, created_date as createdDate, \r\n" + 
			"			created_user as createdUser,'Return temperature' as type, approved \r\n" + 
			"		from	( \r\n" + 
			"		select distinct mr.* from property_account_association pa, property p, supply_point s, meter m, meter_reading mr \r\n" + 
			"		where \r\n" + 
			"		s.property_id = pa.property_id and \r\n" + 
			"		m.supply_id = s.supply_id and\r\n" + 
			"		mr.meter_id = m.meter_id and \r\n" + 
			"		m.meter_id=?1 and s.supply_id=?2 and pa.property_id= ?3 \r\n" + 
			"		and reading_date_time between ?4 and ?5)t where t.return_temperature is not null and t.return_temperature <> 0 \r\n" + 
			"union all \r\n" + 
			"		select\r\n" + 
			"		meter_reading_id as meterReadingId, total_volume as reading, method, reading_date_time as readingDateTime, created_date as createdDate,\r\n" + 
			"		created_user as createdUser,'Total Volume' as type, approved \r\n" + 
			"		from	( \r\n" + 
			"		select distinct mr.* from property_account_association pa, property p, supply_point s, meter m, meter_reading mr \r\n" + 
			"		where \r\n" + 
			"		s.property_id = pa.property_id and \r\n" + 
			"		m.supply_id = s.supply_id and\r\n" + 
			"		mr.meter_id = m.meter_id and \r\n" + 
			"		m.meter_id=?1 and s.supply_id=?2 and pa.property_id= ?3 \r\n" + 
			"		and reading_date_time between ?4 and ?5)t where t.total_volume is not null and t.total_volume <> 0", nativeQuery = true)
	List<Object[]> getAllMeterReadingsForProperty(Long meterId, Long supplyId, Long propertyId, String startDate, String endDate);
	
	@Query(value="select top 1 * from meter_reading where cast(reading_date_time as date)=?1 and meter_id=?2 order by reading_date_time desc", nativeQuery = true)
	MeterReading getMeterReadingForPropertyByDate(String date, long meterId);
	
	@Query(value="select top 1 * from meter_reading where cast(reading_date_time as date)<?1 and meter_id=?2 order by reading_date_time desc", nativeQuery = true)
	MeterReading getImmediateMeterReadingForMeterId(String date, long meterId);
	
	@Query(value="select  * from meter_reading where cast(reading_date_time as date) >= ?1 and meter_id=?3 and cast(reading_date_time as date)<=?2 order by reading_date_time", nativeQuery = true)
	List<MeterReading> getIntermediateMeterReadingForMeterId(String startDate, String endDate, long meterId);
	
	@Query(value="select count(*) as count from meter_reading where meter_id=?1 and CAST(reading_date_time AS DATE)=(select cast(start_date-1 as date) from property_account_association where association_id=?2)", nativeQuery = true)
	int getMeterReadingsCount(long meterId, long associationId);
	
	@Query(value="select count(*) as count from meter_reading where meter_id=?1 and CAST(reading_date_time AS DATE)=(select cast(start_date as date) from property_account_association where association_id=?2)", nativeQuery = true)
	int getMeterReadingsCountForCurrent(long meterId, long associationId);
	
	@Query(value="select count(*) as count from meter_reading where meter_id=?1 and CAST(reading_date_time AS DATE)=(select cast(end_date-1 as date) from property_account_association where association_id=?2)", nativeQuery=true)
	int getPreviousDayMeterReadingsCountForMoveOutTenant(long meterId, long associationId);
	
	@Query(value="select count(*) as count from meter_reading where meter_id=?1 and CAST(reading_date_time AS DATE)=(select cast(end_date as date) from property_account_association where association_id=?2)",nativeQuery=true)
	int getCurrentDayMeterReadingsCountForMoveOutTenant(long meterId, long associationId);
	
	@Query(value="select top 1 * from meter_reading where meter_id=?1 and meter_reading>0 order by created_date desc", nativeQuery = true)
	MeterReading getLatestMeterReadingForId(long meterId);
	
	@Query(value="select top 1 * from meter_reading where meter_id=?1 and (flow_temperature>0 or return_temperature>0) order by created_date desc", nativeQuery = true)
	MeterReading getLatestTempMeterReadingForId(long meterId);
 }