package com.monarch.mabdeck.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class NegativeConsumptionValidation  implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long validationId;
	
	private int supplyId;
	private boolean enabled;
	private int tolerance;
	
	@ManyToOne(targetEntity = Validation.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "validId", referencedColumnName = "validId", insertable = true, updatable = true)
	private Validation validation;
	
	public long getValidationId() {
		return validationId;
	}
	public int getSupplyId() {
		return supplyId;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public int getTolerance() {
		return tolerance;
	}
	public void setValidationId(long validationId) {
		this.validationId = validationId;
	}
	public void setSupplyId(int supplyId) {
		this.supplyId = supplyId;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public void setTolerance(int tolerance) {
		this.tolerance = tolerance;
	}
}
