package com.monarch.mabdeck.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.SupplyPointDto;
import com.monarch.mabdeck.service.SupplyPointService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class SupplyPointController {

	private Logger logger = LoggerFactory.getLogger(SupplyPointController.class);

	@Autowired
	private SupplyPointService supplyPointService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.SUPPLYPOINT, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createSupplyPoint(@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody SupplyPointDto SupplyPoint) {
		logger.info("SupplyPointController: createSupplyPoint - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("SupplyPointController: createSupplyPoint - Service call, Username : " + username);
		supplyPointService.create(SupplyPoint, username);
		logger.info("SupplyPointController: createSupplyPoint - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.SUPPLYPOINT, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void updateSupplyPoint(@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody SupplyPointDto SupplyPoint) {
		logger.info("SupplyPointController: updateSupplyPoint - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("SupplyPointController: updateSupplyPoint - Service call, Username : " + username);
		supplyPointService.update(SupplyPoint, username);
		logger.info("SupplyPointController: updateSupplyPoint - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_SUPPLYPOINT_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody SupplyPointDto getSupplyPointById(@PathVariable("supplypoint_id") Long SupplyPointId)
			throws NotFoundException {
		logger.info("SupplyPointController: getSupplyPointById - Start");
		return supplyPointService.read(SupplyPointId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.SUPPLYPOINT, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<SupplyPointDto> getAllSupplyPoints() throws NotFoundException {
		logger.info("SupplyPointController: getAllSupplyPoints - Start");
		return supplyPointService.readAll();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.SUPPLYPOINT_BY_ClIENT_AND_NETWORK_AND_PROPERTY, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<SupplyPointDto> getSupplyPointsByClientAndNetworkAndProperty(@PathVariable("clientId") Long clientId,
			@PathVariable("networkId") Long networkId, @PathVariable("propertyId") Long propertyId) {
		logger.info("SupplyPointController: getSupplyPointsByClientAndNetworkAndProperty - Start");
		return supplyPointService.getSupplyPointTypes(clientId, networkId, propertyId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.SUPPLYPOINT_BY_ClIENT_AND_NETWORK, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<SupplyPointDto> getSupplyPointsByClientAndNetwork(@PathVariable("clientId") Long clientId,
			@PathVariable("networkId") Long networkId) {
		logger.info("SupplyPointController: getSupplyPointsByClientAndNetwork - Start");
		return supplyPointService.getSupplyPointTypesByNetworkAndClient(clientId, networkId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.SUPPLY_POINT_TEMPLATE, method = RequestMethod.GET, produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> getReport(@RequestParam("client_id") Long clientId,
			@RequestParam("network_id") Long networkId, @RequestParam("band_id") Long bandId,
			@RequestParam("supply_type_id") Long supplyTypeId) throws IOException, InterruptedException {
		logger.info("SupplyPointController: getReport - Start");
		byte[] meterReadingTemplate = supplyPointService.downloadTemplate(clientId, networkId, bandId, supplyTypeId);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "supplyPointTemplate.csv");
		header.setContentLength(meterReadingTemplate.length);
		logger.info("SupplyPointController: getReport - End");
		return new HttpEntity<byte[]>(meterReadingTemplate, header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.SUPPLY_POINT_TEMPLATE, method = RequestMethod.POST, consumes = "multipart/form-data", produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> uploadBulkSupplyPointFile(@RequestParam("file") MultipartFile file) throws IOException {
		logger.info("SupplyPointController: uploadBulkSupplyPointFile - Start");
		byte[] result = supplyPointService.uploadCSV(file);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "result.csv");
		header.setContentLength(result.length);
		logger.info("SupplyPointController: uploadBulkSupplyPointFile - End");
		return new HttpEntity<byte[]>(result, header);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.SUPPLY_COUNT, method = RequestMethod.GET)
	public long getCount() {
		return supplyPointService.getCount();
	}
}
