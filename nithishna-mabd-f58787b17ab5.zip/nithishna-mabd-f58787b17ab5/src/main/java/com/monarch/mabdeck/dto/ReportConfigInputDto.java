package com.monarch.mabdeck.dto;

public class ReportConfigInputDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private long clientId;
	private long networkId;
	private long propertyId;
	private long bandId;
	private boolean isSingleMeter;
	private long supplyId;	
	private String reportName;
	private long reportTypeId;
	private String meterSerialNumber;
	public long getId() {
		return id;
	}
	public long getClientId() {
		return clientId;
	}
	public long getNetworkId() {
		return networkId;
	}
	public long getPropertyId() {
		return propertyId;
	}
	public long getBandId() {
		return bandId;
	}
	public boolean isSingleMeter() {
		return isSingleMeter;
	}
	public long getSupplyId() {
		return supplyId;
	}
	public String getReportName() {
		return reportName;
	}
	public String getMeterSerialNumber() {
		return meterSerialNumber;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setClientId(long clientId) {
		this.clientId = clientId;
	}
	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}
	public void setPropertyId(long propertyId) {
		this.propertyId = propertyId;
	}
	public void setBandId(long bandId) {
		this.bandId = bandId;
	}
	public void setSingleMeter(boolean isSingleMeter) {
		this.isSingleMeter = isSingleMeter;
	}
	public void setSupplyId(long supplyId) {
		this.supplyId = supplyId;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public void setMeterSerialNumber(String meterSerialNumber) {
		this.meterSerialNumber = meterSerialNumber;
	}
	public long getReportTypeId() {
		return reportTypeId;
	}
	public void setReportTypeId(long reportTypeId) {
		this.reportTypeId = reportTypeId;
	}
}
