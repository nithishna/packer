package com.monarch.mabdeck.dto;

public class ClientMetadata implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long clientId;
	private String clientName;
	public long getClientId() {
		return clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientId(long clientId) {
		this.clientId = clientId;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
}
