package com.monarch.mabdeck.entity;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Inheritance(strategy = InheritanceType.JOINED)
@Entity
@DiscriminatorColumn(name = "action_type")
public class Action implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private boolean owner;
	
	@ManyToOne(cascade = CascadeType.ALL, targetEntity = Stage.class, fetch = FetchType.EAGER)
	@JoinColumn(name="stageId",referencedColumnName="stageId", insertable = true, updatable = true)
	private Stage stage;
	private boolean deleted;
	public long getId() {
		return id;
	}
	public boolean isOwner() {
		return owner;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setOwner(boolean owner) {
		this.owner = owner;
	}
	public Stage getStage() {
		return stage;
	}
	public void setStage(Stage stage) {
		this.stage = stage;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
}
