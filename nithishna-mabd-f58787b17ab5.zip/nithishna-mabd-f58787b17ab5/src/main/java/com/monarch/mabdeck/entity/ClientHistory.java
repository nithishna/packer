package com.monarch.mabdeck.entity;

import java.math.BigInteger;
import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ClientHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	private Long clientId;
	private String clientName;
	private String logo;
	
	@Embedded
	private Address address;
	private Date startDate;
	private String companyNumber;
	private BigInteger vatNumber;
	private String currency;
	private int paymentTerm;
	
	@Embedded
	private Audit audit;
	private Long serviceId;
	private Long contactId;
	private Long bankAccountId;
	public Long getClientId() {
		return clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public String getLogo() {
		return logo;
	}
	public Address getAddress() {
		return address;
	}
	public Date getStartDate() {
		return startDate;
	}
	public String getCompanyNumber() {
		return companyNumber;
	}
	public BigInteger getVatNumber() {
		return vatNumber;
	}
	public String getCurrency() {
		return currency;
	}
	public int getPaymentTerm() {
		return paymentTerm;
	}
	public Audit getAudit() {
		return audit;
	}
	public Long getServiceId() {
		return serviceId;
	}
	public Long getContactId() {
		return contactId;
	}
	public Long getBankAccountId() {
		return bankAccountId;
	}
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public void setCompanyNumber(String companyNumber) {
		this.companyNumber = companyNumber;
	}
	public void setVatNumber(BigInteger vatNumber) {
		this.vatNumber = vatNumber;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public void setPaymentTerm(int paymentTerm) {
		this.paymentTerm = paymentTerm;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public void setServiceId(Long serviceId) {
		this.serviceId = serviceId;
	}
	public void setContactId(Long contactId) {
		this.contactId = contactId;
	}
	public void setBankAccountId(Long bankAccountId) {
		this.bankAccountId = bankAccountId;
	}
	
}
