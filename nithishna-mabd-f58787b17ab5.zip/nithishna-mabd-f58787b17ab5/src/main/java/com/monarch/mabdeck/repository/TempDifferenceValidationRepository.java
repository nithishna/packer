package com.monarch.mabdeck.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.TempDifferenceValidation;

@Repository
public interface TempDifferenceValidationRepository extends JpaRepository<TempDifferenceValidation, Long> {

}
