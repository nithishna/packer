package com.monarch.mabdeck.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.CustomerServiceContactDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.CustomerServiceContact;
import com.monarch.mabdeck.mapper.CustomerServiceContactMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.repository.CustomerServiceContactRepository;

@Component
public class CustomerContactService extends CommonServiceImpl<CustomerServiceContactDto, CustomerServiceContact> {
	
	private Logger logger = LoggerFactory.getLogger(CustomerContactService.class);
	
	@Resource
	private CustomerServiceContactRepository repository;
	

	@Override
	public JpaRepository<CustomerServiceContact, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<CustomerServiceContactDto, CustomerServiceContact> getMapper() {
		return CustomerServiceContactMapper.INSTANCE;
	}

	@Override
	public void updateAudit(CustomerServiceContact entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
			}else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
}
