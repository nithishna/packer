package com.monarch.mabdeck.dto;

public class HubTemplateDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long clientId;
	private Long networkId;
	private String hubManufacturer;
	private String hubModel;
	public Long getClientId() {
		return clientId;
	}
	public Long getNetworkId() {
		return networkId;
	}
	public String getHubManufacturer() {
		return hubManufacturer;
	}
	public String getHubModel() {
		return hubModel;
	}
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}
	public void setHubManufacturer(String hubManufacturer) {
		this.hubManufacturer = hubManufacturer;
	}
	public void setHubModel(String hubModel) {
		this.hubModel = hubModel;
	}
	
}
