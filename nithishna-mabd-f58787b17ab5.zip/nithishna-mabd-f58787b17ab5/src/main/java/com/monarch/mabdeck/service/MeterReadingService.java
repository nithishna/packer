package com.monarch.mabdeck.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Scanner;

import javax.annotation.Resource;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.MeterReadingDto;
import com.monarch.mabdeck.dto.MeterReadingItemDto;
import com.monarch.mabdeck.dto.MeterReadingSearchDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Meter;
import com.monarch.mabdeck.entity.MeterReading;
import com.monarch.mabdeck.entity.NegativeConsumptionHistory;
import com.monarch.mabdeck.entity.NegativeConsumptionValidation;
import com.monarch.mabdeck.entity.NegativeReadingHistory;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.TemperatureDifferenceHistory;
import com.monarch.mabdeck.entity.Validation;
import com.monarch.mabdeck.entity.ZeroConsumptionHistory;
import com.monarch.mabdeck.entity.ZeroConsumptionValidation;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.MeterReadingMapper;
import com.monarch.mabdeck.repository.MeterReadingRepository;
import com.monarch.mabdeck.repository.MeterRepository;
import com.monarch.mabdeck.repository.NegativeConsumptionHistoryRepository;
import com.monarch.mabdeck.repository.NegativeConsumptionValidationRepository;
import com.monarch.mabdeck.repository.NegativeReadingHistoryRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.repository.TempDifferenceValidationRepository;
import com.monarch.mabdeck.repository.TemperatureDifferenceHistoryRepository;
import com.monarch.mabdeck.repository.ValidationRepository;
import com.monarch.mabdeck.repository.ZeroConsumptionHistoryRepository;
import com.monarch.mabdeck.repository.ZeroConsumptionValidationRepository;
import com.monarch.mabdeck.util.Constants;

@Component
public class MeterReadingService extends CommonServiceImpl<MeterReadingDto, MeterReading> {

	private Logger logger = LoggerFactory.getLogger(MeterReadingService.class);
	private SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
	@Resource
	private MeterReadingRepository repository;

	@Resource
	private MeterRepository meterRepository;

	@Resource
	private NetworkRepository networkRepository;

	@Resource
	private ValidationRepository validationRepo;

	@Resource
	private NegativeConsumptionValidationRepository negativeConsumptionValidationRepo;

	@Resource
	private ZeroConsumptionValidationRepository zeroConsumptionValidationRepo;

	@Resource
	private TempDifferenceValidationRepository tempDifferenceValidationRepo;

	@Resource
	private ZeroConsumptionHistoryRepository zeroConsumptionHistoryRepo;

	@Resource
	private TemperatureDifferenceHistoryRepository tempDifferenceHistoryRepo;

	@Resource
	private NegativeReadingHistoryRepository negativeReadingHistoryRepo;

	@Resource
	private NegativeConsumptionHistoryRepository negativeConsumptionHistoryRepo;

	@Override
	public JpaRepository<MeterReading, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<MeterReadingDto, MeterReading> getMapper() {
		return MeterReadingMapper.INSTANCE;
	}

	@Override
	public void updateAudit(MeterReading entity, String username) {
		if (entity != null) {
			Calendar cal = Calendar.getInstance();
			if (entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			} else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}
	}

	public MeterReadingDto createNew(MeterReadingDto dto, String username)
			throws ParseException, InvalidFormatException {
		long networkId = 0, meterId = 0;
		String supplyType = null;
		MeterReading entity = this.getMapper().convertToEntity(dto);
		updateAudit(entity, username);
		if (dto.getMeter() != null && dto.getMeter().getMeterId() != null) {
			Meter meter = meterRepository.findOne(dto.getMeter().getMeterId());
			entity.setMeter(meter);
			Network network = meter.getNetwork();
			entity.setNetwork(network);
			networkId = network.getNetworkId();
			meterId = meter.getMeterId();
			supplyType = meter.getSupply() != null ? meter.getSupply().getSupplyType() : null;
		} else {
			throw new InvalidFormatException("Meter details are mandatory");
		}
		MeterReading latestReading = null;
		if(dto.getMeterReading() > 0)
			latestReading =	this.repository.getLatestMeterReadingForId(meterId);
		else
			latestReading = this.repository.getLatestTempMeterReadingForId(meterId);
		entity.setFlowTemperature(dto.getFlowTemperature());
		entity.setInstantaneousFlow(dto.getInstantaneousFlow());
		entity.setReturnTemperature(dto.getReturnTemperature());
		entity.setMeterReading(dto.getMeterReading());
		entity.setTotalVolume(dto.getTotalVolume());
		entity.setMethod(dto.getMethod());
		if (dto.getReadingDateTime() != null)
			entity.setReadingDateTime(formatter.parse(dto.getReadingDateTime()));
		entity.setApproved(false);
		entity.setRejected(false);
		entity = repository.saveAndFlush(entity);
		if(validateMeterReading(entity, networkId, meterId, supplyType, latestReading)) {
			entity.setApproved(true);
			repository.save(entity);
		}
		return dto;
	}

	private boolean validateMeterReading(MeterReading reading, long networkId, long meterId, String supplyType, MeterReading latestReading) {
		boolean flag = true;
		Validation validation = this.validationRepo.findByNetworkNetworkId(networkId);
		if (validation.getTempValidation() != null) {
			if (reading.getFlowTemperature() > 0 || reading.getReturnTemperature() > 0) {
				double diff = reading.getFlowTemperature() - reading.getReturnTemperature();
				int tolerance = validation.getTempValidation().getTolerance();
				if (diff < (-1) * tolerance) {
					flag = false;
					TemperatureDifferenceHistory his = new TemperatureDifferenceHistory();
					his.setDeleted(false);
					his.setFlowTemperature(new BigDecimal(reading.getFlowTemperature()));
					his.setReturnTemperature(new BigDecimal(reading.getReturnTemperature()));
					his.setMeterId(meterId);
					his.setMeterReadingId(reading.getMeterReadingId());
					his.setReadingDate(reading.getReadingDateTime());
					his.setValidationType("Unusual Temperature Difference");
					this.tempDifferenceHistoryRepo.save(his);
				}
				return flag;
			}
		}

		if (validation.getZeroConsumptionValidation() != null) {
			if (latestReading != null) {
				ZeroConsumptionValidation zeroConsumption = validation.getZeroConsumptionValidation();
				double diff = reading.getMeterReading() - latestReading.getMeterReading() - zeroConsumption.getTolerance();
				if (diff <= 0) {
					flag = false;
					ZeroConsumptionHistory his = new ZeroConsumptionHistory();
					his.setDeleted(false);
					his.setMeterId(meterId);
					his.setMeterReadingId(reading.getMeterReadingId());
					his.setReadingDate(reading.getReadingDateTime());
					his.setZeroReading(new BigDecimal(reading.getMeterReading()));
					his.setValidationType("Zero Consumption");
					this.zeroConsumptionHistoryRepo.save(his);
					return flag;
				}
			}
		}

		if (validation.getNegativeValidation() != null && validation.getNegativeValidation().size() > 0) {
			Map<Long, String> supplyTypeMap = Constants.supplyTypeMap;
			Optional<Entry<Long, String>> entry = supplyTypeMap.entrySet().stream()
					.filter(x -> x.getValue().equalsIgnoreCase(supplyType)).findFirst();
			long supplyId = 0;
			if (entry.isPresent()) {
				supplyId = entry.get().getKey();
			}
			final long value = supplyId;
			Optional<NegativeConsumptionValidation> val = validation.getNegativeValidation().stream()
					.filter(x -> (x.getSupplyId() == value)).findFirst();
			if (val.isPresent()) {
				NegativeConsumptionValidation validator = val.get();
				if (latestReading != null) {
					double diff = reading.getMeterReading() - latestReading.getMeterReading();
					if (diff < (-1)*validator.getTolerance()) {
						flag = false;
						NegativeConsumptionHistory his = new NegativeConsumptionHistory();
						his.setDeleted(false);
						his.setMeterId(meterId);
						his.setMeterReadingId(reading.getMeterReadingId());
						his.setPreviousReading(new BigDecimal(latestReading.getMeterReading()));
						his.setPreviousReadingDate(latestReading.getReadingDateTime());
						his.setValidationType("Negative Consumption");
						his.setFailedReading(new BigDecimal(reading.getMeterReading()));
						his.setFailedReadingDate(reading.getReadingDateTime());
						this.negativeConsumptionHistoryRepo.save(his);
						return flag;
					}
				}
			}
		}
		
		if(reading.getMeterReading() < 0) {
			flag = false;
			NegativeReadingHistory his =  new NegativeReadingHistory();
			his.setDeleted(false);
			his.setMeterId(meterId);
			his.setMeterReadingId(reading.getMeterReadingId());
			his.setNegativeReadingDate(reading.getReadingDateTime());
			his.setNegativeReading(new BigDecimal(reading.getMeterReading()));
			his.setValidationType("Zero Consumption");
			this.negativeReadingHistoryRepo.save(his);
		}
		return flag;
	}

	public byte[] uploadCSV(MultipartFile multipartFile) throws IOException {
		File file = null;
		byte[] result = null;
		try {
			file = convertMultiPartToFile(multipartFile);
			FileWriter csvWriter = new FileWriter("result.csv");
			Scanner scanner = new Scanner(file);
			boolean headingValidation = false;
			while (scanner.hasNextLine()) {
				if (!headingValidation) {
					headingValidation = validateHeading(scanner.nextLine());
					if (!headingValidation) {
						scanner.close();
						throw new IOException("Kindly check the heading order");
					}
					for (String value : Constants.meterReadingHeading) {
						csvWriter.append(value);
						csvWriter.append(",");
					}
					csvWriter.append("Message").append("\n");
				} else
					getRecordFromLine(scanner.nextLine(), csvWriter);
			}
			scanner.close();
			csvWriter.flush();
			csvWriter.close();
			InputStream stream = new FileInputStream("result.csv");
			result = IOUtils.toByteArray(stream);
			stream.close();
			if (file != null)
				logger.debug(file.delete() ? "Temp File Deleted successfully" : "Temp File could not be deleted");
			File resultFile = new File("result.csv");
			resultFile.delete();
		} catch (Exception ex) {
			if (file != null)
				logger.debug(file.delete() ? "Temp File Deleted successfully" : "Temp File could not be deleted");
			throw new IOException("Unable to parse the file. Kindly raise a support request and get this sorted");
		}
		return result;
	}

	private boolean validateHeading(String line) {
		List<String> heading = Constants.meterReadingHeading;
		Iterator<String> iterator = heading.iterator();
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			while (rowScanner.hasNext()) {
				if (!iterator.next().equalsIgnoreCase(rowScanner.next())) {
					return false;
				}
			}
		}
		return true;
	}

	private void getRecordFromLine(String line, FileWriter csvWriter) throws IOException {
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			long networkId = 0;
			long meterId = 0;
			String supplyType = null;
			MeterReading reading = new MeterReading();
			if (rowScanner.hasNext()) {
				networkId = rowScanner.nextInt();
				Network network = networkRepository.findOne(networkId);
				reading.setNetwork(network);
				logger.debug("Network name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			if (rowScanner.hasNext()) {
				String serialNumber = rowScanner.next();
				Meter meter = null;
				if (serialNumber != null)
					meter = meterRepository.findMeterByNetworkAndSerialNumber(serialNumber, networkId);
				else
					throw new IOException(
							"Serial Number cannot be empty...Please enter the serial number and try again!");
				if (meter == null)
					throw new IOException(
							"Kindly enter valid serial number...Cannot find serial number: " + serialNumber);
				meterId = meter.getMeterId();
				supplyType = meter.getSupply().getSupplyType();
				reading.setMeter(meter);
			}
			reading.setMethod(rowScanner.hasNext() ? rowScanner.next() : null);
			for (int i = 1; i <= 5; i++) {
				if (rowScanner.hasNext()) {
					String value = rowScanner.next();
					float floatValue = 0;
					switch (i) {
					case 1:
						floatValue = (value.isEmpty() ? 0 : Float.parseFloat(value));
						reading.setMeterReading(floatValue);
						break;
					case 2:
						floatValue = (value.isEmpty() ? 0 : Float.parseFloat(value));
						reading.setFlowTemperature(floatValue);
						break;
					case 3:
						floatValue = (value.isEmpty() ? 0 : Float.parseFloat(value));
						reading.setReturnTemperature(floatValue);
						break;
					case 4:
						floatValue = (value.isEmpty() ? 0 : Float.parseFloat(value));
						reading.setInstantaneousFlow(floatValue);
						break;
					case 5:
						floatValue = (value.isEmpty() ? 0 : Float.parseFloat(value));
						reading.setTotalVolume(floatValue);
						break;
					}
				}
			}
			if (rowScanner.hasNext()) {
				Date date = null;
				try {
					date = new SimpleDateFormat("dd/MM/yyyy").parse(rowScanner.next());
				} catch (Exception ex) {
					throw new IOException(
							"Issue in the data!.....Kindly specify date in dd/MM/YYYY format and try again");
				}
				if (date != null)
					reading.setReadingDateTime(new java.sql.Date(date.getTime()));
				else
					throw new IOException("Reading Date time cannot be empty....Kindly update the excel and try again");
			}
			MeterReading latestReading = null;
			if(reading.getMeterReading() > 0)
				latestReading =	this.repository.getLatestMeterReadingForId(meterId);
			else
				latestReading = this.repository.getLatestTempMeterReadingForId(meterId);
			this.updateAudit(reading, "Application\\Bulk upload");
			reading.setApproved(false);
			reading.setRejected(false);
			reading = repository.saveAndFlush(reading);
			if(validateMeterReading(reading, networkId, meterId, supplyType, latestReading)) {
				reading.setApproved(true);
				repository.save(reading);
			}
			this.writeLine(line, csvWriter);
			csvWriter.append("Success");
			csvWriter.append("\n");
		} catch (Exception ex) {
			this.writeLine(line, csvWriter);
			csvWriter.append("Error: " + ex.getMessage());
			csvWriter.append("\n");
		}
	}

	private void writeLine(String line, FileWriter csvWriter) throws IOException {
		String[] values = line.split(",");
		for (String value : values) {
			csvWriter.append(value);
			csvWriter.append(",");
		}
		int extension = Constants.meterReadingHeading.size() - values.length;
		if (extension > 0) {
			for (int i = 0; i < extension; i++) {
				csvWriter.append("");
				csvWriter.append(",");
			}
		}
	}

	private File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

	public byte[] downloadTemplate(Long networkId) throws IOException {
		File tempFile = new File("template.csv");
		PrintWriter pw = new PrintWriter(tempFile);
		StringBuilder sb = new StringBuilder();
		this.populateHeading(sb);
		String networkName = networkRepository.getNetworkNameById(networkId);
		this.populateRow(networkId, networkName, sb);
		pw.write(sb.toString());
		pw.close();
		InputStream stream = new FileInputStream("template.csv");
		byte[] result = IOUtils.toByteArray(stream);
		stream.close();
		logger.debug("File deletion status : " + (tempFile.delete() ? "Success" : "Failure"));
		return result;
	}

	private void populateHeading(StringBuilder sb) {
		sb.append("NetworkId").append(",");
		sb.append("Network").append(",");
		sb.append("Serial Number").append(",");
		sb.append("Method").append(",");
		sb.append("Meter Reading").append(",");
		sb.append("Flow Temperature").append(",");
		sb.append("Return Temperature").append(",");
		sb.append("Instantaneous Flow").append(",");
		sb.append("Total Volume").append(",");
		sb.append("Reading Date Time");
		sb.append("\n");
	}

	private void populateRow(Long networkId, String networkName, StringBuilder sb) {
		sb.append(networkId.toString()).append(",");
		sb.append(networkName).append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append("").append(",");
		sb.append("").append(",");
		sb.append("").append(",");
		sb.append("").append(",");
		sb.append(Constants.REQUIRED);
		sb.append("\n");
	}

	public List<MeterReadingItemDto> getAllMeterReadingsForAccount(MeterReadingSearchDto input) throws ParseException {
		List<Object[]> meterReadings = repository.getAllMeterReadings(input.getAccountId(), input.getMeterId(),
				input.getSupplyId(), input.getPropertyId(), input.getReadingFromDate(), input.getReadingToDate());

		List<MeterReadingItemDto> dtos = new ArrayList<>();
		for (Object[] element : meterReadings) {
			MeterReadingItemDto dto = new MeterReadingItemDto();
			dto.setMeterReadingId(Long.parseLong(element[0].toString()));
			dto.setReading(element[1] != null ? Double.parseDouble(element[1].toString()) : null);
			dto.setMethod(element[2] != null ? element[2].toString() : null);
			if (element[3] != null)
				dto.setReadingDateTime(element[3].toString().split(" ")[0]);
			else
				dto.setReadingDateTime(null);
			if (element[4] != null)
				dto.setCreatedDate(element[4].toString().split(" ")[0]);
			else
				dto.setCreatedDate(null);
			dto.setCreatedUser(element[5] != null ? element[5].toString() : null);
			dto.setType(element[6] != null ? element[6].toString() : null);
			if (element[7] != null) {
				dto.setApproved(element[7].toString().equalsIgnoreCase("1") ? "Yes" : "No");
			} else
				dto.setApproved(null);
			dtos.add(dto);
		}
		return dtos;
	}

	public List<MeterReadingItemDto> getAllMeterReadingForProperty(MeterReadingSearchDto input) {
		List<Object[]> meterReadings = repository.getAllMeterReadingsForProperty(input.getMeterId(),
				input.getSupplyId(), input.getPropertyId(), input.getReadingFromDate(), input.getReadingToDate());
		List<MeterReadingItemDto> dtos = new ArrayList<>();
		for (Object[] element : meterReadings) {
			MeterReadingItemDto dto = new MeterReadingItemDto();
			dto.setMeterReadingId(Long.parseLong(element[0].toString()));
			dto.setReading(element[1] != null ? Double.parseDouble(element[1].toString()) : null);
			dto.setMethod(element[2] != null ? element[2].toString() : null);
			if (element[3] != null)
				dto.setReadingDateTime(element[3].toString().split(" ")[0]);
			else
				dto.setReadingDateTime(null);
			if (element[4] != null)
				dto.setCreatedDate(element[4].toString().split(" ")[0]);
			else
				dto.setCreatedDate(null);
			dto.setCreatedUser(element[5] != null ? element[5].toString() : null);
			dto.setType(element[6] != null ? element[6].toString() : null);
			if (element[7] != null) {
				dto.setApproved(element[7].toString().equalsIgnoreCase("1") ? "Yes" : "No");
			} else
				dto.setApproved(null);
			dtos.add(dto);
		}
		return dtos;
	}
}
