package com.monarch.mabdeck.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.SupplyPointDto;
import com.monarch.mabdeck.entity.SupplyPoint;

@Mapper(uses = {ClientMapper.class, NetworkMapper.class, PropertyMapper.class})
public abstract class SupplyPointMapper implements IBaseMapper<SupplyPointDto, SupplyPoint>{
	public static final SupplyPointMapper INSTANCE = Mappers.getMapper(SupplyPointMapper.class);
	
	@Mappings({
		@Mapping(target ="meter", ignore = true)
	})
	@Named("toDto")
	public abstract SupplyPointDto convertToDTO(SupplyPoint entity);
	
	@Mappings({
		@Mapping(target ="meter", ignore = true),
		@Mapping(target ="audit", ignore = true)
	})
	public abstract SupplyPoint convertToEntity(SupplyPointDto dto);
	
	@IterableMapping(qualifiedByName = "toDto")
	public abstract List<SupplyPointDto> convertToDTOList(List<SupplyPoint> entities);
	
	@Mappings({
		@Mapping(target ="meter", ignore = true),
		@Mapping(target ="client", ignore = true),
		@Mapping(target ="network", ignore = true),
		@Mapping(target ="property", ignore = true)
	})
	public abstract SupplyPointDto convertToSupplyPointDto(SupplyPoint entity);
}
