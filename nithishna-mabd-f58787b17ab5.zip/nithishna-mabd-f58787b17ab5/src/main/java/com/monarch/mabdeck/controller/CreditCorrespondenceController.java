package com.monarch.mabdeck.controller;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.ActionEmailDto;
import com.monarch.mabdeck.dto.ActionFlagDto;
import com.monarch.mabdeck.dto.ActionLetterDto;
import com.monarch.mabdeck.dto.CreditControlSetupDto;
import com.monarch.mabdeck.dto.CreditCorrespondenceDto;
import com.monarch.mabdeck.dto.CreditNotesDto;
import com.monarch.mabdeck.dto.StageDto;
import com.monarch.mabdeck.service.CreditCorrespondenceService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;

@RestController
public class CreditCorrespondenceController {

	@Autowired
	private CreditCorrespondenceService service;
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_SETUP, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public CreditControlSetupDto getCreditControlSetupByClientId(@RequestParam("clientId") long clientId) throws Exception {
		return this.service.getCreditControlSetupByClientId(clientId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_STAGE, method = RequestMethod.POST, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, consumes = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody StageDto addStage(@RequestBody StageDto stageDto,@PathVariable("clientId") long clientId, @PathVariable("setupId")long setupId) throws Exception {
		return this.service.addStage(stageDto, clientId, setupId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_STAGE_UPDATE, method = RequestMethod.PUT, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, consumes = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void editStage(@RequestBody StageDto stageDto) throws Exception {
		this.service.editStage(stageDto);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_ACTION_EMAIL, method = RequestMethod.POST, consumes = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void addActionEmail(@RequestBody ActionEmailDto dto, @PathVariable("stageId")long stageId) throws Exception {
		this.service.addActionEmail(dto, stageId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_ACTION_LETTER, method = RequestMethod.POST, consumes = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void addActionLetter(@RequestBody ActionLetterDto dto, @PathVariable("stageId")long stageId) throws Exception {
		this.service.addActionLetter(dto, stageId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_ACTION_FLAG, method = RequestMethod.POST, consumes = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void addActionFlag(@RequestBody ActionFlagDto dto, @PathVariable("stageId")long stageId) throws Exception {
		this.service.addActionFlag(dto, stageId);
	}
	
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_ACTION, method = RequestMethod.DELETE)
	public void deleteAction(@RequestParam("id")long actionId,@RequestParam("type") int type) throws Exception {
		this.service.deleteAction(actionId, type);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_CONTROL, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<CreditCorrespondenceDto> getAllCreditControl(@RequestParam("index")int index, @RequestParam("size")int noOfItems){
		return this.service.getAllCreditControl(index, noOfItems);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_CONTROL_CORRESPONDENCE, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<CreditCorrespondenceDto> getAllCreditControlCorrespondence(@RequestParam("index")int index, @RequestParam("size")int noOfItems) {
		return this.service.getAllCreditControlCorrespondence(index, noOfItems);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_CONTROL_CORRESPONDENCE_NOTES, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<CreditNotesDto> getAllNotesForCorrespondenceId(@PathVariable("id")long id){
		return this.service.getAllNotesForCorrespondenceId(id);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CREDIT_CONTROL_CORRESPONDENCE_NOTES, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createNote(@RequestBody CreditNotesDto dto, @PathVariable("id") long correspondenceId, @ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization) {
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		this.service.createNote(dto, correspondenceId, username);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.CREDIT_CONTROL_NOTE_ATTACHMENT, method = RequestMethod.GET, produces = "text/plain; charset=utf-8")
	public HttpEntity<byte[]> getAttachmentForNote(@RequestParam("note_id") Long noteId) throws Exception {
		byte[] attachment = service.getAttachmentForNote(noteId);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "file.txt");
		header.setContentLength(attachment.length);
		return new HttpEntity<byte[]>(attachment, header);
	}	
}
