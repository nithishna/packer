package com.monarch.mabdeck.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Bank implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long bankId;
	
	private String name;
	
	@OneToMany(mappedBy="bank", cascade = CascadeType.ALL)
	private List<BankAccount> account;
	
	@Embedded
	private Audit audit;
	
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Long getId() {
		return bankId;
	}
	public void setId(Long bankId) {
		this.bankId = bankId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<BankAccount> getAccount() {
		return account;
	}
	public void setAccount(List<BankAccount> account) {
		this.account = account;
	}
}
