package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Tariff;
import com.monarch.mabdeck.entity.TariffHistory;
import com.monarch.mabdeck.repository.TariffHistoryRepository;

@Component
public class TariffHistoryService {

	@Resource
	private TariffHistoryRepository historyRepository;
	
	public void updateTariffHistory(Tariff tariff, String username) {
		if(tariff!=null) {
			TariffHistory history = new TariffHistory();
			history.setActiveFromDate(tariff.getActiveFromDate());
			history.setActiveToDate(tariff.getActiveToDate());
			history.setAudit(tariff.getAudit());
			history.setBandId(tariff.getBand() != null? tariff.getBand().getBandId(): null);
			history.setDeleted(tariff.getDeleted());
			history.setPropertyId(tariff.getPropertyAreaCharge()!= null? tariff.getPropertyAreaCharge().getPropertyChargeId() : null);
			history.setSupplyType(tariff.getSupplyType());
			history.setTariffCode(tariff.getTariffCode());
			history.setTariffId(tariff.getTariffId());
			history.setTariffName(tariff.getTariffName());
			history.setTariffType(tariff.getTariffType());
			history.setVatRate(tariff.getVatRate());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
