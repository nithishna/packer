package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PropertyAreaChargeHistory implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long propertyChargeId;
	private String name;
	private float pricePerUnit;
	private String areaUnits;
	@Embedded
	private Audit audit;
	public Long getId() {
		return id;
	}
	public Long getPropertyChargeId() {
		return propertyChargeId;
	}
	public String getName() {
		return name;
	}
	public float getPricePerUnit() {
		return pricePerUnit;
	}
	public String getAreaUnits() {
		return areaUnits;
	}
	public Audit getAudit() {
		return audit;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setPropertyChargeId(Long propertyChargeId) {
		this.propertyChargeId = propertyChargeId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPricePerUnit(float pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public void setAreaUnits(String areaUnits) {
		this.areaUnits = areaUnits;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
}
