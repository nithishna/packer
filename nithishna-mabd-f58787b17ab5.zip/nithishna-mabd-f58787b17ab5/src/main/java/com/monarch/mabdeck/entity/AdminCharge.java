package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class AdminCharge implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long adminChargeId;
	private String chargeTo;
	private String description;
	private float dailyCharge;
	private float vatRate;
	private Date activeFromDate;
	private Date activeToDate;
	
	@ManyToOne(targetEntity = Band.class, fetch = FetchType.LAZY)
	@JoinColumn(name="bandId",referencedColumnName="bandId", insertable = true, updatable = true)
	private Band band;
	
	@Embedded
	private Audit audit;
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Long getAdminChargeId() {
		return adminChargeId;
	}
	public void setAdminChargeId(Long adminChargeId) {
		this.adminChargeId = adminChargeId;
	}
	public String getChargeTo() {
		return chargeTo;
	}
	public void setChargeTo(String chargeTo) {
		this.chargeTo = chargeTo;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public float getDailyCharge() {
		return dailyCharge;
	}
	public void setDailyCharge(float dailyCharge) {
		this.dailyCharge = dailyCharge;
	}
	public float getVatRate() {
		return vatRate;
	}
	public void setVatRate(float vatRate) {
		this.vatRate = vatRate;
	}
	public Date getActiveFromDate() {
		return activeFromDate;
	}
	public void setActiveFromDate(Date activeFromDate) {
		this.activeFromDate = activeFromDate;
	}
	public Date getActiveToDate() {
		return activeToDate;
	}
	public void setActiveToDate(Date activeToDate) {
		this.activeToDate = activeToDate;
	}
	public Band getBand() {
		return band;
	}
	public void setBand(Band band) {
		this.band = band;
	}

}
