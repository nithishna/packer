package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.ZeroConsumptionHistory;

@Repository
public interface ZeroConsumptionHistoryRepository extends JpaRepository<ZeroConsumptionHistory, Long>{

	@Query(value="select * from(select  nrh.id, c.client_name, n.network, p.address_line1, p.address_line2, p.address_line3,\r\n" + 
			"		p.country, p.region, p.town, p.post_code, m.serial_number, s.supply_type, nrh.validation_type, nrh.zero_reading, nrh.reading_date,\r\n" + 
			"		RowNum = row_number() OVER ( order by nrh.id)\r\n" + 
			"		from zero_consumption_history nrh\r\n" + 
			"		inner join meter_reading mr on mr.meter_reading_id = nrh.meter_reading_id\r\n" + 
			"		inner join meter m on m.meter_id = nrh.meter_id\r\n" + 
			"		inner join supply_point s on s.supply_id = m.supply_id \r\n" + 
			"		inner join client c on c.client_id = m.client_id\r\n" + 
			"		inner join network n on n.network_id = m.network_id\r\n" + 
			"		inner join property p on p.property_id = m.property_id\r\n" + 
			"		where nrh.deleted=0)t where RowNum between ?1 and ?2 ", nativeQuery = true)
	List<Object[]> getAllZeroConsumptionValidationErrors(long startDate, long endDate);
	
	@Query(value="select  count(*)\r\n" + 
			"		from zero_consumption_history nrh\r\n" + 
			"		inner join meter_reading mr on mr.meter_reading_id = nrh.meter_reading_id\r\n" + 
			"		inner join meter m on m.meter_id = nrh.meter_id\r\n" + 
			"		inner join supply_point s on s.supply_id = m.supply_id \r\n" + 
			"		inner join client c on c.client_id = m.client_id\r\n" + 
			"		inner join network n on n.network_id = m.network_id\r\n" + 
			"		inner join property p on p.property_id = m.property_id\r\n" + 
			"		where nrh.deleted=0", nativeQuery = true)
	long getTotalZeroConsumptionValidationErrors();
}
