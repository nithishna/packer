package com.monarch.mabdeck.dto;

public class ActionLetterDto extends ActionDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String templateName;

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
}
