package com.monarch.mabdeck.validator;

import java.io.IOException;
import java.util.List;

import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.Property;
import com.monarch.mabdeck.entity.SupplyPoint;

public class RelationshipValidator {

	public boolean validateNetworkClientRelationship(Client client, Network network) throws IOException {
		boolean flag = false;
		List<Network> networks = client.getNetwork();
		if (networks != null && networks.size() > 0) {
			for (Network net : networks) {
				if (net.getNetworkId() == network.getNetworkId())
					flag = true;
			}
			if (!flag)
				throw new IOException(
						"There is no such network for the selected client. Kindly enter correct detail and try again");
		} else {
			throw new IOException(
					"There is no network for the selected client. Kindly enter correct details and try again");
		}
		return flag;
	}

	public boolean validatePropertyNetworkRelationship(Network network, Property property) throws IOException {
		boolean flag = false;
		List<Property> properties = network.getProperty();
		if (properties != null && properties.size() > 0) {
			for (Property prop : properties) {
				if (prop.getPropertyId() == property.getPropertyId())
					flag = true;
			}
			if (!flag)
				throw new IOException(
						"There is no such Property for the selected Network. Kindly enter the correct details and try again");
		} else {
			throw new IOException(
					"There is no Property for the selected Network. Kindly enter the correct details and try again");
		}
		return flag;
	}

	public boolean validateSupplyPropertyRelationship(Property property, SupplyPoint supplyPoint) throws IOException {
		boolean flag = false;
		List<SupplyPoint> supplies = property.getSupply();
		if (supplies != null && supplies.size() > 0) {
			for (SupplyPoint supply : supplies) {
				if (supply.getSupplyId() == supplyPoint.getSupplyId())
					flag = true;
			}
			if (!flag) {
				throw new IOException(
						"There is no such Supply point for the selected Property. Kindly enter the correct details and try again");
			}
		} else {
			throw new IOException(
					"There is no supply point for the selected Property. Kindly enter the correct details and try again");
		}
		return flag;
	}
}
