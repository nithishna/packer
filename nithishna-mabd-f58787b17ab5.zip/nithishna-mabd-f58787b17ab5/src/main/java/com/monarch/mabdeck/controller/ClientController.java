package com.monarch.mabdeck.controller;

import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.ClientDto;
import com.monarch.mabdeck.dto.ClientMetadata;
import com.monarch.mabdeck.dto.NetworkDto;
import com.monarch.mabdeck.service.ClientService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class ClientController {

	private Logger logger = LoggerFactory.getLogger(ClientController.class);

	@Autowired
	private ClientService ClientService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CLIENT, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createClient(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody ClientDto Client) {
		logger.info("ClientController: createClient - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("ClientController: createClient - Service call, Username : " + username);
		ClientService.create(Client, username);
		logger.info("ClientController: createClient - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_CLIENT_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody ClientDto getClientById(@PathVariable("client_id") Long ClientId) throws NotFoundException {
		logger.info("ClientController: getClientById - Start");
		return ClientService.readById(ClientId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CLIENT_COUNT, method = RequestMethod.GET)
	public long clientCount() {
		return ClientService.getCount();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CLIENT, method = RequestMethod.PUT, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void updateClient(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody ClientDto Client) {
		logger.info("ClientController: updateClient - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("ClientController: updateClient - Service call, Username : " + username);
		ClientService.update(Client, username);
		logger.info("ClientController: updateClient - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CLIENT, method = RequestMethod.GET, produces = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public @ResponseBody List<ClientDto> getAllClients() throws NotFoundException {
		logger.info("ClientController: getAllClients - Start");
		return ClientService.readAll();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NETWORK_BY_CLIENT_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<NetworkDto> getAllNetworksForClient(@PathVariable("client_id") Long clientId)
			throws NotFoundException {
		logger.info("ClientController: getAllNetworksForClient - Start");
		return ClientService.getNetworkForClient(clientId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.ALL_CLIENTS, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<ClientDto> readAllClients(@RequestParam("index")int index, @RequestParam("size")int pageSize){
		logger.info("ClientController: readAllClients");
		return ClientService.readAllClients(index, pageSize);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CLIENTS_FOR_HUB, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<ClientDto> getAllClientsByHubManufacturers() {
		logger.info("ClientController: getAllClientsByHubManufacturers - Start");
		return ClientService.readAllClientsByHub();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CLIENTS_WITH_HUB, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<ClientDto> getAllClientsWithHubManufacturer() {
		logger.info("ClientController: getAllClientsWithHubManufacturer - Start");
		return ClientService.getAllClientsWithHubManufacturer();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CLIENT_METADATA, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<ClientMetadata> getClientMetadata() throws Exception {
		return ClientService.getClientMetaData();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.CLIENT_METADATA_BY_NAME, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<ClientMetadata> getClientMetadataByName(@RequestParam("name") String name) throws Exception{
		return ClientService.getClientsByName(name);
	}
}