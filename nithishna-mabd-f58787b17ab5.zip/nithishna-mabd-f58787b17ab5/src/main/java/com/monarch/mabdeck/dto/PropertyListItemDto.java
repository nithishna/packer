package com.monarch.mabdeck.dto;

import java.util.List;

public class PropertyListItemDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long propertyId;
	private String propertyName;
	private List<SupplyListItemDto> supplyList;
	public Long getPropertyId() {
		return propertyId;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	public List<SupplyListItemDto> getSupplyList() {
		return supplyList;
	}
	public void setSupplyList(List<SupplyListItemDto> supplyList) {
		this.supplyList = supplyList;
	}
}
