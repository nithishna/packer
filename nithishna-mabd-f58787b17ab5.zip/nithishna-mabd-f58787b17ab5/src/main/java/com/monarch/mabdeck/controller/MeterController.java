package com.monarch.mabdeck.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.MeterDto;
import com.monarch.mabdeck.dto.MeterTemplateDto;
import com.monarch.mabdeck.service.MeterService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class MeterController {

	private Logger logger = LoggerFactory.getLogger(MeterController.class);

	@Autowired
	private MeterService meterService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.METER, method = RequestMethod.POST, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void createMeter(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody MeterDto meter) {
		logger.info("MeterController: createMeter - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("MeterController: createMeter - Service Call, Username : " + username);
		meterService.create(meter, username);
		logger.info("MeterController: createMeter - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.METER, method = RequestMethod.PUT, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void updateMeter(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody MeterDto meter) {
		logger.info("MeterController: updateMeter - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("MeterController: updateMeter - Service Call, Username : " + username);
		meterService.update(meter, username);
		logger.info("MeterController: updateMeter - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_METER_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody MeterDto getMeterById(@PathVariable("meter_id") Long meterId) throws NotFoundException {
		logger.info("MeterController: getMeterById - Start");
		return meterService.read(meterId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.METER, method = RequestMethod.GET, produces = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public List<MeterDto> getAllMeters() throws NotFoundException {
		logger.info("MeterController: getAllMeters - Start");
		return meterService.readAll();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.METER_TEMPLATE, method = RequestMethod.POST, produces = "application/octet-stream", consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	@ResponseBody
	public HttpEntity<byte[]> getReport(@RequestBody MeterTemplateDto dto) throws IOException, InterruptedException {
		logger.info("MeterController: getReport - Start");
		byte[] meterReadingTemplate = meterService.downloadTemplate(dto);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "meterTemplate.csv");
		header.setContentLength(meterReadingTemplate.length);
		logger.info("MeterController: getReport - End");
		return new HttpEntity<byte[]>(meterReadingTemplate, header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_METER_BY_SUPPLY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	@ResponseBody
	public List<MeterDto> getMeterForSupplyId(@PathVariable("supply_id") Long supplyId) {
		logger.info("MeterController: uploadBulkDataLoggerFile - Start");
		return meterService.getAllMetersForSupplyId(supplyId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.BULK_METER_TEMPLATE, method = RequestMethod.POST, produces = "application/octet-stream", consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	@ResponseBody
	public HttpEntity<byte[]> getBulkMeterTemplate(@RequestBody MeterTemplateDto dto)
			throws IOException, InterruptedException {
		logger.info("DataLoggerController: uploadBulkDataLoggerFile - Start");
		byte[] meterReadingTemplate = meterService.downloadBulkMeterTemplate(dto);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "BulkMeterTemplate.csv");
		header.setContentLength(meterReadingTemplate.length);
		logger.info("DataLoggerController: uploadBulkDataLoggerFile - End");
		return new HttpEntity<byte[]>(meterReadingTemplate, header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.UPLOAD_BULK_METER_TEMPLATE, method = RequestMethod.POST, consumes = "multipart/form-data", produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> uploadBulkMeterFile(@RequestParam("file") MultipartFile file) throws IOException {
		logger.info("DataLoggerController: uploadBulkDataLoggerFile - Start");
		byte[] result = meterService.uploadCSV(file);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "result.csv");
		header.setContentLength(result.length);
		logger.info("DataLoggerController: uploadBulkDataLoggerFile - End");
		return new HttpEntity<byte[]>(result, header);
	}
}
