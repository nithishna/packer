package com.monarch.mabdeck.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.monarch.mabdeck.dto.MeterDto;
import com.monarch.mabdeck.entity.Meter;

@Mapper(uses = {ClientMapper.class, NetworkMapper.class, PropertyMapper.class})
public abstract class MeterMapper implements IBaseMapper<MeterDto, Meter>{
	public static final MeterMapper INSTANCE = Mappers.getMapper(MeterMapper.class);
	
	@Mappings({
		@Mapping(target ="supply", ignore = true)
	})
	@Named("toDto")
	public abstract MeterDto convertToDTO(Meter entity);
	
	@Mappings({
		@Mapping(target ="supply", ignore = true),
		@Mapping(target = "audit", ignore = true)
	})
	public abstract Meter convertToEntity(MeterDto dto);
	
	@Mappings({
		@Mapping(target="supply", ignore = true),
		@Mapping(target="client", ignore = true),
		@Mapping(target="network", ignore = true),
		@Mapping(target="property", ignore = true)
	})
	@Named("toMeterDto")
	public abstract MeterDto convertToMeterDTO(Meter entity);
	
	@IterableMapping(qualifiedByName = "toMeterDto")
	public abstract List<MeterDto> convertToMeterDTOList(List<Meter> entities);
	
	@IterableMapping(qualifiedByName = "toDto")
	public abstract List<MeterDto> convertToDTOList(List<Meter> entities);
}
