package com.monarch.mabdeck.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StatementGenerator implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BillablePersonDto billablePerson;
	private AddressDto address;
	private String accountNumber;
	private String statementNumber;
	private String statementDate;
	private double balanceBroughtForward;
	private String dateChargePeriodFrom;
	private String dateChargePeriodTo;
	private String boxContent;
	private double totalChargeBeforeVat;
	private double vat;
	private double totalInvoice;
	private double accountBalance;
	private List<PaymentDto> payment = new ArrayList<>();
	private Map<String, UtilityDto> utilityTypeMap = new HashMap<>();
	public BillablePersonDto getBillablePerson() {
		return billablePerson;
	}
	public AddressDto getAddress() {
		return address;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public String getStatementNumber() {
		return statementNumber;
	}
	public String getStatementDate() {
		return statementDate;
	}
	public double getBalanceBroughtForward() {
		return balanceBroughtForward;
	}
	public String getDateChargePeriodFrom() {
		return dateChargePeriodFrom;
	}
	public String getDateChargePeriodTo() {
		return dateChargePeriodTo;
	}
	public String getBoxContent() {
		return boxContent;
	}
	public double getTotalChargeBeforeVat() {
		return totalChargeBeforeVat;
	}
	public double getVat() {
		return vat;
	}
	public double getTotalInvoice() {
		return totalInvoice;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public List<PaymentDto> getPayment() {
		return payment;
	}
	public Map<String, UtilityDto> getUtilityTypeMap() {
		return utilityTypeMap;
	}
	public void setBillablePerson(BillablePersonDto billablePerson) {
		this.billablePerson = billablePerson;
	}
	public void setAddress(AddressDto address) {
		this.address = address;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public void setStatementNumber(String statementNumber) {
		this.statementNumber = statementNumber;
	}
	public void setStatementDate(String statementDate) {
		this.statementDate = statementDate;
	}
	public void setBalanceBroughtForward(double balanceBroughtForward) {
		this.balanceBroughtForward = balanceBroughtForward;
	}
	public void setDateChargePeriodFrom(String dateChargePeriodFrom) {
		this.dateChargePeriodFrom = dateChargePeriodFrom;
	}
	public void setDateChargePeriodTo(String dateChargePeriodTo) {
		this.dateChargePeriodTo = dateChargePeriodTo;
	}
	public void setBoxContent(String boxContent) {
		this.boxContent = boxContent;
	}
	public void setTotalChargeBeforeVat(double totalChargeBeforeVat) {
		this.totalChargeBeforeVat = totalChargeBeforeVat;
	}
	public void setVat(double vat) {
		this.vat = vat;
	}
	public void setTotalInvoice(double totalInvoice) {
		this.totalInvoice = totalInvoice;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public void setPayment(List<PaymentDto> payment) {
		this.payment = payment;
	}
	public void setUtilityTypeMap(Map<String, UtilityDto> utilityTypeMap) {
		this.utilityTypeMap = utilityTypeMap;
	}

}
