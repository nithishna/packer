package com.monarch.mabdeck.dto;

import java.util.Date;
import java.util.List;

public class CreditCorrespondenceDto implements IDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long correspondenceId;
	private String clientName;
	private String networkName;
	private String propertyName;
	private String billablePerson;
	private String type;
	private Date correspondenceDate;
	private String fileName;
	private double accountBalance;
	private int daysOverdue;	
	private String stage;
	private boolean letter;
	private List<CreditNotesDto> notes;
	public long getCorrespondenceId() {
		return correspondenceId;
	}
	public String getClientName() {
		return clientName;
	}
	public String getNetworkName() {
		return networkName;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public String getBillablePerson() {
		return billablePerson;
	}
	public String getType() {
		return type;
	}
	public Date getCorrespondenceDate() {
		return correspondenceDate;
	}
	public String getFileName() {
		return fileName;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public int getDaysOverdue() {
		return daysOverdue;
	}
	public String getStage() {
		return stage;
	}
	public boolean isLetter() {
		return letter;
	}
	public List<CreditNotesDto> getNotes() {
		return notes;
	}
	public void setCorrespondenceId(long correspondenceId) {
		this.correspondenceId = correspondenceId;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	public void setBillablePerson(String billablePerson) {
		this.billablePerson = billablePerson;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setCorrespondenceDate(Date correspondenceDate) {
		this.correspondenceDate = correspondenceDate;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public void setDaysOverdue(int daysOverdue) {
		this.daysOverdue = daysOverdue;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public void setLetter(boolean letter) {
		this.letter = letter;
	}
	public void setNotes(List<CreditNotesDto> notes) {
		this.notes = notes;
	}
}
