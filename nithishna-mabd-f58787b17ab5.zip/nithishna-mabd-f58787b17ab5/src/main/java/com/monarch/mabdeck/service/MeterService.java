package com.monarch.mabdeck.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.annotation.Resource;

import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.MeterDto;
import com.monarch.mabdeck.dto.MeterTemplateDto;
import com.monarch.mabdeck.dto.SupplyPointDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.Meter;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.Property;
import com.monarch.mabdeck.entity.SupplyPoint;
import com.monarch.mabdeck.history.service.MeterHistoryService;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.MeterMapper;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.MeterRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.repository.PropertyRepository;
import com.monarch.mabdeck.repository.SupplyPointRepository;
import com.monarch.mabdeck.util.Constants;
import com.monarch.mabdeck.validator.RelationshipValidator;

import javassist.NotFoundException;

@Component
public class MeterService extends CommonServiceImpl<MeterDto, Meter> {

	private Logger logger = LoggerFactory.getLogger(MeterService.class);

	@Resource
	private MeterRepository repository;

	@Resource
	private PropertyRepository propertyRepository;
	
	@Autowired
	private MeterHistoryService historyService;

	@Resource
	private ClientRepository clientRepository;

	@Resource
	private NetworkRepository networkRepository;

	@Resource
	private SupplyPointRepository supplyRepository;

	@Override
	public JpaRepository<Meter, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<MeterDto, Meter> getMapper() {
		return MeterMapper.INSTANCE;
	}

	@Override
	public void updateAudit(Meter entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			}else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
	@Override
	public MeterDto create(MeterDto dto, String username) {
		Meter meter = this.getMapper().convertToEntity(dto);
		updateAudit(meter, username);
		if (dto.getClient() != null && dto.getClient().getClientId() > 0) {
			Client client = clientRepository.findOne(dto.getClient().getClientId());
			meter.setClient(client);
		}
		if (dto.getNetwork() != null && dto.getNetwork().getNetworkId() > 0) {
			Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
			meter.setNetwork(network);
		}
		if (dto.getProperty() != null && dto.getProperty().getPropertyId() > 0) {
			Property property = propertyRepository.findOne(dto.getProperty().getPropertyId());
			meter.setProperty(property);
		}
		if (dto.getSupply() != null && dto.getSupply().getSupplyId() > 0) {
			SupplyPoint supplyPoint = supplyRepository.findOne(dto.getSupply().getSupplyId());
			meter.setSupply(supplyPoint);
		}
		repository.saveAndFlush(meter);
		return dto;
	}

	public MeterDto read(Long id) throws NotFoundException {
		MeterDto dto = null;
		Meter entity = getJPARepository().findOne(id);
		if (entity == null)
			throw new NotFoundException("There is no such element");
		dto = getMapper().convertToDTO(entity);
		if (entity.getSupply() != null) {
			SupplyPointDto supplyDto = new SupplyPointDto();
			SupplyPoint supply = entity.getSupply();
			supplyDto.setSupplyId(supply.getSupplyId());
			dto.setSupply(supplyDto);
		}
		return dto;
	}

	public MeterDto update(MeterDto dto, String username) {
		if (dto != null) {
			Meter meter = repository.findOne(dto.getMeterId());
			updateAudit(meter, username);
			historyService.updateMeterHistory(meter, username);
			Meter newEntity = this.getMapper().convertToEntity(dto);
			if (dto.getClient() != null && dto.getClient().getClientId() > 0) {
				Client client = clientRepository.findOne(dto.getClient().getClientId());
				meter.setClient(client);
			}
			if (dto.getNetwork() != null && dto.getNetwork().getNetworkId() > 0) {
				Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
				meter.setNetwork(network);
			}
			if (dto.getProperty() != null && dto.getProperty().getPropertyId() > 0) {
				Property property = propertyRepository.findOne(dto.getProperty().getPropertyId());
				meter.setProperty(property);
			}
			if (dto.getSupply() != null && dto.getSupply().getSupplyId() > 0) {
				SupplyPoint supplyPoint = supplyRepository.findOne(dto.getSupply().getSupplyId());
				meter.setSupply(supplyPoint);
			}
			meter.setChildMeter(dto.isChildMeter());
			meter.setEndDate(newEntity.getEndDate());
			meter.setInitialReading(dto.getInitialReading());
			meter.setLocation(dto.getLocation());
			meter.setManufacturer(dto.getManufacturer());
			meter.setMeterId(dto.getMeterId());
			meter.setMeterType(dto.getMeterType());
			meter.setModel(dto.getModel());
			meter.setOffset(dto.getOffset());
			meter.setParentSerialNumber(dto.getParentSerialNumber());
			meter.setPulseInputNumber(dto.getPulseInputNumber());
			meter.setReadingFrequency(dto.getReadingFrequency());
			meter.setReadingImportFactor(dto.getReadingImportFactor());
			meter.setSerialNumber(dto.getSerialNumber());
			meter.setStartDate(newEntity.getStartDate());
			meter.setUnit(dto.getUnit());
		}
		return dto;
	}

	public byte[] downloadTemplate(MeterTemplateDto dto) throws IOException {
		File tempFile = new File("template.csv");
		PrintWriter pw = new PrintWriter(tempFile);
		StringBuilder sb = new StringBuilder();
		this.populateHeading(sb);
		this.populateRow(dto, sb);
		pw.write(sb.toString());
		pw.close();
		InputStream stream = new FileInputStream("template.csv");
		byte[] result = IOUtils.toByteArray(stream);
		stream.close();
		logger.debug("File deletion status : " + (tempFile.delete() ? "Success" : "Failure"));
		return result;
	}

	public byte[] downloadBulkMeterTemplate(MeterTemplateDto dto) throws IOException {
		File bulkMeterTemplate = new File("bulkMeterTemplate.csv");
		PrintWriter pw = new PrintWriter(bulkMeterTemplate);
		StringBuilder sb = new StringBuilder();
		this.populateBulkMeterHeading(sb);
		this.PopulateRowsForBulkMeterTemplate(dto, sb);
		pw.write(sb.toString());
		pw.close();
		InputStream stream = new FileInputStream("bulkMeterTemplate.csv");
		byte[] result = IOUtils.toByteArray(stream);
		stream.close();
		logger.debug("File deletion status : " + (bulkMeterTemplate.delete() ? "Success" : "Failure"));
		return result;
	}

	private void populateBulkMeterHeading(StringBuilder sb) {
		sb.append("ClientId").append(",");
		sb.append("Client").append(",");
		sb.append("NetworkId").append(",");
		sb.append("Network").append(",");
		sb.append("PropertyAddress").append(",");
		sb.append("SupplyTypeId	").append(",");
		sb.append("SupplyType").append(",");
		sb.append("MeterSerialNumber").append(",");
		sb.append("BulkMeterSerialNumber").append("\n");
	}

	public List<MeterDto> PopulateRowsForBulkMeterTemplate(MeterTemplateDto dto, StringBuilder sb) {
		List<MeterDto> dtos = new ArrayList<>();
		List<SupplyPoint> supplies = supplyRepository.getAllSuppliesForSupplyType(
				Constants.supplyTypeMap.get(dto.getSupplyTypeId()), dto.getClientId(), dto.getNetworkId());
		List<Long> sId = new ArrayList<>();
		for (SupplyPoint supply : supplies) {
			sId.add(supply.getSupplyId());
		}
		List<Meter> entities = repository.getMeterForClientAndNetworkAndSupplyId(dto.getClientId(), dto.getNetworkId(),
				sId);
		if (entities != null && entities.size() > 0) {
			for (Meter entity : entities) {
				sb.append(entity.getClient().getClientId()).append(",");
				sb.append(entity.getClient().getClientName()).append(",");
				sb.append(entity.getNetwork().getNetworkId()).append(",");
				sb.append(entity.getNetwork().getNetwork()).append(",");
				if (entity.getProperty() != null && entity.getProperty().getAddress() != null) {
					sb.append(entity.getProperty().getAddress().getAddressLine1()).append(",");
				} else {
					sb.append("").append(",");
				}
				sb.append(entity.getSupply().getSupplyId()).append(",");
				sb.append(entity.getSupply().getSupplyType()).append(",");
				sb.append(entity.getSerialNumber()).append(",");
				sb.append("*Required*").append("\n");
			}
		}
		return dtos;
	}

	private void populateHeading(StringBuilder sb) {
		sb.append("ClientId").append(",");
		sb.append("Client").append(",");
		sb.append("NetworkId").append(",");
		sb.append("Network").append(",");
		sb.append("PropertyId").append(",");
		sb.append("PropertyAddress").append(",");
		sb.append("SupplyId").append(",");
		sb.append("SupplyType").append(",");
		sb.append("UnitId").append(",");
		sb.append("Unit").append(",");
		sb.append("ReadingFrequencyId").append(",");
		sb.append("ReadingFrequency").append(",");
		sb.append("ReadingImportFactor").append(",");
		sb.append("Manufacturer").append(",");
		sb.append("Model").append(",");
		sb.append("MeterUseType").append(",");
		sb.append("MeterUseTypeId").append(",");
		sb.append("ParentMeterSerialNumber").append(",");
		sb.append("PulseInputNumber").append(",");
		sb.append("SerialNumber").append(",");
		sb.append("InitialReading").append(",");
		sb.append("Offset").append(",");
		sb.append("Location").append(",");
		sb.append("StartDate").append(",");
		sb.append("EndDate").append("\n");
	}

	public List<MeterDto> getAllMetersForSupplyId(Long supplyId) {
		List<MeterDto> dtos = new ArrayList<>();
		List<Meter> entities = repository.getMeterForTheSupplyId(supplyId);
		if (entities != null && entities.size() > 0) {
			for (Meter entity : entities) {
				if (!entity.isChildMeter()) {
					MeterDto dto = new MeterDto();
					dto.setMeterId(entity.getMeterId());
					dto.setSerialNumber(entity.getSerialNumber());
					dtos.add(dto);
				}
			}
		}
		return dtos;
	}

	private void populateRow(MeterTemplateDto dto, StringBuilder sb) {
		List<SupplyPoint> supplies = supplyRepository.getAllSuppliesForSupplyType(
				Constants.supplyTypeMap.get(dto.getSupplyTypeId()), dto.getClientId(), dto.getNetworkId());
		for (SupplyPoint supply : supplies) {
			sb.append(dto.getClientId()).append(",");
			sb.append(supply.getClient() != null ? supply.getClient().getClientName() : "").append(",");
			sb.append(dto.getNetworkId()).append(",");
			sb.append(supply.getNetwork() != null ? supply.getNetwork().getNetwork() : "").append(",");
			if (supply.getProperty() != null) {
				sb.append(supply.getProperty().getPropertyId()).append(",");
				sb.append(supply.getProperty().getAddress() != null ? replaceCommaByHipen(supply.getProperty().getAddress().getAddressLine1()): "").append(",");
			} else {
				sb.append("").append(",");
				sb.append("").append(",");
			}
			sb.append(supply.getSupplyId()).append(",");
			sb.append(supply.getSupplyType()).append(",");
			sb.append(dto.getUnitId()).append(",");
			sb.append(Constants.unitMap.get(dto.getUnitId())).append(",");
			sb.append(dto.getReadingFrequencyId()).append(",");
			sb.append(Constants.readingFrequencyMap.get(dto.getReadingFrequencyId())).append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append(Constants.meterUseTypeMap.get(dto.getMeterUseId())).append(",");
			sb.append(dto.getMeterUseId()).append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append(Constants.REQUIRED).append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append(Constants.REQUIRED).append(",");
			sb.append("").append("\n");
		}
	}
	
	private String replaceCommaByHipen(String input) {
		String result = input.replace(",", "-");	
		return result;
	}

	public byte[] uploadCSV(MultipartFile multipartFile) throws IOException {
		File file = null;
		byte[] result = null;
		try {
			file = convertMultiPartToFile(multipartFile);
			FileWriter csvWriter = new FileWriter("result.csv");	
			Scanner scanner = new Scanner(file);
			boolean headingValidation = false;
			while (scanner.hasNextLine()) {
				if (!headingValidation) {
					headingValidation = validateHeading(scanner.nextLine());
					if (!headingValidation) {
						scanner.close();
						throw new IOException("Kindly check the heading order");
					}
					for(String value : Constants.meterHeading) {
						csvWriter.append(value);
						csvWriter.append(",");
					}
					csvWriter.append("Message").append("\n");
				} else
					getRecordFromLine(scanner.nextLine(), csvWriter);
			}
			scanner.close();
			csvWriter.flush();
			csvWriter.close();
			InputStream stream = new FileInputStream("result.csv");
			result = IOUtils.toByteArray(stream);
			stream.close();			
			if (file != null)
				logger.debug(file.delete() ? "Temp File Deleted successfully" : "Temp File could not be deleted");
			File resultFile = new File("result.csv");
			resultFile.delete();
		} catch (Exception ex) {
			if(file!= null)
				logger.debug(file.delete()? "Temp File Deleted successfully":"Temp File could not be deleted");
			throw new IOException("Unable to parse the file. Kindly raise a support request and get this sorted");
		}
		return result;
	}

	private boolean validateHeading(String line) {
		List<String> heading = Constants.meterHeading;
		Iterator<String> iterator = heading.iterator();
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			while (rowScanner.hasNext()) {
				if (!iterator.next().equalsIgnoreCase(rowScanner.next())) {
					return false;
				}
			}
		}
		return true;
	}

	private void getRecordFromLine(String line, FileWriter csvWriter) throws IOException {
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			Meter meter = new Meter();
			Client client = null;
			Network network = null;
			Property property = null;
			SupplyPoint supply = null;
			if (rowScanner.hasNext()) {
				long clientId = rowScanner.nextLong();
				client = clientRepository.findOne(clientId);
				if (client == null)
					throw new IOException(
							"Client details are mandatory. Please enter the Client details and try again");
				meter.setClient(client);
				logger.debug("Client name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			if (rowScanner.hasNext()) {
				long networkId = rowScanner.nextLong();
				network = networkRepository.findOne(networkId);
				if (network == null)
					throw new IOException(
							"Network details are mandatory. Please enter the Network details and try again");
				meter.setNetwork(network);
				logger.debug("Network name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			if (rowScanner.hasNext()) {
				long propertyId = rowScanner.nextLong();
				property = propertyRepository.findOne(propertyId);
				if (property == null)
					throw new IOException(
							"Property details are mandatory. Please enter the Property details and try again.");
				meter.setProperty(property);
				logger.debug("Property name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			if (rowScanner.hasNext()) {
				long supplyId = rowScanner.nextLong();
				supply = supplyRepository.findOne(supplyId);
				if (supply == null)
					throw new IOException(
							"Invalid supply id. Kindly enter valid supply point details");
				meter.setSupply(supply);
				logger.debug("Supply name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			this.validateDataRelationship(client, network, property, supply);
			logger.debug("Meter UnitId: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			meter.setUnit((rowScanner.hasNext() ? rowScanner.next() : null));
			logger.debug("Reading frequencyId: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			meter.setReadingFrequency((rowScanner.hasNext() ? rowScanner.next() : null));
			meter.setReadingImportFactor((rowScanner.hasNext() ? rowScanner.next() : null));
			meter.setManufacturer((rowScanner.hasNext() ? rowScanner.next() : null));
			meter.setModel((rowScanner.hasNext() ? rowScanner.next() : null));
			meter.setMeterType((rowScanner.hasNext() ? rowScanner.next() : null));
			logger.debug("MeterUseType Id : " + (rowScanner.hasNext() ? rowScanner.next() : null));
			meter.setParentSerialNumber((rowScanner.hasNext() ? rowScanner.next() : null));
			String pulseInput = (rowScanner.hasNext() ? rowScanner.next() : null);
			int pulseInputNumber = 0;
			try {
				if(pulseInput != null && !pulseInput.equals("") && !pulseInput.isEmpty())
				pulseInputNumber = Integer.parseInt(pulseInput);
			} catch (Exception ex) {
				throw new IOException("PulseInputNumber should be a whole number");
			}
			meter.setPulseInputNumber(pulseInputNumber);
			String serialNumber = (rowScanner.hasNext() ? rowScanner.next() : null);
			if (serialNumber.isEmpty() || serialNumber.equalsIgnoreCase("") || serialNumber == null)
				throw new IOException(
						"Serial Number cannot be empty. Kindly update the serial number in the file and try again");
			else {
				Meter temp = repository.findBySerialNumber(serialNumber);
				if (temp != null)
					throw new IOException("Serial number: " + serialNumber
							+ " is already in use. Kindly update the serial number in the file and try again");
			}
			meter.setSerialNumber(serialNumber);
			meter.setInitialReading(rowScanner.hasNext() ? rowScanner.next() : null);
			meter.setOffset(rowScanner.hasNext() ? rowScanner.next() : null);
			meter.setLocation(rowScanner.hasNext() ? rowScanner.next() : null);

			if (rowScanner.hasNext()) {
				Date date = null;
				try {
					date = new SimpleDateFormat("dd/MM/yyyy").parse(rowScanner.next());
				} catch (Exception ex) {
					throw new IOException(
							"Issue in the data!.....Kindly specify Start date in dd/MM/YYYY format and try again");
				}
				if (date != null)
					meter.setStartDate(new java.sql.Date(date.getTime()));
				else
					throw new IOException("Start Date cannot be empty....Kindly update the excel and try again");
			}

			if (rowScanner.hasNext()) {
				Date date = null;
				try {
					date = new SimpleDateFormat("dd/MM/yyyy").parse(rowScanner.next());
				} catch (Exception ex) {
					throw new IOException(
							"Issue in the data!.....Kindly specify End date in dd/MM/YYYY format and try again");
				}
				if (date != null)
					meter.setEndDate(new java.sql.Date(date.getTime()));
			}
			this.updateAudit(meter, "Application\\Bulk upload");
			repository.saveAndFlush(meter);
			this.writeLine(line, csvWriter);
			csvWriter.append("Success");
			csvWriter.append("\n");

		} catch (Exception ex) {
			this.writeLine(line, csvWriter);
			csvWriter.append("Error: " + ex.getMessage());
			csvWriter.append("\n");
		}
	}
	
	
	private void writeLine(String line, FileWriter csvWriter) throws IOException {
		String[] values = line.split(",");
		for(String value : values) {
			csvWriter.append(value);
			csvWriter.append(",");
		}
		int extension = Constants.meterHeading.size() - values.length;
		if(extension > 0) {
			for(int i=0; i<extension; i++) {
				csvWriter.append("");
				csvWriter.append(",");
			}
		}
	}

	public void validateDataRelationship(Client client, Network network, Property property, SupplyPoint supply)
			throws IOException {
		RelationshipValidator validator = new RelationshipValidator();
		validator.validateNetworkClientRelationship(client, network);
		validator.validatePropertyNetworkRelationship(network, property);
		validator.validateSupplyPropertyRelationship(property, supply);
	}

	private File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}
}