package com.monarch.mabdeck.controller;

import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.PropertyAreaChargeDto;
import com.monarch.mabdeck.service.PropertyAreaChargeService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class PropertyAreaChargeController {

	private Logger logger = LoggerFactory.getLogger(UnitChargeController.class);

	@Autowired
	private PropertyAreaChargeService service;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_AREA_CHARGE, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createPropertyAreaCharge(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody PropertyAreaChargeDto unitCharge) {
		logger.info("PropertyAreaChargeController: createPropertyAreaCharge - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("PropertyAreaChargeController: createPropertyAreaCharge - Service call, Username : " + username);
		service.create(unitCharge, username);
		logger.info("PropertyAreaChargeController: createPropertyAreaCharge - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_AREA_CHARGE_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody PropertyAreaChargeDto getPropertyAreaChargeById(
			@PathVariable("propertycharge_id") Long propertyAreaChargeId) throws NotFoundException {
		logger.info("PropertyAreaChargeController: getPropertyAreaChargeById - Start");
		return service.read(propertyAreaChargeId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PROPERTY_AREA_CHARGE, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PropertyAreaChargeDto> getAllPropertyAreaCharges() throws NotFoundException {
		logger.info("PropertyAreaChargeController: getAllPropertyAreaCharges - Start");
		return service.readAll();
	}
}