package com.monarch.mabdeck.dto;

public class ReportMetadataDto implements IDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private byte[] data;
	private String reportName;
	public byte[] getData() {
		return data;
	}
	public String getReportName() {
		return reportName;
	}
	public void setData(byte[] data) {
		this.data = data;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	
}
