package com.monarch.mabdeck.dto;

import java.util.Date;

public class PropertyAccountAssociationDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long associationId;
	private PropertyDto property;
	private AccountDto account;
	private Date startDate;
	private Date endDate;
	private String tenureType;
	private String message;
	private boolean deleted;
	private String moveOutMessage;
	private String moveInStatus;
	private String moveOutStatus;
	private int counter;
	public Long getAssociationId() {
		return associationId;
	}
	public PropertyDto getProperty() {
		return property;
	}
	public AccountDto getAccount() {
		return account;
	}
	public Date getStartDate() {
		return startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setAssociationId(Long associationId) {
		this.associationId = associationId;
	}
	public void setProperty(PropertyDto property) {
		this.property = property;
	}
	public void setAccount(AccountDto account) {
		this.account = account;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public String getMoveInStatus() {
		return moveInStatus;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	public void setMoveInStatus(String moveInStatus) {
		this.moveInStatus = moveInStatus;
	}
	public String getMoveOutStatus() {
		return moveOutStatus;
	}
	public void setMoveOutStatus(String moveOutStatus) {
		this.moveOutStatus = moveOutStatus;
	}
	public int getCounter() {
		return counter;
	}
	public void setCounter(int counter) {
		this.counter = counter;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMoveOutMessage() {
		return moveOutMessage;
	}
	public void setMoveOutMessage(String moveOutMessage) {
		this.moveOutMessage = moveOutMessage;
	}
	public String getTenureType() {
		return tenureType;
	}
	public void setTenureType(String tenureType) {
		this.tenureType = tenureType;
	}
}
