package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Statement;

@Repository
public interface StatementRepository extends JpaRepository<Statement, Long>{
	
	@Query(value="select top 20 * from statement where approved=0 and deleted=0 order by statement_id desc",nativeQuery = true)
	List<Statement> getRecent20Statements();
	
	@Query(value="select top 20 * from statement where approved=1 and deleted=0 order by statement_id desc", nativeQuery =true)
	List<Statement> getRecent20ApprovedStatements();
	
	List<Statement> findByQueueId(long queueId);
}