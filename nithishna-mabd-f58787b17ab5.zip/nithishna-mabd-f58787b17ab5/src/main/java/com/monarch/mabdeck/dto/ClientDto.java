package com.monarch.mabdeck.dto;

import java.math.BigInteger;
import java.sql.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class ClientDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long clientId;
	
	@JsonDeserialize
	private String logo;
	private String clientName;
	private AddressDto address;
	private Date startDate;
	private String companyNumber;
	private BigInteger vatNumber;
	private String currency;
	private int paymentTerm;
	private MainContactDto mainContact;
	private BankAccountDto bankAccount;
	private List<NetworkDto> network;
	private List<BandDto> band;
	private List<PropertyDto> property;
	private int numberOfNetworks;
	private CustomerServiceContactDto customerServiceContact;
	public long getClientId() {
		return clientId;
	}
	public void setClientId(long clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public AddressDto getAddress() {
		return address;
	}
	public void setAddress(AddressDto address) {
		this.address = address;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public String getCompanyNumber() {
		return companyNumber;
	}
	public void setCompanyNumber(String companyNumber) {
		this.companyNumber = companyNumber;
	}
	public BigInteger getVatNumber() {
		return vatNumber;
	}
	public void setVatNumber(BigInteger vatNumber) {
		this.vatNumber = vatNumber;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public int getPaymentTerm() {
		return paymentTerm;
	}
	public void setPaymentTerm(int paymentTerm) {
		this.paymentTerm = paymentTerm;
	}
	public MainContactDto getMainContact() {
		return mainContact;
	}
	public void setMainContact(MainContactDto mainContact) {
		this.mainContact = mainContact;
	}
	public List<NetworkDto> getNetwork() {
		return network;
	}
	public void setNetwork(List<NetworkDto> network) {
		this.network = network;
	}
	public List<BandDto> getBand() {
		return band;
	}
	public void setBand(List<BandDto> band) {
		this.band = band;
	}
	public int getNumberOfNetworks() {
		return numberOfNetworks;
	}
	public void setNumberOfNetworks(int numberOfNetworks) {
		this.numberOfNetworks = numberOfNetworks;
	}
	public BankAccountDto getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(BankAccountDto bankAccount) {
		this.bankAccount = bankAccount;
	}
	public CustomerServiceContactDto getCustomerServiceContact() {
		return customerServiceContact;
	}
	public void setCustomerServiceContact(CustomerServiceContactDto customerServiceContact) {
		this.customerServiceContact = customerServiceContact;
	}
	public List<PropertyDto> getProperty() {
		return property;
	}
	public void setProperty(List<PropertyDto> property) {
		this.property = property;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
}
