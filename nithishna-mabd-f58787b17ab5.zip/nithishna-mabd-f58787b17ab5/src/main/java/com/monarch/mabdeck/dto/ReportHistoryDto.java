package com.monarch.mabdeck.dto;

import java.sql.Date;

public class ReportHistoryDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ReportHistoryDto() {
		
	}
	
	public ReportHistoryDto(long id, Date fromDate, Date toDate, Date creationDate,ReportConfigurationDto configuration) {
		this.id = id;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.creationDate = creationDate;
		this.configuration = configuration;
	}
	private long id;	
	private Date fromDate;
	private Date toDate;
	private Date creationDate;
	private String status;
	private ReportConfigurationDto configuration;
	public long getId() {
		return id;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public ReportConfigurationDto getConfiguration() {
		return configuration;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public void setConfiguration(ReportConfigurationDto configuration) {
		this.configuration = configuration;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}