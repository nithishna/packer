package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.PropertyAreaCharge;
import com.monarch.mabdeck.entity.PropertyAreaChargeHistory;
import com.monarch.mabdeck.repository.PropertyAreaChargeHistoryRepository;

@Component
public class PropertyAreaChargeHistoryService {

	@Resource
	private PropertyAreaChargeHistoryRepository historyRepository;
	
	public void updatePropertyAreaChargeHistory(PropertyAreaCharge charge, String username) {
		if(charge != null) {
			PropertyAreaChargeHistory history = new PropertyAreaChargeHistory();
			history.setAreaUnits(charge.getAreaUnits());
			history.setAudit(charge.getAudit());
			history.setName(charge.getName());
			history.setPricePerUnit(charge.getPricePerUnit());
			history.setPropertyChargeId(charge.getPropertyChargeId());			
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
