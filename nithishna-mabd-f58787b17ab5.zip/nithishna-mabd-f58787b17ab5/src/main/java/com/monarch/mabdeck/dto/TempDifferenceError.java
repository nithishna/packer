package com.monarch.mabdeck.dto;

import java.math.BigDecimal;

public class TempDifferenceError extends ValidationErrors {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigDecimal flowTemperature;
	private BigDecimal returnTemperature;
	private String readingDate;
	public BigDecimal getFlowTemperature() {
		return flowTemperature;
	}
	public BigDecimal getReturnTemperature() {
		return returnTemperature;
	}
	public String getReadingDate() {
		return readingDate;
	}
	public void setFlowTemperature(BigDecimal flowTemperature) {
		this.flowTemperature = flowTemperature;
	}
	public void setReturnTemperature(BigDecimal returnTemperature) {
		this.returnTemperature = returnTemperature;
	}
	public void setReadingDate(String readingDate) {
		this.readingDate = readingDate;
	}
	
}
