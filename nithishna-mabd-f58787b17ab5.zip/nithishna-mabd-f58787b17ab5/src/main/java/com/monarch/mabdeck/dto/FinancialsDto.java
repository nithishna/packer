package com.monarch.mabdeck.dto;

import java.sql.Date;

public class FinancialsDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private double amount;
	private double credt;
	private double debit;
	private double balance;
	private String paymentType;
	private long paymentTypeId;
	private String paymentMethod;
	private long paymentMethodId;
	private Date date;
	private String reference;
	private long accountId;
	public long getId() {
		return id;
	}
	public double getAmount() {
		return amount;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public Date getDate() {
		return date;
	}
	public String getReference() {
		return reference;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public long getPaymentTypeId() {
		return paymentTypeId;
	}
	public long getPaymentMethodId() {
		return paymentMethodId;
	}
	public void setPaymentTypeId(long paymentTypeId) {
		this.paymentTypeId = paymentTypeId;
	}
	public void setPaymentMethodId(long paymentMethodId) {
		this.paymentMethodId = paymentMethodId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public double getCredt() {
		return credt;
	}
	public double getDebit() {
		return debit;
	}
	public double getBalance() {
		return balance;
	}
	public void setCredt(double credt) {
		this.credt = credt;
	}
	public void setDebit(double debit) {
		this.debit = debit;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
}
