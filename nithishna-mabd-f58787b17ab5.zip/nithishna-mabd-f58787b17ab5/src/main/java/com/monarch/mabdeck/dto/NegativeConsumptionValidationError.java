package com.monarch.mabdeck.dto;

import java.math.BigDecimal;

public class NegativeConsumptionValidationError extends ValidationErrors{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigDecimal previousReading;
	private String previousReadingDate;
	private BigDecimal failedReading;
	private String failedReadingDate;
	public BigDecimal getPreviousReading() {
		return previousReading;
	}
	public String getPreviousReadingDate() {
		return previousReadingDate;
	}
	public BigDecimal getFailedReading() {
		return failedReading;
	}
	public String getFailedReadingDate() {
		return failedReadingDate;
	}
	public void setPreviousReading(BigDecimal previousReading) {
		this.previousReading = previousReading;
	}
	public void setPreviousReadingDate(String previousReadingDate) {
		this.previousReadingDate = previousReadingDate;
	}
	public void setFailedReading(BigDecimal failedReading) {
		this.failedReading = failedReading;
	}
	public void setFailedReadingDate(String failedReadingDate) {
		this.failedReadingDate = failedReadingDate;
	}
	
}
