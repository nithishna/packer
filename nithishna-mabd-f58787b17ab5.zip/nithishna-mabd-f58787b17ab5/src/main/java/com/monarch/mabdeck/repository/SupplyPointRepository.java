package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.SupplyPoint;

@Repository
public interface SupplyPointRepository extends JpaRepository<SupplyPoint, Long>{

	@Query(value="select * from supply_point where client_id=?1 and network_id=?2 and property_id=?3", nativeQuery = true)
	List<SupplyPoint> getSupplyPoint(Long clientId, Long networkId, Long propertyId);
	
	@Query(value="select * from supply_point where client_id=?1 and network_id=?2", nativeQuery=true)
	List<SupplyPoint> getSupplyPointByClientAndNetwork(Long clientId, Long networkId);
	
	@Query(value="select s.* from property p, supply_point s where p.property_id = s.property_id and p.client_id = s.client_id and p.network_id = s.network_id and supply_type=?1 and s.client_id=?2 and s.network_id=?3", nativeQuery = true)
	List<SupplyPoint> getAllSuppliesForSupplyType(String supplyType, Long clientId, Long networkId);
	
	
	/*@Query(value="select * from \r\n" + 
			"		(select	s.supply_id, p.address_line1, p.address_line2, \r\n" + 
			"				p.address_line3, p.town, p.region, p.post_code, \r\n" + 
			"				p.country, c.client_name, n.network, m.count,\r\n" + 
			"				RowNum = row_number() OVER ( order by s.supply_id)\r\n" + 
			"		from	supply_point s\r\n" + 
			"				left join property p on s.property_id = p.property_id \r\n" + 
			"				left join network n on s.network_id = n.network_id \r\n" + 
			"				left join client c on s.client_id = c.client_id \r\n" + 
			"				left join (select s1.supply_id, count(m1.meter_id) as count from supply_point s1 left join meter m1 on m1.supply_id = s1.supply_id\r\n" + 
			"				group by s1.supply_id) m on s.supply_id = m.supply_id)t \r\n" + 
			"	where RowNum between ?1 and ?2", nativeQuery =true)
	List<Object[]> getAllSupplyPoint(int startIndex, int endIndex);*/
	
	@Query(value="select count(*) from property", nativeQuery=true)
	long getCount();
}