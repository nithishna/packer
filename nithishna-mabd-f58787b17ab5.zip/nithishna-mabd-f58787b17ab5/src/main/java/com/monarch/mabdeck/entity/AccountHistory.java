package com.monarch.mabdeck.entity;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AccountHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long accountId;
	private String accountNumber;
	
	@Column(nullable=true)
	private String paymentCardNumber;
	private Long clientId;
	private Long networkId;
	private String emailLanguage;
	private Boolean sendInvitation;
	@Embedded
	private Address address;
	@Embedded
	private Audit audit;

	public long getAccountId() {
		return accountId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}	

	public String getPaymentCardNumber() {
		return paymentCardNumber;
	}

	public long getClientId() {
		return clientId;
	}

	public long getNetworkId() {
		return networkId;
	}

	public String getEmailLanguage() {
		return emailLanguage;
	}

	public Boolean isSendInvitation() {
		return sendInvitation;
	}

	public Audit getAudit() {
		return audit;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setPaymentCardNumber(String paymentCardNumber) {
		this.paymentCardNumber = paymentCardNumber;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public void setEmailLanguage(String emailLanguage) {
		this.emailLanguage = emailLanguage;
	}

	public void setSendInvitation(Boolean sendInvitation) {
		this.sendInvitation = sendInvitation;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
}
