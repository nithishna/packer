package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.dto.AccountLimitedDto;
import com.monarch.mabdeck.entity.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long>{

	@Query(value="select * from Account where network_id = ?1", nativeQuery = true)
	List<Account> fetchAllAccountByNetworkId(Long networkId);
	
	@Query(value="select a.account_id as accountId, b.first_name as firstName, b.last_name as lastName,a.account_number as accountNumber,n.network,c.client_name as clientName from billable_person b, account a,network n, client c where a.account_id = b.account_id and a.network_id = n.network_id and a.client_id = c.client_id and b.deleted=0 order by a.account_id", nativeQuery = true)
	List<AccountLimitedDto> fetchAllAccountDetails();
	
	
	@Query(value = "select \r\n" + 
			"distinct a.account_id as accountId, concat(b.first_name,b.last_name,'-', a.account_number) as firstName \r\n" +
			"from account a, billable_person b,property p \r\n" + 
			"where a.account_id = b.account_id  and p.client_id = a.client_id and p.network_id = a.network_id and b.deleted=0 and p.property_id = ?1", nativeQuery = true)
	List<Object[]> populateAccountDropDownForClientAndNetwork(Long propertyId);
	
	@Query(value = "select account_number, address_line1, address_line2, address_line3,region, town,country, post_code  from account where account_id=?1", nativeQuery = true)
	List<Object[]> getAccountDetailsForAccountId(Long accountId);
	
	@Query(value="SELECT \r\n" + 
			"	account_id, account_number, address_line1, address_line2, address_line3, country, post_code, region, town, \r\n" + 
			"	payment_card_number, client_id, network_id, email_language, send_invitation, created_date, created_user, \r\n" + 
			"	updated_date, updated_user, mood, vulnerable, red_flag, on_hold\r\n" + 
			"FROM   \r\n" + 
			"	(select a.*, RowNum = row_number() OVER (order by a.account_id) from account a) m\r\n" + 
			"where \r\n" + 
			"	RowNum between ?1 and ?2", nativeQuery = true)
	List<Account> getAllAccountsByPaging(int startIndex, int endIndex);
	
	@Query(value="select count(*) from account", nativeQuery =true)
	long getCount();
}
