package com.monarch.mabdeck.controller;

import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.TariffDto;
import com.monarch.mabdeck.service.TariffService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class TariffController {

	private Logger logger = LoggerFactory.getLogger(TariffController.class);

	@Autowired
	private TariffService service;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.TARIFF, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, produces = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody TariffDto createTariff(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody TariffDto tariff) {
		logger.info("TariffController: createTariff - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("TariffController: createTariff - Service call, Username : " + username);
		return service.create(tariff, username);		
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_TARIFF_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody TariffDto getTariffById(@PathVariable("tariff_id") Long tariffId) throws NotFoundException {
		logger.info("TariffController: getTariffById - Start");
		return service.read(tariffId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.TARIFF, method = RequestMethod.GET, produces = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public List<TariffDto> getAllTariffs() throws NotFoundException {
		logger.info("TariffController: getAllTariffs - Start");
		return service.readAll();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_TARIFF_BY_ID, method = RequestMethod.PUT, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void deleteTariff(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@PathVariable("tariff_id") Long tariffId) throws NotFoundException {
		logger.info("TariffController: deleteTariff - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("TariffController: deleteTariff - Service call, Username : " + username);
		service.deleteTariff(tariffId, username);
		logger.info("TariffController: deleteTariff - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.TARIFF, method = RequestMethod.PUT, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void updateTariffEndDate(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody TariffDto tariff) {
		logger.info("TariffController: updateTariffEndDate - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("TariffController: updateTariffEndDate - Service call, Username : " + username);
		service.setTariffEndDate(tariff, username);
		logger.info("TariffController: updateTariffEndDate - End");
	}
}
