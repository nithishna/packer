package com.monarch.mabdeck.dto;

import java.util.ArrayList;
import java.util.List;

public class PreStatementDto implements IDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long preStatementId;
	private Long queueId;
	private String billablePerson;
	private String clientName;
	private String networkName;
	private AddressDto propertyAddress;
	private String fromDate;
	private String toDate;
	private String generationDate;
	private List<PreStatmentEnergyDto> energyList;
	private boolean valid;
	private String validityReason;
	
	private double adminCharge;
	private double totalAdminCharge;
	private double totalCharge;
	private long noOfDays;
	
	public static class PreStatmentEnergyDto{
		private Long preStatementEnergyId;
		private double unitPricePerUnit;
		private double unitsUsed;
		private double totalUnitsUsed;		
		private double totalCost;
		private double adminCharge;
		private double adminVat;
		private double unitChargeVat;
		private String energy;
		private List<ReadingsDto> reading = new ArrayList<>();
		private List<PreStandingChargeDto> standingChargeList = new ArrayList<>();
		public Long getPreStatementEnergyId() {
			return preStatementEnergyId;
		}
		public double getUnitPricePerUnit() {
			return unitPricePerUnit;
		}
		public double getUnitsUsed() {
			return unitsUsed;
		}
		public double getTotalUnitsUsed() {
			return totalUnitsUsed;
		}
		public double getTotalCost() {
			return totalCost;
		}
		public double getAdminCharge() {
			return adminCharge;
		}
		public double getAdminVat() {
			return adminVat;
		}
		public double getUnitChargeVat() {
			return unitChargeVat;
		}
		public String getEnergy() {
			return energy;
		}
		public List<ReadingsDto> getReading() {
			return reading;
		}
		public List<PreStandingChargeDto> getStandingChargeList() {
			return standingChargeList;
		}
		public void setPreStatementEnergyId(Long preStatementEnergyId) {
			this.preStatementEnergyId = preStatementEnergyId;
		}
		public void setUnitPricePerUnit(double unitPricePerUnit) {
			this.unitPricePerUnit = unitPricePerUnit;
		}
		public void setUnitsUsed(double unitsUsed) {
			this.unitsUsed = unitsUsed;
		}
		public void setTotalUnitsUsed(double totalUnitsUsed) {
			this.totalUnitsUsed = totalUnitsUsed;
		}
		public void setTotalCost(double totalCost) {
			this.totalCost = totalCost;
		}
		public void setAdminCharge(double adminCharge) {
			this.adminCharge = adminCharge;
		}
		public void setAdminVat(double adminVat) {
			this.adminVat = adminVat;
		}
		public void setUnitChargeVat(double unitChargeVat) {
			this.unitChargeVat = unitChargeVat;
		}
		public void setEnergy(String energy) {
			this.energy = energy;
		}
		public void setReading(List<ReadingsDto> reading) {
			this.reading = reading;
		}
		public void setStandingChargeList(List<PreStandingChargeDto> standingChargeList) {
			this.standingChargeList = standingChargeList;
		}

	}
	
	public static class PreStandingChargeDto{
		private Long standingChargeId;
		
		private String standingChargeName;
		private float standingCharge;
		private float totalStandingCharge;
		private long noOfDays;
		public Long getStandingChargeId() {
			return standingChargeId;
		}
		public String getStandingChargeName() {
			return standingChargeName;
		}
		public float getStandingCharge() {
			return standingCharge;
		}
		public float getTotalStandingCharge() {
			return totalStandingCharge;
		}
		public long getNoOfDays() {
			return noOfDays;
		}
		public void setStandingChargeId(Long standingChargeId) {
			this.standingChargeId = standingChargeId;
		}
		public void setStandingChargeName(String standingChargeName) {
			this.standingChargeName = standingChargeName;
		}
		public void setStandingCharge(float standingCharge) {
			this.standingCharge = standingCharge;
		}
		public void setTotalStandingCharge(float totalStandingCharge) {
			this.totalStandingCharge = totalStandingCharge;
		}
		public void setNoOfDays(long noOfDays) {
			this.noOfDays = noOfDays;
		}
		
	}
	
	public static class ReadingsDto{
		private Long readingId;
		private String readingDate;
		private Float value;
		public Long getReadingId() {
			return readingId;
		}
		public String getReadingDate() {
			return readingDate;
		}
		public Float getValue() {
			return value;
		}
		public void setReadingId(Long readingId) {
			this.readingId = readingId;
		}
		public void setReadingDate(String readingDate) {
			this.readingDate = readingDate;
		}
		public void setValue(Float value) {
			this.value = value;
		}
	}

	public String getBillablePerson() {
		return billablePerson;
	}

	public String getClientName() {
		return clientName;
	}

	public String getNetworkName() {
		return networkName;
	}

	public AddressDto getPropertyAddress() {
		return propertyAddress;
	}

	public String getFromDate() {
		return fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public String getGenerationDate() {
		return generationDate;
	}

	public void setBillablePerson(String billablePerson) {
		this.billablePerson = billablePerson;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public void setPropertyAddress(AddressDto propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public void setGenerationDate(String generationDate) {
		this.generationDate = generationDate;
	}

	public List<PreStatmentEnergyDto> getEnergyList() {
		return energyList;
	}

	public void setEnergyList(List<PreStatmentEnergyDto> energyList) {
		this.energyList = energyList;
	}
	
	public void addEnergyList(PreStatmentEnergyDto energy) {
		this.energyList.add(energy);
	}

	public Long getPreStatementId() {
		return preStatementId;
	}

	public Long getQueueId() {
		return queueId;
	}

	public void setPreStatementId(Long preStatementId) {
		this.preStatementId = preStatementId;
	}

	public void setQueueId(Long queueId) {
		this.queueId = queueId;
	}

	public boolean isValid() {
		return valid;
	}

	public String getValidityReason() {
		return validityReason;
	}

	public void setValid(boolean valid) {
		this.valid = valid;
	}

	public void setValidityReason(String validityReason) {
		this.validityReason = validityReason;
	}

	public double getAdminCharge() {
		return adminCharge;
	}

	public double getTotalAdminCharge() {
		return totalAdminCharge;
	}

	public double getTotalCharge() {
		return totalCharge;
	}

	public long getNoOfDays() {
		return noOfDays;
	}

	public void setAdminCharge(double adminCharge) {
		this.adminCharge = adminCharge;
	}

	public void setTotalAdminCharge(double totalAdminCharge) {
		this.totalAdminCharge = totalAdminCharge;
	}

	public void setTotalCharge(double totalCharge) {
		this.totalCharge = totalCharge;
	}

	public void setNoOfDays(long noOfDays) {
		this.noOfDays = noOfDays;
	}
}
