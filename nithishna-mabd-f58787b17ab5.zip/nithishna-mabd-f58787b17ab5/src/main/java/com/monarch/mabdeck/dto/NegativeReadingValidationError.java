package com.monarch.mabdeck.dto;

import java.math.BigDecimal;

public class NegativeReadingValidationError extends ValidationErrors {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigDecimal reading;
	private String flaggedDate;
	public BigDecimal getReading() {
		return reading;
	}
	public String getFlaggedDate() {
		return flaggedDate;
	}
	public void setReading(BigDecimal reading) {
		this.reading = reading;
	}
	public void setFlaggedDate(String flaggedDate) {
		this.flaggedDate = flaggedDate;
	}
}
