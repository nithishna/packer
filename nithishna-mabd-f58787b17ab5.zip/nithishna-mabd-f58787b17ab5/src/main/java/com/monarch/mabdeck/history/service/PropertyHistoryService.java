package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Property;
import com.monarch.mabdeck.entity.PropertyHistory;
import com.monarch.mabdeck.repository.PropertyHistoryRepository;

@Component
public class PropertyHistoryService {

	@Resource
	private PropertyHistoryRepository historyRepository;
	
	public void updatePropertyHistory(Property property, String username) {
		if(property != null) {
			PropertyHistory history = new PropertyHistory();
			history.setAddress(property.getAddress());
			history.setArea(property.getArea());
			history.setAudit(property.getAudit());
			history.setBandId(property.getBand() != null? property.getBand().getBandId() : null);
			history.setClientId(property.getClient()!= null? property.getClient().getClientId() : null);
			history.setNetworkId(property.getNetwork() != null ? property.getNetwork().getNetworkId() : null);
			history.setPropertyId(property.getPropertyId());
			history.setReference(property.getReference());			
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
	
}
