package com.monarch.mabdeck.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.DataLoggerHistory;

@Repository
public interface DataLoggerHistoryRepository extends JpaRepository<DataLoggerHistory, Long>{

}
