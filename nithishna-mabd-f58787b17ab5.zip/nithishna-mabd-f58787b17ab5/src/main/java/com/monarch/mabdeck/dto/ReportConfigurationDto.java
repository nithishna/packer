package com.monarch.mabdeck.dto;

public class ReportConfigurationDto implements IDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private String clientName;
	private String networkName;
	private String reportName;
	private String reportType;
	private ScheduleDto schedule;
	
	public ReportConfigurationDto() {		
	}
	
	public ReportConfigurationDto(long id, String clientName, String networkName, String reportName,
			String reportType, ScheduleDto schedule) {
		super();
		this.id = id;
		this.clientName = clientName;
		this.networkName = networkName;
		this.reportName = reportName;
		this.reportType = reportType;
		this.schedule = schedule;
	}
	public long getId() {
		return id;
	}
	public String getClientName() {
		return clientName;
	}
	public String getNetworkName() {
		return networkName;
	}
	public String getReportName() {
		return reportName;
	}
	public String getReportType() {
		return reportType;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public ScheduleDto getSchedule() {
		return schedule;
	}

	public void setSchedule(ScheduleDto schedule) {
		this.schedule = schedule;
	}	
}