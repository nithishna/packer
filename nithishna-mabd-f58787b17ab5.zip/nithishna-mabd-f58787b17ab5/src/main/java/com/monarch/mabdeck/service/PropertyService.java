package com.monarch.mabdeck.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.annotation.Resource;

import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.AddressDto;
import com.monarch.mabdeck.dto.BandDto;
import com.monarch.mabdeck.dto.ClientDto;
import com.monarch.mabdeck.dto.HubDto;
import com.monarch.mabdeck.dto.MeterDto;
import com.monarch.mabdeck.dto.MeterListItemDto;
import com.monarch.mabdeck.dto.NetworkDto;
import com.monarch.mabdeck.dto.PropertyDto;
import com.monarch.mabdeck.dto.PropertyLimited;
import com.monarch.mabdeck.dto.PropertyListItemDto;
import com.monarch.mabdeck.dto.SupplyListItemDto;
import com.monarch.mabdeck.dto.SupplyPointDto;
import com.monarch.mabdeck.entity.Address;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Band;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.Hub;
import com.monarch.mabdeck.entity.Meter;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.Property;
import com.monarch.mabdeck.entity.SupplyPoint;
import com.monarch.mabdeck.history.service.PropertyHistoryService;
import com.monarch.mabdeck.mapper.AddressMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.MeterMapper;
import com.monarch.mabdeck.mapper.PropertyMapper;
import com.monarch.mabdeck.mapper.SupplyPointMapper;
import com.monarch.mabdeck.repository.BandRepository;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.HubRepository;
import com.monarch.mabdeck.repository.MeterRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.repository.PropertyRepository;
import com.monarch.mabdeck.util.Constants;

import javassist.NotFoundException;

@Component
public class PropertyService extends CommonServiceImpl<PropertyDto, Property> {

	private Logger logger = LoggerFactory.getLogger(PropertyService.class);

	@Resource
	private PropertyRepository repository;

	@Resource
	private ClientRepository clientRepository;

	@Resource
	private BandRepository bandRepository;

	@Resource
	private NetworkRepository networkRepository;

	@Resource
	private MeterRepository meterRepository;

	@Resource
	private HubRepository hubRepository;

	@Autowired
	private PropertyHistoryService historyService;

	@Override
	public JpaRepository<Property, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<PropertyDto, Property> getMapper() {
		return PropertyMapper.INSTANCE;
	}

	@Override
	public void updateAudit(Property entity, String username) {
		if (entity != null) {
			Calendar cal = Calendar.getInstance();
			if (entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			} else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}
	}

	public PropertyDto create(PropertyDto dto, String username) {
		Property entity = this.getMapper().convertToEntity(dto);
		updateAudit(entity, username);
		if (dto.getClient() != null && dto.getClient().getClientId() > 0) {
			Client client = clientRepository.findOne(dto.getClient().getClientId());
			entity.setClient(client);
		} else {
			entity.setClient(null);
		}
		if (dto.getNetwork() != null && dto.getNetwork().getNetworkId() != null) {
			Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
			entity.setNetwork(network);
		} else {
			entity.setNetwork(null);
		}
		if (dto.getBand() != null && dto.getBand().getBandId() > 0) {
			Band band = bandRepository.findOne(dto.getBand().getBandId());
			entity.setBand(band);
		} else {
			entity.setBand(null);
		}
		repository.saveAndFlush(entity);
		return dto;
	}

	public PropertyDto update(PropertyDto dto, String username) {
		if (dto != null && dto.getPropertyId() > 0) {
			Property entity = repository.findOne(dto.getPropertyId());
			updateAudit(entity, username);
			historyService.updatePropertyHistory(entity, username);
			Property newEntity = this.getMapper().convertToEntity(dto);
			if (dto.getBand() != null && dto.getBand().getBandId() > 0) {
				this.updateBand(dto, entity);
			} else {
				return null;
			}
			if (dto.getNetwork() != null && dto.getNetwork().getNetworkId() != null) {
				this.updateNetwork(dto, entity);
			} else {
				return null;
			}
			if (dto.getClient() != null) {
				this.updateClient(dto, entity);
			} else {
				return null;
			}
			entity.setAddress(newEntity.getAddress());
			entity.setReference(newEntity.getReference());
			entity.setArea(newEntity.getArea());
			entity.setLastBilledDate(newEntity.getLastBilledDate());
			entity.setPerDayUsage(newEntity.getPerDayUsage());
		}
		return dto;
	}

	private void updateBand(PropertyDto dto, Property existingEntity) {
		if (dto.getBand().getBandId() != existingEntity.getBand().getBandId()) {
			Band band = bandRepository.findOne(dto.getBand().getBandId());
			existingEntity.setBand(band);
		}
	}

	private void updateNetwork(PropertyDto dto, Property existingEntity) {
		if (dto.getNetwork().getNetworkId() != existingEntity.getNetwork().getNetworkId()) {
			Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
			existingEntity.setNetwork(network);
		}
	}

	private void updateClient(PropertyDto dto, Property existingEntity) {
		if (dto.getClient().getClientId() != existingEntity.getClient().getClientId()) {
			Client client = clientRepository.findOne(dto.getClient().getClientId());
			existingEntity.setClient(client);
		}
	}
	
	public List<PropertyListItemDto> getPropertyListForId(Long propertyId){
		List<PropertyListItemDto> properties = new ArrayList<>();
		Property property = repository.findOne(propertyId);
		if(property != null) {
			PropertyListItemDto dto = new PropertyListItemDto();
			dto.setPropertyId(property.getPropertyId());
			dto.setPropertyName(generatePropertyName(property.getAddress()));
			dto.setSupplyList(getAllSupplyListItems(property.getSupply()));
			properties.add(dto);
		}
		return properties;
	}
	
	public long getCount() {
		return repository.getCount();
	}

	public List<PropertyDto> readAll(int index, int noOfItems) throws NotFoundException {
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1) * noOfItems + 1;
		endIndex = index * noOfItems;
		List<Property> properties = repository.getAllPropertiesBySupply(startIndex, endIndex);
		List<PropertyDto> propertyDtos = new ArrayList<>();
		for (Property property : properties) {
			PropertyDto dto = this.getMapper().convertToDTO(property);
			dto.setNoOfMeters(meterRepository.getCount(property.getPropertyId()));
			Network network = property.getNetwork();
			if (network != null) {
				NetworkDto networkDto = new NetworkDto();
				networkDto.setNetworkId(network.getNetworkId());
				networkDto.setNetwork(network.getNetwork());
				dto.setNetwork(networkDto);
			}
			Client client = property.getClient();
			if (client != null) {
				ClientDto clientDto = new ClientDto();
				clientDto.setClientId(client.getClientId());
				clientDto.setClientName(client.getClientName());
				dto.setClient(clientDto);
			}
			Band band = property.getBand();
			if (band != null) {
				BandDto bandDto = new BandDto();
				bandDto.setBandId(band.getBandId());
				bandDto.setBandName(band.getBandName());
				dto.setBand(bandDto);
			}
			dto.setName(this.generateName(dto.getAddress()));
			propertyDtos.add(dto);
		}
		return propertyDtos;
	}
	
	public List<PropertyDto> readAll() throws NotFoundException {
		List<Property> properties = repository.findAll();
		List<PropertyDto> propertyDtos = new ArrayList<>();
		for (Property property : properties) {
			PropertyDto dto = this.getMapper().convertToDTO(property);
			dto.setNoOfMeters(meterRepository.getCount(property.getPropertyId()));
			Network network = property.getNetwork();
			if (network != null) {
				NetworkDto networkDto = new NetworkDto();
				networkDto.setNetworkId(network.getNetworkId());
				networkDto.setNetwork(network.getNetwork());
				dto.setNetwork(networkDto);
			}
			Client client = property.getClient();
			if (client != null) {
				ClientDto clientDto = new ClientDto();
				clientDto.setClientId(client.getClientId());
				clientDto.setClientName(client.getClientName());
				dto.setClient(clientDto);
			}
			Band band = property.getBand();
			if (band != null) {
				BandDto bandDto = new BandDto();
				bandDto.setBandId(band.getBandId());
				bandDto.setBandName(band.getBandName());
				dto.setBand(bandDto);
			}
			dto.setName(this.generateName(dto.getAddress()));
			propertyDtos.add(dto);
		}
		return propertyDtos;
	}
	
	public List<PropertyDto> getAllPropertiesWithSuppliesV2(int index, int noOfItems) {
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1)*noOfItems + 1;
		endIndex = index * noOfItems;		
		List<Property> properties = repository.getAllPropertiesBySupply(startIndex, endIndex);
		List<PropertyDto> dtos = new ArrayList<>();
		boolean flag = true;
		for (Property entity : properties) {
			List<Hub> hubs = hubRepository.getAllHubsForProperty(entity.getPropertyId());
			List<HubDto> hubDtos = new ArrayList<>();
			if (hubs != null && hubs.size() > 0) {
				flag = true;
				for (Hub hub : hubs) {
					HubDto hubDto = new HubDto();
					hubDto.setHubId(hub.getHubId());
					hubDto.setHubManufacturer(hub.getHubManufacturer());
					hubDto.setHubModel(hub.getHubModel());
					hubDto.setIdentifier(hub.getIdentifier());
					hubDto.setSerialNumber(hub.getSerialNumber());
					hubDto.setEndDate(hub.getEndDate());
					hubDto.setStartDate(hub.getStartDate());
					hubDtos.add(hubDto);
				}
			}
			PropertyDto dto = this.getMapper().convertToDTO(entity);
			dto.setHub(hubDtos);
			if (entity.getSupply() != null && entity.getSupply().size() > 0) {
				flag = true;
				List<SupplyPointDto> supplyDtos = new ArrayList<>();
				for (SupplyPoint supply : entity.getSupply()) {
					SupplyPointDto supplyDto = SupplyPointMapper.INSTANCE.convertToSupplyPointDto(supply);
					List<MeterDto> meterDto = new ArrayList<>();
					if (supply.getMeter() != null && supply.getMeter().size() > 0) {
						meterDto = MeterMapper.INSTANCE.convertToMeterDTOList(supply.getMeter());
						supplyDto.setMeter(meterDto);
					}
					supplyDtos.add(supplyDto);
				}
				dto.setSupply(supplyDtos);
			}
			if (flag == true) {
				dto.setName(this.generateName(dto.getAddress()));
				if (entity.getNetwork() != null) {
					Network network = entity.getNetwork();
					NetworkDto networkDto = new NetworkDto();
					networkDto.setNetworkId(network.getNetworkId());
					networkDto.setNetwork(network.getNetwork());
					dto.setNetwork(networkDto);
				}
				if (entity.getClient() != null) {
					Client client = entity.getClient();
					ClientDto clientDto = new ClientDto();
					clientDto.setClientId(client.getClientId());
					clientDto.setClientName(client.getClientName());
					dto.setClient(clientDto);
				}
				dtos.add(dto);
				//flag = false;
			}
		}
		return dtos;
	}

	public List<PropertyDto> getAllPropertiesWithSupplies() {
		List<Property> properties = repository.findAll();
		List<PropertyDto> dtos = new ArrayList<>();
		boolean flag = false;
		for (Property entity : properties) {
			List<Hub> hubs = hubRepository.getAllHubsForProperty(entity.getPropertyId());
			List<HubDto> hubDtos = new ArrayList<>();
			if (hubs != null && hubs.size() > 0) {
				flag = true;
				for (Hub hub : hubs) {
					HubDto hubDto = new HubDto();
					hubDto.setHubId(hub.getHubId());
					hubDto.setHubManufacturer(hub.getHubManufacturer());
					hubDto.setHubModel(hub.getHubModel());
					hubDto.setIdentifier(hub.getIdentifier());
					hubDto.setSerialNumber(hub.getSerialNumber());
					hubDto.setEndDate(hub.getEndDate());
					hubDto.setStartDate(hub.getStartDate());
					hubDtos.add(hubDto);
				}
			}
			PropertyDto dto = this.getMapper().convertToDTO(entity);
			dto.setHub(hubDtos);
			if (entity.getSupply() != null && entity.getSupply().size() > 0) {
				flag = true;
				List<SupplyPointDto> supplyDtos = new ArrayList<>();
				for (SupplyPoint supply : entity.getSupply()) {
					SupplyPointDto supplyDto = SupplyPointMapper.INSTANCE.convertToSupplyPointDto(supply);
					List<MeterDto> meterDto = new ArrayList<>();
					if (supply.getMeter() != null && supply.getMeter().size() > 0) {
						meterDto = MeterMapper.INSTANCE.convertToMeterDTOList(supply.getMeter());
						supplyDto.setMeter(meterDto);
					}
					supplyDtos.add(supplyDto);
				}
				dto.setSupply(supplyDtos);
			}
			if (flag == true) {
				dto.setName(this.generateName(dto.getAddress()));
				if (entity.getNetwork() != null) {
					Network network = entity.getNetwork();
					NetworkDto networkDto = new NetworkDto();
					networkDto.setNetworkId(network.getNetworkId());
					networkDto.setNetwork(network.getNetwork());
					dto.setNetwork(networkDto);
				}
				if (entity.getClient() != null) {
					Client client = entity.getClient();
					ClientDto clientDto = new ClientDto();
					clientDto.setClientId(client.getClientId());
					clientDto.setClientName(client.getClientName());
					dto.setClient(clientDto);
				}
				dtos.add(dto);
				flag = false;
			}
		}
		return dtos;
	}

	private String generateName(AddressDto address) {
		StringBuilder builder = new StringBuilder();
		if (address != null) {
			if (address.getAddressLine1() != null && !address.getAddressLine1().equals("")) {
				builder.append(address.getAddressLine1() + ", ");
			}
			if (address.getAddressLine2() != null && !address.getAddressLine2().equals("")) {
				builder.append(address.getAddressLine2() + ", ");
			}
			if (address.getAddressLine3() != null && !address.getAddressLine3().equals("")) {
				builder.append(address.getAddressLine3() + ", ");
			}
			if (address.getRegion() != null && !address.getRegion().equals("")) {
				builder.append(address.getRegion() + ", ");
			}
			if (address.getTown() != null && !address.getTown().equals("")) {
				builder.append(address.getTown() + ", ");
			}
			if (address.getCountry() != null && !address.getCountry().equals("")) {
				builder.append(address.getCountry() + ", ");
			}
			if (address.getPostCode() != null && !address.getPostCode().equals("")) {
				builder.append(address.getPostCode());
			} else {
				builder.setLength(Math.max(builder.length() - 1, 0));
			}
		}
		return builder.toString();
	}

	public byte[] downloadTemplate(Long clientId, Long networkId, Long bandId) throws IOException {
		File tempFile = new File("template.csv");
		PrintWriter pw = new PrintWriter(tempFile);
		StringBuilder sb = new StringBuilder();
		this.populateHeading(sb);
		this.populateRow(clientId, networkId, bandId, sb);
		pw.write(sb.toString());
		pw.close();
		InputStream stream = new FileInputStream("template.csv");
		byte[] result = IOUtils.toByteArray(stream);
		stream.close();
		logger.debug("File deletion status : " + (tempFile.delete() ? "Success" : "Failure"));
		return result;
	}

	private void populateHeading(StringBuilder sb) {
		sb.append("ClientId").append(",");
		sb.append("Client").append(",");
		sb.append("NetworkId").append(",");
		sb.append("Network").append(",");
		sb.append("PropertyBandId").append(",");
		sb.append("PropertyBand").append(",");
		sb.append("PropertyReference").append(",");
		sb.append("Area").append(",");
		sb.append("AreaUnit").append(",");
		sb.append("AddressLine1").append(",");
		sb.append("AddressLine2").append(",");
		sb.append("AddressLine3").append(",");
		sb.append("Town").append(",");
		sb.append("Region").append(",");
		sb.append("Postcode").append(",");
		sb.append("Country").append(",");
		sb.append("Last Billed date");
		sb.append("\n");
	}

	private void populateRow(Long clientId, Long networkId, Long bandId, StringBuilder sb) {
		sb.append(clientId.toString()).append(",");
		sb.append(clientRepository.getClientNameById(clientId)).append(",");
		sb.append(networkId.toString()).append(",");
		sb.append(networkRepository.getNetworkNameById(networkId)).append(",");
		sb.append(bandId.toString()).append(",");
		sb.append(bandRepository.getBandNameById(bandId)).append(",");
		sb.append("").append(",");
		sb.append("").append(",");
		sb.append("Square Foot OR Square Meter (delete as appropriate)").append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append("").append(",");
		sb.append("").append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append("").append(",");
		sb.append(Constants.REQUIRED).append(",");
		sb.append("").append(",");
		sb.append(Constants.REQUIRED);
		sb.append("\n");
	}
	
	public byte[] uploadCSV(MultipartFile multipartFile) throws IOException {
		File file = null;
		byte[] result = null;
		try {
			FileWriter csvWriter = new FileWriter("result.csv");			
			file = convertMultiPartToFile(multipartFile);
			Scanner scanner = new Scanner(file);
			boolean headingValidation = false;
			while (scanner.hasNextLine()) {
				if (!headingValidation) {
					headingValidation = validateHeading(scanner.nextLine());
					if (!headingValidation) {
						scanner.close();
						throw new IOException("Kindly check the heading order");
					}
					for(String value : Constants.propertiesHeading) {
						csvWriter.append(value);
						csvWriter.append(",");
					}
					csvWriter.append("Message").append("\n");
				} else {
					getRecordFromLine(scanner.nextLine(), csvWriter);
				}
			}
			scanner.close();
			csvWriter.flush();
			csvWriter.close();
			InputStream stream = new FileInputStream("result.csv");
			result = IOUtils.toByteArray(stream);
			stream.close();			
			if (file != null)
				logger.debug(file.delete() ? "Temp File Deleted successfully" : "Temp File could not be deleted");
			File resultFile = new File("result.csv");
			resultFile.delete();
		} catch (Exception ex) {
			if (file != null)
				logger.debug(file.delete() ? "Temp File Deleted successfully" : "Temp File could not be deleted");
			throw new IOException("Unable to parse the file. Kindly raise a support request and get this sorted");
		}
		return result;
	}

	private boolean validateHeading(String line) {
		List<String> heading = Constants.propertiesHeading;
		Iterator<String> iterator = heading.iterator();
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			while (rowScanner.hasNext()) {
				if (!iterator.next().equalsIgnoreCase(rowScanner.next())) {
					return false;
				}
			}
		}
		return true;
	}

	private void getRecordFromLine(String line, FileWriter csvWriter) throws IOException {
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			Property property = new Property();
			List<Network> networks = null;
			if (rowScanner.hasNext()) {
				long clientId = rowScanner.nextLong();
				Client client = clientRepository.findOne(clientId);				
				if (client == null)
					throw new IOException(
							"Client details are mandatory. Please enter the Client details and try again.");
				networks = client.getNetwork();
				property.setClient(client);
				logger.debug("client name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			if (rowScanner.hasNext()) {
				long networkId = rowScanner.nextLong();				
				if (networks == null || networks.size() < 1)
					throw new IOException(
							"There are no networks associated with the client details supplied");
				for(Network network : networks) {
					if(network.getNetworkId() == networkId)
					{
						property.setNetwork(network);
					}
				}
				if(property.getNetwork() == null)
					throw new IOException("The supplied network does not belong to the client");
				logger.debug("Network name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			if (rowScanner.hasNext()) {
				long bandId = rowScanner.nextLong();
				Band band = bandRepository.findOne(bandId);
				if (band == null)
					throw new IOException("Band details are mandatory. Please enter the Band details and try again");
				property.setBand(band);
				logger.debug("Band name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			property.setReference(rowScanner.hasNext() ? rowScanner.next() : null);
			property.setArea(rowScanner.hasNext() ? rowScanner.next() : null);
			logger.debug("Area Unit: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			Address address = new Address();
			address.setAddressLine1(rowScanner.hasNext() ? rowScanner.next() : null);
			if (address.getAddressLine1().isEmpty() || address.getAddressLine1() == null)
				throw new IOException("AddressLine1 is mandatory. Please enter the addressline1 details and try again");
			address.setAddressLine2(rowScanner.hasNext() ? rowScanner.next() : null);
			address.setAddressLine3(rowScanner.hasNext() ? rowScanner.next() : null);
			address.setTown(rowScanner.hasNext() ? rowScanner.next() : null);
			if (address.getTown().isEmpty() || address.getTown() == null)
				throw new IOException("Town is mandatory. Please enter the Town details and try again");
			address.setRegion(rowScanner.hasNext() ? rowScanner.next() : null);
			address.setPostCode(rowScanner.hasNext() ? rowScanner.next() : null);
			if (address.getPostCode().isEmpty() || address.getPostCode() == null)
				throw new IOException("PostCode is mandatory. Please enter the Postcode details and try again");
			address.setCountry(rowScanner.hasNext() ? rowScanner.next() : null);
			property.setAddress(address);
			String lastBilled = rowScanner.hasNext() ? rowScanner.next() : null;
			if( !lastBilled.isEmpty() && !lastBilled.equals("")) {
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				try {
					Date date = formatter.parse(lastBilled);
					property.setLastBilledDate(new java.sql.Date(date.getTime()));
				}catch(Exception ex) {
					throw new IOException("Date should be in dd/MM/yyyy format");
				}
			}else
				throw new IOException("Last billed date is mandatory");
			this.updateAudit(property, "Application\\Bulk Import");
			repository.saveAndFlush(property);
			this.writeLine(line, csvWriter);
			csvWriter.append("Success");
			csvWriter.append("\n");
			
		} catch (Exception ex) {
			this.writeLine(line, csvWriter);
			csvWriter.append("Error: " + ex.getMessage());
			csvWriter.append("\n");
		}
	}
	
	private void writeLine(String line, FileWriter csvWriter) throws IOException {
		String[] values = line.split(",");
		for(String value : values) {
			csvWriter.append(value);
			csvWriter.append(",");
		}
		int extension = Constants.propertiesHeading.size() - values.length;
		if(extension > 0) {
			for(int i=0; i<extension; i++) {
				csvWriter.append("");
				csvWriter.append(",");
			}
		}
	}

	private File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

	public List<PropertyDto> getAllPropertiesNotAssociatedWithAccountForNetwork(Long accountId, Long networkId) {
		List<PropertyDto> dtos = new ArrayList<>();
		List<Property> entites = repository.getAllPropertiesNotInAccount(accountId, networkId, "tenant");
		for (Property entity : entites) {
			PropertyDto dto = new PropertyDto();
			dto.setPropertyId(entity.getPropertyId());
			if (entity.getAddress() != null)
				dto.setAddress(AddressMapper.INSTANCE.convertToDTO(entity.getAddress()));
			dtos.add(dto);
		}
		return dtos;
	}

	public List<PropertyDto> getAllPropertiesUnderMovementOutside(Long accountId, Long networkId) {
		List<PropertyDto> dtos = new ArrayList<>();
		List<Property> entites = repository.getAllPropertiesUnderMovementOutside(accountId, networkId);
		for (Property entity : entites) {
			PropertyDto dto = new PropertyDto();
			dto.setPropertyId(entity.getPropertyId());
			if (entity.getAddress() != null)
				dto.setAddress(AddressMapper.INSTANCE.convertToDTO(entity.getAddress()));
			dtos.add(dto);
		}
		return dtos;
	}

	public List<PropertyDto> getAllPropertiesUnderMovementInside(Long accountId, Long networkId) {
		List<PropertyDto> dtos = new ArrayList<>();
		List<Property> entites = repository.getAllPropertiesUnderMovementInside(accountId, networkId);
		for (Property entity : entites) {
			PropertyDto dto = new PropertyDto();
			dto.setPropertyId(entity.getPropertyId());
			if (entity.getAddress() != null)
				dto.setAddress(AddressMapper.INSTANCE.convertToDTO(entity.getAddress()));
			dtos.add(dto);
		}
		return dtos;
	}
	
	public List<PropertyDto> getAllPropertiesUnderMovementInsideForOwner(Long accountId){
		List<PropertyDto> dtos = new ArrayList<>();
		List<Property> entites = repository.getAllPropertiesUnderMovementInsideForOwner(accountId);
		for (Property entity : entites) {
			PropertyDto dto = new PropertyDto();
			dto.setPropertyId(entity.getPropertyId());
			if (entity.getAddress() != null)
				dto.setAddress(AddressMapper.INSTANCE.convertToDTO(entity.getAddress()));
			dtos.add(dto);
		}
		return dtos;
	}
	
	public List<PropertyDto> getAllPropertiesUnderMovementOutsideForOwner(Long accountId) {
		List<PropertyDto> dtos = new ArrayList<>();
		List<Property> entites = repository.getAllPropertiesUnderMovementOutsideForOwner(accountId);
		for (Property entity : entites) {
			PropertyDto dto = new PropertyDto();
			dto.setPropertyId(entity.getPropertyId());
			if (entity.getAddress() != null)
				dto.setAddress(AddressMapper.INSTANCE.convertToDTO(entity.getAddress()));
			dtos.add(dto);
		}
		return dtos;
	}

	public List<PropertyListItemDto> getPropertyListItemForAccountId(Long accountId) {
		List<PropertyListItemDto> propertyListItems = new ArrayList<>();
		List<Property> properties = repository.getAllPropertiesByAccountId(accountId);
		for (Property property : properties) {
			PropertyListItemDto dto = new PropertyListItemDto();
			dto.setPropertyId(property.getPropertyId());
			dto.setPropertyName(generatePropertyName(property.getAddress()));
			dto.setSupplyList(getAllSupplyListItems(property.getSupply()));
			propertyListItems.add(dto);
		}
		return propertyListItems;
	}

	private String generatePropertyName(Address address) {
		StringBuilder builder = new StringBuilder();
		if (address != null) {
			if (address.getAddressLine1() != null)
				builder.append(address.getAddressLine1()).append(" ");
			if (address.getAddressLine2() != null)
				builder.append(address.getAddressLine2()).append(" ");
			if (address.getAddressLine3() != null)
				builder.append(address.getAddressLine3()).append(" ");
			if (address.getRegion() != null)
				builder.append(address.getRegion()).append(" ");
			if (address.getTown() != null)
				builder.append(address.getTown()).append(" ");
			if (address.getCountry() != null)
				builder.append(address.getCountry()).append(" ");
			if (address.getPostCode() != null)
				builder.append(address.getPostCode()).append(" ");
		}
		return builder.toString();
	}

	private List<SupplyListItemDto> getAllSupplyListItems(List<SupplyPoint> supplies) {
		List<SupplyListItemDto> dtos = new ArrayList<>();
		for (SupplyPoint supply : supplies) {
			SupplyListItemDto dto = new SupplyListItemDto();
			dto.setSupplyId(supply.getSupplyId());
			dto.setSupplyName(supply.getSupplyType());
			dto.setMeterList(getAllMeterListItems(supply.getMeter()));
			dtos.add(dto);
		}
		return dtos;
	}

	private List<MeterListItemDto> getAllMeterListItems(List<Meter> meters) {
		List<MeterListItemDto> dtos = new ArrayList<>();
		for (Meter meter : meters) {
			MeterListItemDto dto = new MeterListItemDto();
			dto.setMeterId(meter.getMeterId());
			StringBuilder builder = new StringBuilder();
			if (meter.getSerialNumber() != null)
				builder.append(meter.getSerialNumber()).append("-meter");
			dto.setMeterName(builder.toString());
			dtos.add(dto);
		}
		return dtos;
	}

	public List<PropertyLimited> getAllPropertiesWithOwnerAndTenant() {
		List<PropertyLimited> properties = new ArrayList<>();
		List<Object[]> propertiesList = repository.getAllPropertiesWithTenantAndOwner();
		Long accountId = null;
		for (Object[] propertyListItem : propertiesList) {
			PropertyLimited property = new PropertyLimited();
			property.setPropertyId(propertyListItem[0] == null ? null : (BigDecimal) propertyListItem[0]);
			property.setAddressLine1(propertyListItem[1] == null ? null : (String) propertyListItem[1]);
			property.setAddressLine2(propertyListItem[2] == null ? null : (String) propertyListItem[2]);
			property.setAddressLine3(propertyListItem[3] == null ? null : (String) propertyListItem[3]);			
			property.setNetworkName(propertyListItem[4] == null ? null : (String) propertyListItem[4]);
			property.setClientName(propertyListItem[5] == null ? null : (String) propertyListItem[5]);
			property.setReference(propertyListItem[6] == null ? null : (String) propertyListItem[6]);			
			accountId = repository.getActiveAccountIdForProperty(property.getPropertyId(), "tenant");
			if(accountId != null)
				property.setCurrentTenant(repository.getBillablePersonNameForAccount(accountId));
			accountId = repository.getActiveAccountIdForProperty(property.getPropertyId(), "owner");
			if(accountId != null)
				property.setCurrentOwner(repository.getBillablePersonNameForAccount(accountId));
			properties.add(property);
		}
		return properties;
	}
	
	public List<PropertyLimited> getAllPropertiesForNetwork(List<Long> networkIds){
		List<Property> properties = repository.getRequestedPropertiesByNetworkIds(networkIds);
		List<PropertyLimited> propertyDtos = new ArrayList<>();
		for(Property property : properties) {
			PropertyLimited props = new PropertyLimited();
			if(property.getAddress()!= null) {
				props.setAddressLine1(property.getAddress().getAddressLine1());
				props.setAddressLine2(property.getAddress().getAddressLine2());
				props.setAddressLine3(property.getAddress().getAddressLine3());
				props.setPostCode(property.getAddress().getPostCode());
				props.setLastBilledDate(property.getLastBilledDate());
			}		
			props.setPid(property.getPropertyId());
			propertyDtos.add(props);
		}
		return propertyDtos;
	}
	
	public List<PropertyLimited> getAllPropertiesByName(String name){
		List<Property> properties = repository.getAllPropertiesByName(name);
		List<PropertyLimited> dtos = new ArrayList<>();
		for(Property property : properties) {
			PropertyLimited props = new PropertyLimited();
			if(property.getAddress() != null) {
				props.setAddressLine1(property.getAddress().getAddressLine1());
				props.setAddressLine2(property.getAddress().getAddressLine2());
				props.setAddressLine3(property.getAddress().getAddressLine3());
				props.setPostCode(property.getAddress().getPostCode());
				props.setLastBilledDate(property.getLastBilledDate());
			}
			props.setPid(property.getPropertyId());
			dtos.add(props);
		}
		return dtos;
	}
	
	public List<PropertyDto> getAllPropertiesByClientIdAndNetworkIdAndBandId(long clientId, long networkId, long bandId){
		List<PropertyDto> dtos = new ArrayList<>();
		List<Object[]> values = repository.getAllPropertiesByClientIdAndNetworkIdAndBandId(clientId, networkId, bandId);
		if(values == null || values.isEmpty())
			return null;
		for(Object[] value : values) {
			PropertyDto dto = new PropertyDto();
			dto.setPropertyId(value[0] == null? null : Long.parseLong(value[0].toString()));
			AddressDto address = new AddressDto();
			address.setAddressLine1(value[1] == null? null: (String)value[1]);
			address.setAddressLine2(value[2] == null? null: (String)value[2]);
			address.setAddressLine3(value[3] == null? null: (String)value[3]);
			address.setTown(value[4] == null? null: (String)value[4]);
			address.setPostCode(value[5] == null? null: (String)value[5]);
			dto.setAddress(address);
			dtos.add(dto);
		}
		return dtos;
	}
}