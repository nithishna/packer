package com.monarch.mabdeck.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;
import javax.naming.directory.InvalidAttributesException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.stereotype.Service;

import com.monarch.mabdeck.dto.ReportConfigInputDto;
import com.monarch.mabdeck.dto.ReportConfigurationDto;
import com.monarch.mabdeck.dto.ReportHistoryDto;
import com.monarch.mabdeck.dto.ReportMetadataDto;
import com.monarch.mabdeck.dto.ReportTypeDto;
import com.monarch.mabdeck.dto.ScheduleDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Band;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.Property;
import com.monarch.mabdeck.entity.ReportConfiguration;
import com.monarch.mabdeck.entity.ReportHistory;
import com.monarch.mabdeck.entity.ReportType;
import com.monarch.mabdeck.entity.Schedule;
import com.monarch.mabdeck.entity.SupplyPoint;
import com.monarch.mabdeck.entity.UserDetails;
import com.monarch.mabdeck.mapper.ReportTypeMapper;
import com.monarch.mabdeck.repository.BandRepository;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.repository.PropertyRepository;
import com.monarch.mabdeck.repository.ReportConfigurationRepository;
import com.monarch.mabdeck.repository.ReportHistoryRepository;
import com.monarch.mabdeck.repository.ReportTypeRepository;
import com.monarch.mabdeck.repository.ScheduleRepository;
import com.monarch.mabdeck.repository.SupplyPointRepository;
import com.monarch.mabdeck.repository.UserDetailsRepository;

@Service
public class ReportService {

	@Resource
	private ReportTypeRepository reportTypeRepository;
	
	@Resource
	private ReportConfigurationRepository reportConfigurationRepository;
	
	@Resource
	private ReportHistoryRepository reportHistoryRepository;
	
	@Resource
	private ClientRepository clientRepository;
	
	@Resource
	private NetworkRepository networkRepository;
	
	@Resource
	private BandRepository bandRepository;
	
	@Resource
	private PropertyRepository propertyRepository;
	
	@Resource
	private SupplyPointRepository supplyPointRepository;
	
	@Resource
	private ScheduleRepository scheduleRepository;
	
	@Resource
	private UserDetailsRepository userDetailsRepository;
	
	public List<ReportTypeDto> getAllReportTypes(){
		List<ReportType> reportTypes = this.reportTypeRepository.findAll();
		return ReportTypeMapper.INSTANCE.convertToDTOList(reportTypes);
	}

	public List<ReportConfigurationDto> getConfigurationByIndex(int index, int noOfItems) {
		int start = 0;
		int end = 0;
		List<ReportConfigurationDto> list = new ArrayList<>();
		start = (index - 1) * noOfItems + 1;
		end = index * noOfItems;
		List<Object[]> confs = reportConfigurationRepository.getConfigurationListByIndex(start, end);
		if (confs == null || confs.isEmpty())
			return list;
		for (Object[] element : confs) {
			ReportConfigurationDto configuration = new ReportConfigurationDto();
			configuration.setId(element[0] == null ? 0 : Long.parseLong(element[0].toString()));
			configuration.setClientName(element[1] == null ? "" : element[1].toString());
			configuration.setNetworkName(element[2] == null ? "" : element[2].toString());
			configuration.setReportName(element[3] == null ? "" : element[3].toString());
			configuration.setReportType(element[4] == null ? "" : element[4].toString());
			ScheduleDto schedule = new ScheduleDto();
			schedule.setScheduleId(element[5] == null ? 0l : Long.parseLong(element[5].toString()));
			schedule.setEmailIds(element[6] == null ? "" : element[6].toString());
			schedule.setOffset(element[7] == null ? 0l : Long.parseLong(element[7].toString()));
			schedule.setPeriod(element[8] == null ? 0 : Integer.parseInt(element[8].toString()));
			schedule.setRecursionType(element[9] == null ? "" : element[9].toString());
			//recursion_offset, hour, minute
			schedule.setRecursionOffset(element[10] == null? 0 : Long.parseLong(element[10].toString()));
			schedule.setHour(element[11] == null? 0 : Long.parseLong(element[11].toString()));
			schedule.setMinute(element[12] == null? 0 : Long.parseLong(element[12].toString()));
			configuration.setSchedule(schedule);
			list.add(configuration);
		}
		return list;
	}

	public List<ReportHistoryDto> getReportHistoryByIndex(int index, int noOfItems) {
		int start = 0;
		int end = 0;
		List<ReportHistoryDto> list = new ArrayList<>();
		start = (index - 1) * noOfItems + 1;
		end = index * noOfItems;
		List<Object[]> confs = reportHistoryRepository.getListOfReportHistoryByIndex(start, end);
		if (confs == null || confs.isEmpty())
			return list;
		for (Object[] element : confs) {
			ReportHistoryDto dto = new ReportHistoryDto();
			ReportConfigurationDto configDto = new ReportConfigurationDto();
			dto.setId(element[0] == null ? 0l : Long.parseLong(element[0].toString()));
			configDto.setClientName(element[1] == null ? "" : element[1].toString());
			configDto.setNetworkName(element[2] == null ? "" : element[2].toString());
			configDto.setReportType(element[3] == null ? "" : element[3].toString());
			configDto.setReportName(element[4] == null ? "" : element[4].toString());
			dto.setConfiguration(configDto);
			if (element[5] != null) {
				Timestamp ts = (Timestamp) element[5];
				dto.setFromDate(new Date(ts.getTime()));
			}
			if (element[6] != null) {
				Timestamp ts = (Timestamp) element[6];
				dto.setToDate(new Date(ts.getTime()));
			}
			if (element[7] != null) {
				Timestamp ts = (Timestamp) element[7];
				dto.setCreationDate(new Date(ts.getTime()));
			}
			if(element[8] != null) {
				dto.setStatus(element[8] == null ? "" : element[8].toString());
			}
			list.add(dto);
		}
		return list;
	}

	public void create(ReportConfigInputDto dto, String username) throws InvalidFormatException {
		ReportConfiguration entity = new ReportConfiguration();
		addClient(entity, dto.getClientId());
		addNetwork(entity, dto.getNetworkId());
		addBand(entity, dto.getBandId());
		addProperty(entity, dto.getPropertyId());
		addSupplyPoint(entity, dto.getSupplyId());
		addReportType(entity, dto.getReportTypeId());
		entity.setReportName(dto.getReportName());
		if (dto.isSingleMeter()) {
			entity.setSingleMeter(true);
			if (dto.getMeterSerialNumber() != null && !dto.getMeterSerialNumber().isEmpty())
				entity.setMeterSerialNumber(dto.getMeterSerialNumber());
			else
				throw new InvalidFormatException("Meter Serial Number is mandatory");
		}
		Audit audit = new Audit();
		Calendar cal = Calendar.getInstance();
		audit.setCreatedUser(username);
		java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
		audit.setCreatedDate(date);
		entity.setAudit(audit);
		entity.setDeleted(false);
		reportConfigurationRepository.save(entity);
	}

	private void addClient(ReportConfiguration entity, long clientId) {
		if (clientId > 0) {
			Client client = clientRepository.findOne(clientId);
			entity.setClient(client);
		}
	}

	private void addNetwork(ReportConfiguration entity, long networkId) {
		if (networkId > 0) {
			Network network = networkRepository.findOne(networkId);
			entity.setNetwork(network);
		}
	}

	private void addProperty(ReportConfiguration entity, long propertyId) {
		if (propertyId > 0) {
			Property property = propertyRepository.findOne(propertyId);
			entity.setProperty(property);
		}
	}

	private void addBand(ReportConfiguration entity, long bandId) {
		if (bandId > 0) {
			Band band = bandRepository.findOne(bandId);
			entity.setBand(band);
		}
	}

	private void addSupplyPoint(ReportConfiguration entity, long supplyId) {
		if (supplyId > 0) {
			SupplyPoint supply = supplyPointRepository.findOne(supplyId);
			entity.setSupply(supply);
		}
	}

	private void addReportType(ReportConfiguration entity, long reportTypeId) {
		if (reportTypeId > 0) {
			ReportType type = reportTypeRepository.findOne(reportTypeId);
			entity.setType(type);
		}
	}

	public ReportMetadataDto downloadReport(long reportId) throws IOException {
		ReportHistory history = this.reportHistoryRepository.findOne(reportId);
		File file = new File(history.getLocation());
		ReportMetadataDto report = new ReportMetadataDto();
		report.setData(Files.readAllBytes(file.toPath()));
		report.setReportName(history.getConfiguration().getReportName());
		return report;
	}

	public void runReport(ReportHistoryDto input, String username) throws InvalidFormatException {
		ReportHistory reportHistory = new ReportHistory();
		reportHistory.setFromDate(input.getFromDate());
		reportHistory.setToDate(input.getToDate());
		reportHistory.setStatus("PENDING");
		Audit audit = new Audit();
		Calendar cal = Calendar.getInstance();
		audit.setCreatedUser(username);
		java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
		audit.setCreatedDate(date);
		reportHistory.setAudit(audit);
		ReportConfiguration config = null;
		if (input.getConfiguration() != null && input.getConfiguration().getId() > 0) {
			config = reportConfigurationRepository.findOne(input.getConfiguration().getId());
			reportHistory.setConfiguration(config);
		} else
			throw new InvalidFormatException("Report configuration is mandatory");
		reportHistoryRepository.save(reportHistory);
	}

	public void updateSchedule(ScheduleDto dto, long reportConfigId, String username) throws InvalidAttributesException {
		ReportConfiguration configuration = reportConfigurationRepository.findOne(reportConfigId);
		boolean isNew = false;
		if(configuration == null)
			throw  new InvalidAttributesException("Invalid report configuration");		
		Schedule schedule = null;
		if(configuration.getSchedule() != null) {
			schedule = configuration.getSchedule();
		}else {
			schedule = new Schedule();
			isNew = true;
		}
		schedule.setEmailIds(dto.getEmailIds());
		schedule.setOffset(dto.getOffset());
		schedule.setPeriod(dto.getPeriod());
		schedule.setRecursionType(dto.getRecursionType());
		schedule.setRecursionOffset(dto.getRecursionOffset());
		schedule.setHour(dto.getHour());
		schedule.setMinute(dto.getMinute());
		Audit audit = new Audit();
		Calendar cal = Calendar.getInstance();
		audit.setCreatedUser(username);
		java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
		audit.setCreatedDate(date);
		schedule.setAudit(audit);
		if(isNew)
			schedule = scheduleRepository.save(schedule);
		configuration.setSchedule(schedule);
		configuration.getAudit().setUpdatedDate(date);
		configuration.getAudit().setUpdatedUser(username);
		reportConfigurationRepository.save(configuration);
	}
	
	public void deleteConfig(long id, String username) {
		ReportConfiguration configuration = reportConfigurationRepository.findOne(id);
		UserDetails userDetails = userDetailsRepository.findByUsername(username);
		if(userDetails != null && userDetails.getRole() != null && userDetails.getRole().getRoleId() == 1) {
			if(configuration != null) {
				configuration.setDeleted(true);
			}
		}
		reportConfigurationRepository.save(configuration);
	}
}