package com.monarch.mabdeck.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.NotesDto;
import com.monarch.mabdeck.service.NotesService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;

@RestController
public class NotesController {
	private Logger logger = LoggerFactory.getLogger(NotesController.class);

	@Autowired
	private NotesService notesService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.NOTES_ATTACHMENT, method = RequestMethod.GET, produces = "text/plain; charset=utf-8")
	@ResponseBody
	public HttpEntity<byte[]> getAttachmentForNote(@RequestParam("note_id") Long noteId)
			throws IOException, InterruptedException {
		logger.info("NotesController: getAttachmentForNote - Start");
		byte[] attachment = notesService.getAttachmentForNote(noteId);
		logger.info("NotesController: getAttachmentForNote - End of Service Call");
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "file.txt");
		header.setContentLength(attachment.length);
		return new HttpEntity<byte[]>(attachment, header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NOTES, method = RequestMethod.POST, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void addNote(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody NotesDto note) {
		logger.info("NotesController: addNote - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("NotesController: addNote - Service Call");
		notesService.createNote(note, username);
		logger.info("NotesController: addNote - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NOTES, method = RequestMethod.PUT)
	public void updatePinStatus(@RequestParam("pin") boolean pin, @RequestParam("note_id") Long noteId) {
		logger.info("NotesController: updatePinStatus - Start");
		notesService.updateNotePinStatus(pin, noteId);
		logger.info("NotesController: updatePinStatus - end");
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NOTES, method = RequestMethod.GET)
	public @ResponseBody List<NotesDto> getAllNotesForAccount(@RequestParam("account_id")long accountId) {
		logger.info("NotesController: updatePinStatus - Start");
		return notesService.getAllNotesForAccount(accountId);
	}
}