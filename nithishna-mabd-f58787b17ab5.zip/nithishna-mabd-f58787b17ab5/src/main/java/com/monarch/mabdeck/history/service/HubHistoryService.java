package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Hub;
import com.monarch.mabdeck.entity.HubHistory;
import com.monarch.mabdeck.repository.HubHistoryRepository;

@Component
public class HubHistoryService {

	@Resource
	private HubHistoryRepository historyRepository;

	public void updateHubHistory(Hub hub, String username) {
		if (hub != null) {
			HubHistory history = new HubHistory();
			history.setAudit(hub.getAudit());
			history.setClientId(hub.getClient()!= null? hub.getClient().getClientId(): null);
			history.setEndDate(hub.getEndDate());
			history.setHubId(hub.getHubId());
			history.setHubManufacturer(hub.getHubManufacturer());
			history.setHubModel(hub.getHubModel());
			history.setIdentifier(hub.getIdentifier());
			history.setNetworkId(hub.getNetwork()!=null? hub.getNetwork().getNetworkId(): null);
			history.setPropertyId(hub.getProperty()!=null? hub.getProperty().getPropertyId(): null);
			history.setSerialNumber(hub.getSerialNumber());
			history.setStartDate(hub.getStartDate());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
