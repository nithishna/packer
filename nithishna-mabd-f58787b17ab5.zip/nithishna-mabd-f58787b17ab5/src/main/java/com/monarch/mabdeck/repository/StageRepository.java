package com.monarch.mabdeck.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.monarch.mabdeck.entity.Stage;

public interface StageRepository extends JpaRepository<Stage, Long>{

}
