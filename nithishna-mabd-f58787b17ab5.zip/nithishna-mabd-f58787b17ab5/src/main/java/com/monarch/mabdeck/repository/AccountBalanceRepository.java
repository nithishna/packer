package com.monarch.mabdeck.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.AccountBalance;

@Repository
public interface AccountBalanceRepository extends JpaRepository<AccountBalance, Long>{

	@Query(value = "select * from account_balance where account_id=?1", nativeQuery = true)
	AccountBalance findByAccountId(long accountId);
}