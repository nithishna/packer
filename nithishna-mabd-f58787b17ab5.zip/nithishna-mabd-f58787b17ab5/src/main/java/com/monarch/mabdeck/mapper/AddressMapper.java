package com.monarch.mabdeck.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.monarch.mabdeck.entity.Address;
import com.monarch.mabdeck.dto.AddressDto;

@Mapper
public abstract class AddressMapper implements IBaseMapper<AddressDto, Address>{

	public static final AddressMapper INSTANCE = Mappers.getMapper(AddressMapper.class);
}
