package com.monarch.mabdeck.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.BillablePerson;

@Repository
public interface BillablePersonRepository extends JpaRepository<BillablePerson, Long>{

	@Query(value="select top 1* from billable_person where account_id=?1", nativeQuery = true)
	BillablePerson getBillablePersonForAccountId(Long accountId);
}