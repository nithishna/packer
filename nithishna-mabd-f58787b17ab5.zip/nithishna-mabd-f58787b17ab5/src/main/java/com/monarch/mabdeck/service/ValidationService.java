package com.monarch.mabdeck.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.ClientDto;
import com.monarch.mabdeck.dto.NegativeConsumptionValidationDto;
import com.monarch.mabdeck.dto.NegativeConsumptionValidationError;
import com.monarch.mabdeck.dto.NegativeReadingValidationError;
import com.monarch.mabdeck.dto.NetworkDto;
import com.monarch.mabdeck.dto.TempDifferenceError;
import com.monarch.mabdeck.dto.TempDifferenceValidationDto;
import com.monarch.mabdeck.dto.ValidationDto;
import com.monarch.mabdeck.dto.ZeroConsumptionValidationDto;
import com.monarch.mabdeck.dto.ZeroReadingValidationError;
import com.monarch.mabdeck.entity.MeterReading;
import com.monarch.mabdeck.entity.NegativeConsumptionHistory;
import com.monarch.mabdeck.entity.NegativeConsumptionValidation;
import com.monarch.mabdeck.entity.NegativeReadingHistory;
import com.monarch.mabdeck.entity.TempDifferenceValidation;
import com.monarch.mabdeck.entity.TemperatureDifferenceHistory;
import com.monarch.mabdeck.entity.Validation;
import com.monarch.mabdeck.entity.ZeroConsumptionHistory;
import com.monarch.mabdeck.entity.ZeroConsumptionValidation;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.MeterReadingRepository;
import com.monarch.mabdeck.repository.NegativeConsumptionHistoryRepository;
import com.monarch.mabdeck.repository.NegativeConsumptionValidationRepository;
import com.monarch.mabdeck.repository.NegativeReadingHistoryRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.repository.TempDifferenceValidationRepository;
import com.monarch.mabdeck.repository.TemperatureDifferenceHistoryRepository;
import com.monarch.mabdeck.repository.ValidationRepository;
import com.monarch.mabdeck.repository.ZeroConsumptionHistoryRepository;
import com.monarch.mabdeck.repository.ZeroConsumptionValidationRepository;

@Component
public class ValidationService {

	@Resource
	private ZeroConsumptionValidationRepository zeroConsumptionRepo;

	@Resource
	private NegativeConsumptionValidationRepository negativeConsumptionRepo;

	@Resource
	private TempDifferenceValidationRepository temDiffValidationRepo;

	@Resource
	private ValidationRepository validationRepo;

	@Resource
	private ClientRepository clientRepo;

	@Resource
	private NetworkRepository networkRepo;

	@Resource
	private NegativeConsumptionHistoryRepository negativeConsumptionHistoryRepo;

	@Resource
	private NegativeReadingHistoryRepository negativeReadingHistoryRepo;

	@Resource
	private TemperatureDifferenceHistoryRepository temperatureDifferenceHistoryRepo;

	@Resource
	private ZeroConsumptionHistoryRepository zeroConsumptionHistoryRepo;

	@Resource
	private MeterReadingRepository meterReadingRepo;

	public NegativeConsumptionValidationDto createOrUpdateNegativeValidation(NegativeConsumptionValidationDto dto)
			throws InvalidFormatException {
		if (dto == null)
			throw new InvalidFormatException("Invalid data");
		ValidationDto validationDto = dto.getValidation();
		NegativeConsumptionValidation entity = new NegativeConsumptionValidation();
		if (dto.getValidationId() > 0) {
			entity = this.negativeConsumptionRepo.findOne(dto.getValidationId());
		}
		entity.setEnabled(dto.isEnabled());
		entity.setSupplyId(dto.getSupplyId());
		entity.setTolerance(dto.getTolerance());
		entity = this.negativeConsumptionRepo.save(entity);
		dto.setValidationId(entity.getValidationId());
		Validation validation = this.getValidation(validationDto);
		if (validation.getNegativeValidation() != null) {
			validation.getNegativeValidation().add(entity);
		} else {
			List<NegativeConsumptionValidation> entities = new ArrayList<>();
			entities.add(entity);
			validation.setNegativeValidation(entities);
		}
		validation = this.validationRepo.save(validation);
		validationDto.setValidId(validation.getValidId());
		dto.setValidation(validationDto);
		return dto;
	}

	public ZeroConsumptionValidationDto createOrUpdateZeroConsumptionValidation(ZeroConsumptionValidationDto dto)
			throws InvalidFormatException {
		if (dto == null)
			throw new InvalidFormatException("Invalid data");
		ValidationDto validationDto = dto.getValidation();
		ZeroConsumptionValidation entity = new ZeroConsumptionValidation();
		if (dto.getValidationId() > 0) {
			entity = this.zeroConsumptionRepo.findOne(dto.getValidationId());
		}
		entity.setEnabled(dto.isEnabled());
		entity.setTolerance(dto.getTolerance());
		entity = this.zeroConsumptionRepo.save(entity);
		dto.setValidationId(entity.getValidationId());
		Validation validation = this.getValidation(validationDto);
		validation.setZeroConsumptionValidation(entity);
		validation = this.validationRepo.save(validation);
		validationDto.setValidId(validation.getValidId());
		dto.setValidation(validationDto);
		return dto;
	}

	public TempDifferenceValidationDto createOrUpdateTempDifferenceValidation(TempDifferenceValidationDto dto)
			throws InvalidFormatException {
		if (dto == null)
			throw new InvalidFormatException("Invalid data");
		ValidationDto validationDto = dto.getValidation();
		TempDifferenceValidation entity = new TempDifferenceValidation();
		if (dto.getValidationId() > 0) {
			entity = this.temDiffValidationRepo.findOne(dto.getValidationId());
		}
		entity.setEnabled(dto.isEnabled());
		entity.setTolerance(dto.getTolerance());
		entity = this.temDiffValidationRepo.save(entity);
		dto.setValidationId(entity.getValidationId());
		Validation validation = this.getValidation(validationDto);
		validation.setTempValidation(entity);
		validation = this.validationRepo.save(validation);
		validationDto.setValidId(validation.getValidId());
		dto.setValidation(validationDto);
		return dto;
	}

	public ValidationDto createNotification(ValidationDto dto) throws InvalidFormatException {
		Validation entity = this.getValidation(dto);
		entity.setEmailNotification(dto.getEmailNotification());
		entity = this.validationRepo.save(entity);
		dto.setValidId(entity.getValidId());
		return dto;
	}

	public ValidationDto getValidationByClientAndNetwork(long clientId, long networkId) {
		Validation entity = this.validationRepo.findByClientClientIdAndNetworkNetworkId(clientId, networkId);
		if(entity == null)
			return null;
		ValidationDto dto = new ValidationDto();
		ClientDto client = new ClientDto();
		NetworkDto network = new NetworkDto();
		client.setClientId(entity.getClient().getClientId());
		client.setClientName(entity.getClient().getClientName());
		network.setNetwork(entity.getNetwork().getNetwork());
		network.setNetworkId(entity.getNetwork().getNetworkId());
		dto.setClient(client);
		dto.setNetwork(network);
		dto.setEmailNotification(entity.getEmailNotification());
		dto.setValidId(entity.getValidId());
		dto.setTempValidation(convertTempDifferenceValidationFromEntityToDto(entity.getTempValidation()));
		dto.setZeroConsumptionValidation(
				convertZeroConsumptionValidationFromEntityToDto(entity.getZeroConsumptionValidation()));
		List<NegativeConsumptionValidation> values = negativeConsumptionRepo.findByValidationId(entity.getValidId());
		dto.setNegativeValidation(convertNegativeConsumptionValidationFromEntityToDto(values));
		return dto;
	}

	public void approveOrRejectBulk(List<Long> errors, boolean flag, int type) throws InvalidFormatException {
		for(long error: errors) {
			this.approveOrReject(error, flag, type);
		}
	}	
	
	public void approveOrReject(long validationId, boolean flag, int type) throws InvalidFormatException {
		long meterReadingId = 0;
		if (type==1) {
			NegativeConsumptionHistory history = this.negativeConsumptionHistoryRepo.findOne(validationId);
			meterReadingId = history.getMeterReadingId();
			history.setDeleted(true);
			this.negativeConsumptionHistoryRepo.save(history);
		} else if (type==2) {
			NegativeReadingHistory history = this.negativeReadingHistoryRepo.findOne(validationId);
			meterReadingId = history.getMeterReadingId();
			history.setDeleted(true);
			this.negativeReadingHistoryRepo.save(history);
		} else if (type==3) {
			TemperatureDifferenceHistory history = this.temperatureDifferenceHistoryRepo
					.findOne(validationId);
			meterReadingId = history.getMeterReadingId();
			history.setDeleted(true);
			this.temperatureDifferenceHistoryRepo.save(history);
		} else if (type==4) {
			ZeroConsumptionHistory history = this.zeroConsumptionHistoryRepo.findOne(validationId);
			meterReadingId = history.getMeterReadingId();
			history.setDeleted(true);
			this.zeroConsumptionHistoryRepo.save(history);
		}else
		{
			throw new InvalidFormatException("Invalid type");
		}
		MeterReading reading = this.meterReadingRepo.findOne(meterReadingId);
		if (flag) {
			reading.setApproved(true);
			reading.setRejected(false);		
		} else {
			reading.setApproved(false);
			reading.setRejected(true);
		}
		this.meterReadingRepo.save(reading);
	}
	
	public long getTotalCountOfNegativeConsumptionHistory() {
		return this.negativeConsumptionHistoryRepo.getTotalCount();
	}
	
	public long getTotalCountOfNegativeReading() {
		return this.negativeReadingHistoryRepo.getTotalNegativeReading();
	}
	
	public long getTotalTemperatureDifferenceValidationErrors() {
		return this.temperatureDifferenceHistoryRepo.getTotalTemperatureDifferenceValidationErrors();
	}
	
	public long getTotalZeroConsumptionValidationErrors() {
		return this.zeroConsumptionHistoryRepo.getTotalZeroConsumptionValidationErrors();
	}
	
	public List<NegativeConsumptionValidationError> getAllNegativeConsumptionHistory(int index, int noOfItems){
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1)*noOfItems + 1;
		endIndex = index * noOfItems;
		List<NegativeConsumptionValidationError> dtos = new ArrayList<>();
		List<Object[]> historyList = this.negativeConsumptionHistoryRepo.findAllNegativeConsumptionHistory(startIndex, endIndex);
		for(Object[] history : historyList) {
			NegativeConsumptionValidationError dto = new NegativeConsumptionValidationError();
			dto.setValidationId(history[0] != null? Long.parseLong(history[0].toString()): 0);//nch.id, 
			dto.setClientName(history[1] !=null?history[1].toString(): null);//c.client_name, 
			dto.setNetworkName(history[2] != null?history[2].toString(): null);//n.network, 
			StringBuilder builder = new StringBuilder();
			for(int counter=3;counter<=8; counter++) {//p.address_line1, p.address_line2, p.address_line3,p.country, p.region, p.town, p.post_code, 
				if(history[counter] != null)
					builder.append(history[counter].toString()).append(" ");
			}
			builder.append(history[9] != null ?history[9].toString(): null);
			dto.setPropertyName(builder.toString());
			dto.setMeterSerialNumber(history[10] != null? history[10].toString(): null);//m.serial_number, 
			dto.setSupplyType(history[11] != null? history[11].toString(): null);//s.supply_type, 
			dto.setValidationType(history[12] != null? history[12].toString(): null);//nch.validation_type, 
			dto.setFailedReading(history[13] != null? new BigDecimal(history[13].toString()): null);//nch.failed_reading, 
			dto.setFailedReadingDate(history[14] != null? history[14].toString(): null);//nch.failed_reading_date
			dtos.add(dto);
		}
		return dtos;
	}
	
	public List<NegativeReadingValidationError> getAllNegativeReading(int index, int noOfItems){
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1)*noOfItems + 1;
		endIndex = index * noOfItems;
		List<NegativeReadingValidationError> dtos = new ArrayList<>();
		List<Object[]> historyList = this.negativeReadingHistoryRepo.getAllNegativeReadingHistory(startIndex, endIndex);
		for(Object[] history: historyList) {
			NegativeReadingValidationError dto = new NegativeReadingValidationError();
			dto.setValidationId(history[0] != null? Long.parseLong(history[0].toString()): 0);
			dto.setClientName(history[1] !=null?history[1].toString(): null);
			dto.setNetworkName(history[2] != null?history[2].toString(): null);
			StringBuilder builder = new StringBuilder();
			for(int counter=3;counter<=8; counter++) {
				if(history[counter] != null)
					builder.append(history[counter].toString()).append(" ");
			}
			builder.append(history[9] != null ?history[9].toString(): null);
			dto.setPropertyName(builder.toString());
			dto.setMeterSerialNumber(history[10] != null? history[10].toString(): null);
			dto.setSupplyType(history[11] != null? history[11].toString(): null);
			dto.setValidationType(history[12] != null? history[12].toString(): null);
			dto.setReading(history[13] != null? new BigDecimal(history[13].toString()): null);
			dto.setFlaggedDate(history[14] != null? history[14].toString(): null);
			dtos.add(dto);
		}
		return dtos;
	}
	
	public List<TempDifferenceError> getAllTemperatureDifferenceValidationErrors(int index, int noOfItems) {
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1)*noOfItems + 1;
		endIndex = index * noOfItems;
		List<TempDifferenceError> dtos = new ArrayList<>();
		List<Object[]> historyList = this.temperatureDifferenceHistoryRepo.getAllTemperatureDifferenceValidationErrors(startIndex, endIndex);
		for(Object[] history: historyList) {
			TempDifferenceError dto = new TempDifferenceError();
			dto.setValidationId(history[0] != null? Long.parseLong(history[0].toString()): null);
			dto.setClientName(history[1] !=null?history[1].toString(): null);
			dto.setNetworkName(history[2] != null?history[2].toString(): null);
			StringBuilder builder = new StringBuilder();
			for(int counter=3;counter<=7; counter++) {
				if(history[counter] != null)
					builder.append(history[counter].toString()).append(" ");
			}
			builder.append(history[9] != null ?history[9].toString(): null);
			dto.setPropertyName(builder.toString());
			dto.setMeterSerialNumber(history[10] != null? history[10].toString(): null);
			dto.setSupplyType(history[11] != null? history[11].toString(): null);
			dto.setValidationType(history[12] != null? history[12].toString(): null);
			dto.setFlowTemperature(history[13] != null? new BigDecimal(history[13].toString()): null);
			dto.setReturnTemperature(history[14] != null? new BigDecimal(history[14].toString()): null);
			dto.setReadingDate(history[15] != null? history[15].toString(): null);
			dtos.add(dto);
		}
		return dtos;
	}

	public List<ZeroReadingValidationError> getAllZeroReadingValidationErrors(int index, int noOfItems){
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1)*noOfItems + 1;
		endIndex = index * noOfItems;
		List<ZeroReadingValidationError> dtos = new ArrayList<>();
		List<Object[]> historyList = this.zeroConsumptionHistoryRepo.getAllZeroConsumptionValidationErrors(startIndex, endIndex);
		for(Object[] history : historyList) {
			ZeroReadingValidationError dto = new ZeroReadingValidationError();
			dto.setValidationId(history[0] != null? Long.parseLong(history[0].toString()): null); 
			dto.setClientName(history[1] !=null?history[1].toString(): null);
			dto.setNetworkName(history[2] != null?history[2].toString(): null);
			StringBuilder builder = new StringBuilder();
			for(int counter=3;counter<=8; counter++) {
				if(history[counter] != null)
					builder.append(history[counter].toString()).append(" ");
			}
			builder.append(history[9] != null ?history[9].toString(): null);
			dto.setPropertyName(builder.toString());
			dto.setMeterSerialNumber(history[10] != null? history[10].toString(): null);
			dto.setSupplyType(history[11] != null? history[11].toString(): null);
			dto.setValidationType(history[12] != null? history[12].toString(): null);
			dto.setReading(history[13] != null? new BigDecimal(history[13].toString()): null);
			dto.setFlaggedDate(history[14] != null? history[14].toString(): null);
			dtos.add(dto);
		}
		return dtos;
	}
	
	private Validation getValidation(ValidationDto dto) throws InvalidFormatException {
		Validation validation = new Validation();
		if (dto == null)
			throw new InvalidFormatException("Invalid data");
		if (dto.getValidId() > 0) {
			validation = validationRepo.findOne(dto.getValidId());
		} else {
			if (dto.getClient() != null && dto.getClient().getClientId() > 0) {
				validation.setClient(clientRepo.findOne(dto.getClient().getClientId()));
			} else {
				throw new InvalidFormatException("Client detail is mandatory");
			}

			if (dto.getNetwork() != null && dto.getNetwork().getNetworkId() > 0) {
				validation.setNetwork(networkRepo.findOne(dto.getNetwork().getNetworkId()));
			} else {
				throw new InvalidFormatException("Network detail is mandatory");
			}
		}
		return validation;
	}

	private TempDifferenceValidationDto convertTempDifferenceValidationFromEntityToDto(
			TempDifferenceValidation entity) {
		TempDifferenceValidationDto dto = null;
		if (entity != null) {
			dto = new TempDifferenceValidationDto();
			dto.setEnabled(entity.isEnabled());
			dto.setTolerance(entity.getTolerance());
			dto.setValidationId(entity.getValidationId());
		}
		return dto;
	}

	private ZeroConsumptionValidationDto convertZeroConsumptionValidationFromEntityToDto(
			ZeroConsumptionValidation entity) {
		ZeroConsumptionValidationDto dto = null;
		if (entity != null) {
			dto = new ZeroConsumptionValidationDto();
			dto.setEnabled(entity.isEnabled());
			dto.setTolerance(entity.getTolerance());
			dto.setValidationId(entity.getValidationId());
		}
		return dto;
	}

	private List<NegativeConsumptionValidationDto> convertNegativeConsumptionValidationFromEntityToDto(
			List<NegativeConsumptionValidation> entities) {
		List<NegativeConsumptionValidationDto> dtos = null;
		if (entities != null && entities.size() > 0) {
			dtos = new ArrayList<>();
			for (NegativeConsumptionValidation entity : entities) {
				NegativeConsumptionValidationDto dto = new NegativeConsumptionValidationDto();
				dto.setEnabled(entity.isEnabled());
				dto.setSupplyId(entity.getSupplyId());
				dto.setTolerance(entity.getTolerance());
				dto.setValidationId(entity.getValidationId());
				dtos.add(dto);
			}
		}
		return dtos;
	}
}
