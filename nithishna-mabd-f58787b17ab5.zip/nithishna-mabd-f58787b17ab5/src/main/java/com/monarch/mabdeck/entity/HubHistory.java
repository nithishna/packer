package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class HubHistory implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long hubId;
	
	private String hubManufacturer;
	private String hubModel;
	private String serialNumber;
	private String identifier;
	private Long clientId;
	private Long networkId;
	private Long propertyId;
	private Date startDate;
	private Date endDate;
	
	@Embedded
	private Audit audit;

	public Long getHubId() {
		return hubId;
	}

	public String getHubManufacturer() {
		return hubManufacturer;
	}

	public String getHubModel() {
		return hubModel;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public String getIdentifier() {
		return identifier;
	}

	public Long getClientId() {
		return clientId;
	}

	public Long getNetworkId() {
		return networkId;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public Audit getAudit() {
		return audit;
	}

	public void setHubId(Long hubId) {
		this.hubId = hubId;
	}

	public void setHubManufacturer(String hubManufacturer) {
		this.hubManufacturer = hubManufacturer;
	}

	public void setHubModel(String hubModel) {
		this.hubModel = hubModel;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}
}
