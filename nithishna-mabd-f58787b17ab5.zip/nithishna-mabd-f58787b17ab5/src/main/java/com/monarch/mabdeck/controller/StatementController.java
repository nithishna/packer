package com.monarch.mabdeck.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.DocumentException;
import com.monarch.mabdeck.dto.PreStatementDto;
import com.monarch.mabdeck.dto.StatementDto;
import com.monarch.mabdeck.dto.StatementGenerationInput;
import com.monarch.mabdeck.dto.StatementQueueDto;
import com.monarch.mabdeck.service.StatementService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;

@RestController
public class StatementController {

	private Logger logger = LoggerFactory.getLogger(StatementController.class);
	
	@Autowired
	public StatementService service;
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.GENERATE_STATEMENT, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void generateStatement(@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization, @RequestParam("id") long queueId) throws MalformedURLException, DocumentException, IOException {
		logger.info("StatementController: generateStatement: start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		service.generatePdf(queueId, username);	
		logger.info("StatementController: generateStatement: end");
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.STATEMENT, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<StatementDto> getAllStatements(){
		logger.info("StatementController: getAllStatements: start");
		return service.getAllStatements();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.GENERATE_PRE_STATEMENT, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public String generatePreStatement(@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody StatementGenerationInput input) throws Exception {
		logger.info("StatementController: generatePreStatement: start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		return service.generatePreStatement(input, username);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.GENERATE_PRE_STATEMENT_QUEUE, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public String generatePreStatementQueue(@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody StatementGenerationInput input) throws Exception {
		logger.info("StatementController: generatePreStatementQueue: start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		return service.generatePreStatementQueue(input, username);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FETCH_PRE_STATEMENT_LIST, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<StatementQueueDto> fetchStatementQueueDetails(){
		logger.info("StatementController: fetchStatementQueueDetails - Start");
		return service.fetchStatementQueueDetails();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FETCH_PRE_STATEMENT_LIST, method = RequestMethod.POST, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void deletePreStatementQueueById(@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization, @RequestParam("id")long id) {
		logger.info("StatementController: deletePreStatementQueueById - start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		service.deleteFromQueue(id, username);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.PRE_STATEMENT, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<PreStatementDto> fetchPreStatementsGeneratedForQueueByID(@RequestParam("queueId") long queueId){
		logger.info("StatementController: fetchPreStatementsGeneratedForQueueByID - start");
		return service.fetchPreStatementsGeneratedForQueueByID(queueId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FETCH_PRE_STATEMENT_LIST, method = RequestMethod.PUT, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void updatePreStatementQueueById(@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization, @RequestParam("id")long id) {
		logger.info("StatementController: deletePreStatementQueueById - start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		service.updateStatus(id, username);
	}
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.STATEMENT_APPROVAL, method = RequestMethod.PUT, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })	
	public void updateApprovalState(@RequestParam("statement_id")long statementId, @RequestParam("state") byte state) {
		logger.info("StatementController: updateApprovalState - start");
		if(state==0)
			this.service.approveStatement(statementId);
		else
			this.service.unapproveStatement(statementId);
		logger.info("StatementController: updateApprovalState - end");
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.DOWNLOAD_STATEMENT, method = RequestMethod.GET, produces = "application/pdf")
	@ResponseBody
	public HttpEntity<byte[]> getReport(@RequestParam("statement_id") long id)
			throws IOException, InterruptedException {
		logger.info("StatementController: getReport - Start");
		byte[] pdfFile = service.downloadPdf(id);
		byte[] encodedBytes = java.util.Base64.getEncoder().encode(pdfFile);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "Statement_"+id+".pdf");
		header.setContentLength(encodedBytes.length);
		logger.info("StatementController: getReport - End");
		return new HttpEntity<byte[]>(encodedBytes, header);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.APPROVED_STATEMENTS, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<StatementDto> getAllApprovedStatements(){
		logger.info("StatementController: getAllApprovedStatements: start");
		return service.getAllApprovedStatements();
	}
}
