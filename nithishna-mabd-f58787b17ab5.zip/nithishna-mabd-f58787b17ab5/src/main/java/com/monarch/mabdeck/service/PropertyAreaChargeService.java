package com.monarch.mabdeck.service;

import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.PropertyAreaChargeDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.PropertyAreaCharge;
import com.monarch.mabdeck.entity.Tariff;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.PropertyAreaChargeMapper;
import com.monarch.mabdeck.repository.PropertyAreaChargeRepository;
import com.monarch.mabdeck.repository.TariffRepository;

@Component
public class PropertyAreaChargeService extends CommonServiceImpl<PropertyAreaChargeDto, PropertyAreaCharge>{
	
	private Logger logger = LoggerFactory.getLogger(NetworkService.class);
	
	@Resource
	private PropertyAreaChargeRepository repository;
	
	@Resource
	private TariffRepository tariffRepository;
	
	@Override
	public JpaRepository<PropertyAreaCharge, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<PropertyAreaChargeDto, PropertyAreaCharge> getMapper() {
		return PropertyAreaChargeMapper.INSTANCE;
	}
	
	@Override
	public void updateAudit(PropertyAreaCharge entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
			}else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
	
	public PropertyAreaChargeDto create(PropertyAreaChargeDto dto, String username) {
		PropertyAreaCharge entity = getMapper().convertToEntity(dto);
		updateAudit(entity, username);
		Tariff tariff = null;
		if(dto.getTariff() != null) {
			tariff = tariffRepository.findOne(dto.getTariff().getTariffId());
		}
		tariff.setPropertyAreaCharge(entity);
		entity.setTariff(tariff);
		repository.save(entity);
		return dto;
	}

}
