package com.monarch.mabdeck.dto;

public class DirectDebitConfigDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private long clientId;
	private String clientName;
	private long networkId;
	private String networkName;
	private long claimOffset;
	private int billingFrequency;
	private String permissiblePaymentDays;
	private int permissibleDirectDebitOptions;
	private boolean transactionsForDirectDebit;
	private boolean directDebitLetter;
	private boolean auddisFile;
	private boolean collectionFile;
	private String emailForLetter;
	private String phoneForLetter;
	public long getId() {
		return id;
	}
	public long getClientId() {
		return clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public long getNetworkId() {
		return networkId;
	}
	public String getNetworkName() {
		return networkName;
	}
	public long getClaimOffset() {
		return claimOffset;
	}
	public int getBillingFrequency() {
		return billingFrequency;
	}
	public String getPermissiblePaymentDays() {
		return permissiblePaymentDays;
	}
	public int getPermissibleDirectDebitOptions() {
		return permissibleDirectDebitOptions;
	}
	public boolean isTransactionsForDirectDebit() {
		return transactionsForDirectDebit;
	}
	public boolean isDirectDebitLetter() {
		return directDebitLetter;
	}
	public boolean isAuddisFile() {
		return auddisFile;
	}
	public boolean isCollectionFile() {
		return collectionFile;
	}
	public String getEmailForLetter() {
		return emailForLetter;
	}
	public String getPhoneForLetter() {
		return phoneForLetter;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setClientId(long clientId) {
		this.clientId = clientId;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}
	public void setClaimOffset(long claimOffset) {
		this.claimOffset = claimOffset;
	}
	public void setBillingFrequency(int billingFrequency) {
		this.billingFrequency = billingFrequency;
	}
	public void setPermissiblePaymentDays(String permissiblePaymentDays) {
		this.permissiblePaymentDays = permissiblePaymentDays;
	}
	public void setPermissibleDirectDebitOptions(int permissibleDirectDebitOptions) {
		this.permissibleDirectDebitOptions = permissibleDirectDebitOptions;
	}
	public void setTransactionsForDirectDebit(boolean transactionsForDirectDebit) {
		this.transactionsForDirectDebit = transactionsForDirectDebit;
	}
	public void setDirectDebitLetter(boolean directDebitLetter) {
		this.directDebitLetter = directDebitLetter;
	}
	public void setAuddisFile(boolean auddisFile) {
		this.auddisFile = auddisFile;
	}
	public void setCollectionFile(boolean collectionFile) {
		this.collectionFile = collectionFile;
	}
	public void setEmailForLetter(String emailForLetter) {
		this.emailForLetter = emailForLetter;
	}
	public void setPhoneForLetter(String phoneForLetter) {
		this.phoneForLetter = phoneForLetter;
	}
	
}
