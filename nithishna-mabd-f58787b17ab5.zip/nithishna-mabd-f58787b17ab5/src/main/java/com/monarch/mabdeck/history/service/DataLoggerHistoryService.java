package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.DataLogger;
import com.monarch.mabdeck.entity.DataLoggerHistory;
import com.monarch.mabdeck.repository.DataLoggerHistoryRepository;

@Component
public class DataLoggerHistoryService {

	@Resource
	private DataLoggerHistoryRepository historyRepository;
	
	public void updateDataLoggerHistory(DataLogger dataLogger, String username) {
		if(dataLogger != null ) {
			DataLoggerHistory history = new DataLoggerHistory();
			history.setAudit(dataLogger.getAudit());
			history.setClientId(dataLogger.getClient() != null? dataLogger.getClient().getClientId() : null);
			history.setCommunicationType(dataLogger.getCommunicationType());
			history.setEndDate(dataLogger.getEndDate());
			history.setId(dataLogger.getId());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
