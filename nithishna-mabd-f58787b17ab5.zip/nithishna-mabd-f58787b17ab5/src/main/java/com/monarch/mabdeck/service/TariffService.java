package com.monarch.mabdeck.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.PropertyAreaChargeDto;
import com.monarch.mabdeck.dto.StandingChargeDto;
import com.monarch.mabdeck.dto.TariffDto;
import com.monarch.mabdeck.dto.UnitChargeDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Band;
import com.monarch.mabdeck.entity.PropertyAreaCharge;
import com.monarch.mabdeck.entity.StandingCharge;
import com.monarch.mabdeck.entity.Tariff;
import com.monarch.mabdeck.entity.UnitCharge;
import com.monarch.mabdeck.history.service.TariffHistoryService;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.PropertyAreaChargeMapper;
import com.monarch.mabdeck.mapper.StandingChargeMapper;
import com.monarch.mabdeck.mapper.TariffMapper;
import com.monarch.mabdeck.mapper.UnitChargeMapper;
import com.monarch.mabdeck.repository.BandRepository;
import com.monarch.mabdeck.repository.TariffRepository;
import com.monarch.mabdeck.util.Constants;

import javassist.NotFoundException;

@Component
public class TariffService extends CommonServiceImpl<TariffDto, Tariff>{
	
	private Logger logger = LoggerFactory.getLogger(TariffService.class);
	
	@Resource
	private TariffRepository repository;
	
	@Resource
	private BandRepository bandRepository;
	
	@Autowired
	private TariffHistoryService historyService;

	@Override
	public JpaRepository<Tariff, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<TariffDto, Tariff> getMapper() {
		return TariffMapper.INSTANCE;
	}
	
	@Override
	public void updateAudit(Tariff entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			}else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
	
	@Override
	public TariffDto create(TariffDto dto, String username) {
		Tariff tariff = getMapper().convertToEntity(dto);
		tariff.setSupplyType(Constants.supplyTypeMap.get(dto.getSupplyType()));
		updateAudit(tariff, username);
		if(dto.getBand() != null) {
			Band band = bandRepository.getOne(dto.getBand().getBandId());
			tariff.setBand(band);
		}else 
			return null;
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String startDate = simpleDateFormat.format(dto.getActiveFromDate());
		if(dto.getActiveToDate() != null) {
			String endDate = simpleDateFormat.format(dto.getActiveToDate());
			List<Tariff> overlappingTariffs = repository.getOverLappingTariff(startDate, endDate, tariff.getSupplyType(), dto.getBand().getBandId());
			if(overlappingTariffs.size() > 0)
				return null;
		}else {
			List<Tariff> overlappingTariffs = repository.getOverLappingTariff(startDate, tariff.getSupplyType(), dto.getBand().getBandId());
			if(overlappingTariffs.size()>0)
				return null;
		}		
		repository.save(tariff);
		return dto;		
	}
	
	@Override
	public TariffDto read(Long id) throws NotFoundException {
		Tariff entity = repository.findOne(id);
		TariffDto dto = null;
		if(entity!= null) {
			dto = getMapper().convertToDTO(entity);
			dto.setSupplyType(Constants.supplyTypeMap.entrySet().stream().filter(e -> e.getValue().equals(entity.getSupplyType())).map(Map.Entry::getKey).findFirst().orElse(null));			
			dto.setUnitCharge(this.getUnitCharge(entity.getUnitCharge()));
			dto.setStandingCharge(this.getStandingCharge(entity.getStandingCharge()));
			PropertyAreaChargeDto propertyAreaChargeDto = this.getPropertyAreaCharge(entity.getPropertyAreaCharge());
			if(propertyAreaChargeDto != null) {
				List<PropertyAreaChargeDto> propertyAreaChargeDtoList = new ArrayList<>();
				propertyAreaChargeDtoList.add(propertyAreaChargeDto);
				dto.setPropertyAreaCharge(propertyAreaChargeDtoList);
			}
		}
		return dto;
	}
	
	public void deleteTariff(Long id, String username) throws NotFoundException{
		Tariff entity = repository.findOne(id);
		updateAudit(entity, username);
		historyService.updateTariffHistory(entity, username);
		
		if(entity != null) {
			entity.setDeleted(1);			
		}else {
			throw new NotFoundException("Tariff Not found");
		}
		
	}
	
	public TariffDto setTariffEndDate(TariffDto  dto, String username) {
		if(dto == null || dto.getTariffId() == null)
			return null;
		Tariff entity = repository.findOne(dto.getTariffId());
		updateAudit(entity, username);
		historyService.updateTariffHistory(entity, username);
		entity.setActiveToDate(dto.getActiveToDate());
		return dto;
	}
	
	public PropertyAreaChargeDto getPropertyAreaCharge (PropertyAreaCharge entity) {
		PropertyAreaChargeDto dto = null;
		if(entity != null) {
			dto = PropertyAreaChargeMapper.INSTANCE.convertToDTO(entity);
		}
		return dto;
	}
	
	public List<StandingChargeDto> getStandingCharge (List<StandingCharge> entity){
		List<StandingChargeDto> dtos = null;
		if(entity != null && entity.size() > 0) {
			dtos = StandingChargeMapper.INSTANCE.convertToDTOList(entity);
		}
		return dtos;
	}
	
	public List<UnitChargeDto> getUnitCharge(List<UnitCharge> entity) {
		List<UnitChargeDto> dtos = null;
		if(entity != null && entity.size() > 0)
			dtos = UnitChargeMapper.INSTANCE.convertToDTOList(entity);
		return dtos;
	}
}
