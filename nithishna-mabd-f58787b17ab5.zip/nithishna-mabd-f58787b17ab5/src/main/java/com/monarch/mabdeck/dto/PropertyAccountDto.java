package com.monarch.mabdeck.dto;

import java.util.Date;

public class PropertyAccountDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long associationId;
	private long propertyId;
	private long accountId;
	private String reference;
	private String area;
	private AddressDto propertyAddress;
	private AddressDto billingAddress;
	private String name; 
	private Date startDate;
	private Date endDate;
	private boolean deleted;
	private String moveInStatus;
	private String moveOutStatus;
	private boolean generateLetter;
	public long getPropertyId() {
		return propertyId;
	}
	public long getAccountId() {
		return accountId;
	}
	public String getReference() {
		return reference;
	}
	public String getArea() {
		return area;
	}
	public AddressDto getPropertyAddress() {
		return propertyAddress;
	}
	public AddressDto getBillingAddress() {
		return billingAddress;
	}
	public String getName() {
		return name;
	}
	public Date getStartDate() {
		return startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setPropertyId(long propertyId) {
		this.propertyId = propertyId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public void setPropertyAddress(AddressDto propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	public void setBillingAddress(AddressDto billingAddress) {
		this.billingAddress = billingAddress;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public String getMoveInStatus() {
		return moveInStatus;
	}
	public String getMoveOutStatus() {
		return moveOutStatus;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	public void setMoveInStatus(String moveInStatus) {
		this.moveInStatus = moveInStatus;
	}
	public void setMoveOutStatus(String moveOutStatus) {
		this.moveOutStatus = moveOutStatus;
	}
	public long getAssociationId() {
		return associationId;
	}
	public void setAssociationId(long associationId) {
		this.associationId = associationId;
	}
	public boolean isGenerateLetter() {
		return generateLetter;
	}
	public void setGenerateLetter(boolean generateLetter) {
		this.generateLetter = generateLetter;
	}
}
