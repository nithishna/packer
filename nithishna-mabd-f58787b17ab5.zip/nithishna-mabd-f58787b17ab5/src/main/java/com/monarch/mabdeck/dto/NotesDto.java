package com.monarch.mabdeck.dto;

import java.sql.Date;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class NotesDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long noteId;
	private Date modifiedDate;
	private String author;
	private String summary;	
	private boolean pin;
	
	@JsonDeserialize
	private String attachment;
	private String fileName;
	private Long accountId;
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public Long getNoteId() {
		return noteId;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public String getAuthor() {
		return author;
	}
	public String getSummary() {
		return summary;
	}
	public void setNoteId(Long noteId) {
		this.noteId = noteId;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getAttachment() {
		return attachment;
	}
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public boolean isPin() {
		return pin;
	}
	public void setPin(boolean pin) {
		this.pin = pin;
	}
}