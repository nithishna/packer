package com.monarch.mabdeck.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.HubDto;
import com.monarch.mabdeck.dto.HubTemplateDto;
import com.monarch.mabdeck.service.HubService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class HubController {

	private Logger logger = LoggerFactory.getLogger(HubController.class);

	@Autowired
	private HubService hubService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.HUB, method = RequestMethod.POST, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void createHub(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody HubDto Hub) {
		logger.info("HubController: createHub - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("HubController: createHub - Service Call, Username : " + username);
		hubService.create(Hub, username);
		logger.info("HubController: createHub - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.HUB, method = RequestMethod.PUT, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void updateHub(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody HubDto hub) {
		logger.info("HubController: updateHub - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("HubController: updateHub - Service call, Username : " + username);
		hubService.update(hub, username);
		logger.info("HubController: updateHub - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_HUB_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody HubDto getHubById(@PathVariable("hub_id") Long HubId) throws NotFoundException {
		logger.info("HubController: getHubById - Start");
		return hubService.read(HubId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.HUB, method = RequestMethod.GET, produces = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public List<HubDto> getAllHubs() throws NotFoundException {
		logger.info("HubController: getAllHubs - Start");
		return hubService.readAll();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.HUB_MODELS, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<String> getAllHubModelsForClientAndNetwork(@RequestParam("client_id") Long clientId,
			@RequestParam("network_id") Long networkId) {
		logger.info("HubController: getAllHubModelsForClientAndNetwork - Start");
		return hubService.getAllHubModelsForClientAndNetwork(clientId, networkId);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.HUB_TEMPLATE, method = RequestMethod.POST, produces = "application/octet-stream", consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	@ResponseBody
	public HttpEntity<byte[]> getReport(@RequestBody HubTemplateDto dto) throws IOException, InterruptedException {
		logger.info("HubController: getReport - Start");
		byte[] hubTemplate = hubService.downloadTemplate(dto);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "hubTemplate.csv");
		header.setContentLength(hubTemplate.length);
		logger.info("HubController: getReport - End");
		return new HttpEntity<byte[]>(hubTemplate, header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.UPLOAD_BULK_HUB_TEMPLATE, method = RequestMethod.POST, consumes = "multipart/form-data")
	public void uploadBulkAccountFile(@RequestParam("file") MultipartFile file) throws IOException {
		logger.info("HubController: uploadBulkAccountFile - Start");
		hubService.uploadCSV(file);
	}
}
