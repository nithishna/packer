package com.monarch.mabdeck.dto;

import java.util.List;

public class SupplyListItemDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long supplyId;
	private String supplyName;
	private List<MeterListItemDto> meterList;
	public Long getSupplyId() {
		return supplyId;
	}
	public String getSupplyName() {
		return supplyName;
	}
	public void setSupplyId(Long supplyId) {
		this.supplyId = supplyId;
	}
	public void setSupplyName(String supplyName) {
		this.supplyName = supplyName;
	}
	public List<MeterListItemDto> getMeterList() {
		return meterList;
	}
	public void setMeterList(List<MeterListItemDto> meterList) {
		this.meterList = meterList;
	}	
}
