package com.monarch.mabdeck.dto;

public class BillablePersonDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long billablePersonId;
	private String titles;
	private String firstName;
	private String lastName;
	private String preferredName;
	private String landlineNumber;
	private String mobileNumber;
	private String emailAddress;
	private boolean deleted;
	public Long getBillablePersonId() {
		return billablePersonId;
	}
	public String getTitles() {
		return titles;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getPreferredName() {
		return preferredName;
	}
	public String getLandlineNumber() {
		return landlineNumber;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setBillablePersonId(Long billablePersonId) {
		this.billablePersonId = billablePersonId;
	}
	public void setTitles(String titles) {
		this.titles = titles;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}
	public void setLandlineNumber(String landlineNumber) {
		this.landlineNumber = landlineNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
}
