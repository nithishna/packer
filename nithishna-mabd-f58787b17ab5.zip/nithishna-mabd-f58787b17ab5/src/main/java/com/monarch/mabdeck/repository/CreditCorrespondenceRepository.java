package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.CreditCorrespondence;

@Repository
public interface CreditCorrespondenceRepository  extends JpaRepository<CreditCorrespondence, Long>{

	CreditCorrespondence findByClientId(long clientId);
	
	@Query(value="select correspondence_id, account_balance, account_id, client_id, correspondence_date, days_overdue, file_name, letter, network_id, property_id, stage, type, deleted \r\n" + 
			"from (select correspondence_id, account_balance, account_id, client_id, correspondence_date, days_overdue,file_name, letter, network_id, property_id, stage, type, deleted, RowNum = row_number() OVER ( order by correspondence_id) \r\n" + 
			"from credit_correspondence where letter=?1 and deleted=0\r\n" + 
			")t where RowNum between ?2 and ?3", nativeQuery=true)
	List<CreditCorrespondence> getAllCreditCorrespondenceByIndex(int letter, int startIndex, int endIndex);
}
