package com.monarch.mabdeck.dto;

public class CustomerServiceContactDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long custServiceId;

	private AddressDto address;
	private long mainContactNumber;
	private String emailAddress;
	public Long getCustServiceId() {
		return custServiceId;
	}
	public void setCustServiceId(Long custServiceId) {
		this.custServiceId = custServiceId;
	}
	public AddressDto getAddress() {
		return address;
	}
	public void setAddress(AddressDto address) {
		this.address = address;
	}
	public long getMainContactNumber() {
		return mainContactNumber;
	}
	public void setMainContactNumber(long mainContactNumber) {
		this.mainContactNumber = mainContactNumber;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
}
