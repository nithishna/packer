package com.monarch.mabdeck.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class CorrespondenceNotes implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private Date modifiedDate;
	private String author;
	private String summary;
	private String fileName;
	private byte[] attachment;
	
	@ManyToOne(targetEntity = CreditCorrespondence.class, fetch = FetchType.EAGER)
	@JoinColumn(name="correspondenceId",referencedColumnName="correspondenceId", insertable = true, updatable = false)
	private CreditCorrespondence creditCorrespondence;
	
	public long getId() {
		return id;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public String getAuthor() {
		return author;
	}
	public String getSummary() {
		return summary;
	}
	public String getFileName() {
		return fileName;
	}
	public byte[] getAttachment() {
		return attachment;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}
	public CreditCorrespondence getCreditCorrespondence() {
		return creditCorrespondence;
	}
	public void setCreditCorrespondence(CreditCorrespondence creditCorrespondence) {
		this.creditCorrespondence = creditCorrespondence;
	}
}
