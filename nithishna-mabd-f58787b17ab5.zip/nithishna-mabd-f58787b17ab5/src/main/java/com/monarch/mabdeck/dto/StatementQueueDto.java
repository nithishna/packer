package com.monarch.mabdeck.dto;

import java.util.List;

public class StatementQueueDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String createdDate;
	private String createdUser; 
	private List<PropertyLimited> property;
	private String status;
	private String message;
	private long id;
	public String getCreatedDate() {
		return createdDate;
	}
	public String getCreatedUser() {
		return createdUser;
	}
	public List<PropertyLimited> getProperty() {
		return property;
	}
	public String getStatus() {
		return status;
	}
	public String getMessage() {
		return message;
	}
	public long getId() {
		return id;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	public void setProperty(List<PropertyLimited> property) {
		this.property = property;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public void setId(long id) {
		this.id = id;
	}
}