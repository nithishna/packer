package com.monarch.mabdeck.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Account implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long accountId;
	
	@ManyToOne(targetEntity = Client.class, fetch = FetchType.LAZY)
	@JoinColumn(name="clientId",referencedColumnName="clientId", insertable = true, updatable = true)
	private Client client;
	
	@ManyToOne(targetEntity = Network.class, fetch = FetchType.LAZY)
	@JoinColumn(name="networkId",referencedColumnName="networkId", insertable = true, updatable = true)
	private Network network;
	private String accountNumber;
	private String paymentCardNumber;

	@OneToMany(mappedBy = "account", cascade = CascadeType.ALL)
	private List<BillablePerson> billablePerson;
	
	@OneToMany(mappedBy = "account")
	private List<PropertyAccountAssociation> association;
	
	@Embedded
	private Address address;
	private boolean sendInvitation;
	private String emailLanguage;
	
	private boolean vulnerable;
	private boolean redFlag;
	private boolean onHold;
	private String mood;
	
	@Embedded
	private Audit audit;
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public Network getNetwork() {
		return network;
	}
	public void setNetwork(Network network) {
		this.network = network;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getPaymentCardNumber() {
		return paymentCardNumber;
	}
	public void setPaymentCardNumber(String paymentCardNumber) {
		this.paymentCardNumber = paymentCardNumber;
	}	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<BillablePerson> getBillablePerson() {
		return billablePerson;
	}
	public void setBillablePerson(List<BillablePerson> billablePerson) {
		this.billablePerson = billablePerson;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public boolean isSendInvitation() {
		return sendInvitation;
	}
	public String getEmailLanguage() {
		return emailLanguage;
	}
	public void setSendInvitation(boolean sendInvitation) {
		this.sendInvitation = sendInvitation;
	}
	public void setEmailLanguage(String emailLanguage) {
		this.emailLanguage = emailLanguage;
	}
	public boolean isVulnerable() {
		return vulnerable;
	}
	public boolean isRedFlag() {
		return redFlag;
	}
	public boolean isOnHold() {
		return onHold;
	}
	public void setVulnerable(boolean vulnerable) {
		this.vulnerable = vulnerable;
	}
	public void setRedFlag(boolean redFlag) {
		this.redFlag = redFlag;
	}
	public void setOnHold(boolean onHold) {
		this.onHold = onHold;
	}
	public String getMood() {
		return mood;
	}
	public void setMood(String mood) {
		this.mood = mood;
	}
	public List<PropertyAccountAssociation> getAssociation() {
		return association;
	}
	public void setAssociation(List<PropertyAccountAssociation> association) {
		this.association = association;
	}
}
