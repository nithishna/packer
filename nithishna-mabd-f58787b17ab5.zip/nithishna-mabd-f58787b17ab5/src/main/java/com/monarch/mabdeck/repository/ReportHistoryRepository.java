package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.ReportHistory;

@Repository
public interface ReportHistoryRepository extends JpaRepository<ReportHistory, Long>{
	
	
	@Query(value="select id, client_name, network, type, report_name, from_date, to_date, created_date, status from \r\n" + 
			"			(select rh.id, c.client_name, n.network, t.name as type, rc.report_name, rh.from_date, rh.to_date, rh.created_date, rh.status, RowNum = row_number() OVER ( order by rh.id)\r\n" + 
			"			from report_history rh\r\n" + 
			"			inner join report_configuration rc on rh.config_id = rc.id\r\n" + 
			"			inner join client c on c.client_id = rc.client_id\r\n" + 
			"			inner join network n on n.network_id = rc.network_id\r\n" + 
			"			inner join report_type t on t.id = rc.type)t\r\n" + 
			"			where t.RowNum between ?1 and ?2", nativeQuery = true)
	public List<Object[]> getListOfReportHistoryByIndex(int start, int end);
}
