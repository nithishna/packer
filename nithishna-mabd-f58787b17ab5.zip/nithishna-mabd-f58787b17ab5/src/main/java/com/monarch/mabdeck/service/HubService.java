package com.monarch.mabdeck.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.annotation.Resource;

import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.HubDto;
import com.monarch.mabdeck.dto.HubTemplateDto;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.Hub;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.Property;
import com.monarch.mabdeck.history.service.HubHistoryService;
import com.monarch.mabdeck.mapper.HubMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.HubRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.repository.PropertyRepository;
import com.monarch.mabdeck.util.Constants;
import com.monarch.mabdeck.validator.RelationshipValidator;

@Component
public class HubService extends CommonServiceImpl<HubDto, Hub> {

	private Logger logger = LoggerFactory.getLogger(HubService.class);

	@Resource
	private HubRepository repository;
	
	@Autowired
	private HubHistoryService historyService;

	@Resource
	private PropertyRepository propertyRepository;

	@Resource
	private ClientRepository clientRepository;

	@Resource
	private NetworkRepository networkRepository;
	
	@Override
	public JpaRepository<Hub, Long> getJPARepository() {
		return repository;
	}
	
	@Override
	public IBaseMapper<HubDto, Hub> getMapper() {
		return HubMapper.INSTANCE;
	}

	@Override
	public void updateAudit(Hub entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				java.sql.Date date = new java.sql.Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
			}else {
				entity.getAudit().setUpdatedDate(new java.sql.Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
	@Override
	public HubDto update(HubDto dto, String username) {
		if(dto != null && dto.getHubId() != null) {
			Hub hub = repository.findOne(dto.getHubId());
			updateAudit(hub, username);
			historyService.updateHubHistory(hub, username);
			Hub newHub = this.getMapper().convertToEntity(dto);
			if(hub != null) {
				if(dto.getClient() != null && dto.getClient().getClientId()>0) {
					Client client = clientRepository.findOne(dto.getClient().getClientId());
					hub.setClient(client);
				}else {
					hub.setClient(null);
				}
			}
			if(dto.getNetwork() != null && dto.getNetwork().getNetworkId()>0) {
				Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
				hub.setNetwork(network);
			}else {
				hub.setNetwork(null);
			}
			if(dto.getProperty() != null && dto.getProperty().getPropertyId()>0) {
				Property property = propertyRepository.findOne(dto.getProperty().getPropertyId());
				hub.setProperty(property);
			}else {
				hub.setProperty(null);
			}
			hub.setEndDate(newHub.getEndDate());
			hub.setStartDate(newHub.getStartDate());;
			hub.setHubManufacturer(newHub.getHubManufacturer());
			hub.setHubModel(newHub.getHubModel());
			hub.setIdentifier(newHub.getIdentifier());
			hub.setSerialNumber(newHub.getSerialNumber());
		}		
		return dto;
	}
	
	
	@Override
	public HubDto create(HubDto dto, String username) {
		Hub hub = this.getMapper().convertToEntity(dto);
		updateAudit(hub, username);
		if (dto.getClient() != null && dto.getClient().getClientId() > 0) {
			Client client = clientRepository.findOne(dto.getClient().getClientId());
			hub.setClient(client);
		}
		if (dto.getNetwork() != null && dto.getNetwork().getNetworkId() > 0) {
			Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
			hub.setNetwork(network);
		}
		if (dto.getProperty() != null && dto.getProperty().getPropertyId() > 0) {
			Property property = propertyRepository.findOne(dto.getProperty().getPropertyId());
			hub.setProperty(property);
		}
		repository.saveAndFlush(hub);
		return dto;
	}

	public List<String> getAllHubModelsForClientAndNetwork(Long clientId, Long networkId) {
		return repository.getAllHubModelsForClient(clientId, networkId);
	}

	public byte[] downloadTemplate(HubTemplateDto dto) throws IOException {
		File tempFile = new File("template.csv");
		PrintWriter pw = new PrintWriter(tempFile);
		StringBuilder sb = new StringBuilder();
		this.populateHeading(sb);
		this.populateRow(dto, sb);
		pw.write(sb.toString());
		pw.close();
		InputStream stream = new FileInputStream("template.csv");
		byte[] result = IOUtils.toByteArray(stream);
		stream.close();
		logger.debug("File deletion status : " + (tempFile.delete() ? "Success" : "Failure"));
		return result;
	}

	private void populateHeading(StringBuilder sb) {
		sb.append("ClientId").append(",");
		sb.append("Client").append(",");
		sb.append("NetworkId").append(",");
		sb.append("Network").append(",");
		sb.append("PropertyId").append(",");
		sb.append("PropertyAddress").append(",");
		sb.append("HubManufacturer").append(",");
		sb.append("HubModelName").append(",");
		sb.append("SerialNumber").append(",");
		sb.append("Identifier").append(",");
		sb.append("StartDate").append(",");
		sb.append("EndDate").append("\n");
	}

	private void populateRow(HubTemplateDto dto, StringBuilder sb) {
		List<Property> properties = propertyRepository.fetchAllPropertiesByNetwork(dto.getNetworkId());
		for (Property property : properties) {
			sb.append(dto.getClientId()).append(",");
			sb.append(clientRepository.getClientNameById(dto.getClientId())).append(",");
			sb.append(dto.getNetworkId()).append(",");
			sb.append(networkRepository.getNetworkNameById(dto.getNetworkId())).append(",");
			sb.append(property.getPropertyId()).append(",");
			sb.append(property.getAddress() != null ? property.getAddress().getAddressLine1() : "").append(",");
			sb.append(dto.getHubManufacturer()).append(",");
			sb.append(dto.getHubModel()).append(",");
			sb.append(Constants.REQUIRED).append(",");
			sb.append(Constants.REQUIRED).append(",");
			sb.append(Constants.REQUIRED).append(",");
			sb.append("").append("\n");
		}
	}
	
	public void uploadCSV(MultipartFile multipartFile) throws IOException {
		File file = null;
		try {
			file = convertMultiPartToFile(multipartFile);
			Scanner scanner = new Scanner(file);
			boolean headingValidation = false;
			while (scanner.hasNextLine()) {
				if (!headingValidation) {
					headingValidation = validateHeading(scanner.nextLine());
					if (!headingValidation) {
						scanner.close();
						throw new IOException("Kindly check the heading order");
					}
				} else
					getRecordFromLine(scanner.nextLine());
			}
			scanner.close();
			if(file!= null)
				logger.debug(file.delete()? "Temp File Deleted successfully":"Temp File could not be deleted");
		} catch (IOException ex) {
			if(file!= null)
				logger.debug(file.delete()? "Temp File Deleted successfully":"Temp File could not be deleted");
			throw ex;
		} catch (Exception ex) {
			if(file!= null)
				logger.debug(file.delete()? "Temp File Deleted successfully":"Temp File could not be deleted");
			throw new IOException("Unable to parse the file. Kindly raise a support request and get this sorted");
		}
	}

	private boolean validateHeading(String line) {
		List<String> heading = Constants.hubHeading;
		Iterator<String> iterator = heading.iterator();
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			while (rowScanner.hasNext()) {
				if (!iterator.next().equalsIgnoreCase(rowScanner.next())) {
					return false;
				}
			}
		}
		return true;
	}

	private void getRecordFromLine(String line) throws IOException {
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			Hub hub = new Hub();
			Client client = null;
			Network network = null;
			Property property = null;			
			if (rowScanner.hasNext()) {
				long clientId = rowScanner.nextLong();
				client = clientRepository.findOne(clientId);
				if(client == null)
					throw new IOException("Client details is mandatory. Kindly specify the Client details in the file and try again");
				hub.setClient(client);
				logger.debug("Client name: " + (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			if(rowScanner.hasNext()) {
				long networkId = rowScanner.nextLong();
				network = networkRepository.findOne(networkId);
				if(network == null)
					throw new IOException("Network details are mandatory. Kindly specify the Network details in the file and try again");
				hub.setNetwork(network);
				logger.debug("Network name: "+ (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			if(rowScanner.hasNext()) {
				long propertyId = rowScanner.nextLong();
				property = propertyRepository.findOne(propertyId);
				if(property == null)
					throw new IOException("Property details are mandatory. Kindly specify the Property details in the file and try again");
				hub.setProperty(property);
				logger.debug("Property name: "+ (rowScanner.hasNext() ? rowScanner.next() : null));
			}
			this.validateRelationship(client, network, property);
			hub.setHubManufacturer(rowScanner.hasNext() ? rowScanner.next() : null);
			hub.setHubModel(rowScanner.hasNext() ? rowScanner.next() : null);
			String serialNumber = rowScanner.hasNext() ? rowScanner.next() : null;
			if(serialNumber.isEmpty() || serialNumber == null) {
				throw new IOException("Serial number cannot be empty. Kindly enter the serial number and try again");
			}
			hub.setSerialNumber(serialNumber);
			String identifier = rowScanner.hasNext() ? rowScanner.next() : null;
			if(identifier.isEmpty() || identifier == null) {
				throw new IOException("Identifier cannot be empty. Kindly enter the identifier and try again");
			}
			hub.setIdentifier(identifier);
			if (rowScanner.hasNext()) {
				Date date = null;
				try {
					date = new SimpleDateFormat("dd/MM/yyyy").parse(rowScanner.next());
				} catch (Exception ex) {
					throw new IOException(
							"Issue in the data!.....Kindly specify start date in dd/MM/YYYY format and try again");
				}
				if (date != null)
					hub.setStartDate(new java.sql.Date(date.getTime()));
				else
					throw new IOException("Start Date time cannot be empty....Kindly update the excel and try again");
			}
			if (rowScanner.hasNext()) {
				Date date = null;
				try {
					date = new SimpleDateFormat("dd/MM/yyyy").parse(rowScanner.next());
				} catch (Exception ex) {
					throw new IOException(
							"Issue in the data!.....Kindly specify End date in dd/MM/YYYY format and try again");
				}
				if (date != null)
					hub.setEndDate(new java.sql.Date(date.getTime()));
			}
			repository.saveAndFlush(hub);
		}catch(IOException ex) { 
			throw ex;
		}catch (Exception ex) {
			throw new IOException("Unable to parse the file. Kindly raise a support request and get this sorted");
		}
	}
	
	public void validateRelationship(Client client, Network network, Property property) throws IOException {
		RelationshipValidator validator = new RelationshipValidator();
		validator.validateNetworkClientRelationship(client, network);
		validator.validatePropertyNetworkRelationship(network, property);
	}
	
	private File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}


}