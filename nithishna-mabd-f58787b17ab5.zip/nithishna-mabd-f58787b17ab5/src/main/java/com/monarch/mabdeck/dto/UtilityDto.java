package com.monarch.mabdeck.dto;

public class UtilityDto implements IDto{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long meterSerialNumber;
	private String tariff;
	private MeterRead fromDate;
	private MeterRead toDate;
	private double pricePerUnit;
	private double unitsUsed;
	private double unitcharge;
	
	private double pricePerDay;
	private double standingCharge;
	private int noOfDays;	
	
	class MeterRead{
		private String date;
		private double reading;
		public String getDate() {
			return date;
		}
		public double getReading() {
			return reading;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public void setReading(double reading) {
			this.reading = reading;
		}
	}

	public Long getMeterSerialNumber() {
		return meterSerialNumber;
	}

	public String getTariff() {
		return tariff;
	}

	public MeterRead getFromDate() {
		return fromDate;
	}

	public MeterRead getToDate() {
		return toDate;
	}

	public double getPricePerUnit() {
		return pricePerUnit;
	}

	public double getUnitsUsed() {
		return unitsUsed;
	}

	public double getUnitcharge() {
		return unitcharge;
	}

	public double getPricePerDay() {
		return pricePerDay;
	}

	public double getStandingCharge() {
		return standingCharge;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setMeterSerialNumber(Long meterSerialNumber) {
		this.meterSerialNumber = meterSerialNumber;
	}

	public void setTariff(String tariff) {
		this.tariff = tariff;
	}

	public void setFromDate(MeterRead fromDate) {
		this.fromDate = fromDate;
	}

	public void setToDate(MeterRead toDate) {
		this.toDate = toDate;
	}

	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	public void setUnitsUsed(double unitsUsed) {
		this.unitsUsed = unitsUsed;
	}

	public void setUnitcharge(double unitcharge) {
		this.unitcharge = unitcharge;
	}

	public void setPricePerDay(double pricePerDay) {
		this.pricePerDay = pricePerDay;
	}

	public void setStandingCharge(double standingCharge) {
		this.standingCharge = standingCharge;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
}
