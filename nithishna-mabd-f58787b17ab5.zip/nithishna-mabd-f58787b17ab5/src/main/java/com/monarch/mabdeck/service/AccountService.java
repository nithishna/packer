package com.monarch.mabdeck.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.monarch.mabdeck.dto.AccountDto;
import com.monarch.mabdeck.dto.AccountLimitedDto;
import com.monarch.mabdeck.dto.BillablePersonDto;
import com.monarch.mabdeck.dto.NotesDto;
import com.monarch.mabdeck.entity.Account;
import com.monarch.mabdeck.entity.Address;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.BillablePerson;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.Notes;
import com.monarch.mabdeck.history.service.AccountHistoryService;
import com.monarch.mabdeck.history.service.BillablePersonHistoryService;
import com.monarch.mabdeck.mapper.AccountMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.repository.AccountRepository;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.repository.NotesRepository;
import com.monarch.mabdeck.repository.PropertyRepository;
import com.monarch.mabdeck.util.Constants;

import javassist.NotFoundException;

@Component
public class AccountService extends CommonServiceImpl<AccountDto, Account> {

	private Logger logger = LoggerFactory.getLogger(AccountService.class);

	@Resource
	private AccountRepository repository;

	@Resource
	private ClientRepository clientRepository;

	@Resource
	private NetworkRepository networkRepository;

	@Resource
	private NotesRepository notesRepository;

	@Autowired
	private AccountHistoryService historyService;

	@Autowired
	private BillablePersonHistoryService billablePersonHistoryService;

	@Resource
	private PropertyRepository propertyRepository;

	@Override
	public JpaRepository<Account, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<AccountDto, Account> getMapper() {
		return AccountMapper.INSTANCE;
	}

	@Override
	public void updateAudit(Account entity, String username) {
		if (entity != null) {
			Calendar cal = Calendar.getInstance();
			if (entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			} else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}
	}

	@Override
	public AccountDto read(Long id) throws NotFoundException {
		Account entity = getJPARepository().findOne(id);
		if (entity == null)
			throw new NotFoundException("There is no such element");
		AccountDto dto = getMapper().convertToDTO(entity);
		List<BillablePersonDto> billablePersonList = dto.getBillablePerson();
		if (billablePersonList != null && billablePersonList.size() > 0) {
			Iterator<BillablePersonDto> iterator = billablePersonList.iterator();
			while (iterator.hasNext()) {
				BillablePersonDto person = iterator.next();
				if (person.isDeleted())
					iterator.remove();
			}
		}
		List<Notes> notes = notesRepository.getAllNotesById(dto.getAccountId());
		List<NotesDto> notesList = new ArrayList<>();
		for (Notes note : notes) {
			NotesDto notesDto = new NotesDto();
			notesDto.setAttachment(note.getAttachment() != null ? "Yes" : "No");
			notesDto.setAuthor(note.getAuthor());
			notesDto.setFileName(note.getFileName());
			notesDto.setModifiedDate(note.getModifiedDate());
			notesDto.setNoteId(note.getNoteId());
			notesDto.setSummary(note.getSummary());
			notesDto.setPin(note.isPin());
			notesList.add(notesDto);
		}
		dto.setNotes(notesList);
		return dto;
	}

	@Override
	public AccountDto create(AccountDto dto, String username) {
		Account entity = this.getMapper().convertToEntity(dto);
		entity.setEmailLanguage(Constants.LANGUAGE);
		entity.setSendInvitation(true);
		updateAudit(entity, username);
		if (dto.getClient() != null && dto.getClient().getClientId() > 0) {
			Client client = clientRepository.findOne(dto.getClient().getClientId());
			entity.setClient(client);
		}
		if (dto.getNetwork() != null && dto.getNetwork().getNetworkId() > 0) {
			Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
			entity.setNetwork(network);
		}
		if (entity.getBillablePerson() != null && entity.getBillablePerson().size() > 0) {
			Iterator<BillablePerson> iterator = entity.getBillablePerson().iterator();
			while (iterator.hasNext()) {
				BillablePerson person = iterator.next();
				if (person.isDeleted()) {
					iterator.remove();
				}
			}
		}
		for (BillablePerson person : entity.getBillablePerson()) {
			person.setAccount(entity);
		}
		repository.saveAndFlush(entity);
		return dto;
	}

	@Override
	public List<AccountDto> readAll() throws NotFoundException {
		List<Account> entities = getJPARepository().findAll();
		for (Account entity : entities) {
			if (entity.getBillablePerson() != null && entity.getBillablePerson().size() > 0) {
				Iterator<BillablePerson> iterator = entity.getBillablePerson().iterator();
				while (iterator.hasNext()) {
					BillablePerson person = iterator.next();
					if (person.isDeleted()) {
						iterator.remove();
					}
				}
			}
		}
		/** check if there are any entities in backend **/
		if (entities == null || entities.size() == 0) {
			throw new NotFoundException("There are no elements to display");
		}
		return getMapper().convertToDTOList(entities);
	}

	public List<AccountLimitedDto> getAllAccounts() throws NotFoundException {
		Set<Long> accountIds = new HashSet<>();
		List<AccountLimitedDto> accounts = repository.fetchAllAccountDetails();
		if (accounts == null)
			throw new NotFoundException("No account details found");
		Iterator<AccountLimitedDto> iterator = accounts.iterator();
		while (iterator.hasNext()) {
			AccountLimitedDto account = iterator.next();
			if (accountIds.contains(account.getAccountId()))
				iterator.remove();
			else
				accountIds.add(account.getAccountId());
		}
		return accounts;
	}

	public List<AccountLimitedDto> getAllAccountsUnderClientAndNetworkForProperty(Long propertyId) {
		List<AccountLimitedDto> accounts = new ArrayList<>();
		List<Object[]> elements = repository.populateAccountDropDownForClientAndNetwork(propertyId);
		for (Object[] element : elements) {
			AccountLimitedDto accountDto = new AccountLimitedDto();
			if (element[0] != null)
				accountDto.setAccountId(((BigDecimal) element[0]).longValue());
			accountDto.setAccountNumber((String) element[1]);
			accounts.add(accountDto);
		}
		return accounts;
	}

	public long getCount() {
		return repository.getCount();
	}

	public List<AccountDto> readAllAccountsV2(int index, int size) throws NotFoundException {
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index - 1) * size + 1;
		endIndex = index * size;
		List<Account> entities = repository.getAllAccountsByPaging(startIndex, endIndex);
		for (Account entity : entities) {
			if (entity.getBillablePerson() != null && entity.getBillablePerson().size() > 0) {
				Iterator<BillablePerson> iterator = entity.getBillablePerson().iterator();
				while (iterator.hasNext()) {
					BillablePerson person = iterator.next();
					if (person.isDeleted()) {
						iterator.remove();
					}
				}
			}
			if (entity.getClient() != null) {
				Client client = entity.getClient();
				Client temp = new Client();
				temp.setClientId(client.getClientId());
				temp.setClientName(client.getClientName());
				entity.setClient(temp);
			}
			if (entity.getNetwork() != null) {
				Network network = entity.getNetwork();
				Network temp = new Network();
				temp.setNetworkId(network.getNetworkId());
				temp.setNetwork(network.getNetwork());
				entity.setNetwork(temp);
			}
		}
		/** check if there are any entities in backend **/
		if (entities == null || entities.size() == 0) {
			throw new NotFoundException("There are no elements to display");
		}
		List<AccountDto> accountsDto = getMapper().convertToDTOList(entities);
		return accountsDto;
	}

	public List<AccountDto> readAllAccounts() throws NotFoundException {
		List<Account> entities = getJPARepository().findAll();
		for (Account entity : entities) {
			if (entity.getBillablePerson() != null && entity.getBillablePerson().size() > 0) {
				Iterator<BillablePerson> iterator = entity.getBillablePerson().iterator();
				while (iterator.hasNext()) {
					BillablePerson person = iterator.next();
					if (person.isDeleted()) {
						iterator.remove();
					}
				}
			}
			if (entity.getClient() != null) {
				Client client = entity.getClient();
				Client temp = new Client();
				temp.setClientId(client.getClientId());
				temp.setClientName(client.getClientName());
				entity.setClient(temp);
			}
			if (entity.getNetwork() != null) {
				Network network = entity.getNetwork();
				Network temp = new Network();
				temp.setNetworkId(network.getNetworkId());
				temp.setNetwork(network.getNetwork());
				entity.setNetwork(temp);
			}
		}
		/** check if there are any entities in backend **/
		if (entities == null || entities.size() == 0) {
			throw new NotFoundException("There are no elements to display");
		}
		return getMapper().convertToDTOList(entities);

	}

	public AccountDto update(AccountDto dto, String username) {
		if (dto == null)
			return dto;
		Account entity = repository.findOne(dto.getAccountId());
		updateAudit(entity, username);
		historyService.updateAccountHistory(entity, username);
		if (dto.getClient() != null && dto.getClient().getClientId() > 0) {
			Client client = clientRepository.findOne(dto.getClient().getClientId());
			entity.setClient(client);
		}
		if (dto.getNetwork() != null && dto.getNetwork().getNetworkId() > 0) {
			Network network = networkRepository.findOne(dto.getNetwork().getNetworkId());
			entity.setNetwork(network);
		}
		entity.setAccountNumber(dto.getAccountNumber());
		entity.setPaymentCardNumber(dto.getPaymentCardNumber());
		entity.setEmailLanguage(Constants.LANGUAGE);
		entity.setSendInvitation(true);
		List<BillablePerson> billablePersonEntityList = entity.getBillablePerson();
		billablePersonHistoryService.updateBillablePersonHistoryList(billablePersonEntityList, username);
		List<BillablePersonDto> billablePersonDtoList = dto.getBillablePerson();
		for (BillablePerson billablePerson : billablePersonEntityList) {
			boolean flag = false;
			for (BillablePersonDto personDto : billablePersonDtoList) {
				if (personDto.getBillablePersonId() == billablePerson.getBillablePersonId()) {
					flag = true;
					billablePerson.setDeleted(false);
					billablePerson.setEmailAddress(personDto.getEmailAddress());
					billablePerson.setFirstName(personDto.getFirstName());
					billablePerson.setLastName(personDto.getLastName());
					billablePerson.setLandlineNumber(personDto.getLandlineNumber());
					billablePerson.setMobileNumber(personDto.getMobileNumber());
					billablePerson.setPreferredName(personDto.getPreferredName());
					billablePerson.setTitles(personDto.getTitles());
				}
			}
			if (!flag) {
				billablePerson.setDeleted(true);
			}
		}
		for (BillablePersonDto personDto : billablePersonDtoList) {
			if (personDto.getBillablePersonId() == null || personDto.getBillablePersonId() == 0) {
				BillablePerson person = new BillablePerson();
				person.setAccount(entity);
				person.setDeleted(false);
				person.setEmailAddress(personDto.getEmailAddress());
				person.setFirstName(personDto.getFirstName());
				person.setLandlineNumber(personDto.getLandlineNumber());
				person.setLastName(personDto.getLastName());
				person.setMobileNumber(personDto.getMobileNumber());
				person.setPreferredName(personDto.getPreferredName());
				person.setTitles(personDto.getTitles());
				entity.getBillablePerson().add(person);
			}
		}
		if (dto.getAddress() != null) {
			Address address = new Address();
			address.setAddressLine1(dto.getAddress().getAddressLine1());
			address.setAddressLine2(dto.getAddress().getAddressLine2());
			address.setAddressLine3(dto.getAddress().getAddressLine3());
			address.setCountry(dto.getAddress().getCountry());
			address.setPostCode(dto.getAddress().getPostCode());
			address.setRegion(dto.getAddress().getRegion());
			address.setTown(dto.getAddress().getTown());
			entity.setAddress(address);
		}

		return dto;
	}

	public void updateAccountStatus(Long accountId, String username, String status) throws IOException {
		Account account = repository.findOne(accountId);
		if (account == null || status == null)
			throw new IOException("Invalid account number");
		historyService.updateAccountHistory(account, username);
		if (status.equalsIgnoreCase("vulnerable")) {
			if (account.isVulnerable())
				account.setVulnerable(false);
			else
				account.setVulnerable(true);
		} else if (status.equalsIgnoreCase("onhold")) {
			if (account.isOnHold())
				account.setOnHold(false);
			else
				account.setOnHold(true);
		} else if (status.equalsIgnoreCase("redflag")) {
			if (account.isRedFlag())
				account.setRedFlag(false);
			else
				account.setRedFlag(true);
		} else {
			throw new IOException("There is no such status");
		}
	}

	public void updateMoodForAccount(Long accountId, String username, String mood) throws IOException {
		Account account = repository.findOne(accountId);
		if (account == null || mood == null)
			throw new IOException("Invalid account number");
		historyService.updateAccountHistory(account, username);
		if (!isAltered(account, mood)) {
			if (mood.equalsIgnoreCase("good")) {
				account.setMood("good");
			} else if (mood.equalsIgnoreCase("ok")) {
				account.setMood("ok");
			} else if (mood.equalsIgnoreCase("bad")) {
				account.setMood("bad");
			} else {
				throw new IOException("Invalid data supplied for Customer mood");
			}
		}
	}

	private boolean isAltered(Account account, String mood) {
		if(account.getMood() == null)
		{
			return false;
		}
		if (account.getMood().equalsIgnoreCase(mood)) {
			account.setMood("0");
			return true;
		}
		return false;
	}

	public byte[] uploadCSV(MultipartFile multipartFile) throws IOException {
		File file = null;
		byte[] result = null;
		try {
			file = convertMultiPartToFile(multipartFile);
			FileWriter csvWriter = new FileWriter("result.csv");
			Scanner scanner = new Scanner(file);
			boolean headingValidation = false;
			while (scanner.hasNextLine()) {
				if (!headingValidation) {
					headingValidation = validateHeading(scanner.nextLine());
					if (!headingValidation) {
						scanner.close();
						throw new IOException("Kindly check the heading order");
					}
					for (String value : Constants.accountsHeading) {
						csvWriter.append(value);
						csvWriter.append(",");
					}
					csvWriter.append("Message").append("\n");
				} else
					getRecordFromLine(scanner.nextLine(), csvWriter);
			}
			scanner.close();
			csvWriter.flush();
			csvWriter.close();
			InputStream stream = new FileInputStream("result.csv");
			result = IOUtils.toByteArray(stream);
			stream.close();
			if (file != null)
				logger.debug(file.delete() ? "Temp File Deleted successfully" : "Temp File could not be deleted");
			File resultFile = new File("result.csv");
			resultFile.delete();
		} catch (Exception ex) {
			if (file != null)
				logger.debug(file.delete() ? "Temp File Deleted successfully" : "Temp File could not be deleted");
			throw new IOException("Unable to parse the file. Kindly raise a support request and get this sorted");
		}
		return result;
	}

	private boolean validateHeading(String line) {
		List<String> heading = Constants.accountsHeading;
		Iterator<String> iterator = heading.iterator();
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			while (rowScanner.hasNext()) {
				if (!iterator.next().equalsIgnoreCase(rowScanner.next())) {
					return false;
				}
			}
		}
		return true;
	}

	private void writeLine(String line, FileWriter csvWriter) throws IOException {
		String[] values = line.split(",");
		for (String value : values) {
			csvWriter.append(value);
			csvWriter.append(",");
		}
		int extension = Constants.accountsHeading.size() - values.length;
		if (extension > 0) {
			for (int i = 0; i < extension; i++) {
				csvWriter.append("");
				csvWriter.append(",");
			}
		}
	}

	private void getRecordFromLine(String line, FileWriter csvWriter) throws IOException {
		if(line.startsWith(Constants.COMMA_DELIMITER))
			line = " "+ line;
		try (Scanner rowScanner = new Scanner(line)) {
			rowScanner.useDelimiter(Constants.COMMA_DELIMITER);
			Account account = new Account();
			if (rowScanner.hasNext()) {
				String nextValue = rowScanner.next();
				String networkName = (rowScanner.hasNext() ? rowScanner.next() : null);
				Network network = null;
				if (nextValue == "" || nextValue == null || nextValue.equals(" ")) {
					if (networkName == "" || networkName == null)
						throw new IOException("Network Id cannot be empty. Kindly update the file and try again");
					network = networkRepository.findByNetwork(networkName);
				} else {
					long networkId = Integer.parseInt(nextValue);
					network = networkRepository.findOne(networkId);					
				}
				logger.debug("Network name: " + networkName);
				if (network != null) {
					account.setNetwork(network);
					Client client = network.getClient();
					account.setClient(client);
				}else
					throw new IOException("Either supply Network Id or correct the network Name");
			}
			String accountNumber = rowScanner.hasNext() ? rowScanner.next() : null;
			if (accountNumber.isEmpty() || accountNumber == null) {
				throw new IOException("Account Number cannot be empty. Kindly update the file and try again");
			}
			account.setAccountNumber(accountNumber);
			try {
				account.setPaymentCardNumber((rowScanner.hasNext() ? rowScanner.next() : null));
			}catch(Exception ex) {
				throw new IOException("Payment card number invalid");
			}
			BillablePerson billablePerson = new BillablePerson();
			String title = rowScanner.hasNext() ? rowScanner.next() : null;
			billablePerson.setTitles(title);
			String firstName = rowScanner.hasNext() ? rowScanner.next() : null;
			if (firstName.isEmpty() || firstName == null)
				throw new IOException("FirstName cannot be empty. Kindly update the file and try again");
			billablePerson.setFirstName(firstName);
			String lastName = rowScanner.hasNext() ? rowScanner.next() : null;
			if (lastName.isEmpty() || lastName == null)
				throw new IOException("LastName cannot be empty. Kindly update the file and try again");
			billablePerson.setLastName(lastName);
			billablePerson.setPreferredName(rowScanner.hasNext() ? rowScanner.next() : null);
			billablePerson.setLandlineNumber(rowScanner.hasNext() ? rowScanner.next() : null);
			billablePerson.setMobileNumber(rowScanner.hasNext() ? rowScanner.next() : null);
			billablePerson.setEmailAddress(rowScanner.hasNext() ? rowScanner.next() : null);
			billablePerson.setAccount(account);
			List<BillablePerson> billablePersons = new ArrayList<>();
			billablePersons.add(billablePerson);
			account.setBillablePerson(billablePersons);
			Address address = new Address();
			String addressLine1 = rowScanner.hasNext() ? rowScanner.next() : null;
			if (addressLine1.isEmpty() || addressLine1 == null)
				throw new IOException("AddressLine1 cannot be empty. Kindly update the file and try again");
			address.setAddressLine1(addressLine1);
			address.setAddressLine2(rowScanner.hasNext() ? rowScanner.next() : null);
			address.setAddressLine3(rowScanner.hasNext() ? rowScanner.next() : null);
			String town = rowScanner.hasNext() ? rowScanner.next() : null;
			if (town.isEmpty() || town == null)
				throw new IOException("Town cannot be empty. Kindly update the file and try again");
			address.setTown(town);
			address.setRegion(rowScanner.hasNext() ? rowScanner.next() : null);
			String postCode = rowScanner.hasNext() ? rowScanner.next() : null;
			if (postCode.isEmpty() || postCode == null)
				throw new IOException("PostCode cannot be empty. Kindly update the file and try again");
			address.setPostCode(postCode);
			address.setCountry(rowScanner.hasNext() ? rowScanner.next() : null);
			account.setAddress(address);
			if (rowScanner.hasNext()) {
				String sendInvitation = rowScanner.hasNext() ? rowScanner.next() : null;
				if (sendInvitation != null) {
					account.setSendInvitation(sendInvitation.toLowerCase().equals("true") ? true : false);
				}
			}
			account.setEmailLanguage(rowScanner.hasNext() ? rowScanner.next() : null);
			this.updateAudit(account, "Application\\Bulk upload");
			repository.saveAndFlush(account);
			this.writeLine(line, csvWriter);
			csvWriter.append("Success");
			csvWriter.append("\n");
		} catch (Exception ex) {
			this.writeLine(line, csvWriter);
			csvWriter.append("Error: " + ex.getMessage());
			csvWriter.append("\n");
		}
	}

	private File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

	public byte[] downloadAccountTemplate(Long clientId, Long networkId) throws IOException {
		File accountTemplate = new File("accountTemplate.csv");
		PrintWriter pw = new PrintWriter(accountTemplate);
		StringBuilder sb = new StringBuilder();
		this.populateHeading(sb);
		this.populateRows(clientId, networkId, sb);
		pw.write(sb.toString());
		pw.close();
		InputStream stream = new FileInputStream("accountTemplate.csv");
		byte[] result = IOUtils.toByteArray(stream);
		stream.close();
		logger.debug("File deletion status : " + (accountTemplate.delete() ? "Success" : "Failure"));
		return result;
	}

	public void populateHeading(StringBuilder sb) {
		sb.append("NetworkId").append(",");
		sb.append("Network").append(",");
		sb.append("AccountNumber").append(",");
		sb.append("PaymentCardNo").append(",");
		sb.append("Title").append(",");
		sb.append("FirstName").append(",");
		sb.append("LastName").append(",");
		sb.append("PreferredName").append(",");
		sb.append("LandlineNumber").append(",");
		sb.append("MobileNumber").append(",");
		sb.append("EmailAddress").append(",");
		sb.append("AddressLine1").append(",");
		sb.append("AddressLine2").append(",");
		sb.append("AddressLine3").append(",");
		sb.append("Town").append(",");
		sb.append("Region").append(",");
		sb.append("Postcode").append(",");
		sb.append("Country").append(",");
		sb.append("SendInvitation").append(",");
		sb.append("EmailLanguage").append("\n");
	}

	public void populateRows(Long clientId, Long networkId, StringBuilder sb) {
		Network network = networkRepository.findOne(networkId);
		if (network == null) {
			return;
		}
		if (network.getClient() != null && network.getClient().getClientId() == clientId) {
			sb.append(network.getNetworkId()).append(",");
			sb.append(network.getNetwork()).append(",");
			sb.append("*Required*").append(",");
			sb.append("").append(",");
			sb.append("*Required*").append(",");
			sb.append("*Required*").append(",");
			sb.append("*Required*").append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append("*Required*").append(",");
			sb.append("").append(",");
			sb.append("").append(",");
			sb.append("*Required*").append(",");
			sb.append("").append(",");
			sb.append("*Required*").append(",");
			sb.append("").append(",");
			sb.append("TRUE").append(",");
			sb.append("").append("\n");
		}
	}
}
