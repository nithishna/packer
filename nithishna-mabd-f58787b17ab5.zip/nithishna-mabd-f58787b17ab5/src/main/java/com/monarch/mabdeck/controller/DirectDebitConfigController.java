package com.monarch.mabdeck.controller;

import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.DirectDebitConfigDto;
import com.monarch.mabdeck.service.DirectDebitConfigService;
import com.monarch.mabdeck.util.Constants;

import javassist.NotFoundException;

@RestController
public class DirectDebitConfigController {

	@Autowired
	private DirectDebitConfigService service;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.DIRECT_DEBIT_CONFIG, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody List<DirectDebitConfigDto> getAllDirectDebitConfigs() {
		return this.service.getAllDirectDebitConfigs();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.DIRECT_DEBIT_CONFIG, method = RequestMethod.POST, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, consumes = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody DirectDebitConfigDto create(@RequestBody DirectDebitConfigDto dto) throws Exception {
		return this.service.create(dto);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.DIRECT_DEBIT_CONFIG, method = RequestMethod.PUT, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" }, consumes = {
					"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void update(@RequestBody DirectDebitConfigDto dto) throws InvalidFormatException, NotFoundException {
		this.service.update(dto);
	}
}
