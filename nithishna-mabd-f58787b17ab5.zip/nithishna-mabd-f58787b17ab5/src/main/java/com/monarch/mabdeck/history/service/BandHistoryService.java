package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Band;
import com.monarch.mabdeck.entity.BandHistory;
import com.monarch.mabdeck.repository.BandHistoryRepository;

@Component
public class BandHistoryService {
	
	@Resource
	BandHistoryRepository historyRepository;
	
	public void updateBandHistory(Band band, String username) {
		if(band != null) {
			BandHistory history = new BandHistory();
			history.setAudit(band.getAudit());
			history.setBandId(band.getBandId());
			history.setBandName(band.getBandName());
			history.setBandType(band.getBandType());
			history.setClientId(band.getClient() != null? band.getClient().getClientId(): null);
			history.setEndDate(band.getEndDate());
			history.setNetworkId(band.getNetwork() != null? band.getNetwork().getNetworkId() : null);
			history.setNumberOfBedroom(band.getNumberOfBedroom());
			history.setPropertyPart1(band.getPropertyPart1());
			history.setPropertyPart2(band.getPropertyPart2());
			history.setPropertyUnit(band.getPropertyUnit());
			history.setStartDate(band.getStartDate());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);
		}
	}
}
