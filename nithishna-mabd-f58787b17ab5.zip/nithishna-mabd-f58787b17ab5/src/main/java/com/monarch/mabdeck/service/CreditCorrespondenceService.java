package com.monarch.mabdeck.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.IOUtils;
import org.springframework.stereotype.Service;

import com.monarch.mabdeck.dto.ActionDto;
import com.monarch.mabdeck.dto.ActionEmailDto;
import com.monarch.mabdeck.dto.ActionFlagDto;
import com.monarch.mabdeck.dto.ActionLetterDto;
import com.monarch.mabdeck.dto.CreditControlSetupDto;
import com.monarch.mabdeck.dto.CreditCorrespondenceDto;
import com.monarch.mabdeck.dto.CreditNotesDto;
import com.monarch.mabdeck.dto.StageDto;
import com.monarch.mabdeck.entity.Action;
import com.monarch.mabdeck.entity.ActionEmail;
import com.monarch.mabdeck.entity.ActionFlag;
import com.monarch.mabdeck.entity.ActionLetter;
import com.monarch.mabdeck.entity.BillablePerson;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.CorrespondenceNotes;
import com.monarch.mabdeck.entity.CreditControlSetup;
import com.monarch.mabdeck.entity.CreditCorrespondence;
import com.monarch.mabdeck.entity.Stage;
import com.monarch.mabdeck.repository.ActionEmailRepository;
import com.monarch.mabdeck.repository.ActionFlagRepository;
import com.monarch.mabdeck.repository.ActionLetterRepository;
import com.monarch.mabdeck.repository.BillablePersonRepository;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.CorrespondenceNotesRepository;
import com.monarch.mabdeck.repository.CreditControlSetupRepository;
import com.monarch.mabdeck.repository.CreditCorrespondenceRepository;
import com.monarch.mabdeck.repository.NetworkRepository;
import com.monarch.mabdeck.repository.PropertyRepository;
import com.monarch.mabdeck.repository.StageRepository;

@Service
public class CreditCorrespondenceService {

	@Resource
	private CorrespondenceNotesRepository noteRepo;

	@Resource
	private CreditControlSetupRepository setupRepo;

	@Resource
	private ClientRepository clientRepo;

	@Resource
	private NetworkRepository networkRepo;

	@Resource
	private PropertyRepository propertyRepo;

	@Resource
	private CreditCorrespondenceRepository repository;

	@Resource
	private BillablePersonRepository billablePersonRepo;

	@Resource
	private StageRepository stageRepo;

	@Resource
	private ActionEmailRepository actionEmailRepo;

	@Resource
	private ActionFlagRepository actionFlagRepo;

	@Resource
	private ActionLetterRepository actionLetterRepo;

	public CreditControlSetupDto getCreditControlSetupByClientId(long clientId) throws Exception {
		CreditControlSetupDto dto = null;
		CreditControlSetup entity = this.setupRepo.findByClientClientId(clientId);
		if(entity != null) {
			dto = new CreditControlSetupDto();
			dto.setControlId(entity.getControlId());
			List<Stage> stages = entity.getStage();
			List<StageDto> stageDtos = new ArrayList<>();
			for(Stage stage: stages) {
				StageDto stageDto = new StageDto();
				stageDto.setName(stage.getName());
				stageDto.setNoOfDays(stage.getNoOfDays());
				stageDto.setOverDue(stage.isOverDue());
				stageDto.setStageId(stage.getStageId());
				List<Action> actions = stage.getActions();
				List<ActionDto> actionDtos = new ArrayList<>();
				for(Action action : actions) {
					if(action.isDeleted())
						continue;
					if(action instanceof ActionEmail) {
						ActionEmail actionEmail = (ActionEmail)action;
						ActionEmailDto actionDto = new ActionEmailDto();
						actionDto.setId(action.getId());
						actionDto.setOwner(action.isOwner());
						actionDto.setBody(actionEmail.getBody());
						actionDto.setEmailIds(actionEmail.getEmailIds());
						actionDto.setSubject(actionEmail.getSubject());
						actionDto.setType(1);
						actionDtos.add(actionDto);
					}
					else if(action instanceof ActionFlag) {
						ActionFlag actionFlag = (ActionFlag)action;
						ActionFlagDto actionFlagDto = new ActionFlagDto();
						actionFlagDto.setFlag(actionFlag.isFlag());
						actionFlagDto.setId(actionFlag.getId());
						actionFlagDto.setOwner(actionFlag.isOwner());
						actionFlagDto.setType(3);
						actionDtos.add(actionFlagDto);
					}else if(action instanceof ActionLetter) {
						ActionLetter actionLetter  = (ActionLetter)action;
						ActionLetterDto actionLetterDto = new ActionLetterDto();
						actionLetterDto.setId(actionLetter.getId());
						actionLetterDto.setOwner(actionLetter.isOwner());
						actionLetterDto.setTemplateName(actionLetter.getTemplateName());
						actionLetterDto.setType(2);
						actionDtos.add(actionLetterDto);
					}else {
						throw new Exception("No such action structure");
					}
				}
				stageDto.setActions(actionDtos);
				stageDtos.add(stageDto);
			}
			dto.setStages(stageDtos);
		}
		return dto;
	}
	
	public StageDto addStage(StageDto stageDto, long clientId, long setupId) throws Exception {
		Stage stage = new Stage();
		CreditControlSetup setup = new CreditControlSetup();
		if(setupId > 0) {
			setup = this.setupRepo.findOne(setupId);
			if(setup == null)
				throw new Exception("No data found");
		}else {
			Client client = this.clientRepo.findOne(clientId);
			setup.setClient(client);
			setup = this.setupRepo.save(setup);
		}
		stage.setName(stageDto.getName());
		stage.setNoOfDays(stageDto.getNoOfDays());
		stage.setOverDue(stageDto.isOverDue());
		stage.setSetup(setup);
		stage = this.stageRepo.save(stage);
		stageDto.setStageId(stage.getStageId());
		return stageDto;
	}
	
	public void editStage(StageDto stageDto) throws Exception {
		if(stageDto != null && stageDto.getStageId() > 0) {
			Stage entity = this.stageRepo.findOne(stageDto.getStageId());
			entity.setName(stageDto.getName());
			entity.setNoOfDays(stageDto.getNoOfDays());
			entity.setOverDue(stageDto.isOverDue());
			this.stageRepo.save(entity);
		}else {
			throw new InvalidFormatException("Data invalid");
		}
	}
	
	public void addActionEmail(ActionEmailDto dto, long stageId) throws Exception {
		this.addAction(dto, stageId);
	}
	
	public void addActionLetter(ActionLetterDto dto, long stageId) throws Exception {
		this.addAction(dto, stageId);
	}
	
	public void addActionFlag(ActionFlagDto dto, long stageId) throws Exception {
		this.addAction(dto, stageId);
	}
	
	
	public void deleteAction(long id, int type) throws Exception {
		if(type==1) {
			ActionEmail action = this.actionEmailRepo.findOne(id);
			if(action == null)
				throw new Exception("No Data Found");
			action.setDeleted(true);
			this.actionEmailRepo.save(action);
		}else if(type==2) {
			ActionLetter letter = this.actionLetterRepo.findOne(id);
			if(letter == null)
				throw new Exception("No Data Found");
			letter.setDeleted(true);
			this.actionLetterRepo.save(letter);
		}else if(type==3) {
			ActionFlag flag = this.actionFlagRepo.findOne(id);
			if(flag == null)
				throw new Exception("No Data Found");
			flag.setDeleted(true);
			this.actionFlagRepo.save(flag);
		}else
			throw new Exception("Invalid type");
	}
	
	public ActionDto addAction(ActionDto dto, long stageId) throws Exception {
		Stage stage = this.stageRepo.findOne(stageId);
		if(stage==null)
			throw new Exception("No data found");
		if(dto instanceof ActionEmailDto) {
			ActionEmail action = new ActionEmail();
			action.setBody(((ActionEmailDto) dto).getBody());
			action.setEmailIds(((ActionEmailDto) dto).getEmailIds());
			action.setOwner(((ActionEmailDto) dto).isOwner());
			action.setStage(stage);
			action.setSubject(((ActionEmailDto) dto).getSubject());
			action = this.actionEmailRepo.save(action);
			dto.setId(action.getId());
					
		}else if(dto instanceof ActionFlagDto) {
			ActionFlag action = new ActionFlag();
			action.setFlag(((ActionFlagDto) dto).isFlag());
			action.setOwner(dto.isOwner());
			action.setStage(stage);
			action = this.actionFlagRepo.save(action);
			dto.setId(action.getId());
		}else if(dto instanceof ActionLetterDto) {
			ActionLetter action = new ActionLetter();
			action.setTemplateName(((ActionLetterDto) dto).getTemplateName());
			action.setOwner(dto.isOwner());
			action.setStage(stage);
			action = this.actionLetterRepo.save(action);
			dto.setId(action.getId());
		}else
			throw new Exception("Invalid action structure");	
		return dto;
	}
	
	public List<CreditCorrespondenceDto> getAllCreditControl(int index, int noOfItems){
		List<CreditCorrespondenceDto> dtos = new ArrayList<>();
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1)*noOfItems + 1;
		endIndex = index * noOfItems;
		List<CreditCorrespondence> entities = this.repository.getAllCreditCorrespondenceByIndex(0, startIndex, endIndex);
		for(CreditCorrespondence entity : entities) {
			CreditCorrespondenceDto dto = new CreditCorrespondenceDto();
			dto.setCorrespondenceId(entity.getCorrespondenceId());
			dto.setAccountBalance(entity.getAccountBalance());
			BillablePerson person = this.billablePersonRepo.getBillablePersonForAccountId(entity.getAccountId());
			if(person != null)
				dto.setBillablePerson(person.getFirstName() + " " + person.getLastName());
			dto.setClientName(this.clientRepo.getClientNameById(entity.getClientId()));
			dto.setCorrespondenceDate(entity.getCorrespondenceDate());
			dto.setStage(entity.getStage());
			dto.setAccountBalance(entity.getAccountBalance());
			dto.setDaysOverdue(entity.getDaysOverdue());
			dtos.add(dto);
		}
		return dtos;
	}
	
	public List<CreditCorrespondenceDto> getAllCreditControlCorrespondence(int index, int noOfItems) {
		List<CreditCorrespondenceDto> dtos = new ArrayList<>();
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1)*noOfItems + 1;
		endIndex = index * noOfItems;
		List<CreditCorrespondence> entities = this.repository.getAllCreditCorrespondenceByIndex(1, startIndex, endIndex);
		for(CreditCorrespondence entity : entities) {
			CreditCorrespondenceDto dto = new CreditCorrespondenceDto();
			dto.setCorrespondenceId(entity.getCorrespondenceId());
			dto.setAccountBalance(entity.getAccountBalance());
			BillablePerson person = this.billablePersonRepo.getBillablePersonForAccountId(entity.getAccountId());
			if(person != null)
				dto.setBillablePerson(person.getFirstName() + " " + person.getLastName());
			dto.setClientName(this.clientRepo.getClientNameById(entity.getClientId()));
			dto.setCorrespondenceDate(entity.getCorrespondenceDate());
			dto.setStage(entity.getStage());
			dto.setAccountBalance(entity.getAccountBalance());
			dto.setDaysOverdue(entity.getDaysOverdue());
			dtos.add(dto);
		}
		return dtos;
	}
	
	public List<CreditNotesDto> getAllNotesForCorrespondenceId(long id){
		List<CorrespondenceNotes> notes = this.noteRepo.getAllNotesByCorrespondenceId(id);
		List<CreditNotesDto> dtos = new ArrayList<>();
		for(CorrespondenceNotes note: notes) {
			CreditNotesDto dto = new CreditNotesDto();
			dto.setAuthor(note.getAuthor());
			dto.setSummary(note.getSummary());
			dto.setModifiedDate(note.getModifiedDate());
			dto.setId(note.getId());
			if(note.getAttachment() != null)
				dto.setIsAttachment(true);
			else
				dto.setIsAttachment(false);
			dtos.add(dto);
		}
		return dtos;
	}
	
	public void createNote(CreditNotesDto dto, long correspondenceId, String username) {
		if(dto != null) {
			CorrespondenceNotes notes = new CorrespondenceNotes();
			notes.setCreditCorrespondence(this.repository.findOne(correspondenceId));
			notes.setAttachment(dto.getAttachment() != null? dto.getAttachment().getBytes():null);
			notes.setAuthor(username);
			notes.setFileName(dto.getFileName());
			Calendar cal = Calendar.getInstance();
			notes.setModifiedDate(new Date(cal.getTime().getTime()));
			notes.setSummary(dto.getSummary());
			this.noteRepo.saveAndFlush(notes);
		}
	}
	
	public byte[] getAttachmentForNote(Long noteId) throws Exception {
		byte[] result = null;
		CorrespondenceNotes note = this.noteRepo.findOne(noteId);
		if(note == null)
			throw new Exception("No data found");
		byte[] attachment = note.getAttachment();
		String encodedAttachement = new String(attachment);
		byte[] decoded = Base64.getDecoder().decode(encodedAttachement.split(",")[1]);
		File file = null;
		FileOutputStream fileOuputStream = null;
		FileInputStream inputStream = null;
		try {
		file = new File("attachment.txt");
		fileOuputStream = new FileOutputStream(file);
		fileOuputStream.write(decoded);
		fileOuputStream.close();
		inputStream = new FileInputStream(file);
		result = IOUtils.toByteArray(inputStream);		
		}catch(IOException e) {
			throw new IOException("Could not read the attachment for Notes. Kindly check with the administrator");
		}finally {
			if (inputStream != null) {
                try {
                	inputStream.close();
                	file.delete();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
		}
		return result;		
	}
}
