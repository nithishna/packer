package com.monarch.mabdeck.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import javax.naming.directory.InvalidAttributesException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.ReportConfigInputDto;
import com.monarch.mabdeck.dto.ReportConfigurationDto;
import com.monarch.mabdeck.dto.ReportHistoryDto;
import com.monarch.mabdeck.dto.ReportMetadataDto;
import com.monarch.mabdeck.dto.ReportTypeDto;
import com.monarch.mabdeck.dto.ScheduleDto;
import com.monarch.mabdeck.service.ReportService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;

@RestController
public class ReportController {

	private Logger logger = LoggerFactory.getLogger(ReportController.class);

	@Autowired
	private ReportService service;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.REPORT_TYPE, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<ReportTypeDto> getAllReportTypes() {
		return service.getAllReportTypes();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.REPORT_CONFIGURATION, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<ReportConfigurationDto> getAllReportConfigurationsWithStartAndEndIndex(@RequestParam("index") int index,
			@RequestParam("size") int pageSize) {
		logger.info("ReportController: getAllReportConfigurationsWithStartAndEndIndex - Start");
		return service.getConfigurationByIndex(index, pageSize);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.REPORT_HISTORY, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<ReportHistoryDto> getReportHistoryByIndex(@RequestParam("index") int index,
			@RequestParam("size") int pageSize) {
		logger.info("ReportController: getReportHistoryByIndex - Start");
		return service.getReportHistoryByIndex(index, pageSize);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.REPORT_CONFIGURATION, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createReportConfiguration(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody ReportConfigInputDto configuration) throws InvalidFormatException {
		logger.info("ReportController: createReportConfiguration - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("ReportController: createReportConfiguration - Service call, Username : " + username);
		service.create(configuration, username);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(value = Constants.REPORT, method = RequestMethod.POST, produces = "application/octet-stream")
	@ResponseBody
	public HttpEntity<byte[]> downloadReport(@RequestParam("id") long reportId) throws IOException {
		logger.info("ReportController: downloadReport - Start");
		ReportMetadataDto result = service.downloadReport(reportId);
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + result.getReportName() + ".csv");
		header.setContentLength(result.getData().length);
		logger.info("ReportController: downloadReport - End");
		return new HttpEntity<byte[]>(result.getData(), header);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.REPORT_RUN, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void runReport(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody ReportHistoryDto reportHistory) throws InvalidFormatException {
		logger.info("ReportController: runReport - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("ReportController: runReport - Service call, Username : " + username);
		service.runReport(reportHistory, username);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.REPORT, method = RequestMethod.PUT, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void updateSchedule(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody ScheduleDto dto, @RequestParam("id") long reportConfigId) throws InvalidAttributesException {
		logger.info("ReportController: updateSchedule - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("ReportController: updateSchedule - Service call, Username : " + username);
		service.updateSchedule(dto, reportConfigId, username);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.REPORT, method = RequestMethod.DELETE, consumes = { "application/json; charset=utf-8",
			"application/xml; charset=utf-8" })
	public void deleteConfig(@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization, @RequestParam("id") long id) {
		logger.info("ReportController: deleteConfig - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("ReportController: deleteConfig - Service call, Username : " + username);
		service.deleteConfig(id, username);
	}
}
