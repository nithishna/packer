package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class UnitChargeHistory implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long UnitChargeId;
	
	private String name;
	private float pricePerUnit;
	private String unit;
	private Long tariffId;
	
	@Embedded
	private Audit audit;

	public Long getId() {
		return id;
	}

	public Long getUnitChargeId() {
		return UnitChargeId;
	}

	public String getName() {
		return name;
	}

	public float getPricePerUnit() {
		return pricePerUnit;
	}

	public String getUnit() {
		return unit;
	}

	public Long getTariffId() {
		return tariffId;
	}

	public Audit getAudit() {
		return audit;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUnitChargeId(Long unitChargeId) {
		UnitChargeId = unitChargeId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPricePerUnit(float pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public void setTariffId(Long tariffId) {
		this.tariffId = tariffId;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}
}
