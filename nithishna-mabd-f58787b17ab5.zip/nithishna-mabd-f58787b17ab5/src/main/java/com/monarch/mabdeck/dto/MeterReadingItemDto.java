package com.monarch.mabdeck.dto;

import java.util.Date;

public class MeterReadingItemDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long meterReadingId;
	private double reading;
	private String method; 
	private String readingDateTime;
	private String createdDate;
	private String createdUser;
	private String type;
	private String approved;
	public Long getMeterReadingId() {
		return meterReadingId;
	}
	public double getReading() {
		return reading;
	}
	public String getMethod() {
		return method;
	}
	public String getReadingDateTime() {
		return readingDateTime;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public String getCreatedUser() {
		return createdUser;
	}
	public String getType() {
		return type;
	}
	public String getApproved() {
		return approved;
	}
	public void setMeterReadingId(Long meterReadingId) {
		this.meterReadingId = meterReadingId;
	}
	public void setReading(double reading) {
		this.reading = reading;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public void setReadingDateTime(String readingDateTime) {
		this.readingDateTime = readingDateTime;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setApproved(String approved) {
		this.approved = approved;
	}

}
