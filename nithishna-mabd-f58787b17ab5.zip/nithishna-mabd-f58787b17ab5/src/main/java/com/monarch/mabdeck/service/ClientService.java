package com.monarch.mabdeck.service;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.monarch.mabdeck.dto.BandDto;
import com.monarch.mabdeck.dto.BankAccountDto;
import com.monarch.mabdeck.dto.ClientDto;
import com.monarch.mabdeck.dto.ClientMetadata;
import com.monarch.mabdeck.dto.CustomerServiceContactDto;
import com.monarch.mabdeck.dto.MainContactDto;
import com.monarch.mabdeck.dto.NetworkDto;
import com.monarch.mabdeck.dto.PropertyDto;
import com.monarch.mabdeck.entity.Address;
import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.Band;
import com.monarch.mabdeck.entity.BankAccount;
import com.monarch.mabdeck.entity.Client;
import com.monarch.mabdeck.entity.CustomerServiceContact;
import com.monarch.mabdeck.entity.MainContact;
import com.monarch.mabdeck.entity.Network;
import com.monarch.mabdeck.entity.Property;
import com.monarch.mabdeck.history.service.ClientHistoryService;
import com.monarch.mabdeck.mapper.BankAccountMapper;
import com.monarch.mabdeck.mapper.ClientMapper;
import com.monarch.mabdeck.mapper.CustomerServiceContactMapper;
import com.monarch.mabdeck.mapper.IBaseMapper;
import com.monarch.mabdeck.mapper.MainContactMapper;
import com.monarch.mabdeck.mapper.NetworkMapper;
import com.monarch.mabdeck.repository.BankAccountRepository;
import com.monarch.mabdeck.repository.BankRepository;
import com.monarch.mabdeck.repository.ClientRepository;
import com.monarch.mabdeck.repository.CustomerServiceContactRepository;
import com.monarch.mabdeck.repository.MainContactRepository;

import javassist.NotFoundException;

@Component
public class ClientService extends CommonServiceImpl<ClientDto, Client> {

	private Logger logger = LoggerFactory.getLogger(ClientService.class);

	@Resource
	private ClientRepository repository;
	
	@Autowired
	private ClientHistoryService historyService;

	@Resource
	private MainContactRepository mainContactRepository;

	@Resource
	private BankAccountRepository bankAccountRepository;

	@Resource
	private BankRepository bankRepository;

	@Resource
	private CustomerServiceContactRepository customerServiceContactRepository;

	@Override
	public JpaRepository<Client, Long> getJPARepository() {
		return repository;
	}

	@Override
	public IBaseMapper<ClientDto, Client> getMapper() {
		return ClientMapper.INSTANCE;
	}

	@Override
	public void updateAudit(Client entity, String username) {
		if(entity != null) {
			this.updateAuditForBankAccount(entity.getBankAccount(), username);
			this.updateAuditForCustomerServiceContact(entity.getCustomerServiceContact(), username);
			this.updateAuditForMainContact(entity.getMainContact(), username);
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			}else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}		
	}
	public List<ClientDto> readAllClientsByHub() {
		List<Client> clients = getJPARepository().findAll();
		List<ClientDto> clientDtos = new ArrayList<>();
		for (Client client : clients) {
			ClientDto dto = this.getClientDtoForEntity(client);
			if (dto != null)
				clientDtos.add(dto);
		}
		return clientDtos;
	}

	private ClientDto getClientDtoForEntity(Client client) {
		ClientDto dto = getMapper().convertToDTO(client);
		List<NetworkDto> networkDtos = new ArrayList<>();
		if (client.getNetwork() == null || client.getNetwork().size() == 0)
			return null;
		for (Network network : client.getNetwork()) {
			if (!network.getHubManufacturer().equalsIgnoreCase("None")) {
				NetworkDto networkDto = NetworkMapper.INSTANCE.convertToDTO(network);
				List<PropertyDto> propertyDtos = new ArrayList<>();
				for (Property property : network.getProperty()) {
					PropertyDto propertyDto = new PropertyDto();
					propertyDto.setPropertyId(property.getPropertyId());
					propertyDto.setName(this.generateName(property.getAddress()));
					propertyDtos.add(propertyDto);
				}
				networkDto.setProperty(propertyDtos);
				networkDtos.add(networkDto);
			}
		}
		dto.setNetwork(networkDtos);
		return dto;
	}

	public ClientDto update(ClientDto dto, String username) {
		Client entity = repository.findOne(dto.getClientId());
		updateAudit(entity, username);
		historyService.updateClientHistory(entity, username);
		Client newEntity = this.getMapper().convertToEntity(dto);
		this.updateClient(entity, newEntity);
		BankAccountDto bankAccount = dto.getBankAccount();
		if (bankAccount != null) {
			if (bankAccount.getId() != null) {
				BankAccount account = bankAccountRepository.getBankAccountById(bankAccount.getId());
				historyService.updateBankAccountHistory(account, username);
				this.updateBankAccount(account, newEntity.getBankAccount());
			} else {
				BankAccount newAccount = bankAccountRepository.saveAndFlush(newEntity.getBankAccount());
				entity.setBankAccount(newAccount);
			}
		}
		MainContactDto newContact = dto.getMainContact();
		if (newContact != null) {
			if (newContact.getId() != null) {
				MainContact contact = mainContactRepository.findOne(newContact.getId());
				historyService.updateMainContactHistory(contact, username);
				this.updateMainContact(contact, newEntity.getMainContact());
			} else {
				MainContact newMainContact = mainContactRepository.saveAndFlush(newEntity.getMainContact());
				entity.setMainContact(newMainContact);
			}
		}
		CustomerServiceContactDto newCustServiceContact = dto.getCustomerServiceContact();
		if (newCustServiceContact != null) {
			if (newCustServiceContact.getCustServiceId() != null) {
				CustomerServiceContact customerServiceContact = customerServiceContactRepository
						.findOne(newCustServiceContact.getCustServiceId());
				historyService.updateCustomerContactHistory(customerServiceContact, username);
				this.updateCustomerServiceContact(customerServiceContact, newEntity.getCustomerServiceContact());
			} else {
				CustomerServiceContact newCustomerServiceContact = customerServiceContactRepository
						.saveAndFlush(newEntity.getCustomerServiceContact());
				entity.setCustomerServiceContact(newCustomerServiceContact);
			}
		}
		return dto;
	}

	private void updateCustomerServiceContact(CustomerServiceContact entity, CustomerServiceContact newEntity) {
		entity.setAddress(newEntity.getAddress());
		entity.setCustServiceId(newEntity.getCustServiceId());
		entity.setEmailAddress(newEntity.getEmailAddress());
		entity.setMainContactNumber(newEntity.getMainContactNumber());
	}

	private void updateBankAccount(BankAccount entity, BankAccount newEntity) {
		entity.setAccountHolderName(newEntity.getAccountHolderName());
		entity.setAccountNumber(newEntity.getAccountNumber());
		entity.setBank(newEntity.getBank());
		entity.setSortCode(newEntity.getSortCode());
	}

	private void updateMainContact(MainContact entity, MainContact newEntity) {
		entity.setAddress(newEntity.getAddress());
		entity.setEmailAddress(newEntity.getEmailAddress());
		entity.setFirstName(newEntity.getFirstName());
		entity.setLandlineNumber(newEntity.getLandlineNumber());
		entity.setLastName(newEntity.getLastName());
		entity.setMobileNumber(newEntity.getMobileNumber());
		entity.setTitle(newEntity.getTitle());
	}

	private void updateClient(Client entity, Client newEntity) {
		entity.setAddress(newEntity.getAddress());
		entity.setClientName(newEntity.getClientName());
		entity.setCompanyNumber(newEntity.getCompanyNumber());
		entity.setCurrency(newEntity.getCurrency());
		entity.setLogo(newEntity.getLogo());
		entity.setPaymentTerm(newEntity.getPaymentTerm());
		entity.setStartDate(newEntity.getStartDate());
		entity.setVatNumber(newEntity.getVatNumber());
	}
	
	public long getCount() {
		return repository.getCount();
	}

	public List<ClientDto> readAllClients(int index, int noOfItems){
		List<ClientDto> dtos = new ArrayList<>();
		int startIndex = 0;
		int endIndex = 0;
		startIndex = (index-1)*noOfItems + 1;
		endIndex = index * noOfItems;
		List<Object[]> clients = this.repository.getAllClientData(startIndex, endIndex);
		for(Object[] client : clients) {
			
			ClientDto dto = new ClientDto();
			if(client[0] != null)
				dto.setClientId(Long.parseLong(client[0].toString()));
			if(client[1] != null)
				dto.setClientName(client[1].toString());
			if(client[2] != null)
				dto.setPaymentTerm(Integer.parseInt(client[2].toString()));
			if(client[3]!=null) {
				Timestamp ts = (Timestamp)client[3];
				dto.setStartDate(new Date(ts.getTime()));
			}
			MainContactDto mainContact = new MainContactDto();
			if(client[4] != null)
				mainContact.setMobileNumber(client[4].toString());
			dto.setMainContact(mainContact);
			if(client[5] != null)
				dto.setNumberOfNetworks(Integer.parseInt(client[5].toString()));
			dtos.add(dto);
		}
		return dtos;
	}	
	
	public ClientDto readById(long clientId) {
		Client client = getJPARepository().findOne(clientId);
		if(client == null)
			return null;
		ClientDto dto = this.getMapper().convertToDTO(client);
		if (client.getBankAccount() != null) {
			BankAccountDto bandAccountDto = BankAccountMapper.INSTANCE.convertToDTO(client.getBankAccount());
			dto.setBankAccount(bandAccountDto);
		}
		if (client.getMainContact() != null) {
			MainContactDto mainContactDto = MainContactMapper.INSTANCE.convertToDTO(client.getMainContact());
			dto.setMainContact(mainContactDto);
		}
		if (client.getCustomerServiceContact() != null) {
			CustomerServiceContactDto customerServiceContactDto = CustomerServiceContactMapper.INSTANCE
					.convertToDTO(client.getCustomerServiceContact());
			dto.setCustomerServiceContact(customerServiceContactDto);
		}
		List<NetworkDto> networkDtos = new ArrayList<>();
		for (Network network : client.getNetwork()) {
			NetworkDto networkDto = new NetworkDto();
			networkDto.setNetworkId(network.getNetworkId());
			networkDto.setNetwork(network.getNetwork());
			List<BandDto> bandDtoList = new ArrayList<>();
			for (Band band : network.getBand()) {
				BandDto bandDto = new BandDto();
				bandDto.setBandId(band.getBandId());
				bandDto.setBandName(band.getBandName());
				bandDtoList.add(bandDto);
			}
			networkDto.setBand(bandDtoList);

			List<PropertyDto> propertyDtos = new ArrayList<>();
			for (Property property : network.getProperty()) {
				PropertyDto propertyDto = new PropertyDto();
				propertyDto.setPropertyId(property.getPropertyId());
				propertyDto.setName(this.generateName(property.getAddress()));
				propertyDtos.add(propertyDto);
			}
			networkDto.setProperty(propertyDtos);
			networkDtos.add(networkDto);
		}
		dto.setNetwork(networkDtos);
		return dto;		
	}

	public List<ClientDto> readAll() throws NotFoundException {
		List<Client> clients = getJPARepository().findAll();
		List<ClientDto> clientDtos = new ArrayList<>();
		for (Client client : clients) {
			ClientDto dto = this.getMapper().convertToDTO(client);
			dto.setNumberOfNetworks(client.getNetwork() != null ? client.getNetwork().size() : 0);

			if (client.getBankAccount() != null) {
				BankAccountDto bandAccountDto = BankAccountMapper.INSTANCE.convertToDTO(client.getBankAccount());
				dto.setBankAccount(bandAccountDto);
			}
			if (client.getMainContact() != null) {
				MainContactDto mainContactDto = MainContactMapper.INSTANCE.convertToDTO(client.getMainContact());
				dto.setMainContact(mainContactDto);
			}
			if (client.getCustomerServiceContact() != null) {
				CustomerServiceContactDto customerServiceContactDto = CustomerServiceContactMapper.INSTANCE
						.convertToDTO(client.getCustomerServiceContact());
				dto.setCustomerServiceContact(customerServiceContactDto);
			}
			List<NetworkDto> networkDtos = new ArrayList<>();
			for (Network network : client.getNetwork()) {
				NetworkDto networkDto = new NetworkDto();
				networkDto.setNetworkId(network.getNetworkId());
				networkDto.setNetwork(network.getNetwork());
				List<BandDto> bandDtoList = new ArrayList<>();
				for (Band band : network.getBand()) {
					BandDto bandDto = new BandDto();
					bandDto.setBandId(band.getBandId());
					bandDto.setBandName(band.getBandName());
					bandDtoList.add(bandDto);
				}
				networkDto.setBand(bandDtoList);

				List<PropertyDto> propertyDtos = new ArrayList<>();
				for (Property property : network.getProperty()) {
					PropertyDto propertyDto = new PropertyDto();
					propertyDto.setPropertyId(property.getPropertyId());
					propertyDto.setName(this.generateName(property.getAddress()));
					propertyDtos.add(propertyDto);
				}
				networkDto.setProperty(propertyDtos);
				networkDtos.add(networkDto);
			}
			dto.setNetwork(networkDtos);
			clientDtos.add(dto);
		}
		return clientDtos;
	}

	public List<NetworkDto> getNetworkForClient(Long clientId) {
		Client client = getJPARepository().findOne(clientId);
		List<NetworkDto> networkDtos = new ArrayList<>();
		if (client.getNetwork() != null && client.getNetwork().size() > 0) {
			for (Network network : client.getNetwork()) {
				NetworkDto networkDto = NetworkMapper.INSTANCE.convertToDTO(network);
				networkDtos.add(networkDto);
			}
		}
		return networkDtos;
	}

	private String generateName(Address address) {
		StringBuilder builder = new StringBuilder();
		if(address != null) {
			if(address.getAddressLine1()!=null && !address.getAddressLine1().equals("")) {
				builder.append(address.getAddressLine1()+", ");
			}
			if(address.getAddressLine2()!=null && !address.getAddressLine2().equals("")) {
				builder.append(address.getAddressLine2()+", ");
			}
			if(address.getAddressLine3()!=null && !address.getAddressLine3().equals("")) {
				builder.append(address.getAddressLine3()+", ");
			}
			if(address.getRegion()!=null && !address.getRegion().equals("")) {
				builder.append(address.getRegion()+", ");
			}
			if(address.getTown()!=null && !address.getTown().equals("")) {
				builder.append(address.getTown()+", ");
			}
			if(address.getCountry()!=null && !address.getCountry().equals("")) {
				builder.append(address.getCountry()+", ");
			}
			if(address.getPostCode()!=null && !address.getPostCode().equals("")) {
				builder.append(address.getPostCode());
			}else {
				builder.setLength(Math.max(builder.length() - 1, 0));
			}
		}
		return builder.toString();
	}

	public List<ClientDto> getAllClientsWithHubManufacturer() {
		List<Client> clients = repository.getAllClientsWithHubManufacturer();
		List<ClientDto> dtos = new ArrayList<>();
		for (Client client : clients) {
			ClientDto dto = new ClientDto();
			dto.setClientId(client.getClientId());
			dto.setClientName(client.getClientName());
			if (client.getNetwork() != null && client.getNetwork().size() > 0) {
				List<NetworkDto> networkDtos = this.convertToNetworkDtoList(client.getNetwork());
				dto.setNetwork(networkDtos);
			}
			dtos.add(dto);
		}
		return dtos;
	}

	public List<NetworkDto> convertToNetworkDtoList(List<Network> entities) {
		List<NetworkDto> dtos = new ArrayList<>();
		for (Network network : entities) {
			if (!network.getHubManufacturer().equalsIgnoreCase("None")) {
				NetworkDto dto = new NetworkDto();
				dto.setNetwork(network.getNetwork());
				dto.setNetworkId(network.getNetworkId());
				dto.setHubManufacturer(network.getHubManufacturer());
				dtos.add(dto);
			}
		}
		return dtos;
	}
	
	private void updateAuditForMainContact(MainContact entity, String username){
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			}else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}
	}
	
	private void updateAuditForCustomerServiceContact(CustomerServiceContact entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			}else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}
	}
	
	private void updateAuditForBankAccount(BankAccount entity, String username) {
		if(entity != null) {
			Calendar cal = Calendar.getInstance();
			if(entity.getAudit() == null) {
				Audit audit = new Audit();
				audit.setCreatedUser(username);
				Date date = new Date(cal.getTime().getTime());
				audit.setCreatedDate(date);
				entity.setAudit(audit);
			}else {
				entity.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				entity.getAudit().setUpdatedUser(username);
			}
		}
	}

	public List<ClientMetadata> getClientMetaData() throws Exception{
		List<ClientMetadata> dtos = new ArrayList<>();
		List<Object[]> entities = repository.getClientMetaData();
		if(entities == null || entities.size() <1)
			return dtos;
		try {
		for(Object[] object : entities) {
			ClientMetadata dto = new ClientMetadata();
			dto.setClientId(Long.parseLong(object[0].toString()));
			dto.setClientName(object[1].toString());
			dtos.add(dto);
		}
		}catch(Exception ex) {
			throw new Exception("Something went wrong. Kindly check with administrator");
		}
		return dtos;
	}
	
	public List<ClientMetadata> getClientsByName(String name) throws Exception{
		List<ClientMetadata> dtos = new ArrayList<>();
		List<Object[]> entities = repository.getClientMetaDataByName(name);
		if(entities == null || entities.size() <1)
			return dtos;
		try {
		for(Object[] object : entities) {
			ClientMetadata dto = new ClientMetadata();
			dto.setClientId(Long.parseLong(object[0].toString()));
			dto.setClientName(object[1].toString());
			dtos.add(dto);
		}
		}catch(Exception ex) {
			throw new Exception("Something went wrong. Kindly check with administrator");
		}
		return dtos;
	}
	
}