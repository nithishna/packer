package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.ReportConfiguration;

@Repository
public interface ReportConfigurationRepository extends JpaRepository<ReportConfiguration, Long>{

	@Query(value="select id, client_name, network, report_name, type, schedule_id, email_ids, offset, period, recursion_type, recursion_offset, hour, minute from\r\n" + 
			"	(select r.id, c.client_name, n.network, r.report_name,t.name as type, s.schedule_id, s.email_ids, s.offset, s.period, s.recursion_type,s.recursion_offset, s.hour, s.minute,\r\n" + 
			"	RowNum = row_number() OVER ( order by r.id)\r\n" + 
			"	from report_configuration r\r\n" + 
			"	inner join client c on c.client_id =r.client_id \r\n" + 
			"	inner join network n on n.network_id = r.network_id \r\n" + 
			"	inner join report_type t on t.id = r.type\r\n" + 
			"	left outer join schedule s on r.schedule_id = s.schedule_id\r\n" + 
			"	where r.deleted=0)t\r\n" + 
			"	where t.RowNum between ?1 and ?2", nativeQuery = true)
	List<Object[]> getConfigurationListByIndex(int start, int end);
}
