package com.monarch.mabdeck.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class ReportConfiguration implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@OneToOne
	@JoinColumn(name = "client_id")
	private Client client;
	
	@OneToOne
	@JoinColumn(name = "network_id")
	private Network network;
	
	@OneToOne
	@JoinColumn(name = "property_id")
	private Property property;
	
	@OneToOne
	@JoinColumn(name = "band_id")
	private Band band;
	
	private boolean isSingleMeter;
	
	@OneToOne
	@JoinColumn(name = "supply_id")
	private SupplyPoint supply;
	
	private String reportName;
	
	private String meterSerialNumber;
	
	@OneToOne
	@JoinColumn(name = "schedule_id", insertable = true, updatable = true)
	private Schedule schedule;
	
	@Embedded
	private Audit audit;
	
	private boolean deleted;
	
	@ManyToOne
	@JoinColumn(name="type")
	private ReportType type;

	public long getId() {
		return id;
	}

	public Client getClient() {
		return client;
	}

	public Network getNetwork() {
		return network;
	}

	public Property getProperty() {
		return property;
	}

	public Band getBand() {
		return band;
	}

	public SupplyPoint getSupply() {
		return supply;
	}

	public String getReportName() {
		return reportName;
	}

	public String getMeterSerialNumber() {
		return meterSerialNumber;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public void setNetwork(Network network) {
		this.network = network;
	}

	public void setProperty(Property property) {
		this.property = property;
	}

	public void setBand(Band band) {
		this.band = band;
	}

	public void setSupply(SupplyPoint supply) {
		this.supply = supply;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public void setMeterSerialNumber(String meterSerialNumber) {
		this.meterSerialNumber = meterSerialNumber;
	}

	public Audit getAudit() {
		return audit;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}

	public boolean isSingleMeter() {
		return isSingleMeter;
	}

	public void setSingleMeter(boolean isSingleMeter) {
		this.isSingleMeter = isSingleMeter;
	}

	public ReportType getType() {
		return type;
	}

	public void setType(ReportType type) {
		this.type = type;
	}

	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}	
}
