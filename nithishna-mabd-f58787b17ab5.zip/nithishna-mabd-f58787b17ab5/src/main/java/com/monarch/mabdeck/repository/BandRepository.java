package com.monarch.mabdeck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.monarch.mabdeck.entity.Band;

@Repository
public interface BandRepository extends JpaRepository<Band, Long>{
	@Query(value="select band_name from band where band_id=?1", nativeQuery = true)
	String getBandNameById(Long bandId);
	
	@Query(value="select * from band where client_id=?1 and network_id=?2", nativeQuery = true)
	List<Band> fetchAllBandForNetworkAndClient(Long clientId, Long networkId);
	
	@Query(value="select band_id, band_name, band_type, start_date, client_id, network_id, number_of_bedroom, property_part1, property_part2, property_unit, end_date, created_date, created_user, updated_date, updated_user \r\n" + 
			"from (SELECT b.*, RowNum = row_number() OVER ( order by b.band_id)  FROM   band b)t\r\n" + 
			"where RowNum between ?1 and ?2", nativeQuery = true)
	List<Band> getAllBandsV2(int startIndex, int endIndex);
	
	@Query(value="select count(*) from band", nativeQuery =true)
	long getCount();
}