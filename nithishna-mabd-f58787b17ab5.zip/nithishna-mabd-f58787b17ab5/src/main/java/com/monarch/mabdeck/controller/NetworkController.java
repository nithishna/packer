package com.monarch.mabdeck.controller;

import java.util.Base64;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.monarch.mabdeck.dto.NetworkDto;
import com.monarch.mabdeck.service.NetworkService;
import com.monarch.mabdeck.util.Constants;

import io.swagger.annotations.ApiParam;
import javassist.NotFoundException;

@RestController
public class NetworkController {
	private Logger logger = LoggerFactory.getLogger(NetworkController.class);

	@Autowired
	private NetworkService NetworkService;

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NETWORK, method = RequestMethod.POST, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void createNetwork(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody NetworkDto Network) {
		logger.info("NetworkController: createNetwork - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("NetworkController: createNetwork - Service call, Username : " + username);
		NetworkService.create(Network, username);
		logger.info("NetworkController: createNetwork - End");
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.FIND_NETWORK_BY_ID, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public @ResponseBody NetworkDto getNetworkById(@PathVariable("Network_id") Long NetworkId)
			throws NotFoundException {
		logger.info("NetworkController: getNetworkById - Start");
		return NetworkService.read(NetworkId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NETWORK_COUNT, method = RequestMethod.GET)
	public long networkCount() {
		return NetworkService.getCount();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NETWORK, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<NetworkDto> getAllNetworks() throws NotFoundException {
		logger.info("NetworkController: getAllNetworks - Start");
		return NetworkService.readAll();
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NETWORKV2, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<NetworkDto> getAllNetworksV2(@RequestParam("index")int index, @RequestParam("size")int pageSize) throws NotFoundException {
		logger.info("NetworkController: getAllNetworks_v2 - Start");
		return NetworkService.readAllByStartIndexAndRange(index, pageSize);
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NETWORKS_BY_DATALOGGERS, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public Set<NetworkDto> getAllNetworkForDataLogger() {
		logger.info("NetworkController: getAllNetworkForDataLogger - Start");
		return NetworkService.getAllNetworkForDataLogger();
	}

	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NETWORK, method = RequestMethod.PUT, consumes = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public void UpdateNetwork(
			@ApiParam(value = "Authorization", required = false) @RequestHeader("Authorization") String authorization,
			@RequestBody NetworkDto Network) {
		logger.info("NetworkController: UpdateNetwork - Start");
		String authToken = authorization.substring("Basic".length()).trim();
		String username = new String(Base64.getDecoder().decode(authToken)).split(":")[0];
		logger.info("NetworkController: UpdateNetwork - Service call, Username : " + username);
		NetworkService.update(Network, username);
		logger.info("NetworkController: UpdateNetwork - End");
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NETWORKS_BY_CLIENT, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<NetworkDto> getAllNetworkForClient(long clientId) throws Exception{
		logger.info("NetworkController: getAllNetworkForClient: ClientID-"+clientId+" - Start");
		return NetworkService.getAllNetworksForClientID(clientId);
	}
	
	@CrossOrigin(origins = "http://fileserver:4200")
	@RequestMapping(path = Constants.NETWORKS_BY_NAME, method = RequestMethod.GET, produces = {
			"application/json; charset=utf-8", "application/xml; charset=utf-8" })
	public List<NetworkDto> getAllNetworksByName(@RequestParam("name") String name){
		logger.info("NetworkController: getAllNetworksByName - Start");
		return NetworkService.getAllNetworksByName(name);
	}
}