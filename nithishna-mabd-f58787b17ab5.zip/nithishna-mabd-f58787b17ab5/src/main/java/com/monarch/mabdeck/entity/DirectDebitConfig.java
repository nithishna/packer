package com.monarch.mabdeck.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class DirectDebitConfig  implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(targetEntity = Client.class, fetch = FetchType.EAGER)
	@JoinColumn(name="clientId",referencedColumnName="clientId", insertable = true, updatable = true)
	private Client client;
	
	@OneToOne
	@JoinColumn(name = "network_id", insertable = true, updatable = true)
	private Network network;
	private long claimOffset;
	private int billingFrequency;
	private String permissiblePaymentDays;
	private int permissibleDirectDebitOptions;
	private boolean transactionsForDirectDebit;
	private boolean directDebitLetter;
	private boolean auddisFile;
	private boolean collectionFile;
	private String emailForLetter;
	private String phoneForLetter;
	public Long getId() {
		return id;
	}
	public Client getClient() {
		return client;
	}
	public Network getNetwork() {
		return network;
	}
	public long getClaimOffset() {
		return claimOffset;
	}
	public int getBillingFrequency() {
		return billingFrequency;
	}
	public String getPermissiblePaymentDays() {
		return permissiblePaymentDays;
	}
	public int getPermissibleDirectDebitOptions() {
		return permissibleDirectDebitOptions;
	}
	public boolean isTransactionsForDirectDebit() {
		return transactionsForDirectDebit;
	}
	public boolean isDirectDebitLetter() {
		return directDebitLetter;
	}
	public boolean isAuddisFile() {
		return auddisFile;
	}
	public boolean isCollectionFile() {
		return collectionFile;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public void setNetwork(Network network) {
		this.network = network;
	}
	public void setClaimOffset(long claimOffset) {
		this.claimOffset = claimOffset;
	}
	public void setBillingFrequency(int billingFrequency) {
		this.billingFrequency = billingFrequency;
	}
	public void setPermissiblePaymentDays(String permissiblePaymentDays) {
		this.permissiblePaymentDays = permissiblePaymentDays;
	}
	public void setPermissibleDirectDebitOptions(int permissibleDirectDebitOptions) {
		this.permissibleDirectDebitOptions = permissibleDirectDebitOptions;
	}
	public void setTransactionsForDirectDebit(boolean transactionsForDirectDebit) {
		this.transactionsForDirectDebit = transactionsForDirectDebit;
	}
	public void setDirectDebitLetter(boolean directDebitLetter) {
		this.directDebitLetter = directDebitLetter;
	}
	public void setAuddisFile(boolean auddisFile) {
		this.auddisFile = auddisFile;
	}
	public void setCollectionFile(boolean collectionFile) {
		this.collectionFile = collectionFile;
	}
	public String getEmailForLetter() {
		return emailForLetter;
	}
	public String getPhoneForLetter() {
		return phoneForLetter;
	}
	public void setEmailForLetter(String emailForLetter) {
		this.emailForLetter = emailForLetter;
	}
	public void setPhoneForLetter(String phoneForLetter) {
		this.phoneForLetter = phoneForLetter;
	}
	
}
