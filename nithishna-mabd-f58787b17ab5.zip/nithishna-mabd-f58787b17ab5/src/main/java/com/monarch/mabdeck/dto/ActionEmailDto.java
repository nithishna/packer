package com.monarch.mabdeck.dto;

public class ActionEmailDto extends ActionDto {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String subject;
	private String body;
	private String emailIds;
	public String getSubject() {
		return subject;
	}
	public String getBody() {
		return body;
	}
	public String getEmailIds() {
		return emailIds;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public void setEmailIds(String emailIds) {
		this.emailIds = emailIds;
	}
}
