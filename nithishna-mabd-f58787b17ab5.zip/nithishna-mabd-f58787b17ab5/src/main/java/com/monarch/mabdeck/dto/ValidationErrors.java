package com.monarch.mabdeck.dto;

public class ValidationErrors implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String clientName;
	private String networkName;
	private String propertyName;
	private String meterSerialNumber;
	private String supplyType;
	private String validationType;
	private long meterReadingId;
	private long validationId;
	public String getClientName() {
		return clientName;
	}
	public String getNetworkName() {
		return networkName;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public String getMeterSerialNumber() {
		return meterSerialNumber;
	}
	public String getSupplyType() {
		return supplyType;
	}
	public String getValidationType() {
		return validationType;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	public void setMeterSerialNumber(String meterSerialNumber) {
		this.meterSerialNumber = meterSerialNumber;
	}
	public void setSupplyType(String supplyType) {
		this.supplyType = supplyType;
	}
	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}
	public long getMeterReadingId() {
		return meterReadingId;
	}
	public void setMeterReadingId(long meterReadingId) {
		this.meterReadingId = meterReadingId;
	}
	public long getValidationId() {
		return validationId;
	}
	public void setValidationId(long validationId) {
		this.validationId = validationId;
	}
	

}
