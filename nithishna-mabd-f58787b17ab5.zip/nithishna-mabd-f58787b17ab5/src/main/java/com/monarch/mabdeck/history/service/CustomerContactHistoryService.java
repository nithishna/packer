package com.monarch.mabdeck.history.service;

import java.sql.Date;
import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.monarch.mabdeck.entity.Audit;
import com.monarch.mabdeck.entity.CustomerServiceContact;
import com.monarch.mabdeck.entity.CustomerServiceContactHistory;
import com.monarch.mabdeck.repository.CustomerServiceContactHistoryRepository;

@Component
public class CustomerContactHistoryService {

	@Resource
	private CustomerServiceContactHistoryRepository historyRepository;
	
	public void updateCustomerServiceContactHistory(CustomerServiceContact contact, String username) {
		if(contact != null) {
			CustomerServiceContactHistory history = new CustomerServiceContactHistory();
			history.setAddress(contact.getAddress());
			history.setAudit(contact.getAudit());
			history.setCustServiceId(contact.getCustServiceId());
			history.setEmailAddress(contact.getEmailAddress());
			history.setMainContactNumber(contact.getMainContactNumber());
			Calendar cal = Calendar.getInstance();
			if(history.getAudit() != null) {
				history.getAudit().setUpdatedDate(new Date(cal.getTime().getTime()));
				history.getAudit().setUpdatedUser(username);
			}else {
				Audit audit = new Audit();
				audit.setUpdatedDate(new Date(cal.getTime().getTime()));
				audit.setUpdatedUser(username);
				history.setAudit(audit);
			}
			historyRepository.saveAndFlush(history);	
		}
	}
}
