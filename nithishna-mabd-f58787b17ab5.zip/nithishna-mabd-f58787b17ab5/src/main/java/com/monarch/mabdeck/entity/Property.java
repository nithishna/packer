package com.monarch.mabdeck.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Property implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long propertyId;

	@ManyToOne(targetEntity = Client.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "clientId", referencedColumnName = "clientId", insertable = true, updatable = true)
	private Client client;

	@ManyToOne(targetEntity = Network.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "networkId", referencedColumnName = "networkId", insertable = true, updatable = true)
	private Network network;

	@ManyToOne(targetEntity = Band.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "bandId", referencedColumnName = "bandId", insertable = true, updatable = true)
	private Band band;

	@OneToMany(mappedBy = "property")
	private List<SupplyPoint> supply;
	
	@OneToMany(mappedBy = "property")
	private List<PropertyAccountAssociation> association;

	@Embedded
	private Address address;

	private String reference;
	private String area;
	
	private float perDayUsage;
	private Date lastBilledDate;

	@Embedded
	private Audit audit;

	public Audit getAudit() {
		return audit;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Network getNetwork() {
		return network;
	}

	public void setNetwork(Network network) {
		this.network = network;
	}

	public Band getBand() {
		return band;
	}

	public void setBand(Band band) {
		this.band = band;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<SupplyPoint> getSupply() {
		return supply;
	}

	public void setSupply(List<SupplyPoint> supply) {
		this.supply = supply;
	}

	public List<PropertyAccountAssociation> getAssociation() {
		return association;
	}

	public void setAssociation(List<PropertyAccountAssociation> association) {
		this.association = association;
	}

	public float getPerDayUsage() {
		return perDayUsage;
	}

	public Date getLastBilledDate() {
		return lastBilledDate;
	}

	public void setPerDayUsage(float perDayUsage) {
		this.perDayUsage = perDayUsage;
	}

	public void setLastBilledDate(Date lastBilledDate) {
		this.lastBilledDate = lastBilledDate;
	}
}
