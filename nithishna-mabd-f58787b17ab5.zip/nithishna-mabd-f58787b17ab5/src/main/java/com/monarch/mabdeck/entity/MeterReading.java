package com.monarch.mabdeck.entity;

import java.util.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class MeterReading implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long meterReadingId;
	
	@ManyToOne(targetEntity = Network.class, fetch = FetchType.EAGER)
	@JoinColumn(name="networkId",referencedColumnName="networkId", insertable = true, updatable = true)
	private Network network;
	
	@ManyToOne(targetEntity = Meter.class, fetch = FetchType.EAGER)
	@JoinColumn(name="meterId",referencedColumnName="meterId", insertable = true, updatable = true)
	private Meter meter;
	private String method;
	private float meterReading;
	private float flowTemperature;
	private float returnTemperature;
	private float instantaneousFlow;
	private float totalVolume;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date readingDateTime;
	private boolean approved;
	private boolean rejected;
	
	@Embedded
	private Audit audit;
	
	public Audit getAudit() {
		return audit;
	}
	public void setAudit(Audit audit) {
		this.audit = audit;
	}
	public Long getMeterReadingId() {
		return meterReadingId;
	}
	public Network getNetwork() {
		return network;
	}
	public Meter getMeter() {
		return meter;
	}
	public String getMethod() {
		return method;
	}
	public float getMeterReading() {
		return meterReading;
	}
	public float getFlowTemperature() {
		return flowTemperature;
	}
	public float getReturnTemperature() {
		return returnTemperature;
	}
	public float getInstantaneousFlow() {
		return instantaneousFlow;
	}
	public float getTotalVolume() {
		return totalVolume;
	}
	public Date getReadingDateTime() {
		return readingDateTime;
	}
	public void setMeterReadingId(Long meterReadingId) {
		this.meterReadingId = meterReadingId;
	}
	public void setNetwork(Network network) {
		this.network = network;
	}
	public void setMeter(Meter meter) {
		this.meter = meter;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public void setMeterReading(float meterReading) {
		this.meterReading = meterReading;
	}
	public void setFlowTemperature(float flowTemperature) {
		this.flowTemperature = flowTemperature;
	}
	public void setReturnTemperature(float returnTemperature) {
		this.returnTemperature = returnTemperature;
	}
	public void setInstantaneousFlow(float instantaneousFlow) {
		this.instantaneousFlow = instantaneousFlow;
	}
	public void setTotalVolume(float totalVolume) {
		this.totalVolume = totalVolume;
	}
	public void setReadingDateTime(Date readingDateTime) {
		this.readingDateTime = readingDateTime;
	}
	public boolean isApproved() {
		return approved;
	}
	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	public boolean isRejected() {
		return rejected;
	}
	public void setRejected(boolean rejected) {
		this.rejected = rejected;
	}
}
