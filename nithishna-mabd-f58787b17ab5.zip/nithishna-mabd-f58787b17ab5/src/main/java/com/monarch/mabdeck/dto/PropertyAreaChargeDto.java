package com.monarch.mabdeck.dto;

public class PropertyAreaChargeDto implements IDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long propertyChargeId;
	
	private String name;
	private float pricePerUnit;
	private String areaUnits;
	private TariffDto tariff;
	public Long getPropertyChargeId() {
		return propertyChargeId;
	}
	public void setPropertyChargeId(Long propertyChargeId) {
		this.propertyChargeId = propertyChargeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(float pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public String getAreaUnits() {
		return areaUnits;
	}
	public void setAreaUnits(String areaUnits) {
		this.areaUnits = areaUnits;
	}
	public TariffDto getTariff() {
		return tariff;
	}
	public void setTariff(TariffDto tariff) {
		this.tariff = tariff;
	}

}
